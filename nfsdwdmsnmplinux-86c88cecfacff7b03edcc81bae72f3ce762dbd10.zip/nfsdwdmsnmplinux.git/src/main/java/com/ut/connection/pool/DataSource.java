package com.ut.connection.pool;
import java.beans.PropertyVetoException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import com.mchange.v2.c3p0.ComboPooledDataSource;

public class DataSource {

    private static DataSource     datasource;
    private ComboPooledDataSource cpds;

    private DataSource() throws IOException, SQLException, PropertyVetoException {
    	Properties snmpSettingsProp = new Properties();
    	String resourceName = "database.properties";
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		try(InputStream resourceStream = loader.getResourceAsStream(resourceName)) {
			snmpSettingsProp.load(resourceStream);
		}
		
        cpds = new ComboPooledDataSource();
        cpds.setDriverClass((String) snmpSettingsProp.get("DriverClass")); //loads the jdbc driver
        cpds.setJdbcUrl((String) snmpSettingsProp.get("JdbcUrl"));
        cpds.setUser((String) snmpSettingsProp.get("User"));
        cpds.setPassword((String) snmpSettingsProp.get("Password"));    
        cpds.setAcquireIncrement(5);
        cpds.setMaxIdleTime(600);
        cpds.setMaxIdleTimeExcessConnections(240);
        cpds.setMaxPoolSize(2000);
        cpds.setMinPoolSize(5);
        cpds.setNumHelperThreads(10);
        cpds.setUnreturnedConnectionTimeout(180);
        cpds.setInitialPoolSize(5);
        cpds.setCheckoutTimeout(30000);
       // cpds.setIdleConnectionTestPeriod(10800);

    }

    public static DataSource getInstance() throws IOException, SQLException, PropertyVetoException {
        if (datasource == null) {
        	synchronized(DataSource.class){
        		 if (datasource == null) {
					datasource = new DataSource();
				}
        	}
        } 
		return datasource;
    }

    public Connection getConnection() throws SQLException {
        return this.cpds.getConnection();
    }

}