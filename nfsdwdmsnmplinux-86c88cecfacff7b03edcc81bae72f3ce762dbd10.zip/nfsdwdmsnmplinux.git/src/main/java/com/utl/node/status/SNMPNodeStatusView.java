package com.utl.node.status;

/*
 * SNMP Trap Test
 *
 * Copyright (C) 2004, Jonathan Sevy <jsevy@mcs.drexel.edu>
 *
 * This is free software. Redistribution and use in source and binary forms, with
 * or without modification, are permitted provided that the following conditions
 * are met:
 *
 *  1. Redistributions of source code must retain the above copyright notice, this
 *     list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright notice,
 *     this list of conditions and the following disclaimer in the documentation 
 *     and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products 
 *     derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR IMPLIED 
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO 
 * EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
 * OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */



import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.net.ServerSocket;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import com.utl.dao.NodeDetails;
import com.utl.dao.ServiceSettings;
import com.utl.dao.service.NodeStatusPoll;
import com.utl.node.status.GetSoftwareType;
import com.ut.connection.pool.DataSource;




public class SNMPNodeStatusView implements Runnable
{
    
    JButton clearButton;
    JTextArea messagesArea;
    String nodeStatusStr;
       
    JScrollPane messagesScroll;
    JTextField hostIDField, communityField, OIDField, valueField, enterpriseField, agentField;
    JLabel authorLabel, hostIDLabel, communityLabel, OIDLabel, valueLabel, enterpriseLabel, agentLabel, genericTrapLabel, specificTrapLabel;
    JComboBox valueTypeBox, genericTrapBox, specificTrapBox;
    
    MenuBar theMenubar;
    Menu fileMenu;
    MenuItem aboutItem, quitItem;
    
    PipedReader errorReader;
    PipedWriter errorWriter;
    Thread readerThread;

    
    
    
    
    // WindowCloseAdapter to catch window close-box closings
    private class WindowCloseAdapter extends WindowAdapter
    { 
        public void windowClosing(WindowEvent e)
        {
            if (readerThread!=null) {
				readerThread.interrupt();
			}
            if(serverSocketObj!=null){
            	try {
					serverSocketObj.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
            }
			System.exit(0);
        }
    };
            
    
    public SNMPNodeStatusView() 
    { 
        try
        {
        	//setIconImage(Toolkit.getDefaultToolkit().getImage(SNMPNodeStatusView.class.getResource("/icons/utl.PNG")));
        	System.setProperty("com.mchange.v2.log.MLog",
    				"com.mchange.v2.log.FallbackMLog");
    		System.setProperty(
    				"com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL",
    				"SEVERE");
           // setUpDisplay();
           /* this.addWindowListener(new WindowAdapter() {
        		public void windowIconified(WindowEvent e){	
        	    	setVisible(false);    	
        	    }
			});*/	
    		System.out.println("==============================================");        	
        	System.out.println("UTL-MP-0072 Spectrum DWDM Node Status Service");
        	System.out.println("==============================================");   
    		
            DataSource.getInstance().getConnection();
            errorReader = new PipedReader();
            errorWriter = new PipedWriter(errorReader);
            
            readerThread = new Thread(this);
            readerThread.setName("SNMPNodeStatusView");
            readerThread.start();
        }
        catch(Exception e)
        {
        /*	JOptionPane.showMessageDialog(this, "Problem starting Node Status Poll "+e.toString(), "DWDM 10G Node Status Poll", JOptionPane.WARNING_MESSAGE);
            messagesArea.append("Problem starting Node Status Poll:" + e.toString() + "\n");
            System.exit(0);*/
        }
    }
    
    
    
    private void setUpDisplay()
    {   
     /*   this.setTitle("UTL - MP - 0072 Spectrum DWDM Node Status Service");
            
        this.getRootPane().setBorder(new BevelBorder(BevelBorder.RAISED));*/
        
        // set fonts to smaller-than-normal size, for compaction!
        /*
        FontUIResource appFont = new FontUIResource("SansSerif", Font.PLAIN, 10);
        UIDefaults defaults = UIManager.getLookAndFeelDefaults();
        Enumeration keys = defaults.keys();
        
        while (keys.hasMoreElements())
        {
            String nextKey = (String)(keys.nextElement());
            if ((nextKey.indexOf("font") > -1) || (nextKey.indexOf("Font") > -1))
            {
                UIManager.put(nextKey, appFont);
            }
        }
        */
        
        
        // add WindowCloseAdapter to catch window close-box closings
        /*addWindowListener(new WindowCloseAdapter());

        
        theMenubar = new MenuBar();
        this.setMenuBar(theMenubar);
        fileMenu = new Menu("File");
        
        aboutItem = new MenuItem("About...");
        aboutItem.setActionCommand("about");
        aboutItem.addActionListener(this);
        //fileMenu.add(aboutItem);
        
        fileMenu.addSeparator();
        
        quitItem = new MenuItem("Quit");
        quitItem.setActionCommand("quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);
        
        theMenubar.add(fileMenu);
        
        
        authorLabel = new JLabel(" Version 1.0");
        authorLabel.setFont(new Font("SansSerif", Font.ITALIC,12));
            
        
        clearButton = new JButton("Clear messages");
        clearButton.setActionCommand("clear messages");
        clearButton.addActionListener(this);
        
        messagesArea = new JTextArea(10,60);
        messagesScroll = new JScrollPane(messagesArea);
        
        
        // now set up display
        
        // set params for layout manager
        GridBagLayout  theLayout = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.ipadx = 0;
        c.ipady = 0;
        c.insets = new Insets(2,2,2,2);
        c.anchor = GridBagConstraints.CENTER;
        c.weightx = 0;
        c.weighty = 0; 
               
        
        JPanel messagesPanel = new JPanel();
        messagesPanel.setLayout(theLayout);
        
        c.gridx = 1;
        c.gridy = 1;
        c.anchor = GridBagConstraints.WEST;
        JLabel messagesLabel = new JLabel("Node Status:");
        theLayout.setConstraints(messagesLabel, c);
        messagesPanel.add(messagesLabel);
        
        c.gridx = 2;
        c.gridy = 1;
        c.anchor = GridBagConstraints.EAST;
        theLayout.setConstraints(clearButton, c);
        messagesPanel.add(clearButton);
        
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 2;
        c.weightx = .5;
        c.weighty = .5;
        c.anchor = GridBagConstraints.CENTER;
        theLayout.setConstraints(messagesScroll, c);
        messagesPanel.add(messagesScroll);
        
        
        c.gridwidth = 1;
        c.weightx = 0;
        c.weighty = 0;
        
        
        
        this.getContentPane().setLayout(theLayout);
        
        
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        theLayout.setConstraints(messagesPanel, c);
        this.getContentPane().add(messagesPanel);
        
        c.fill = GridBagConstraints.NONE;
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0;
        c.weighty = 0;
        theLayout.setConstraints(authorLabel, c);
        this.getContentPane().add(authorLabel);*/
        
        
    }
    
    
    
    
    
    public void actionPerformed(ActionEvent theEvent)
    // respond to button pushes, menu selections
    {
        String command = theEvent.getActionCommand();
        
    
        if (command == "quit")
        {
            readerThread.interrupt();
            System.exit(0);
        }
        
        
        
        if (command == "clear messages")
        {
            messagesArea.setText("");
        }
        
        
        
        if (command == "about")
        {
            //AboutDialog aboutDialog = new AboutDialog(this);
        }
        
              
    }
   /* private final static byte THREAD_POOL_SIZE=50;//if ems change 20 to 50
    private  static long patience = 60000 * 60 * 1;//if ems change time to 60000
*/    
    
    private final static byte THREAD_POOL_SIZE=20;//if ems change 20 to 50
    private  static long patience = 1000 * 60 * 1;//if ems change time to 60000
    
    public void run()
    {
       try{
    	   Date date;
    	   short temp=0;
    	   while (true) {
				try {
					short nodeTime=1;
					try {
						short intervals[]=ServiceSettings.getServiceSettings();
						nodeTime = intervals[0];
					} catch (Exception e) {
					}
					patience = 1000 * 60 * nodeTime;
		    		long startTime = System.currentTimeMillis();
					date=new Date();
					temp++;
		    		   if(temp>10){
		    			   temp=0;
		    			   //messagesArea.setText("");
		    				  System.out.println("");
		    		   }
		    		   //messagesArea.append("Polling start at "+date.toString());
		    		  // messagesArea.append("\n");
		    			  System.out.println("\n");
		    	
		    		int  strGNeType  = 1;
					List<String> allNodeIPlist = NodeDetails
							.getAllNodeIPAddresses();
					
					Collection<Future<?>> futures = new LinkedList<Future<?>>();
					for (String nodeIP : allNodeIPlist) {
						if (!"0.0.0.0".equals(nodeIP.trim())) {
							NodeStatusPoll statusPoll = new NodeStatusPoll(
									nodeIP,nodeStatusStr);
							futures.add(executorServiceObj.submit(statusPoll));
						}
					}
				
					for (Future<?> future:futures) {
					    future.get();
					}
					//messagesArea.append("Task Count "+executorServiceObj.getTaskCount()+" Completed Task"+executorServiceObj.getCompletedTaskCount()+" \n");
					//make thread sleep
					long executionTime = System.currentTimeMillis() - startTime;
	    			if (executionTime< patience) {
	    				try {
	    					long threadSleepTime=patience-executionTime;
	    					//messagesArea.append("thread sleep time: "+threadSleepTime+" \n");
	    					Thread.sleep(threadSleepTime);
	    				} catch (InterruptedException e) {
	    					e.printStackTrace();
	    				}
	    			}
					date=new Date();
					//messagesArea.append("Polling end at "+date.toString());
					//messagesArea.append("\n\n");
					  System.out.println("\n\n");
				} catch (Exception e) {
					e.printStackTrace();
				}
		}
       }catch(Exception e){
    	   e.printStackTrace();
       }
    }
    
    static ThreadPoolExecutor executorServiceObj=null;
    static ServerSocket serverSocketObj=null;
    public static void main(String args[]) 
    {
        try
        {
        	/*String softwareType=null;
			try {
				softwareType = GetSoftwareType.getType();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,e.getMessage(),"Node Status Service", JOptionPane.ERROR_MESSAGE);
	        	System.exit(0);
			}*/
			serverSocketObj=new ServerSocket(9991); 
        	executorServiceObj = (ThreadPoolExecutor) Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        	SNMPNodeStatusView snmpNodeStatusViewObj = new SNMPNodeStatusView();
        	//snmpNodeStatusViewObj.pack();
        	//snmpNodeStatusViewObj.setSize(700,500);
        
       
        //	System.out.println(softwareType);
        /*	if("u/system/t/management/l/element".equals(softwareType)){
        //		System.out.println(softwareType);
            	snmpNodeStatusViewObj.setVisible(true);
        	}else{
        		
        		TrayIconForSNMPNodeStatusService trayIcon=new TrayIconForSNMPNodeStatusService();
            	trayIcon.createAndShowTrayIcon(snmpNodeStatusViewObj);
            	snmpNodeStatusViewObj.setVisible(false);
        	}*/
        }catch (IOException e) {
        	//JOptionPane.showMessageDialog(null, "Node Status Service already running..",e.getMessage(), JOptionPane.ERROR_MESSAGE);
        	  System.out.println("Node Status Service already running..");
        	System.exit(0);
        }
        catch (Exception e)
        {
        	//JOptionPane.showMessageDialog(null,e.getMessage(), "Node Status Service", JOptionPane.ERROR_MESSAGE);
        	  System.out.println("Node Status Service.");
        	System.exit(0);
        }
    }
    
}