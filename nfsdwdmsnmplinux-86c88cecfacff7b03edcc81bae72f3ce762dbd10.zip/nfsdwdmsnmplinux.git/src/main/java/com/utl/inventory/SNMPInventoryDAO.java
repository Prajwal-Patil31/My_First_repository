package com.utl.inventory;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ut.connection.pool.DataSource;
import com.utl.util.StringArray;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.DBConnection;

public class SNMPInventoryDAO {
	static SNMPVersionDetails userDetails;
	public static List<List<String>>  getPerformanceCards(long nodeDetailsID) throws Exception{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<List<String>> dwdmMasterDetailsAll=new ArrayList<List<String>>();
		try {
			conn=DataSource.getInstance().getConnection();
			ps=conn.prepareStatement("SELECT slot.dwdm_slot_master_id,slot.card_name,dwdm_port_master_id,traffic_name,rack.rack_number,subrack.subrack_number,slot.slot_number,portm.port_number,portm.port_traffic_type,portm.port_client_line_type FROM node_details node left outer join dwdm_rack_master rack on node.node_details_id=rack.node_details_id left outer join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id left outer join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id left outer join dwdm_port_master portm on slot.dwdm_slot_master_id=portm.dwdm_slot_master_id left outer join dwdm_port_traffic_name traffic on portm.port_traffic_type=traffic.dwdm_port_traffic_name_id where node.node_details_id=? and slot.card_name in ('OPA1PLUS','OPA2PLUS','OPA3PLUS','OPA4PLUS','OBA1PLUS','OBA2PLUS','OBA3PLUS','OBA4PLUS','OLA1PLUS','OLA2PLUS','OLA3PLUS','OLA4PLUS','10GOMTP12PLUS','10GOMTP11PLUS','10GOMTP11TPLUS','10GOMMP81PLUS','10GOMMP82PLUS')");
			ps.setLong(1,nodeDetailsID);
			rs=ps.executeQuery();
			List<String> dwdmMasterDetailsEach;
			while(rs.next()){
					dwdmMasterDetailsEach=new ArrayList<String>();
					dwdmMasterDetailsEach.add(rs.getString("dwdm_slot_master_id"));
					dwdmMasterDetailsEach.add(rs.getString("card_name"));
					dwdmMasterDetailsEach.add(rs.getString("dwdm_port_master_id"));
					dwdmMasterDetailsEach.add(rs.getString("traffic_name"));
					dwdmMasterDetailsEach.add(rs.getString("rack_number"));
					dwdmMasterDetailsEach.add(rs.getString("subrack_number"));
					dwdmMasterDetailsEach.add(rs.getString("slot_number"));
					dwdmMasterDetailsEach.add(rs.getString("port_number"));
					dwdmMasterDetailsEach.add(rs.getString("port_traffic_type"));
					dwdmMasterDetailsEach.add(rs.getString("port_client_line_type"));
					dwdmMasterDetailsAll.add(dwdmMasterDetailsEach);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(ps!=null){
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return dwdmMasterDetailsAll;
	}
	
	public static String[][] getCardInventoryBasedOnNodeIPAddress(
			 int nodeID) throws Exception {
		Connection conn = null;
		CallableStatement callable = null;
		ResultSet rs = null;
		String[][] strForCardInventory = null;
		ArrayList<ArrayList<String>> alForCardInventory = new ArrayList<ArrayList<String>>();
		ArrayList<String> al = null;
		PreparedStatement pst=null;
		try {
			//conn = DBConnection.getMYSQLDBConn();
			conn = DataSource.getInstance().getConnection();
			pst=conn.prepareStatement("select card_name,rack_number,subrack_number,slot_number,node_ip_address,dwdm_slot_master_id,nd.node_details_id from dwdm_slot_master dsm,dwdm_subrack_master dsrm,dwdm_rack_master drm,node_details nd where dsm.dwdm_subrack_master_id=dsrm.dwdm_subrack_master_id and dsrm.dwdm_rack_master_id=drm.dwdm_rack_master_id and drm.node_details_id=nd.node_details_id and card_name!='MCB' and card_name!='MCBONON' and card_name!='MCBONOFF' and card_name!='NO' and card_name!='FIM1' and card_name!='FIM2' and card_name!='FIM3' and card_name!='PSU-1' and card_name!='PSU-2' and card_name!='BUZZER' and card_name!='BUZZER_OFF' and card_name!='BUZZER_ON' and card_name!='BUZZER_MUTE' and nd.node_details_id=? and card_status!='removed';");
			pst.setInt(1, nodeID);		
			rs=pst.executeQuery();
				while (rs.next()) {
				  al=new ArrayList<String>();
				  Short nodeNumber=1;
				  short rackNumber=Short.parseShort(rs.getString("rack_number"));
				  short subrackNumber=Short.parseShort(rs.getString("subrack_number"));
				  short slotNumber=Short.parseShort(rs.getString("slot_number"));
				  short slotMasterId= Short.parseShort(rs.getString("dwdm_slot_master_id"));
				  short nodedetailsId= Short.parseShort(rs.getString("node_details_id"));
				  
				  short cardID=0;
				  short serialID=0;
				  short softwareID=0;
				  short hardwareID=0;
				  short partCodeID=0;
				  byte portNumber=0;
				  short directionNumber=0;
				  short portType=0;
				  short channelNumber=0;
				  byte interfaceNumber=0;
				  String cardName=rs.getString("card_name");
				  String nodeIP=rs.getString("node_ip_address");
				 // CurrentUserDetailsBean userDetails=CurrentUserBeanPermissions.getUserBeanObject();			  
				  al.add(cardName);
	    		  //al.add(rs.getString("rackNumber"));
	    		  al.add(rs.getString("subrack_number"));
	    		  al.add(rs.getString("slot_number"));
	    		 
	    		  if(cardName.equals("demux_plus"))
	    		  {
	    			  cardName="DEMUXPLUS";
	    		  }
	    		  if(cardName.equals("demux"))
	    		  {
	    			  cardName="DEMUX";
	    		  }
	    		  if(cardName.equals("mux_plus"))
	    		  {
	    			  cardName="MUXPLUS";
	    		  }
	    		  if(cardName.equals("mux"))
	    		  {
	    			  cardName="MUX";
	    		  }
		    		  switch(cardName){
		    		  case "10GOMMP82":
		    		  	  cardID=14;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "10GOMMP82PLUS":
		    			  cardID=87;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "10GOMMP81":
		    		  	  cardID=6;
			    		  serialID=10;
			    		  softwareID=12;
			    		  hardwareID=14;
			    		  break;
		    		  case "10GOMMP81PLUS":
		    			  cardID=86;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "10GOMTP11":
		    		  	  cardID=7;
			    		  serialID=16;
			    		  softwareID=14;
			    		  hardwareID=17;
			    		  break;
		    		  case "10GOMTP11PLUS":
		    			  cardID=71;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "10GOMTP11TPLUS":
		    		  	  cardID=72;
		    		  	partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "10GOMTP12":
		    		  	  cardID=13;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "10GOMTP12PLUS":
		    			  cardID=73;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "OMMP100":
		    			  cardID=88;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;		    		  
		    		  case "OMMP400":
		    			  cardID=90;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
			    		  
		    		  case "BMU":
		    		  	  cardID=8;
			    		  serialID=1;
			    		  softwareID=2;
			    		  hardwareID=3;
			    		  interfaceNumber=1;
			    		  break;
		    		  case "BMUPLUS":
		    			  cardID=46;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  interfaceNumber=1;
			    		  break;
		    		  case "SCU":
		    		  	  cardID=9;
			    		  serialID=1;
			    		  softwareID=2;
			    		  hardwareID=3;
			    		  break;
		    		  case "SCUPLUS":
		    			  cardID=51;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "SCC":
		    		  case "SCCPLUS":
		    			  cardID=1;
		    			  partCodeID=13;
			    		  serialID=14;
			    		  softwareID=16;
			    		  hardwareID=15;
			    		  break;
		    		  case "MD-ROADM-DIR-1":	    			
		    		  case "MD-ROADM-DIR-2":
		    		  case "MD-ROADM-DIR-3":
		    		  case "MD-ROADM-DIR-4":
		    			  cardID=2;	    			
			    		  serialID=7;
			    		  softwareID=9;
			    		  hardwareID=8;
			    		  directionNumber=1;
			    		  portType=2;
			    		  channelNumber=0;
			    		  break;
		    		  case "MD-ROADMPLUS-DIR-1":	    			
		    		  case "MD-ROADMPLUS-DIR-2":
		    		  case "MD-ROADMPLUS-DIR-3":
		    		  case "MD-ROADMPLUS-DIR-4":
		    			  cardID=191;
		    			  partCodeID=6;
			    		  serialID=7;
			    		  softwareID=9;
			    		  hardwareID=8;
			    		  directionNumber=0;
			    		  portType=0;
			    		  channelNumber=0;
			    		  break;
		    		  case "OBA1":
		    		  case "OBA2":
		    		  case "OBA3":	    		  
		    		  	  cardID=3;
			    		  serialID=4;
			    		  softwareID=6;
			    		  hardwareID=5;
			    		  break;
		    		  case "OBA1PLUS":
		    		  case "OBA2PLUS":
		    		  case "OBA3PLUS":
		    		  case "OBA4PLUS":
		    			  cardID=131;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;		 		    		  
		    		  case "OPA1":
		    		  case "OPA2":
		    		  case "OPA3":
		    		  	  cardID=4;
			    		  serialID=4;
			    		  softwareID=6;
			    		  hardwareID=5;
			    		  break;	
		    		  case "OPA1PLUS":
		    		  case "OPA2PLUS":
		    		  case "OPA3PLUS":
		    		  case "OPA4PLUS":
		    			  cardID=141;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;	    	
		    		  case "OLA1":
		    		  case "OLA2":
		    		  	  cardID=5;
			    		  serialID=4;
			    		  softwareID=6;
			    		  hardwareID=5;
			    		  break;
		    		  case "OLA1PLUS":
		    		  case "OLA2PLUS":
		    		  case "OLA3PLUS":
		    		  case "OLA4PLUS":
		    			  cardID=151;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "DEMUX1PLUS":
		    		  case "DEMUX2PLUS":
		    		  case "DEMUX3PLUS":
		    		  case "DEMUX4PLUS":
		    			  cardID=181;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  case "MUX1PLUS":
		    		  case "MUX2PLUS":
		    		  case "MUX3PLUS":
		    		  case "MUX4PLUS":
		    			  cardID=171;
		    			  partCodeID=4;
			    		  serialID=5;
			    		  softwareID=7;
			    		  hardwareID=6;
			    		  break;
		    		  }
		    		  
		    		  	 // System.out.println("CArsd:"+cardName);
		    		  if(cardName.equals("DEMUX1")||cardName.equals("DEMUX1PLUS")||cardName.equals("DEMUX2")||cardName.equals("DEMUX2PLUS")||cardName.equals("DEMUX3")||cardName.equals("DEMUX3PLUS")||cardName.equals("DEMUX4")||cardName.equals("DEMUX4PLUS")||cardName.equals("MUX1PLUS")|| cardName.equals("MUX2PLUS") ||cardName.equals("MUX3PLUS") ||cardName.equals("MUX4PLUS")||cardName.equals("MUX1")||cardName.equals("MUX2")||cardName.equals("MUX3")||cardName.equals("MUX4")||cardName.equals("SCC")||cardName.equals("SCU")||cardName.equals("BMU")||cardName.equals("10GOMMP82")||cardName.equals("10GOMMP81")||cardName.equals("10GOMTP11")||cardName.equals("10GOMTP12")||cardName.substring(0,3).equals("OPA")||cardName.substring(0,3).equals("OBA")||cardName.substring(0,3).equals("OLA")||cardName.equals("MD-ROADM-DIR-1")||cardName.equals("MD-ROADM-DIR-2")||cardName.equals("MD-ROADM-DIR-3")||cardName.equals("MD-ROADM-DIR-4")||cardName.equals("MD-ROADMPLUS-DIR-1")||cardName.equals("MD-ROADMPLUS-DIR-2")||cardName.equals("MD-ROADMPLUS-DIR-3")||cardName.equals("MD-ROADMPLUS-DIR-4") || cardName.equals("SCCPLUS")||cardName.equals("SCUPLUS")||cardName.equals("BMUPLUS")||cardName.equals("10GOMMP82PLUS")||cardName.equals("10GOMMP81PLUS")||cardName.equals("10GOMTP11PLUS")||cardName.equals("10GOMTP11TPLUS")||cardName.equals("10GOMTP12PLUS"))
		    		  {
		    			 
		    			 
		        		  
			    		  if(cardName.equals("MD-ROADM-DIR-1")||cardName.equals("MD-ROADM-DIR-2")||cardName.equals("MD-ROADM-DIR-3")||cardName.equals("MD-ROADM-DIR-4"))
			    		  {
			    			  al.add(SNMPInventoryBL.getMDRoadmSoftwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,softwareID));
			    			  al.add(SNMPInventoryBL.getMDRoadmHardwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,hardwareID));
			    			  al.add(SNMPInventoryBL.getMDRoadmCardSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,serialID));  
			    		  }
			    		  
			    		 
			    		  else if(cardName.equals("MD-ROADMPLUS-DIR-1")||cardName.equals("MD-ROADMPLUS-DIR-2")||cardName.equals("MD-ROADMPLUS-DIR-3")||cardName.equals("MD-ROADMPLUS-DIR-4"))
			    		  {
			    			 // System.out.println("card Name11111111" +cardName);
			    			  al.add(SNMPInventoryBL.getMDRoadmplusSoftwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,softwareID));
			    			  al.add(SNMPInventoryBL.getMDRoadmplusHardwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,hardwareID));
			    			  al.add(SNMPInventoryBL.getMDRoadmplusCardSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,serialID));  
			    			  al.add(SNMPInventoryBL.getMDRoadmplusCardPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber,directionNumber,portType,channelNumber, nodeIP, userDetails,cardID,partCodeID));  //Added PartCode for Inventory
			    		  }
			    		  else
			    		  {
			    			 if(cardName.equals("SCC")||cardName.equals("10GOMMP81")||cardName.equals("10GOMMP82")||cardName.equals("10GOMTP11")||cardName.equals("10GOMTP12")||cardName.equals("SCCPLUS")||cardName.equals("10GOMMP81PLUS")||cardName.equals("10GOMMP82PLUS")||cardName.equals("10GOMTP11PLUS")||cardName.equals("10GOMTP12PLUS")||cardName.equals("10GOMTP11T")||cardName.equals("10GOMTP11TPLUS") ||cardName.equals("OMMP100")||cardName.equals("OMMP400"))
			    			 {
			    				  al.add(SNMPInventoryBL.getSoftwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, userDetails,cardID,softwareID));
			    				  al.add(SNMPInventoryBL.getHardwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, userDetails,cardID,hardwareID));
			    				  al.add(SNMPInventoryBL.getCardSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, userDetails,cardID,serialID));
			    				  al.add(SNMPInventoryBL.getCardPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, userDetails,cardID,partCodeID));
			    				  
			    			 }
			    			 else if (cardName.equals("BMU")||cardName.equals("SCU")){
			    				  al.add(SNMPInventoryBL.getAmplifierSoftwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,softwareID));
					    		  al.add(SNMPInventoryBL.getAmplifierHardwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,hardwareID));
					    		  al.add(SNMPInventoryBL.getAmplifierCardSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,serialID));				    		  
			    			 }
			    			 else
			    			 {
			    				  al.add(SNMPInventoryBL.getAmplifierPlusSoftwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,softwareID));
					    		  al.add(SNMPInventoryBL.getAmplifierPlusHardwareVersion(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,hardwareID));
				    			  al.add(SNMPInventoryBL.getAmplifierPlusCardSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,serialID)); 
				    			  al.add(SNMPInventoryBL.getAmplifierPlusCardPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber,nodeIP, userDetails,cardID,partCodeID)); 
			    			 }
			    		  }		    	
			    		  al.add(rs.getString("dwdm_slot_master_id"));
			    		  al.add(rs.getString("node_details_id"));
			    		  
		    		  }
		    		  else
		    		  {
		    			  	 al.add("0.0"); 
		    			  	 al.add("0.0");
		    			  	 al.add("0.0");
		    			  	// al.add("0.0");
		    			  	 
		    			  	 
		    		  }
//		    		  al.add(rs.getString("card_legacy"));	 
		    		  alForCardInventory.add(al);
				}				
				// Check for next result set
				//results = callable.getMoreResults();
			//}
			if (alForCardInventory.size() != 0) {
				strForCardInventory = new String[alForCardInventory.size()][alForCardInventory.get(0).size()];
				for (int i = 0; i < alForCardInventory.size(); i++) {
					ArrayList<String> list = alForCardInventory.get(i);
					for (int j = 0; j < list.size(); j++) {
						strForCardInventory[i][j] = list.get(j);		
						//System.out.println("strForCardInventory" + strForCardInventory[i][j] +"&&&&&&&&&&&&&&------------");
					}
				}
				//System.out.println("strForCardInventory" + strForCardInventory +"&&&&&&&&&&&&&&&&&&------------");
			}
		} catch (ClassNotFoundException | SQLException | IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (callable != null) {
					callable.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		return strForCardInventory;
	}
	
///////////////
	public static String updateCardSerialNumberDetails( String nodeid,String cardSerialnumber,String slotmasterid,List<StringArray> lLiveAlarms, String softwareVersion, String hardwareVersion, String  cardName,String subrackNumber,String strSlotNumber,String cardAddress, String cardPartCode)throws Exception {
	Connection conn = null;
	PreparedStatement psForAddCardInventoryDetails = null;	
	PreparedStatement psForUpdateCardInventoryDetails = null;
	PreparedStatement psForGetCardInventoryDetails = null;	
	ResultSet rsForGetCardInventoryDetails = null;	
	String resultType="not success";
	String rackNumber = "1";
	StringBuffer sbCardAddress;
	int slotID;
	int nodeID;
	String strCardPartCode;
	String sqlQueryForAddCardInventoryDetails="INSERT INTO `dwdm_card_history`(`card_software_version`,`card_hardware_version`,`card_serial_number`,`card_name`,`card_address`,`card_part_code`,`dwdm_slot_master_id`,node_details_id)VALUES(?,?,?,?,?,?,?,?)";
	String sqlQueryForUpdateCardInventoryDetails="update dwdm_card_history set card_software_version=?,card_hardware_version=?,card_serial_number=?,card_name=?,card_address=?,card_part_code=?,dwdm_slot_master_id=?,node_details_id=? where dwdm_card_history_id=?";
	String sqlQueryForGetCardInventoryDetails="SELECT * FROM dwdm_card_history where dwdm_slot_master_id=?";
	
	try {
		conn = DataSource.getInstance().getConnection();	
	for (int i = 0; i < lLiveAlarms.size(); i++) {
			ArrayList<String> tempLiveAlarms;				
			tempLiveAlarms=new ArrayList<String>();				
			tempLiveAlarms.add(""+(i+1));				
			StringArray saLiveAlarms = lLiveAlarms.get(i);				
			List<String> lEachLiveAlarmDetails = saLiveAlarms.getItem();
			cardName = lEachLiveAlarmDetails.get(0);
			subrackNumber = lEachLiveAlarmDetails.get(1);
			strSlotNumber = lEachLiveAlarmDetails.get(2);
			softwareVersion = lEachLiveAlarmDetails.get(3);
			if (softwareVersion.length() == 5)
				softwareVersion = softwareVersion.substring(0, softwareVersion.length() - 2);
			
			
			hardwareVersion = lEachLiveAlarmDetails.get(4);		
			cardSerialnumber = lEachLiveAlarmDetails.get(5);	
			cardPartCode = lEachLiveAlarmDetails.get(6);	
			strCardPartCode = removeAfter(cardPartCode);
			strCardPartCode = strCardPartCode.replace("#", "");
			slotmasterid = lEachLiveAlarmDetails.get(7);	
			nodeid = lEachLiveAlarmDetails.get(8);
			psForGetCardInventoryDetails=conn.prepareStatement(sqlQueryForGetCardInventoryDetails);			
			psForGetCardInventoryDetails.setString(1,slotmasterid);
			rsForGetCardInventoryDetails=psForGetCardInventoryDetails.executeQuery();
			int rowCount = 0;
			if (rsForGetCardInventoryDetails.last()) {
				rowCount = rsForGetCardInventoryDetails.getRow();
				rsForGetCardInventoryDetails.beforeFirst();
			}
			if(rsForGetCardInventoryDetails.next()){
				int cardHistoryId=rsForGetCardInventoryDetails.getInt(1);
				psForUpdateCardInventoryDetails = conn.prepareStatement(sqlQueryForUpdateCardInventoryDetails);	
				psForUpdateCardInventoryDetails.setString(1,softwareVersion);
				psForUpdateCardInventoryDetails.setString(2,hardwareVersion);
				psForUpdateCardInventoryDetails.setString(3,cardSerialnumber);
				psForUpdateCardInventoryDetails.setString(4,cardName);
				sbCardAddress=new StringBuffer("Rack="+rackNumber).append("/").append("Shelf="+subrackNumber).append("/").append("Slot="+strSlotNumber);
				cardAddress = sbCardAddress.toString();
				psForUpdateCardInventoryDetails.setString(5,cardAddress);
				psForUpdateCardInventoryDetails.setString(6,strCardPartCode);
				psForUpdateCardInventoryDetails.setString(7,slotmasterid);	
				psForUpdateCardInventoryDetails.setString(8,nodeid);
				psForUpdateCardInventoryDetails.setInt(9,cardHistoryId);
				int result=psForUpdateCardInventoryDetails.executeUpdate();
				if(result==1){
					resultType="success";
				}		
			}				
			else{					
				psForAddCardInventoryDetails = conn.prepareStatement(sqlQueryForAddCardInventoryDetails);
				psForAddCardInventoryDetails.setString(1,softwareVersion);
				psForAddCardInventoryDetails.setString(2,hardwareVersion);
				psForAddCardInventoryDetails.setString(3,cardSerialnumber);
				psForAddCardInventoryDetails.setString(4,cardName);
				sbCardAddress=new StringBuffer("Rack="+rackNumber).append("/").append("Shelf="+subrackNumber).append("/").append("Slot="+strSlotNumber);
				cardAddress = sbCardAddress.toString();
				psForAddCardInventoryDetails.setString(5,cardAddress);	
				psForAddCardInventoryDetails.setString(6,strCardPartCode);	
				psForAddCardInventoryDetails.setString(7,slotmasterid);		
				psForAddCardInventoryDetails.setString(8,nodeid);
				int result=psForAddCardInventoryDetails.executeUpdate();	
				if(result==1){
					resultType="success";
				}	
			}
	}
	} catch (SQLException | IOException e) {
	e.printStackTrace();
	throw e;
	} finally {
	try {
		if (rsForGetCardInventoryDetails != null) {
			rsForGetCardInventoryDetails.close();
		}	if (psForGetCardInventoryDetails != null) {
			psForGetCardInventoryDetails.close();
		}
		if (psForAddCardInventoryDetails != null) {
			psForAddCardInventoryDetails.close();
		}
		if (conn != null) {
			conn.close();
		}
	} catch (SQLException e) {
		e.printStackTrace();
	}
	}
	return resultType;
	}
	
	private static String removeAfter(String input) {
	    int index = input.indexOf("10");
	    if (index == -1) {
	        index = input.indexOf("20");
	    }
	    if (index != -1) {
	        return input.substring(0, index + 2);
	    }
	    return input;
	}
	

public static String[][] getCardAndPortInventoryBasedOnNodeIPAddress(
		 int nodeID) throws Exception {
	Connection conn = null;
	CallableStatement callable = null;
	ResultSet rs = null;
	String[][] strForCardInventory = null;
	ArrayList<ArrayList<String>> alForCardInventory = new ArrayList<ArrayList<String>>();
	ArrayList<String> al = null;
	PreparedStatement pst=null;
	try {
		conn = DataSource.getInstance().getConnection();	
		//pst=conn.prepareStatement("select card_name,rack_number,subrack_number,slot_number,node_ip_address,dwdm_slot_master_id,nd.node_details_id from dwdm_slot_master dsm,dwdm_subrack_master dsrm,dwdm_rack_master drm,node_details nd where dsm.dwdm_subrack_master_id=dsrm.dwdm_subrack_master_id and dsrm.dwdm_rack_master_id=drm.dwdm_rack_master_id and drm.node_details_id=nd.node_details_id and card_name!='MCB' and card_name!='MCBONON' and card_name!='MCBONOFF' and card_name!='NO' and card_name!='FIM1' and card_name!='FIM2' and card_name!='FIM3' and card_name!='PSU-1' and card_name!='PSU-2' and card_name!='BUZZER' and card_name!='BUZZER_OFF' and card_name!='BUZZER_ON' and card_name!='BUZZER_MUTE' and nd.node_details_id=? and card_status!='removed';");
		pst=conn.prepareStatement("SELECT node.node_details_id,slot.dwdm_slot_master_id,slot.card_name,dwdm_port_master_id,traffic_name,rack.rack_number,subrack.subrack_number,slot.slot_number,portm.port_number,portm.port_traffic_type,portm.port_client_line_type FROM node_details node left outer join dwdm_rack_master rack on node.node_details_id=rack.node_details_id left outer join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id left outer join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id left outer join dwdm_port_master portm on slot.dwdm_slot_master_id=portm.dwdm_slot_master_id left outer join dwdm_port_traffic_name traffic on portm.port_traffic_type=traffic.dwdm_port_traffic_name_id where node.node_details_id=? and slot.card_name in ('10GOMTP12PLUS','10GOMTP11PLUS','10GOMTP11TPLUS','10GOMMP81PLUS','10GOMMP82PLUS')");
		pst.setInt(1, nodeID);		
		rs=pst.executeQuery();
			while (rs.next()) {
			  al=new ArrayList<String>();			
			  String cardName=rs.getString("card_name");	
			  al.add(cardName);//0
    		  al.add(rs.getString("rack_number"));//1
    		  al.add(rs.getString("subrack_number"));//2
    		  al.add(rs.getString("slot_number"));//3			  
    		  al.add(rs.getString("dwdm_slot_master_id"));//4
    		  al.add(rs.getString("node_details_id"));//5
    		  al.add(rs.getString("dwdm_port_master_id"));//6
    		  al.add(rs.getString("port_client_line_type"));//7
    		  al.add(rs.getString("port_number"));//8
    		  al.add(rs.getString("traffic_name"));//9
			  	
    		  alForCardInventory.add(al);
			}				
			// Check for next result set
			//results = callable.getMoreResults();
		//}
		if (alForCardInventory.size() != 0) {
			strForCardInventory = new String[alForCardInventory.size()][alForCardInventory.get(0).size()];
			for (int i = 0; i < alForCardInventory.size(); i++) {
				ArrayList<String> list = alForCardInventory.get(i);
				for (int j = 0; j < list.size(); j++) {
					strForCardInventory[i][j] = list.get(j);		
					//System.out.println("strForCardInventory" + strForCardInventory[i][j] +"&&&&&&&&&&&&&&------------");
				}
			}
			//System.out.println("strForCardInventory" + strForCardInventory +"&&&&&&&&&&&&&&&&&&------------");
		}
	} catch (SQLException | IOException e) {
		e.printStackTrace();
	} finally {
		try {
			if (rs != null) {
				rs.close();
			}
			if (callable != null) {
				callable.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	return strForCardInventory;
}

	
	public static String updateCardPortSerialNumberDetails( String nodeid,String slotmasterid,String portmasterid,List<StringArray> lLiveAlarms, String  cardName,String rackNumber,String subrackNumber,String strSlotNumber,String portAddress,String portParentCard, String porttype, String portnumber, String trafficname )throws Exception {
		//public static String updateCardPortSerialNumberDetails( String nodeid,String slotmasterid,List<StringArray> lLiveAlarms, String  cardName,String rackNumber,String subrackNumber,String strSlotNumber )throws Exception {
			Connection conn = null;
			PreparedStatement psForAddCardInventoryDetails = null;	
			PreparedStatement psForUpdateCardInventoryDetails = null;
			PreparedStatement psForGetCardInventoryDetails = null;	
			ResultSet rsForGetCardInventoryDetails = null;	
			String resultType="not success";
			StringBuffer sbPortAddress;
			StringBuffer sbPortParentCard;	
			String sqlQueryForAddCardInventoryDetails="INSERT INTO `dwdm_port_history`(`port_name`,`port_number`,`traffic_name`,`port_card_name`,`port_address`,`port_parent_card`,`dwdm_slot_master_id`,`dwdm_port_master_id`,node_details_id)VALUES(?,?,?,?,?,?,?,?,?)";
			String sqlQueryForUpdateCardInventoryDetails="update dwdm_port_history set port_name=?,port_number=?,traffic_name=?,port_card_name=?,port_address=?,port_parent_card=?,dwdm_slot_master_id=?,dwdm_port_master_id=?,node_details_id=? where dwdm_port_history_id=?";
			//String sqlQueryForAddCardInventoryDetails="INSERT INTO `dwdm_port_history`(`port_card_name`,`dwdm_slot_master_id`,`node_details_id`)VALUES(?,?,?)";
			//String sqlQueryForUpdateCardInventoryDetails="update dwdm_port_history set port_card_name=?,dwdm_slot_master_id=?,node_details_id=? where dwdm_port_history_id=?";
				
			String sqlQueryForGetCardInventoryDetails="SELECT * FROM dwdm_port_history where dwdm_port_master_id=?";
			
			try {
				conn = DataSource.getInstance().getConnection();		
				for (int i = 0; i < lLiveAlarms.size(); i++) {
						ArrayList<String> tempLiveAlarms;				
						tempLiveAlarms=new ArrayList<String>();				
						tempLiveAlarms.add(""+(i+1));				
						StringArray saLiveAlarms = lLiveAlarms.get(i);				
						List<String> lEachLiveAlarmDetails = saLiveAlarms.getItem();
						cardName = lEachLiveAlarmDetails.get(0);
						if(cardName.equals("10GOMTP11PLUS")||cardName.equals("10GOMTP11TPLUS")||cardName.equals("10GOMTP12PLUS")||cardName.equals("10GOMMP82PLUS")||cardName.equals("10GOMMP81PLUS"))
						{
							rackNumber = lEachLiveAlarmDetails.get(1);
							subrackNumber = lEachLiveAlarmDetails.get(2);
							strSlotNumber = lEachLiveAlarmDetails.get(3);
							slotmasterid = lEachLiveAlarmDetails.get(4);	
							nodeid = lEachLiveAlarmDetails.get(5);
							portmasterid = lEachLiveAlarmDetails.get(6);
							porttype = lEachLiveAlarmDetails.get(7);
							portnumber = lEachLiveAlarmDetails.get(8);
							trafficname = lEachLiveAlarmDetails.get(9);
						}
						else
						{					
							rackNumber = lEachLiveAlarmDetails.get(1);
							subrackNumber = lEachLiveAlarmDetails.get(2);
							strSlotNumber = lEachLiveAlarmDetails.get(3);
							slotmasterid = lEachLiveAlarmDetails.get(4);	
							nodeid = lEachLiveAlarmDetails.get(5);
							portmasterid = "0";
							porttype = "--";
							portnumber = "0";
							trafficname = "--";
						}
						psForGetCardInventoryDetails=conn.prepareStatement(sqlQueryForGetCardInventoryDetails);			
						psForGetCardInventoryDetails.setString(1,portmasterid);
						rsForGetCardInventoryDetails=psForGetCardInventoryDetails.executeQuery();
						int rowCount = 0;
						if (rsForGetCardInventoryDetails.last()) {
							rowCount = rsForGetCardInventoryDetails.getRow();
							rsForGetCardInventoryDetails.beforeFirst();
						}
						if(rsForGetCardInventoryDetails.next()){
							int portHistoryId=rsForGetCardInventoryDetails.getInt(1);
							psForUpdateCardInventoryDetails = conn.prepareStatement(sqlQueryForUpdateCardInventoryDetails);	
							psForUpdateCardInventoryDetails.setString(1,porttype);
							psForUpdateCardInventoryDetails.setString(2,portnumber);
							psForUpdateCardInventoryDetails.setString(3,trafficname);
							psForUpdateCardInventoryDetails.setString(4,cardName);					
							sbPortAddress=new StringBuffer("Rack="+rackNumber).append("/").append("Shelf="+subrackNumber).append("/").append("Slot="+strSlotNumber).append("/").append("Port="+portnumber);
							portAddress = sbPortAddress.toString();
							psForUpdateCardInventoryDetails.setString(5,portAddress);
							sbPortParentCard=new StringBuffer(cardName+"["+rackNumber).append("-").append(subrackNumber).append("-").append(strSlotNumber).append("-").append(portnumber).append("]");
							portParentCard = sbPortParentCard.toString();
							psForUpdateCardInventoryDetails.setString(6,portParentCard);
							psForUpdateCardInventoryDetails.setString(7,slotmasterid);	
							psForUpdateCardInventoryDetails.setString(8,portmasterid);	
							psForUpdateCardInventoryDetails.setString(9,nodeid);
							psForUpdateCardInventoryDetails.setInt(10,portHistoryId);	
							
							int result=psForUpdateCardInventoryDetails.executeUpdate();
							if(result==1){
								resultType="success";
							}		
						}				
						else{					
							psForAddCardInventoryDetails = conn.prepareStatement(sqlQueryForAddCardInventoryDetails);
							psForAddCardInventoryDetails.setString(1,porttype);
							psForAddCardInventoryDetails.setString(2,portnumber);
							psForAddCardInventoryDetails.setString(3,trafficname);
							psForAddCardInventoryDetails.setString(4,cardName);
							sbPortAddress=new StringBuffer("Rack="+rackNumber).append("/").append("Shelf="+subrackNumber).append("/").append("Slot="+strSlotNumber).append("/").append("Port="+portnumber);
							portAddress = sbPortAddress.toString();
							psForAddCardInventoryDetails.setString(5,portAddress);	
							sbPortParentCard=new StringBuffer(cardName+"["+rackNumber).append("-").append(subrackNumber).append("-").append(strSlotNumber).append("-").append(portnumber).append("]");
							portParentCard = sbPortParentCard.toString();
							psForAddCardInventoryDetails.setString(6,portParentCard);
							psForAddCardInventoryDetails.setString(7,slotmasterid);		
							psForAddCardInventoryDetails.setString(8,portmasterid);	
							psForAddCardInventoryDetails.setString(9,nodeid);	
							
							int result=psForAddCardInventoryDetails.executeUpdate();
							if(result==1){
								resultType="success";
							}	
						}
				}
			} catch (SQLException | IOException e) {
				e.printStackTrace();
				throw e;
			} finally {
				try {
					if (rsForGetCardInventoryDetails != null) {
						rsForGetCardInventoryDetails.close();
					}	if (psForGetCardInventoryDetails != null) {
						psForGetCardInventoryDetails.close();
					}
					if (psForAddCardInventoryDetails != null) {
						psForAddCardInventoryDetails.close();
					}
					if (conn != null) {
						conn.close();
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			return resultType;
		}
	
	//SFP/XFP Inventory
	public static String updateCardPortXFPSFPDetails( String nodeid,String slotmasterid,String portmasterid,List<StringArray> lLiveAlarms,String sfpstatus, String sfpSerialnumber, String  cardName,String rackNumber,String subrackNumber,String strSlotNumber,String sfpModel,String sfpAddress, String sfpPartCode,  String portnumber,String trafficType )throws Exception {
		Connection conn = null;
		PreparedStatement psForAddCardInventoryDetails = null;	
		PreparedStatement psForUpdateCardInventoryDetails = null;
		PreparedStatement psForGetCardInventoryDetails = null;	
		ResultSet rsForGetCardInventoryDetails = null;	
		String resultType="not success";
		StringBuffer sbSfpAddress;		
		/*String sqlQueryForAddCardInventoryDetails="INSERT INTO `dwdm_sfp_history`(`sfp_card_name`,`sfp_port_number`,`sfp_name`,`sfp_part_code`,`sfp_model`,`sfp_serial_number`,`sfp_address`,`sfp_status`,`dwdm_slot_master_id`,`dwdm_port_master_id`,node_details_id)VALUES(?,?,?,?,?,?,?,?,?,?,?)";
		String sqlQueryForUpdateCardInventoryDetails="update dwdm_sfp_history set sfp_card_name=?,sfp_port_number=?,sfp_name=?,sfp_part_code=?,sfp_model=?,sfp_serial_number=?,sfp_address=?,sfp_status=?,dwdm_slot_master_id=?,dwdm_port_master_id=?,node_details_id=? where dwdm_sfp_history_id=?";
		*/
		String sqlQueryForAddCardInventoryDetails="INSERT INTO `dwdm_sfp_history`(`sfp_card_name`,`sfp_port_number`,`sfp_status`,`sfp_part_code`,`sfp_model`,`sfp_serial_number`,`sfp_address`,`dwdm_slot_master_id`,`dwdm_port_master_id`,node_details_id)VALUES(?,?,?,?,?,?,?,?,?,?)";
		String sqlQueryForUpdateCardInventoryDetails="update dwdm_sfp_history set sfp_card_name=?,sfp_port_number=?,sfp_status=?,sfp_part_code=?,sfp_model=?,sfp_serial_number=?,sfp_address=?,dwdm_slot_master_id=?,dwdm_port_master_id=?,node_details_id=? where dwdm_sfp_history_id=?";

		
		String sqlQueryForGetCardInventoryDetails="SELECT * FROM dwdm_sfp_history where dwdm_port_master_id=?";
		
		try {
			//conn = DBConnection.getMYSQLDBConn();		
			conn = DataSource.getInstance().getConnection();	
			for (int i = 0; i < lLiveAlarms.size(); i++) {
					ArrayList<String> tempLiveAlarms;				
					tempLiveAlarms=new ArrayList<String>();				
					tempLiveAlarms.add(""+(i+1));				
					StringArray saLiveAlarms = lLiveAlarms.get(i);				
					List<String> lEachLiveAlarmDetails = saLiveAlarms.getItem();
					cardName = lEachLiveAlarmDetails.get(0);
					rackNumber = lEachLiveAlarmDetails.get(1);
					subrackNumber = lEachLiveAlarmDetails.get(2);
					strSlotNumber = lEachLiveAlarmDetails.get(3);
					nodeid = lEachLiveAlarmDetails.get(4);
					slotmasterid = lEachLiveAlarmDetails.get(5);
					portmasterid = lEachLiveAlarmDetails.get(6);	
					portnumber = lEachLiveAlarmDetails.get(7);
					trafficType = lEachLiveAlarmDetails.get(8);
					sfpstatus=lEachLiveAlarmDetails.get(9);		//sfpstatus
					
					try {
						sfpSerialnumber = lEachLiveAlarmDetails.get(10);
						sfpSerialnumber = sfpSerialnumber.replace(" ","");
						sfpstatus = "Present";
					}
					catch(Exception e)
					{
						e.printStackTrace();
						sfpstatus = "Absent";
					}
					try {
						sfpPartCode = lEachLiveAlarmDetails.get(11);
						sfpPartCode = sfpPartCode.replace(" ","");
						sfpstatus = "Present";
					}
					catch(Exception e)
					{
						e.printStackTrace();
						sfpstatus = "Absent";
					}
					try {
						sfpModel =  lEachLiveAlarmDetails.get(12);
						sfpModel = sfpModel.replace(" ","");
						sfpstatus = "Present";
							
					}
					catch(Exception e)
					{
						e.printStackTrace();
						sfpstatus = "Absent";
					}
				
									
					psForGetCardInventoryDetails=conn.prepareStatement(sqlQueryForGetCardInventoryDetails);			
					psForGetCardInventoryDetails.setString(1,portmasterid);
					rsForGetCardInventoryDetails=psForGetCardInventoryDetails.executeQuery();
					int rowCount = 0;
					if (rsForGetCardInventoryDetails.last()) {
						rowCount = rsForGetCardInventoryDetails.getRow();
						rsForGetCardInventoryDetails.beforeFirst();
					}
					if(rsForGetCardInventoryDetails.next()){
						int sfpHistoryId=rsForGetCardInventoryDetails.getInt(1);
						psForUpdateCardInventoryDetails = conn.prepareStatement(sqlQueryForUpdateCardInventoryDetails);	
						psForUpdateCardInventoryDetails.setString(1,cardName);
						psForUpdateCardInventoryDetails.setString(2,portnumber);
						psForUpdateCardInventoryDetails.setString(3,sfpstatus);					
						psForUpdateCardInventoryDetails.setString(4,sfpPartCode);	
						psForUpdateCardInventoryDetails.setString(5,sfpModel);	
						psForUpdateCardInventoryDetails.setString(6,sfpSerialnumber);
						sbSfpAddress=new StringBuffer("Rack="+rackNumber).append("/").append("Shelf="+subrackNumber).append("/").append("Slot="+strSlotNumber).append("/").append("Port="+portnumber);
						sfpAddress = sbSfpAddress.toString();
						psForUpdateCardInventoryDetails.setString(7,sfpAddress);	
						psForUpdateCardInventoryDetails.setString(8,slotmasterid);	
						psForUpdateCardInventoryDetails.setString(9,portmasterid);	
						psForUpdateCardInventoryDetails.setString(10,nodeid);
						psForUpdateCardInventoryDetails.setInt(11,sfpHistoryId);	
											
						int result=psForUpdateCardInventoryDetails.executeUpdate();
						if(result==1){
							resultType="success";
						}		
					}				
					else{					
						psForAddCardInventoryDetails = conn.prepareStatement(sqlQueryForAddCardInventoryDetails);
						psForAddCardInventoryDetails.setString(1,cardName);
						psForAddCardInventoryDetails.setString(2,portnumber);
						psForAddCardInventoryDetails.setString(3,sfpstatus);
						psForAddCardInventoryDetails.setString(4,sfpPartCode);
						psForAddCardInventoryDetails.setString(5,sfpModel);	
						psForAddCardInventoryDetails.setString(6,sfpSerialnumber);
						sbSfpAddress=new StringBuffer("Rack="+rackNumber).append("/").append("Shelf="+subrackNumber).append("/").append("Slot="+strSlotNumber).append("/").append("Port="+portnumber);
						sfpAddress = sbSfpAddress.toString();
						psForAddCardInventoryDetails.setString(7,sfpAddress);
						psForAddCardInventoryDetails.setString(8,slotmasterid);	
						psForAddCardInventoryDetails.setString(9,portmasterid);	
						psForAddCardInventoryDetails.setString(10,nodeid);
						
						int result=psForAddCardInventoryDetails.executeUpdate();
						if(result==1){
							resultType="success";
						}	
					}
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (rsForGetCardInventoryDetails != null) {
					rsForGetCardInventoryDetails.close();
				}	if (psForGetCardInventoryDetails != null) {
					psForGetCardInventoryDetails.close();
				}
				if (psForAddCardInventoryDetails != null) {
					psForAddCardInventoryDetails.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return resultType;
	}
	
	public static String[][] getCardAndXFPSFPInventoryBasedOnNodeIPAddress(int nodeID) throws Exception {
		Connection conn = null;
		CallableStatement callable = null;
		ResultSet rs = null;
		String[][] strForCardInventory = null;
		ArrayList<ArrayList<String>> alForCardInventory = new ArrayList<ArrayList<String>>();
		ArrayList<String> al = null;
		PreparedStatement pst=null;
		try {
			//conn = DBConnection.getMYSQLDBConn();
			conn = DataSource.getInstance().getConnection();	
			//pst=conn.prepareStatement("select card_name,rack_number,subrack_number,slot_number,node_ip_address,dwdm_slot_master_id,nd.node_details_id from dwdm_slot_master dsm,dwdm_subrack_master dsrm,dwdm_rack_master drm,node_details nd where dsm.dwdm_subrack_master_id=dsrm.dwdm_subrack_master_id and dsrm.dwdm_rack_master_id=drm.dwdm_rack_master_id and drm.node_details_id=nd.node_details_id and card_name!='MD-ROADMPLUS-DIR-1' and card_name!='MD-ROADMPLUS-DIR-2' and card_name!='MD-ROADMPLUS-DIR-3' and card_name!='SCUPLUS' and card_name!='MUXPLUS' and card_name!='DEMUXPLUS' and card_name!='BMUPLUS' and card_name!='MCB' and card_name!='MCBONON' and card_name!='MCBONOFF' and card_name!='NO' and card_name!='FIM1' and card_name!='FIM2' and card_name!='FIM3' and card_name!='PSU-1' and card_name!='PSU-2' and card_name!='BUZZER' and card_name!='BUZZER_OFF' and card_name!='BUZZER_ON' and card_name!='BUZZER_MUTE' and nd.node_details_id=? and card_status!='removed';");
			//pst=conn.prepareStatement("SELECT nd.node_details_id,dsm.card_name,dsm.slot_number,dsm.dwdm_slot_master_id,drm.rack_number,dsrm.subrack_number, a.port_client_line_type, a.port_number,a.dwdm_port_master_id FROM node_details nd,dwdm_rack_master drm,dwdm_subrack_master dsrm,dwdm_slot_master dsm, dwdm_port_master a, dwdm_port_traffic_name as b  where nd.node_details_id=? and dsrm.dwdm_rack_master_id=drm.dwdm_rack_master_id and dsm.dwdm_subrack_master_id=dsrm.dwdm_subrack_master_id  and a.port_traffic_type=b.dwdm_port_traffic_name_id and a.dwdm_slot_master_id=dsm.dwdm_slot_master_id and dsm.card_name in('10GOMTP11','10GOMTP11T','10GOMTP12','10GOMMP81','10GOMMP82','10GOMTP11PLUS','10GOMTP11TPLUS','10GOMTP12PLUS','10GOMMP81PLUS','10GOMMP82PLUS','SCC'");
			//pst=conn.prepareStatement("select card_name,rack_number,subrack_number,slot_number,node_ip_address,dwdm_slot_master_id,nd.node_details_id  from dwdm_slot_master dsm,dwdm_subrack_master dsrm,dwdm_rack_master drm,node_details nd where dsm.dwdm_subrack_master_id=dsrm.dwdm_subrack_master_id and dsrm.dwdm_rack_master_id=drm.dwdm_rack_master_id and drm.node_details_id=nd.node_details_id and card_name!='BMUPLUS' and card_name!='SCC' and card_name!='SCUPLUS' and card_name!='MUX1PLUS' and card_name!='MUX2PLUS' and card_name!='MUX3PLUS' and card_name!='DEMUX1PLUS' and card_name!='DEMUX2PLUS' and card_name!='DEMUX3PLUS' and card_name!='MD-ROADMPLUS-DIR-1' and card_name!='MD-ROADMPLUS-DIR-2' and card_name!='MD-ROADMPLUS-DIR-3'  and card_name!='MCB' and card_name!='MCBONON' and card_name!='MCBONOFF' and card_name!='NO' and card_name!='FIM1' and card_name!='FIM2' and card_name!='FIM3' and card_name!='PSU-1' and card_name!='PSU-2' and card_name!='BUZZER' and card_name!='BUZZER_OFF' and card_name!='BUZZER_ON' and card_name!='BUZZER_MUTE' and nd.node_details_id=? and card_status!='removed';");
			pst=conn.prepareStatement("SELECT node.node_details_id,node.node_ip_address,slot.dwdm_slot_master_id,slot.card_name,dwdm_port_master_id,traffic_name,rack.rack_number,subrack.subrack_number,slot.slot_number,portm.port_number,portm.port_traffic_type,portm.port_client_line_type FROM node_details node left outer join dwdm_rack_master rack on node.node_details_id=rack.node_details_id left outer join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id left outer join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id left outer join dwdm_port_master portm on slot.dwdm_slot_master_id=portm.dwdm_slot_master_id left outer join dwdm_port_traffic_name traffic on portm.port_traffic_type=traffic.dwdm_port_traffic_name_id where node.node_details_id=? and slot.card_name in ('10GOMTP12PLUS','10GOMTP11PLUS','10GOMTP11TPLUS','10GOMMP81PLUS','10GOMMP82PLUS')");
			pst.setInt(1, nodeID);		
			rs=pst.executeQuery();
				while (rs.next()) {
					  al=new ArrayList<String>();
					  Short nodeNumber=1;
					  short rackNumber=Short.parseShort(rs.getString("rack_number"));
					  short subrackNumber=Short.parseShort(rs.getString("subrack_number"));
					  short slotNumber=Short.parseShort(rs.getString("slot_number"));
					
					  String stringValue; 
					  String stringPortNumber;
					  String strSpfStatus = null;
					  String strSerialNumber;
					  String strPartCode;
					  String strModel;
					  
					  short portnumber;
					  short cardID=0;
					  short sfpserialID=0;
					  short xfpserialID=0;
					  short sfppartCodeID=0;
					  short xfppartCodeID=0;
					  short sfpmodel=0;
					  short xfpmodel=0;			  
					  short sfpstatus=0;
					  short xfpstatus=0;
					
					  //byte  portNumber=0;
					  byte portNo;
					  short directionNumber=0;
					  short portType=0;
					  short channelNumber=0;
					  byte interfaceNumber=0;
					  String cardName=rs.getString("card_name");
					  String nodeIP=rs.getString("node_ip_address");
					  String nodeId = rs.getString("dwdm_slot_master_id");
					  String slotmasterId = rs.getString("node_details_id");
					  String portmasterId = rs.getString("dwdm_port_master_id");
					  String strPortNumber = rs.getString("port_number");
					  String strTrafficname = rs.getString("traffic_name");
					  String portClientLineType =  rs.getString("port_client_line_type");
					  
					 // CurrentUserDetailsBean userDetails=CurrentUserBeanPermissions.getUserBeanObject();			  
					  al.add(cardName);
					  al.add(rs.getString("rack_number"));		    				   		  
					  al.add(rs.getString("subrack_number"));
			   		  al.add(rs.getString("slot_number"));
			   		  al.add(rs.getString("node_details_id"));
		    		  al.add(rs.getString("dwdm_slot_master_id"));
		    		  al.add(portmasterId);
					  al.add(strPortNumber);		
					  al.add(strTrafficname);
					
		    		  switch(cardName){	    		
		    		  case "10GOMMP82PLUS":
		    			  cardID=87;
		    			  sfpstatus=63;
		    			  sfpserialID=107;
		    			  sfppartCodeID=106;
		    			  sfpmodel=104;
		    			  xfpstatus=23;
		    			  xfpserialID=39;
		    			  xfppartCodeID=38;
		    			  xfpmodel=36;	    			 
			    		  break;	    		
		    		  case "10GOMMP81PLUS":
		    			  cardID=86;
		    			  sfpstatus=63;
		    			  sfpserialID=107;
		    			  sfppartCodeID=106;
		    			  sfpmodel=104;
		    			  xfpstatus=23;
		    			  xfpserialID=39;
		    			  xfppartCodeID=38;
		    			  xfpmodel=36;
			    		  break;	    		
		    		  case "10GOMTP11PLUS":
		    			  cardID=71;	    			 
		    			  xfpstatus=23;
		    			  xfpserialID=39;
		    			  xfppartCodeID=38;
		    			  xfpmodel=36;	
			    		  break;
		    		  case "10GOMTP11TPLUS":
		    		  	  cardID=72;	    		  
		    			  xfpstatus=23;
		    			  xfpserialID=39;
		    			  xfppartCodeID=38;
		    			  xfpmodel=36;	
			    		  break;	    	
		    		  case "10GOMTP12PLUS":
		    			  cardID=73;	    			 
		    			  xfpstatus=23;
		    			  xfpserialID=39;
		    			  xfppartCodeID=38;
		    			  xfpmodel=36;	
			    		  break;
		    		
		    		  case "SCC":
		    		  case "SCCPLUS":
		    			  cardID=1;
		    			  sfpstatus=143;
		    			  sfpserialID=42;
		    			  sfppartCodeID=43;
		    			  sfpmodel=41;
			    		  break;
		    		
		    		  case "OBA1PLUS":
		    		  case "OBA2PLUS":
		    		  case "OBA3PLUS":
		    		  case "OBA4PLUS":
		    			  cardID=131;
		    			  sfpmodel=31;
			    		  break;		 		    		  

		    		  case "OPA1PLUS":
		    		  case "OPA2PLUS":
		    		  case "OPA3PLUS":
		    		  case "OPA4PLUS":
		    			  cardID=141;
		    			  sfpmodel=31;
			    		  break;	    	
		    		  case "OLA1PLUS":
		    		  case "OLA2PLUS":
		    		  case "OLA3PLUS":
		    		  case "OLA4PLUS":
		    			  cardID=151;
		    			  sfpmodel=31;
			    		  break;
		    		  }
		    	  switch (cardName) {					
								/*case "SCC":	case "SCCPLUS":
									  al.add(rs.getString("rack_number"));		    				   		  
		    						  al.add(rs.getString("subrack_number"));
		    				   		  al.add(rs.getString("slot_number"));	    				   		  
		    				   		Byte portNum = null;	
									try {
										portNum=1;	
			  							al.add(ReportsBL.getSCCSFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpstatus));
					    			    al.add(ReportsBL.getSCCSfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpserialID));
					    			    al.add(ReportsBL.getSCCSFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfppartCodeID));
					    				al.add(ReportsBL.getSCCSFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpmodel));				    				
					    				al.add(nodeId);
										al.add(slotmasterId);
										portmasterId = "0";
										al.add(portmasterId);
										al.add(strPortNumber.valueOf(portNum));								
								}
									 catch (Exception e1) {
										e1.printStackTrace();
									 }
							
								try {
									portNum=2;	
										al.add(cardName);
									 	al.add(rs.getString("rack_number"));		    				   		  
									 	al.add(rs.getString("subrack_number"));
									 	al.add(rs.getString("slot_number"));
			  							al.add(ReportsBL.getSCCSFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpstatus));
					    			    al.add(ReportsBL.getSCCSfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpserialID));
					    			    al.add(ReportsBL.getSCCSFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfppartCodeID));
					    				al.add(ReportsBL.getSCCSFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpmodel));
					    				al.add(nodeId);
										al.add(slotmasterId);
										portmasterId = "0";
										al.add(portmasterId);
										al.add(strPortNumber.valueOf(portNum));
									
									} catch (Exception e) {
										e.printStackTrace();
								}

								try {
										portNum=3;									
										al.add(cardName);
									 	al.add(rs.getString("rack_number"));		    				   		  
									 	al.add(rs.getString("subrack_number"));
									 	al.add(rs.getString("slot_number"));
			  							al.add(ReportsBL.getSCCSFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpstatus));
					    			    al.add(ReportsBL.getSCCSfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpserialID));
					    			    al.add(ReportsBL.getSCCSFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfppartCodeID));
					    				al.add(ReportsBL.getSCCSFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpmodel));
					    				al.add(nodeId);
										al.add(slotmasterId);
										portmasterId = "0";
										al.add(portmasterId);
										al.add(strPortNumber.valueOf(portNum));
									
									} catch (Exception e) {
									e.printStackTrace();
									}
								try {
									portNum=4;									
										al.add(cardName);
									 	al.add(rs.getString("rack_number"));		    		
									 	
									 	al.add(rs.getString("subrack_number"));
									 	al.add(rs.getString("slot_number"));
			  							al.add(ReportsBL.getSCCSFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpstatus));
					    			    al.add(ReportsBL.getSCCSfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpserialID));
					    			    al.add(ReportsBL.getSCCSFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfppartCodeID));
					    				al.add(ReportsBL.getSCCSFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNum, nodeIP, userDetails,cardID,sfpmodel));
					    				al.add(nodeId);
										al.add(slotmasterId);
										portmasterId = "0";
										al.add(portmasterId);
										al.add(strPortNumber.valueOf(portNum));
									
								} catch (Exception e) {
									e.printStackTrace();
							}
							alForCardInventory.add(al);	
								
							break;*/
						case "10GOMTP12":case "10GOMTP12PLUS":
							  portnumber = Short.parseShort(rs.getString("port_number"));
							 	
						   		if("line".equals(portClientLineType)){
						   			portnumber +=1;
								}
				   		  
								try {	    					
									portNo = (byte)portnumber;
									if (!"Free".equals(strTrafficname)) {
										//optical
										switch (portClientLineType) {
										case "client":case "line":
											try {
						  							al.add(SNMPInventoryBL.getXFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpstatus));			  						
								    			    al.add(SNMPInventoryBL.getXfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpserialID));
								    			    al.add(SNMPInventoryBL.getXFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfppartCodeID));
								    				al.add(SNMPInventoryBL.getXFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpmodel));
											}
											 catch (Exception e1) {
													e1.printStackTrace();
											 }									
										}//switch
				    			
									}//if
								}
								 catch (Exception e1) {
									e1.printStackTrace();
								 }			
						
							break;
						case "10GOMTP11T":case "10GOMTP11TPLUS":
							  portnumber = Short.parseShort(rs.getString("port_number"));
						   		if("line".equals(portClientLineType)){
						   			portnumber +=0;
								}			   		  
								try {	
									if (!"Free".equals(strTrafficname)) {
										//optical
										switch (portClientLineType) {
										case "client":case "line":
											try {
													portNo = (byte)portnumber;
						  							al.add(SNMPInventoryBL.getXFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpstatus));
								    			    al.add(SNMPInventoryBL.getXfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpserialID));
								    			    al.add(SNMPInventoryBL.getXFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfppartCodeID));
								    				al.add(SNMPInventoryBL.getXFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpmodel));
												}
										
										 catch (Exception e1) {
												e1.printStackTrace();
										 }									
									}//switch
			    			
								}//if
								} catch (Exception e1) {
									e1.printStackTrace();
								 }						
								
							
							break;
						case "10GOMTP11":case "10GOMTP11PLUS":
							  portnumber = Short.parseShort(rs.getString("port_number"));
							  portClientLineType =  rs.getString("port_client_line_type");
							  try {
									if("line".equals(portClientLineType)){
							   			portnumber +=1;
									}
									portNo = (byte)portnumber;
									if (!"Free".equals(strTrafficname)) {
										//optical
										switch (portClientLineType) {
										case "client":case "line":
											try {
												try {
							  						strSpfStatus = SNMPInventoryBL.getXFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpstatus);
							  					//	if(strSpfStatus.equals("0"))
							  					//	{
							  					//		strSpfStatus = "Present";
							  					//	}
							  					//	else
							  					//	{
							  						//	strSpfStatus = "Absent";
							  					//	}
							  						al.add(strSpfStatus);
												}
												 catch (Exception e1) {
														e1.printStackTrace();
												 }	
							  							
													//if(strSpfStatus.equals("Present")) {												
														strSerialNumber = SNMPInventoryBL.getXfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpserialID);
									    			    strPartCode = SNMPInventoryBL.getXFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfppartCodeID);
									    				strModel = SNMPInventoryBL.getXFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpmodel);
									    				al.add(strSerialNumber);
									    				al.add(strPartCode);
									    				al.add(strModel);
													//}
													//else
												//	{
													//	al.add("Absent");
														///al.add("Absent");
														//al.add("Absent");													
														
												//	}
											}
											 catch (Exception e1) {
													e1.printStackTrace();
											 }									
										}//switch
				    			
									}//if
								} catch (Exception e1) {
									e1.printStackTrace();
								 }					
							
							break;
							case "10GOMMP82":case "10GOMMP82PLUS":
								  portnumber = Short.parseShort(rs.getString("port_number"));
								  portClientLineType =  rs.getString("port_client_line_type");
								
								  try {
										if("client".equals(portClientLineType)){
								   			portnumber +=0;									
											portNo = (byte)portnumber;
											if (!"Free".equals(strTrafficname)) {
												//optical
												switch (portClientLineType) {
												case "client":case "line":
													try {
								  							al.add(SNMPInventoryBL.getSFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfpstatus));
										    			    al.add(SNMPInventoryBL.getSfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfpserialID));
										    			    al.add(SNMPInventoryBL.getSFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfppartCodeID));
										    				al.add(SNMPInventoryBL.getSFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfpmodel));	
													}
													 catch (Exception e1) {
															e1.printStackTrace();
													 }									
												}//switch
						    			
											}//if
										}
					    				
					    				if("line".equals(portClientLineType)){
								   			portnumber +=8;									
						    				portNo = (byte)portnumber;
						    				if (!"Free".equals(strTrafficname)) {
												//optical
												switch (portClientLineType) {
												case "client":case "line":
													try {
										    				al.add(SNMPInventoryBL.getXFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpstatus));
										    			    al.add(SNMPInventoryBL.getXfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpserialID));
										    			    al.add(SNMPInventoryBL.getXFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfppartCodeID));
										    				al.add(SNMPInventoryBL.getXFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpmodel));  
													}
													 catch (Exception e1) {
															e1.printStackTrace();
													 }									
												}//switch
						    			
											}//if
					    				}	//if			    				
					    			
								    }catch (Exception e1) {
										e1.printStackTrace();
									 }		
								
							break;
						case "10GOMMP81":case "10GOMMP81PLUS":
							  portnumber = Short.parseShort(rs.getString("port_number"));
							  portClientLineType =  rs.getString("port_client_line_type");
							
							  try {
									if("client".equals(portClientLineType)){
							   			portnumber +=0;									
										portNo = (byte)portnumber;
										if (!"Free".equals(strTrafficname)) {
											//optical
											switch (portClientLineType) {
											case "client":case "line":
												try {
							  							al.add(SNMPInventoryBL.getSFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfpstatus));
									    			    al.add(SNMPInventoryBL.getSfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfpserialID));
									    			    al.add(SNMPInventoryBL.getSFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfppartCodeID));
									    				al.add(SNMPInventoryBL.getSFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,sfpmodel));	
												}
												 catch (Exception e1) {
														e1.printStackTrace();
												 }									
											}//switch
					    			
										}//if
									}
				    				
				    				if("line".equals(portClientLineType)){
							   			portnumber +=8;									
					    				portNo = (byte)portnumber;
					    				if (!"Free".equals(strTrafficname)) {
											//optical
											switch (portClientLineType) {
											case "client":case "line":
												try {
									    				al.add(SNMPInventoryBL.getXFPStatus(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpstatus));
									    			    al.add(SNMPInventoryBL.getXfpSerialNumber(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpserialID));
									    			    al.add(SNMPInventoryBL.getXFPPartCode(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfppartCodeID));
									    				al.add(SNMPInventoryBL.getXFPModel(nodeNumber, rackNumber, subrackNumber, slotNumber, portNo, nodeIP, userDetails,cardID,xfpmodel));  	
												}
												 catch (Exception e1) {
														e1.printStackTrace();
												 }									
											}//switch
					    			
										}//if
				    				}				    				
				    			
							    }catch (Exception e1) {
									e1.printStackTrace();
								 }		
							
							break;
						
					}//switch
		    		  alForCardInventory.add(al);		    		  
				} //while
		    	  				
				// Check for next result set
				//results = callable.getMoreResults();
			//}
			if (alForCardInventory.size() != 0) {
				strForCardInventory = new String[alForCardInventory.size()][alForCardInventory.get(0).size()];
				for (int i = 0; i < alForCardInventory.size(); i++) {
					ArrayList<String> list = alForCardInventory.get(i);
					for (int j = 0; j < list.size(); j++) {
						strForCardInventory[i][j] = list.get(j);		
						//System.out.println("strForCardInventory" + strForCardInventory[i][j] +"&&&&&&&&&&&&&&------------");
					}
				}
				//System.out.println("strForCardInventory" + strForCardInventory +"&&&&&&&&&&&&&&&&&&------------");
			}
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (callable != null) {
					callable.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		return strForCardInventory;
	}
}
