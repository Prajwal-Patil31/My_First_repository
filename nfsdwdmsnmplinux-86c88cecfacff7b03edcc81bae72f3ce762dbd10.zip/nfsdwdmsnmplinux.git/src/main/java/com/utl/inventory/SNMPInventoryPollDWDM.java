package com.utl.inventory;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.net.ServerSocket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

//import org.apache.log4j.Logger;
import org.snmp4j.test.GetSoftwareType;

import com.ut.connection.pool.DataSource;
import com.utl.dao.ServiceSettings;

public class SNMPInventoryPollDWDM implements Runnable
{
	//static Logger l = Logger.getLogger(SNMPPerformancePollDWDM.class);
	private static ThreadPoolExecutor executorServiceObj=null;
	private final static byte THREAD_POOL_SIZE=10;//if ems change 10 to 50
	private  static long patience = 1000 * 60 * 3;
    
    JButton clearButton;
    JTextArea messagesArea;
    JScrollPane messagesScroll;
    JTextField hostIDField, communityField, OIDField, valueField, enterpriseField, agentField;
    JLabel authorLabel, hostIDLabel, communityLabel, OIDLabel, valueLabel, enterpriseLabel, agentLabel, genericTrapLabel, specificTrapLabel;
    JComboBox valueTypeBox, genericTrapBox, specificTrapBox;
    static SNMPInventoryPollDWDM snmpInventoryPollDWDMObj;
    MenuBar theMenubar;
    Menu fileMenu;
    MenuItem aboutItem, quitItem;
    
    PipedReader errorReader;
    PipedWriter errorWriter;
    Thread readerThread;
    
	static ServerSocket serverSocketObj=null;
    
    // WindowCloseAdapter to catch window close-box closings
  /*  private class WindowCloseAdapter extends WindowAdapter
    { 
        public void windowClosing(WindowEvent e)
        {
            if (readerThread!=null) {
				readerThread.interrupt();
			}
            if(serverSocketObj!=null){
            	try {
					serverSocketObj.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
            }
			System.exit(0);
        }
    };*/
            
    
    public SNMPInventoryPollDWDM() 
    { 
        try
        {
        	//setIconImage(Toolkit.getDefaultToolkit().getImage(SNMPPerformancePollDWDM.class.getResource("/icons/utl.PNG")));
        	System.setProperty("com.mchange.v2.log.MLog",
    				"com.mchange.v2.log.FallbackMLog");
    		System.setProperty(
    				"com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL",
    				"SEVERE");
           // setUpDisplay();
    		System.out.println("=======================================================");        	
        	System.out.println("UTL-MP-0072 Spectrum DWDM Inventory Polling Service");
        	System.out.println("=======================================================");   
       
            DataSource.getInstance().getConnection();
            errorReader = new PipedReader();
            errorWriter = new PipedWriter(errorReader);
            
            readerThread = new Thread(this);
            readerThread.setName("SNMPInventoryPollDWDM");
            readerThread.start();
            
            /*	this.addWindowListener(new WindowAdapter() {
            		public void windowIconified(WindowEvent e){	
            	    	setVisible(false);    	
            	    }
				});*/
        }
        catch(Exception e)
        {
        	// System.exit(0);
        }
      /*  catch(Exception e)
        {
            messagesArea.append("Problem starting Performance Poll:" + e.toString() + "\n");
            JOptionPane.showMessageDialog(this, "Problem with starting Performance Poll."+e.toString(), "DWDM 10G Performance Poll", JOptionPane.WARNING_MESSAGE);
            System.exit(0);
        }*/
    }
    
    
    
    private void setUpDisplay()
    {   
       /* this.setTitle("UTL - MP - 0072 Spectrum DWDM Performance Service");
            
        this.getRootPane().setBorder(new BevelBorder(BevelBorder.RAISED));
        
        // add WindowCloseAdapter to catch window close-box closings
        addWindowListener(new WindowCloseAdapter());

        
        theMenubar = new MenuBar();
        this.setMenuBar(theMenubar);
        fileMenu = new Menu("File");
        
        aboutItem = new MenuItem("About...");
        aboutItem.setActionCommand("about");
        aboutItem.addActionListener(this);
       // fileMenu.add(aboutItem);
        
        fileMenu.addSeparator();
        
        quitItem = new MenuItem("Quit");
        quitItem.setActionCommand("quit");
        quitItem.addActionListener(this);
        fileMenu.add(quitItem);
        
        theMenubar.add(fileMenu);
        
        
        authorLabel = new JLabel(" Version 1.0");
        authorLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
            
        
        clearButton = new JButton("Clear messages");
        clearButton.setActionCommand("clear messages");
        clearButton.addActionListener(this);
        
        messagesArea = new JTextArea(10,60);
        messagesScroll = new JScrollPane(messagesArea);
        
        
        // now set up display
        
        // set params for layout manager
        GridBagLayout  theLayout = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();
        
        c.gridwidth = 1;
        c.gridheight = 1;
        c.fill = GridBagConstraints.NONE;
        c.ipadx = 0;
        c.ipady = 0;
        c.insets = new Insets(2,2,2,2);
        c.anchor = GridBagConstraints.CENTER;
        c.weightx = 0;
        c.weighty = 0; 
               
        
        JPanel messagesPanel = new JPanel();
        messagesPanel.setLayout(theLayout);
        
        c.gridx = 1;
        c.gridy = 1;
        c.anchor = GridBagConstraints.WEST;
        JLabel messagesLabel = new JLabel("Performance Poll:");
        theLayout.setConstraints(messagesLabel, c);
        messagesPanel.add(messagesLabel);
        
        c.gridx = 2;
        c.gridy = 1;
        c.anchor = GridBagConstraints.EAST;
        theLayout.setConstraints(clearButton, c);
        messagesPanel.add(clearButton);
        
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 2;
        c.weightx = .5;
        c.weighty = .5;
        c.anchor = GridBagConstraints.CENTER;
        theLayout.setConstraints(messagesScroll, c);
        messagesPanel.add(messagesScroll);
        
        
        c.gridwidth = 1;
        c.weightx = 0;
        c.weighty = 0;
        
        
        
        this.getContentPane().setLayout(theLayout);
        
        
        c.fill = GridBagConstraints.BOTH;
        c.gridx = 1;
        c.gridy = 1;
        c.weightx = .5;
        c.weighty = .5;
        theLayout.setConstraints(messagesPanel, c);
        this.getContentPane().add(messagesPanel);
        
        c.fill = GridBagConstraints.NONE;
        c.gridx = 1;
        c.gridy = 2;
        c.weightx = 0;
        c.weighty = 0;
        theLayout.setConstraints(authorLabel, c);
        this.getContentPane().add(authorLabel);
        */
        
    }
        
    
   /* public void actionPerformed(ActionEvent theEvent)
    // respond to button pushes, menu selections
    {
        String command = theEvent.getActionCommand();
        
    
        if (command == "quit")
        {
            readerThread.interrupt();
            System.exit(0);
        }
        
        
        
        if (command == "clear messages")
        {
            messagesArea.setText("");
        }
        
        
        
        if (command == "about")
        {
            //AboutDialog aboutDialog = new AboutDialog(this);
        }
        
              
    }*/

    public void run()
    {
    	short temp=0;
    	while (true) {
    		temp++;
 		    if(temp>10){
 			   temp=0;
 			 //  messagesArea.setText("");
 			  System.out.println("");
 		    }
 		   short InventoryTime=1440;
 		  // short InventoryTime=2880;
 		 //  short InventoryTime = 0;
			/*try {
				//short intervals[]=ServiceSettings.getServiceSettings();
				//short intervals[]=  ;
				InventoryTime = intervals[1];
				System.out.println("InventoryTime"+InventoryTime);
			} catch (Exception e) {
			}*/
			patience = 1000 * 60 * InventoryTime;
			System.out.println("patience"+patience);
    		long startTime = System.currentTimeMillis();
    		Connection conn = null;
    		PreparedStatement psForSelectNodeDetails = null;
    		ResultSet rsForSelectNodeDetails = null;
    		SNMPInventoryRunnable runnableObj = null;
    		int nodeDetailsID;
    		String nodeIP;
    		String nodeType;
    		byte channelNumber;
    		List<List<String>> nodeDetailsAll=new ArrayList<List<String>>();
    		try {
    			Date date = new Date();
    			//messagesArea.append("Polling start at "+date.toString());
    			System.out.println("Polling start at "+date.toString());   
	    		//messagesArea.append("\n");
	    		System.out.println("\n");   
	    		//System.out.println("111111111111111111111111111");
    			conn = DataSource.getInstance().getConnection();
    			//System.out.println("22222222222222222222222222222");
    			psForSelectNodeDetails = conn.prepareStatement("SELECT node_details_id,node_ip_address,node_type,node_channel_number FROM node_details");
    			//System.out.println("33333333333333333333333333333");
    			rsForSelectNodeDetails = psForSelectNodeDetails.executeQuery();
    			//System.out.println("444444444444444444444444444444");
        		
    			List<String> nodeDetailsEach;
    			while (rsForSelectNodeDetails.next()) {
    				nodeDetailsEach=new ArrayList<String>();
    				nodeDetailsEach.add(rsForSelectNodeDetails.getString("node_details_id"));
    				nodeDetailsEach.add(rsForSelectNodeDetails.getString("node_ip_address"));
    				nodeDetailsAll.add(nodeDetailsEach);
    			}
    			//System.out.println("nodeDetailsAll"+nodeDetailsAll);
    		} catch (Exception e) {
    			e.printStackTrace();
    		} finally {
    			if (rsForSelectNodeDetails != null) {
    				try {
    					rsForSelectNodeDetails.close();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
    			}
    			if (psForSelectNodeDetails != null) {
    				try {
    					psForSelectNodeDetails.close();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
    			}
    			if (conn != null) {
    				try {
    					conn.close();
    				} catch (SQLException e) {
    					e.printStackTrace();
    				}
    			}
    		}

    		try{
    			Collection<Future<?>> futures = new LinkedList<Future<?>>();
    			for(List<String> nodeDetailsEach:nodeDetailsAll){
    				nodeDetailsID = Integer.parseInt(nodeDetailsEach.get(0));
    				//System.out.println("nodeDetailsID"+nodeDetailsID);
    				nodeIP = nodeDetailsEach.get(1);
    				//System.out.println("nodeIP"+nodeIP);
    				runnableObj = new SNMPInventoryRunnable(nodeIP,
    						nodeDetailsID,snmpInventoryPollDWDMObj);
    				futures.add(executorServiceObj.submit(runnableObj));
    			}

    			//new UpdateAcitveThreadCount(executorServiceObj, authorLabel).start();
    			//wait the thread  certain amount of  time  
    			long executionTime=System.currentTimeMillis() - startTime;
    				try {
    					long threadSleepTime=patience-executionTime;
//    					messagesArea.append("thread sleep time: "+threadSleepTime+" \n");
    					Thread.sleep(threadSleepTime);
    				} catch (InterruptedException e) {
    					e.printStackTrace();
    				}

    			// cancel the uncompleted thread's with in certain amount of time
    			for (Future<?> future:futures) {
    				future.cancel(true);
    			}

    			//debug
    			/*try {
    				while(executorServiceObj.getActiveCount()!=0){
    					Thread.sleep(2000);
    				}
					
				} catch (Exception e) {
					e.printStackTrace();
				}*/
    			//messagesArea.append("Task Count "+executorServiceObj.getTaskCount()+" Completed Task "+executorServiceObj.getCompletedTaskCount()+" Active Count "+executorServiceObj.getActiveCount()+" \n");
    			Date date = new Date();
				//messagesArea.append("Polling end at "+date.toString()+"\n\n");
    			System.out.println("Polling end at "+date.toString());   
    		}catch(Exception e){
    			e.printStackTrace();
    		}

    	}
	}
    
    public static void main(String args[]) 
    {
        try
        {
        	/*String softwareType=null;
        	try {
				softwareType = GetSoftwareType.getType();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,e.getMessage(),"Performance Poll Service", JOptionPane.ERROR_MESSAGE);
	        	System.exit(0);
			}*/
        	serverSocketObj=new ServerSocket(9997); 
        	executorServiceObj = (ThreadPoolExecutor) Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        	snmpInventoryPollDWDMObj = new SNMPInventoryPollDWDM();
        	
        	//snmpPerformancePollDWDMObj.pack();
        	//snmpPerformancePollDWDMObj.setSize(700,500);
        	
        
        	
        	/*if("u/system/t/management/l/element".equals(softwareType)){
        		snmpPerformancePollDWDMObj.setVisible(true);
        	}else{
        		snmpPerformancePollDWDMObj.setVisible(false);
        		TrayIconForSNMPPerformancePoll trayIcon=new TrayIconForSNMPPerformancePoll();
            	trayIcon.createAndShowTrayIcon(snmpPerformancePollDWDMObj);
        	}*/
        	
        }catch (IOException e) {
        	//JOptionPane.showMessageDialog(null, "Performance Poll Service already running..",e.getMessage(), JOptionPane.ERROR_MESSAGE);
        	 // e.getMessage();
    		  System.out.println("Inventory Poll Service already running.");
    		  System.exit(0);
        }
        catch (Exception e)
        {
        	//JOptionPane.showMessageDialog(null,e.getMessage(), "Performance Poll", JOptionPane.ERROR_MESSAGE);
        	// e.getMessage();
        	 System.out.println("Inventory Poll.");
        	 System.exit(0);
        }
    }
    
}

class UpdateAcitveThreadCount extends Thread{

	ThreadPoolExecutor executorServiceObj;
	JLabel updateCount;
	
	public UpdateAcitveThreadCount(ThreadPoolExecutor executorServiceObj, JLabel updateCount) {
		super();
		this.executorServiceObj = executorServiceObj;
		this.updateCount = updateCount;
	}

	@Override
	public void run() {
		boolean stop=true;
		
		while(stop){
			short count=(short) executorServiceObj.getActiveCount();
			if(count<1){
				stop=false;
			}
			updateCount.setText("Active Count "+count);
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}