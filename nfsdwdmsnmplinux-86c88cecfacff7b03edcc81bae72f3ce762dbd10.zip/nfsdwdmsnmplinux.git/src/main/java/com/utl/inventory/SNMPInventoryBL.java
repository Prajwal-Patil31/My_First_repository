package com.utl.inventory;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;


import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPSet;
import com.utl.snmp4j.SNMPVersionDetails;

public class SNMPInventoryBL {

	private final static String community = "public";
	private final static String communitySet = "all-rights";
	private final static byte retries = 0;
	private final static short timeOut = 25000;

	public static String getAmplifiersPerformance(short nodeNumber, byte rackNumber, short subrackNumber,
			byte slotNumber,byte interfaceNumber, String nodeIP, SNMPVersionDetails userDetails,short cardID,short performancePeramaters,short performanceorsettings) throws Exception {
		
		VariableBinding inputOID = new VariableBinding(new OID(new int[] { 1, 3, 6, 1, 4, 1, 18036, 1, 1, 1, cardID, performanceorsettings, 1, 1,
				performancePeramaters, nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber }));
		VariableBinding resultVB = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);

		return resultVB.getVariable().toString();
	}
	
	public static String getClientLinePerformance(short nodeNumber, byte rackNumber, short subrackNumber,
			byte slotNumber,byte interfaceNumber, String nodeIP, SNMPVersionDetails userDetails,short cardID,short performancePeramaters,short performanceorsettings) throws Exception {
		
		VariableBinding inputOID = new VariableBinding(new OID(new int[] { 1, 3, 6, 1, 4, 1, 18036, 1, 1, 1, cardID, performanceorsettings, 1, 1,
				performancePeramaters, nodeNumber, rackNumber, subrackNumber, slotNumber,interfaceNumber }));
		VariableBinding resultVB = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
	
		return resultVB.getVariable().toString();
		
	}
	
	public static String getPortsfpxfpPresenceStatus(short nodeNumber, byte rackNumber, short subrackNumber,
			short slotNumber,byte portNumber, String nodeIP, SNMPVersionDetails userDetails,short cardID,short alarmID) throws Exception {
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,3,1,1,1,alarmID,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();

	}
	
	public static String getPortTraffic(short nodeNumber, byte rackNumber, short subrackNumber,
			byte slotNumber,byte portNumber, String nodeIP, SNMPVersionDetails userDetails,short cardID,short portTrafficSettingParameters,short configurationParams) throws Exception {
		
		
		VariableBinding inputOID = new VariableBinding(new OID(new int[] { 1, 3, 6, 1, 4, 1, 18036, 1, 1, 1, cardID, configurationParams, 1, 1,
				portTrafficSettingParameters, nodeNumber, rackNumber, subrackNumber, slotNumber,portNumber }));
		VariableBinding resultVB = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);

		return resultVB.getVariable().toString();
	}
	
	public static String getPortTrafficOpticalPerformance(short nodeNumber,byte rackNumber, short subrackNumber,
			byte slotNumber,byte portNumber, String nodeIP, SNMPVersionDetails userDetails,short cardID,short portTrafficSettingParameters,short configurationParams) throws Exception {
		
		
		VariableBinding inputOID = new VariableBinding(new OID(new int[] { 1, 3, 6, 1, 4, 1, 18036, 1, 1, 1, cardID, configurationParams, 1, 1,
				portTrafficSettingParameters,nodeNumber, rackNumber, subrackNumber, slotNumber,portNumber }));
		VariableBinding resultVB = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);

		return resultVB.getVariable().toString();
	}
	
	
	/* Card's Part Code	*/		
		
	public static String getCardPartCode(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte portNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short partCodeID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,partCodeID,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	/* Card's Serial Number */			
	public static String getCardSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte portNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short serialID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,serialID,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}

	/* Software Version Number */	
	public static String getSoftwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte portNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short softwareID) throws Exception{
		// System.out.println("slotNumbere33333333333333333300-------------  " +slotNumber);
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,softwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	
	/* Hardware Version Number */			
	public static String getHardwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte portNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short hardwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,hardwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	/*ROADM Card Serial Number */		
	public static String getMDRoadmCardSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short serialID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,7,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	/*ROADM Software Version */	
	
	public static String getMDRoadmSoftwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short softwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,softwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		float f = Float.parseFloat(resultVB.getVariable().toString());
		String resultString=String.format("%.1f", f );
		return resultString;
	}
	
	
	/*ROADM Hardware Version */		
	public static String getMDRoadmHardwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short hardwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,hardwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		float f = Float.parseFloat(resultVB.getVariable().toString());
		String resultString=String.format("%.1f", f );
		return resultString;
		//return resultVB.getVariable().toString();
	}
	
	/*ROADMPLUS Card Serial Number */	
	
	public static String getMDRoadmplusCardSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short serialID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,7,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	/*ROADMPLUS partCodeID */	
	
	public static String getMDRoadmplusCardPartCode(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short partCodeID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,partCodeID,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	/*ROADMPLUS Software Version */	
	
	public static String getMDRoadmplusSoftwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short softwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,softwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
	}
	
	
	/*ROADMPLUS Hardware Version */	
	
	public static String getMDRoadmplusHardwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short directionNumber,short portType,short channelNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short hardwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,hardwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber,portType,channelNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
	
		return resultVB.getVariable().toString();
	}
	
	/*BMU SCU Card Serial Number */	
	public static String getBMUSCUCardSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short serialID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,serialID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		

		return resultVB.getVariable().toString();
				
	}
	
	/*Amplier Card Serial Number */	
	public static String getAmplifierCardSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short serialID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,serialID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		String ampSerial = "UTLMPHFCLA0916O" + resultVB.getVariable().toString();

	//	return resultVB.getVariable().toString();
				return ampSerial;
	}
	
	/*Amplier Software Version Number */	
	public static String getAmplifierPlusCardPartCode(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short partCodeID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,partCodeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		String ampPartCode =resultVB.getVariable().toString();

	//	return resultVB.getVariable().toString();
				return ampPartCode;
	}
	
	public static String getAmplifierPlusCardSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short serialID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,serialID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		String ampSerial =resultVB.getVariable().toString();

	//	return resultVB.getVariable().toString();
				return ampSerial;
	}

	/*Amplier Software Version Number */	
		
	
	
	public static String getAmplifierSoftwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short softwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,softwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	
	/* Amplier Hardware Version Number */	
		
	public static String getAmplifierHardwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short hardwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,hardwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	public static String getAmplifierPlusSoftwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short softwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,softwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	
	
	/* Amplier Hardware Version Number */	
		
	public static String getAmplifierPlusHardwareVersion(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short hardwareID) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,hardwareID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toString();
	}
	//All Amplifiers SoftWare Update
	public static void setAmplifiersSoftwareUpgrade(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String softwareUpgradeValue,String nodeIP,SNMPVersionDetails userDetails,short cardID,short swupgradeID) throws Exception{
		OctetString value=new OctetString(softwareUpgradeValue);
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,2,1,1,swupgradeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}),value);
		SNMPSet.setSNMP(nodeIP, communitySet, retries, timeOut, inputOID, userDetails);		
	}
	//All Line Cards SoftWare Update
		public static void setLineCardsSoftwareUpgrade(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte portNumber,String softwareUpgradeValue,String nodeIP,SNMPVersionDetails userDetails,short cardID,short swupgradeID) throws Exception{
			OctetString value=new OctetString(softwareUpgradeValue);
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,2,1,1,swupgradeID,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}),value);
			SNMPSet.setSNMP(nodeIP, communitySet, retries, timeOut, inputOID, userDetails);		
		}
		//MuxDemuxScu SoftWare Update
		public static void setMuxDeMuxScuPlusSoftwareUpgrade(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String softwareUpgradeValue,String nodeIP,SNMPVersionDetails userDetails,short cardID,short swupgradeID) throws Exception{
			OctetString value=new OctetString(softwareUpgradeValue);
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,2,1,1,swupgradeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}),value);
			SNMPSet.setSNMP(nodeIP, communitySet, retries, timeOut, inputOID, userDetails);		
		}
		//MdRoadmPlus Software Update

		public static void setMdRoadmPlusSoftwareUpgrade(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short mantisDirectionNo,short mantisPortType,short mantisChannelNo,String softwareUpgradeValue,String nodeIP,SNMPVersionDetails userDetails,short cardID,short swupgradeID) throws Exception{

			OctetString value=new OctetString(softwareUpgradeValue);

			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,2,1,1,swupgradeID,nodeNumber,rackNumber,subrackNumber,slotNumber,mantisDirectionNo,mantisPortType,mantisChannelNo}),value);

			SNMPSet.setSNMP(nodeIP, communitySet, retries, timeOut, inputOID, userDetails);		
		}
		
		//SCC Software Update
		public static void setSCCSoftwareUpgrade(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String softwareUpgradeValue,String nodeIP,SNMPVersionDetails userDetails,short cardID,short swupgradeID) throws Exception{
			OctetString value=new OctetString(softwareUpgradeValue);
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,1,2,1,1,swupgradeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}),value);
			SNMPSet.setSNMP(nodeIP, communitySet, retries, timeOut, inputOID, userDetails);		
		}
		public static String getSccSoftwareFiles(short nodeNumber, short rackNumber, short subrackNumber,
				short slotNumber,short swtype, String nodeIP,  SNMPVersionDetails userDetails) throws Exception {
			
			VariableBinding inputOID = new VariableBinding(new OID(new int[] { 1, 3, 6, 1, 4, 1, 18036, 1, 1, 1, 1, 2, 1, 1, swtype ,nodeNumber, rackNumber, subrackNumber, slotNumber, 0 }));
			VariableBinding resultVB = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);

			return resultVB.getVariable().toString();
		}	
		
		
		public static String getAmplifierPlusXFPModel(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short xfpmodel) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,xfpmodel,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
	
		
		public static String getSfpSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpserialID) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfpserialID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getSFPPartCode(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfppartCodeID) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfppartCodeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getSFPStatus(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpstatus) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,3,1,1,1,sfpstatus,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
			
		public static String getSFPModel(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpmodel) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfpmodel,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
///
		public static String getSCCSfpSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpserialID) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfpserialID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getSCCSFPPartCode(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfppartCodeID) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfppartCodeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getSCCSFPStatus(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpstatus) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,2,1,1,sfpstatus,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getSCCSFPModel(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpmodel) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfpmodel,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getAplifierSFPModel(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpmodel) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfpmodel,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		
		
		public static String getXfpSerialNumber(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfpserialID) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfpserialID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getXFPPartCode(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short sfppartCodeID) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,sfppartCodeID,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getXFPModel(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short xfpmodel) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,1,1,1,xfpmodel,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
		
		public static String getXFPStatus(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber,String nodeIP,SNMPVersionDetails userDetails,short cardID,short xfpstatus) throws Exception{
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,cardID,3,1,1,1,xfpstatus,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
			VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
			return resultVB.getVariable().toString();
		}
}
