package com.utl.inventory;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.obaplus.PerformanceOBAPLUSBL;
import com.utl.performance.olaplus.PerformanceOLAPLUSBL;
import com.utl.performance.ommp40.PerformanceOMMP40BL;
import com.utl.performance.ommp81plus.PerformanceOMMP81PLUSBL;
import com.utl.performance.ommp82plus.PerformanceOMMP82PLUSBL;
import com.utl.performance.omtp100.PerformanceOMTP100BL;
import com.utl.performance.omtp11plus.PerformanceOMTP11PLUSBL;
import com.utl.performance.omtp11tplus.PerformanceOMTP11TPLUSBL;
import com.utl.performance.omtp12plus.PerformanceOMTP12PLUSBL;
import com.utl.performance.opaplus.PerformanceOPAPLUSBL;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.StringArray;

public class SNMPInventoryRunnable implements Runnable {
	private String nodeIP;
	private int nodeDetailsID;
	private SNMPInventoryPollDWDM inventoryPollGuiObj;
	ArrayList<String> tempLiveAlarms;
	ArrayList<ArrayList<String>> data=new ArrayList<ArrayList<String>>();

	public ArrayList<ArrayList<String>> getData() {
		return data;
	}

	public void setData(ArrayList<ArrayList<String>> data) {
		this.data = data;
	}

	public ArrayList<String> getTempLiveAlarms() {
		return tempLiveAlarms;
	}

	public void setTempLiveAlarms(ArrayList<String> tempLiveAlarms) {
		this.tempLiveAlarms = tempLiveAlarms;
	}

	public SNMPInventoryRunnable(String nodeIP, int nodeDetailsID,
			SNMPInventoryPollDWDM inventoryPollGuiObj) {
		super();
		this.nodeIP = nodeIP;
		this.nodeDetailsID = nodeDetailsID;
		this.inventoryPollGuiObj=inventoryPollGuiObj;
	}

	@Override
	public void run(){
		JTextArea messagesArea=inventoryPollGuiObj.messagesArea;
		//messagesArea.append("started Performance Poll for node : "+nodeIP+" \n");
		System.out.println(	"started Inventory Poll for node : "+nodeIP+" \n"); 
		/*String cardName;
		long dwdmSlotMasterId = 0;
		long dwdmPortMasterId = 0;
		String trafficName = null;
		short rackNumber =1;
		short subrackNumber =1;
		short slotNumber = 1;
		short portNumber = 1;
		short portTrafficTypeID = 0;
		String portClientLineType = null;
		int cardID = 0;
		List<List<String>> dwdmMasterDetailsAll=null;*/

		try {
			VariableBinding result = null;
			try {
				result = getSystemDescription(nodeIP);
			} catch (Exception e) {
				try {
					result = getSystemDescription(nodeIP);
				} catch (Exception e1) {
				}
			}
			/*if(result!=null){
				//dwdmMasterDetailsAll=SNMPInventoryDAO.getPerformanceCards(nodeDetailsID);
				List<StringArray> lLiveAlarms = SNMPInventoryModel.getCardInventoryReportsModel(nodeDetailsID);
				Thread currentThreadObj = Thread.currentThread();
				for (List<String> dwdmMasterDetailsEach:dwdmMasterDetailsAll) {
					
					try {
						if(!currentThreadObj.isInterrupted()){
							
							dwdmSlotMasterId = Long.parseLong(dwdmMasterDetailsEach.get(0));
							cardName = dwdmMasterDetailsEach.get(1);
							if(cardName.equals("10GOMTP11PLUS")||cardName.equals("10GOMTP11TPLUS")||cardName.equals("10GOMTP12PLUS")||cardName.equals("10GOMMP82PLUS")||cardName.equals("10GOMMP81PLUS")){
								dwdmPortMasterId = Long.parseLong(dwdmMasterDetailsEach.get(2));
								trafficName = dwdmMasterDetailsEach.get(3);
								rackNumber =Short.parseShort(dwdmMasterDetailsEach.get(4));
								subrackNumber =Short.parseShort(dwdmMasterDetailsEach.get(5));
								slotNumber =Short.parseShort(dwdmMasterDetailsEach.get(6));
								portNumber  =Short.parseShort(dwdmMasterDetailsEach.get(7));
								portTrafficTypeID = Short.parseShort(dwdmMasterDetailsEach.get(8));
								portClientLineType = dwdmMasterDetailsEach.get(9);
							}
							else //for obaplus,opaplus,olaplus cards
							{
								dwdmPortMasterId = 0;							
								rackNumber =Short.parseShort(dwdmMasterDetailsEach.get(4));
								subrackNumber =Short.parseShort(dwdmMasterDetailsEach.get(5));
								slotNumber =Short.parseShort(dwdmMasterDetailsEach.get(6));
								portNumber  = 0;							
							}
							System.out.println(dwdmMasterDetailsEach);

							switch (cardName) {
							case "OPA1PLUS":
							case "OPA2PLUS":
							case "OPA3PLUS":
							case "OPA4PLUS":	
								PerformanceOPAPLUSBL.proccessRequest(dwdmSlotMasterId, rackNumber, subrackNumber, slotNumber, (short)0, nodeIP);	
								break;
							case "OBA1PLUS":
							case "OBA2PLUS":
							case "OBA3PLUS":
							case "OBA4PLUS":
								PerformanceOBAPLUSBL.proccessRequest(dwdmSlotMasterId, rackNumber, subrackNumber, slotNumber, (short)0, nodeIP);								
								break;
							case "OLA1PLUS":
							case "OLA2PLUS":
							case "OLA3PLUS":
							case "OLA4PLUS":
								PerformanceOLAPLUSBL.proccessRequest(dwdmSlotMasterId, rackNumber, subrackNumber, slotNumber, (short)0, nodeIP);
								break;
						    case "10GOMTP12PLUS":
								if("line".equals(portClientLineType)){
									portNumber +=1;
								}
								PerformanceOMTP12PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								
								break;
							case "10GOMTP11PLUS":
								if("line".equals(portClientLineType)){
								portNumber +=1;
								}
								PerformanceOMTP11PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								
								break;
							case "10GOMTP11TPLUS":
								if("line".equals(portClientLineType)){
									portNumber +=0;
								}
								PerformanceOMTP11TPLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
						
								break;
							case "10GOMMP81PLUS":
								if("line".equals(portClientLineType)){
									portNumber +=8;
								}
								PerformanceOMMP81PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								
								break;
							case "10GOMMP82PLUS":
								if("line".equals(portClientLineType)){
									portNumber +=8;
								}
								PerformanceOMMP82PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								break;
								
								
							}
						}else{
							//messagesArea.append("Performance Poll Is Not Completed With In Time For : "+nodeIP+" \n");
							System.out.println("inventory Poll Is Not Completed With In Time For : "+nodeIP+" \n");
							
							return;
						}
					}catch (Exception e) {
						System.out.println(nodeIP+"  "+ cardID+"    "+ dwdmSlotMasterId+"   "+e.getMessage());
						e.printStackTrace();
					}
				}
			}else{
				//messagesArea.append("Node is Down : "+nodeIP+" \n");
				System.out.println("Node is Down : "+nodeIP+" \n");
				
			}*/
			
			///////////////// Card Inventory Update //////////////////////////////
			 List<StringArray> lLiveAlarms = SNMPInventoryModel.getCardInventoryReportsModel(nodeDetailsID);
			 System.out.println("##################lLiveAlarms#################"+lLiveAlarms);
			 
			 
			 
			 String cardSerialnumber = null;
			 String softwareVersion= null;
			 String hardwareVersion = null;
			 String nodeid= null;
			 String slotmasterid = null;
			 String cardName = null;
			 String rackNumber = "1";
			 String subrackNumber = null;
			 String cardAddress = null;
			 String cardPartCode = null;
			 int slotNumber = 0;
			 String strSlotNumber = null;
			 if(lLiveAlarms.size()!=0){
				 for (int i = 0; i < lLiveAlarms.size(); i++) {
						tempLiveAlarms=new ArrayList<String>();
						tempLiveAlarms.add(""+(i+1));
						StringArray saLiveAlarms = lLiveAlarms.get(i);
						List<String> lEachLiveAlarmDetails = saLiveAlarms.getItem();
						//System.out.println(lEachLiveAlarmDetails);
						cardName=lEachLiveAlarmDetails.get(0);
						//String rackNumber=lEachLiveAlarmDetails.get(1);
						 subrackNumber=lEachLiveAlarmDetails.get(1);
						 slotNumber=Integer.parseInt(lEachLiveAlarmDetails.get(2));
						 strSlotNumber=lEachLiveAlarmDetails.get(2);
						//portNumber=lEachLiveAlarmDetails.get(4);						
						//alarmName=lEachLiveAlarmDetails.get(3);
						//alarmSeverity=lEachLiveAlarmDetails.get(4);
						//alarmGeneratedTime=""+lEachLiveAlarmDetails.get(5).subSequence(0, lEachLiveAlarmDetails.get(5).length()-2);	
						String cardNameToDisplay=cardName.replace("PLUS","");
						cardNameToDisplay=cardNameToDisplay.replace("_plus", "");
						cardNameToDisplay=cardNameToDisplay.toUpperCase();
						tempLiveAlarms.add(cardNameToDisplay);//shelf number(in cardName i saved shelf number only in bmu case)
						//tempLiveAlarms.add(rackNumber);// rack number
						tempLiveAlarms.add(subrackNumber);//sub rack number
						if(slotNumber==254)
						{
							slotNumber=1;
						}
						tempLiveAlarms.add(slotNumber+"");//shelf number(in alarmSeverity i saved tray number only in bmu case)
						//tempLiveAlarms.add(portNumber);	
						softwareVersion=lEachLiveAlarmDetails.get(3);
						hardwareVersion=lEachLiveAlarmDetails.get(4);
						
						if(!lEachLiveAlarmDetails.get(3).contains("."))
						{
							softwareVersion=lEachLiveAlarmDetails.get(3).substring(0, 1)+"."+lEachLiveAlarmDetails.get(3).substring(1, lEachLiveAlarmDetails.get(3).length());
						    if (softwareVersion.length()==2)
						    	softwareVersion = softwareVersion+"0";
						}
						else
						{
							softwareVersion=lEachLiveAlarmDetails.get(3).substring(0, 1)+".0";
						}
						if(!lEachLiveAlarmDetails.get(4).contains("."))
						{
							hardwareVersion=lEachLiveAlarmDetails.get(4).substring(0, 1)+"."+lEachLiveAlarmDetails.get(4).substring(1, lEachLiveAlarmDetails.get(4).length());
						}
						else
						{
							hardwareVersion=lEachLiveAlarmDetails.get(4).substring(0, 1)+".0";
						}
						if (softwareVersion.length() == 5)
							softwareVersion = softwareVersion.substring(0, softwareVersion.length() - 2);
						//System.out.println("softwareVersion inventory  ==>" + softwareVersion +"========------------");
						
						if (hardwareVersion.length() == 5)
							hardwareVersion = hardwareVersion.substring(0, hardwareVersion.length() - 2);
							
							
						if(cardName.contains("MD-ROADM"))
						{	
					//	softwareVersion=softwareVersion;
					//	hardwareVersion=hardwareVersion;
						 softwareVersion = "3.0";								 
						 }
						
						else
						{
							softwareVersion="1.0";
							hardwareVersion="1.0";	
						}
						
						tempLiveAlarms.add(softwareVersion);
						tempLiveAlarms.add(hardwareVersion);
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(5)); //serial number
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(6)); //part code
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(7)); //slotid
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(8)); //nodeid
						
						data.add(tempLiveAlarms);
						//System.out.println("Invetory Details lEachLiveAlarmDetails.get(5)" + lEachLiveAlarmDetails.get(5) +"========------------");
						 cardSerialnumber = lEachLiveAlarmDetails.get(5);
						 cardPartCode = lEachLiveAlarmDetails.get(6);
						 slotmasterid = lEachLiveAlarmDetails.get(7);
						 nodeid = lEachLiveAlarmDetails.get(8);
						//System.out.println("slotmasterid  ==>" + slotmasterid +"========------------");					 
						 
						
				 }
				 	
				} 
			 	//byte result = ReportsDAO.updateCardSerialNumber(nodeid, cardSerialnumber,slotmasterid);
			 	//if(result!=0){
				//	status="success";
				//}
			//System.out.println("softwareVersion  ==>" + softwareVersion +"========------------");
			 SNMPInventoryDAO.updateCardSerialNumberDetails(nodeid, cardSerialnumber,slotmasterid,lLiveAlarms,softwareVersion,hardwareVersion, cardName,subrackNumber,strSlotNumber,cardAddress, cardPartCode);
			
			 ////////////// Port Inventory ////////////
			 cardPortInventoryGet();
			 //////////////////////////////////////
			 
			 
			 //////////////SFP/XFP Inventory ////////////
			 cardPortXFPSFPInventoryGet();
			 /////////////////////////////////////////////
			 
		
		} catch (Exception e1) {
				e1.printStackTrace();
			}
	
		//messagesArea.append("ended Performance Poll for node : "+nodeIP+" \n");
		System.out.println("ended Inventory Poll for node : "+nodeIP+" \n");
	}
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=10000;
	public static VariableBinding getSystemDescription(String nodeIP) throws Exception{
		VariableBinding result=null;
		try {
			VariableBinding descOID        = new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,1,0}));
			result = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, descOID, new SNMPVersionDetails());
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public void cardPortInventoryGet()
	{
			/////////////////////
			//Port Inventory
			//////////////////////
			try {
			//String portNumber="",alarmName="",alarmSeverity="",alarmGeneratedTime="";
			List<StringArray> lLiveAlarms = SNMPInventoryModel.getCardAndPortInventoryReportsModel(nodeDetailsID);
			String portmasterid = null;
			String porttype= null;
			String portnumber = null;
			String nodeid= null;
			String slotmasterid = null;
			String cardName = null;
			String rackNumber = "0";
			String subrackNumber = null;
			String portAddress = null;
			String portParentCard = null;
			String trafficname = null;
			int slotNumber = 0;
			String strSlotNumber = null;
			if(lLiveAlarms.size()!=0){
			for (int i = 0; i < lLiveAlarms.size(); i++) {
				tempLiveAlarms=new ArrayList<String>();
				tempLiveAlarms.add(""+(i+1));
				StringArray saLiveAlarms = lLiveAlarms.get(i);
				List<String> lEachLiveAlarmDetails = saLiveAlarms.getItem();
				//System.out.println(lEachLiveAlarmDetails);
				cardName=lEachLiveAlarmDetails.get(0);
				rackNumber=lEachLiveAlarmDetails.get(1);
				subrackNumber=lEachLiveAlarmDetails.get(2);
				slotNumber=Integer.parseInt(lEachLiveAlarmDetails.get(3));
				strSlotNumber=lEachLiveAlarmDetails.get(3);
			
				String cardNameToDisplay=cardName.replace("PLUS","");
				cardNameToDisplay=cardNameToDisplay.replace("_plus", "");
				cardNameToDisplay=cardNameToDisplay.toUpperCase();
				tempLiveAlarms.add(cardNameToDisplay);//shelf number(in cardName i saved shelf number only in bmu case)
				tempLiveAlarms.add(rackNumber);//rack number
				tempLiveAlarms.add(subrackNumber);//sub rack number
				//if(slotNumber==254)
				//{
				//	slotNumber=1;
				//}					
				//tempLiveAlarms.add(slotNumber+"");//shelf number(in alarmSeverity i saved tray number only in bmu case)
				tempLiveAlarms.add(strSlotNumber);
				tempLiveAlarms.add(lEachLiveAlarmDetails.get(4)); //slotid
				tempLiveAlarms.add(lEachLiveAlarmDetails.get(5)); //nodeid
				tempLiveAlarms.add(lEachLiveAlarmDetails.get(6)); //dwdm_port_master_id
				tempLiveAlarms.add(lEachLiveAlarmDetails.get(7)); //port_client_line_type
				tempLiveAlarms.add(lEachLiveAlarmDetails.get(8)); //port_number
				tempLiveAlarms.add(lEachLiveAlarmDetails.get(9)); //traffic_name
			
				data.add(tempLiveAlarms);
			
				slotmasterid = lEachLiveAlarmDetails.get(4);
				nodeid = lEachLiveAlarmDetails.get(5);
				portmasterid = lEachLiveAlarmDetails.get(6);
				porttype = lEachLiveAlarmDetails.get(7);
				portnumber = lEachLiveAlarmDetails.get(8);
				trafficname = lEachLiveAlarmDetails.get(9);
				
				}
				
			} 		 
			SNMPInventoryDAO.updateCardPortSerialNumberDetails(nodeid,slotmasterid,portmasterid,lLiveAlarms,cardName,rackNumber,subrackNumber,strSlotNumber,portAddress,portParentCard, porttype,portnumber,trafficname);
			//result = ReportsDAO.updateCardPortSerialNumberDetails(nodeid,slotmasterid,lLiveAlarms,cardName,rackNumber,subrackNumber,strSlotNumber);
			//cardSCCPortInventoryGet();
			
			} catch (Exception e) {
			e.printStackTrace();
			}
		
		//return "SUCCESS";
	}
	
	//SFP/XFP Inventory
	public void cardPortXFPSFPInventoryGet()
	{

		/////////////////////
		//XFP/SFP Inventory
		//////////////////////
		try {
			 //String portNumber="",alarmName="",alarmSeverity="",alarmGeneratedTime="";
			// List<StringArray> lLiveAlarms = ReportsModel.getCardandXFPSFPInventoryReportsModel(nodeID);
			 List<StringArray> lLiveAlarms = SNMPInventoryModel.getCardXfpSfpInventoryReportsModel(nodeDetailsID);
			 String sfpSerialnumber = null;
			 String sfpModel= null;
			 String sfpstatus = null;
			 String nodeid= null;
			 String slotmasterid = null;
			 String portmasterid = null;
			 String cardName = null;
			 String rackNumber = null;
			 String subrackNumber = null;
			 String sfpAddress = null;
			 String sfpPartCode = null;
			 String portnumber = null;
			 String sfpcapacity = null;
			 String sfpname = null;
			 String trafficType = null;
			 int slotNumber = 0;
			 String strSlotNumber = null;
			 if(lLiveAlarms.size()!=0){
				 for (int i = 0; i < lLiveAlarms.size(); i++) {
						tempLiveAlarms=new ArrayList<String>();
						tempLiveAlarms.add(""+(i+1));
						StringArray saLiveAlarms = lLiveAlarms.get(i);
						List<String> lEachLiveAlarmDetails = saLiveAlarms.getItem();				
						cardName=lEachLiveAlarmDetails.get(0);
						rackNumber = lEachLiveAlarmDetails.get(1);				
						subrackNumber=lEachLiveAlarmDetails.get(2);
						slotNumber=Integer.parseInt(lEachLiveAlarmDetails.get(3));
						strSlotNumber=lEachLiveAlarmDetails.get(3);					
						String cardNameToDisplay=cardName.replace("PLUS","");
						cardNameToDisplay=cardNameToDisplay.replace("_plus", "");
						cardNameToDisplay=cardNameToDisplay.toUpperCase();		
						
						tempLiveAlarms.add(cardNameToDisplay);//shelf number(in cardName i saved shelf number only in bmu case)					
						tempLiveAlarms.add(rackNumber);// rack number
						tempLiveAlarms.add(subrackNumber);//sub rack number				
						tempLiveAlarms.add(slotNumber+"");//shelf number(in alarmSeverity i saved tray number only in bmu case)					
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(4)); //nodeid
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(5)); //slotmasterid
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(6)); //portmasterid
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(7)); //portnumber
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(8)); //traffic tyep					
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(9)); //sfpstatus					
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(10)); //sfp serial number
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(11)); //sfp part code
						tempLiveAlarms.add(lEachLiveAlarmDetails.get(12)); //sfp model		
						nodeid = lEachLiveAlarmDetails.get(4);
						slotmasterid = lEachLiveAlarmDetails.get(5);					
						portmasterid = lEachLiveAlarmDetails.get(6);
						portnumber = lEachLiveAlarmDetails.get(7);
						trafficType = lEachLiveAlarmDetails.get(8);
						sfpstatus=lEachLiveAlarmDetails.get(9);		//sfpstatus			
						
						sfpSerialnumber = lEachLiveAlarmDetails.get(10);		
						sfpPartCode = lEachLiveAlarmDetails.get(11);							
						sfpModel =  lEachLiveAlarmDetails.get(12);		
						//sfpAddress = lEachLiveAlarmDetails.get(12);
						//sfpcapacity = lEachLiveAlarmDetails.get(13);
						//sfpname = lEachLiveAlarmDetails.get(14);									
											
						data.add(tempLiveAlarms);					
				 }
				 	
				} 		 
			 	SNMPInventoryDAO.updateCardPortXFPSFPDetails(nodeid, slotmasterid,portmasterid,lLiveAlarms,sfpstatus, sfpSerialnumber,cardName,rackNumber, subrackNumber,strSlotNumber,sfpModel,sfpAddress, sfpPartCode, portnumber,trafficType);
			 
			 
		 } catch (Exception e) {
				e.printStackTrace();
		}
		
		//return SUCCESS;
	}
	
}
