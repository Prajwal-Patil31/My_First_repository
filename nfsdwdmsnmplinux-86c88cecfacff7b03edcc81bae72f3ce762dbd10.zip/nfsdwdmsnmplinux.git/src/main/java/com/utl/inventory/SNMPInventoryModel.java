package com.utl.inventory;

import java.util.List;

import com.utl.util.ArrayToStringArray;
import com.utl.util.StringArray;


public class SNMPInventoryModel {

	public static List<StringArray> getCardInventoryReportsModel(int nodeID) throws Exception{
		List<StringArray> currentAlarms=ArrayToStringArray.convertDoubleDimensionToList(SNMPInventoryDAO.getCardInventoryBasedOnNodeIPAddress(nodeID));
		return currentAlarms;
	}
	
	public static List<StringArray> getCardAndPortInventoryReportsModel(int nodeID) throws Exception{
		List<StringArray> currentAlarms=ArrayToStringArray.convertDoubleDimensionToList(SNMPInventoryDAO.getCardAndPortInventoryBasedOnNodeIPAddress(nodeID));
		return currentAlarms;
	}
	
	/*public static List<StringArray> getCardSCCAndPortInventoryReportsModel(int nodeID) throws Exception{
		List<StringArray> currentAlarms=ArrayToStringArray.convertDoubleDimensionToList(ReportsDAO.getCardSCCAndPortInventoryBasedOnNodeIPAddress(nodeID));
		return currentAlarms;
	}*/
	
	public static List<StringArray> getCardXfpSfpInventoryReportsModel(int nodeID) throws Exception{
		List<StringArray> currentAlarms=ArrayToStringArray.convertDoubleDimensionToList(SNMPInventoryDAO.getCardAndXFPSFPInventoryBasedOnNodeIPAddress(nodeID));
		//List<StringArray> currentAlarms=ArrayToStringArray.convertDoubleDimensionToList(ReportsDAO.getCardXFPSFPInventory(nodeID,nodeIP,cardName));
		return currentAlarms;
	}
}
