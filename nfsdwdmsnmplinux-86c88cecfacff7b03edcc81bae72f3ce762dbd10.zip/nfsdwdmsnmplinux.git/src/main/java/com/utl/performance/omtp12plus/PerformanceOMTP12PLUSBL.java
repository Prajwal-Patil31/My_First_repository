package com.utl.performance.omtp12plus;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.omtp12plus.PerfromanceOMTP12PLUSDAO;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;

public class PerformanceOMTP12PLUSBL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=30000;
	
	public static Map<Short,String> getClientOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding   omtp12PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusXfpInputPower);
			
			index = 2;
			VariableBinding   omtp12PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusXfpOutputPower);
			
			index = 3;
			VariableBinding   omtp12PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusXfpBiasCurrent);
			
			// index  4 is reserved
			
			index = 5;
			VariableBinding   omtp12PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusXfpTemperature);
					
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding  ommp12PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp12PlusXfpInputPower);
			
			index = 2;
			VariableBinding  ommp12PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp12PlusXfpOutputPower);

			index = 3;
			VariableBinding  ommp12PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp12PlusXfpBiasCurrent);
			
			//index = 4 is reserved
			
			index = 5;
			VariableBinding  ommp12PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp12PlusXfpTemperature);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getClientSTMPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			
			index=1;
			VariableBinding  ommp12PlusSdhRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,81,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp12PlusSdhRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding  ommp12PlusSdhMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,82,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp12PlusSdhMsB2BitInterleavedParityErrors);
			
			//index 3-5 is reserved;
			
			index=6;
			VariableBinding   omtp12PlusSdhErrorFreeSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,86,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusSdhErrorFreeSeconds);
			
			index=7;
			VariableBinding   omtp12PlusSdhErrorSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,87,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusSdhErrorSeconds);
			
			index=8;
			VariableBinding   omtp12PlusSdhBackgroundBlockErrors      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,88,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusSdhBackgroundBlockErrors);
			
			index=9;
			VariableBinding   omtp12PlusSdhSevereErrorSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,89,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusSdhSevereErrorSeconds);			
			
			index=10;
			VariableBinding   omtp12PlusSdhUnavailableSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,90,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusSdhUnavailableSeconds);
							
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	public static Map<Short,String> getClient10GWANPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding   omtp12PlusWan10gRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,101,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding   omtp12PlusWan10gMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,102,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gMsB2BitInterleavedParityErrors);
			
			//index 3-5 is reserved;
			
			index=6;
			VariableBinding   omtp12PlusWan10gErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,106,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gErrorFreeSeconds);
			
			index=7;
			VariableBinding   omtp12PlusWan10gErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,107,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gErrorSeconds);
			
			index=8;
			VariableBinding   omtp12PlusWan10gBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,108,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gBackgroundBlockErrors);
			
			index=9;
			VariableBinding   omtp12PlusWan10gSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,109,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gSevereErrorSeconds);
			
			index=10;
			VariableBinding   omtp12PlusWan10gUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,110,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusWan10gUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	public static Map<Short,String> getClient10GLANPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding   omtp12PlusLan10gMacTerminatedFramesTransmitted        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,121,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedFramesTransmitted);
			
			index=2;
			VariableBinding   omtp12PlusLan10gMacTerminatedFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,122,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedFramesReceived);
			
//			index 3 is reserved;
			
			index=4;
			VariableBinding   omtp12PlusLan10gMacTerminatedPauseFramesReceived      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,124,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedPauseFramesReceived);
			
			index=5;
			VariableBinding    omtp12PlusLan10gMacTerminatedUnicastFramesTransmitted      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,125,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusLan10gMacTerminatedUnicastFramesTransmitted);	
			
			index=6;
			VariableBinding   omtp12PlusLan10gMacTerminatedUnicastFramesReceived       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,126,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedUnicastFramesReceived);
			
			index=7;
			VariableBinding   omtp12PlusLan10gMacTerminatedMulticastFramesTransmitted        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,127,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedMulticastFramesTransmitted);
			
			index=8;
			VariableBinding   omtp12PlusLan10gMacTerminatedMulticastFramesReceived       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,128,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedMulticastFramesReceived);
			
			index=9;
			VariableBinding   omtp12PlusLan10gMacTerminatedBroadcastFramesTransmitted       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,129,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedBroadcastFramesTransmitted);
			
			index=10;
			VariableBinding   omtp12PlusLan10gMacTerminatedBroadcastFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,130,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedBroadcastFramesReceived);
			
			//index 11 is reserved;
			
			index=12;
			VariableBinding   omtp12PlusLan10gMacTerminatedUnderSizeFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,132,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedUnderSizeFramesReceived);
			
			//index 13 is reserved;
			
			index=14;
			VariableBinding   omtp12PlusLan10gMacTerminatedOverSizeFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,134,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedOverSizeFramesReceived);
			
			//index 15-17 is reserved;
			
			index=18;
			VariableBinding   omtp12PlusLan10gMacTerminatedFragmentFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,138,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedFragmentFramesReceived);
			
			index=19;
			VariableBinding   omtp12PlusLan10gMacTerminatedFrameCheckSequenceErrorsReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,139,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusLan10gMacTerminatedFrameCheckSequenceErrorsReceived);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	
	public static Map<Short,String> getClientOTU2Performance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  omtp12PlusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, omtp12PlusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   omtp12PlusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding   omtp12PlusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   omtp12PlusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   omtp12PlusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBitInterleavedParityErrors);
			
		
			index=6;
			VariableBinding   omtp12PlusOtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   omtp12PlusOtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   omtp12PlusOtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    omtp12PlusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   omtp12PlusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuErrorSeconds);
			
			index=11;
			VariableBinding   omtp12PlusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   omtp12PlusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   omtp12PlusOtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    omtp12PlusOtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    omtp12PlusOtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   omtp12PlusOtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    omtp12PlusOtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    omtp12PlusOtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     omtp12PlusOduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusOduBitInterleavedParityErrors);
			index=32;
			VariableBinding     omtp12PlusOduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusOduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     omtp12PlusOduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusOduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      omtp12PlusOduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp12PlusOduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      omtp12PlusOduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp12PlusOduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       omtp12PlusOduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      omtp12PlusOduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        omtp12PlusOduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduErrorFreeSeconds);
			
			index=49;
			VariableBinding        omtp12PlusOduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduErrorSeconds);
			
			index=50;
			VariableBinding        omtp12PlusOduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        omtp12PlusOduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduSevereErrorSeconds);
			
			index=52;
			VariableBinding        omtp12PlusOduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         omtp12PlusOduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         omtp12PlusOduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         omtp12PlusOduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         omtp12PlusOduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         omtp12PlusOduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOTNPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  omtp12PlusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, omtp12PlusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   omtp12PlusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding   omtp12PlusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   omtp12PlusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   omtp12PlusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBitInterleavedParityErrors);
			
		
			index=4;
			VariableBinding   omtp12PlusOtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   omtp12PlusOtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   omtp12PlusOtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    omtp12PlusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   omtp12PlusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuErrorSeconds);
			
			index=11;
			VariableBinding   omtp12PlusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   omtp12PlusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   omtp12PlusOtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    omtp12PlusOtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    omtp12PlusOtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   omtp12PlusOtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp12PlusOtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    omtp12PlusOtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    omtp12PlusOtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp12PlusOtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     omtp12PlusOduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusOduBitInterleavedParityErrors);
			index=32;
			VariableBinding     omtp12PlusOduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusOduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     omtp12PlusOduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp12PlusOduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      omtp12PlusOduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp12PlusOduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      omtp12PlusOduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp12PlusOduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       omtp12PlusOduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      omtp12PlusOduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        omtp12PlusOduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduErrorFreeSeconds);
			
			index=49;
			VariableBinding        omtp12PlusOduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduErrorSeconds);
			
			index=50;
			VariableBinding        omtp12PlusOduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        omtp12PlusOduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduSevereErrorSeconds);
			
			index=52;
			VariableBinding        omtp12PlusOduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp12PlusOduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         omtp12PlusOduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         omtp12PlusOduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         omtp12PlusOduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         omtp12PlusOduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         omtp12PlusOduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp12PlusOduFarEndUnavailableSeconds);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	static short nodeNumber=1;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,long portMasterID,String trafficName,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,short traffinNameID,String clientOrLine){
		if (!"Free".equals(trafficName)) {
			//optical
			switch (clientOrLine) {
			case "client":
				try {
					Map<Short, String> opticalResult = getClientOpticalPerformance(nodeNumber, rackNumber,subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMTP12PLUSDAO.saveClientOpticalPerformance(portNumber, slotMasterID, portMasterID,opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			case "line":
				try {
					Map<Short, String> opticalResult = getLineOpticalPerformance(nodeNumber, rackNumber, subrackNumber,	slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMTP12PLUSDAO.saveLineOpticalPerformance(portNumber, slotMasterID, portMasterID,	opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}
		//traffic
		switch(trafficName){	
		case "STM64":
			try {
				Map<Short,String> result = getClientSTMPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP12PLUSDAO.saveClientSTMPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10GWAN":
			try {
				Map<Short,String> result = getClient10GWANPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP12PLUSDAO.saveClient10GWANPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10GLAN":
			try {
				Map<Short,String> result = getClient10GLANPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP12PLUSDAO.saveClient10GLANPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTU2":
			try {
				Map<Short,String> result = getClientOTU2Performance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP12PLUSDAO.saveClientOTU2Performance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTN":
			try {
				Map<Short,String> result = getLineOTNPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP12PLUSDAO.saveLineOTNPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}
