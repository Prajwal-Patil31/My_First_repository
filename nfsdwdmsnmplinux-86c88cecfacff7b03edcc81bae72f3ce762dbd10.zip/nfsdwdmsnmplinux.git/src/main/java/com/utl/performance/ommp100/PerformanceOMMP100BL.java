package com.utl.performance.ommp100;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.ommp100.PerfromanceOMMP100DAO;
import com.utl.performance.ommp81plus.PerfromanceOMMP81PLUSDAO;
import com.utl.performance.omtp100.PerfromanceOMTP100DAO;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;

public class PerformanceOMMP100BL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=30000;
	
	public static Map<Short,String> getClientOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  ommp82PlusSfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpInputPower);
			
			index = 2;
			VariableBinding  ommp82PlusSfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,6,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpOutputPower);
			
			index = 3;
			VariableBinding  ommp82PlusSfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,7,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpBiasCurrent);
			
			index = 4;
			VariableBinding  ommp82PlusSfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,9,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpTemperature);
					
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding  ommp82PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpInputPower);
			
			index = 2;
			VariableBinding  ommp82PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpOutputPower);

		/*	index = 3;
			VariableBinding  ommp82PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpBiasCurrent);*/
			
			//index = 4 is reserved
			
			index = 3;
			VariableBinding  ommp82PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,4,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpTemperature);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getClientSTMPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index;
			index=1;  //sdh_b1_error_count
			VariableBinding  ommp82PlusSdhRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhRsB1BitInterleavedParityErrors);
			
			index=2;  //sdh_b2_error_count
			VariableBinding  ommp82PlusSdhMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhMsB2BitInterleavedParityErrors);
			
			
			index=3; //sdh_ms_rei_error_count
			VariableBinding  ommp82PlusSdhMsRemoteErrorIndicationErrorCount      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhMsRemoteErrorIndicationErrorCount);

			
			index=4;  //sdh_error_free_seconds
			VariableBinding  ommp82PlusSdhErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhErrorFreeSeconds);
			
			index=5; //sdh_error_seconds
			VariableBinding  ommp82PlusSdhErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,71,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhErrorSeconds);
			 
			index=6;  //sdh_background_block_errors
			VariableBinding  ommp82PlusSdhBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,72,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhBackgroundBlockErrors);
			
			index=7;  //sdh_severely_error_seconds
			VariableBinding  ommp82PlusSdhSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,73,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhSevereErrorSeconds);
			
			index=8;  //sdh_unavailable_seconds
			VariableBinding  ommp82PlusSdhUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,74,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	
	
	public static Map<Short,String> getGEGFPF10GigePerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding ftOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,78,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ftOID);
			
			index=2;
			VariableBinding frOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,79,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,frOID);
			
			index=3;
			VariableBinding pftOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,80,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,pftOID);
			
			index=4;
			VariableBinding pfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,81,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,pfrOID);
			
			index=5;
			VariableBinding ucfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,83,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ucfrOID);
			
			index=6;
			VariableBinding mfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,85,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,mfrOID);
			
			index=7;
			VariableBinding bfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,87,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,bfrOID);
			
			index=8;
			VariableBinding usfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,88,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,usfrOID);
			
			index=9;
			VariableBinding osftOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,89,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,osftOID);
			
			index=10;
			VariableBinding osfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,91,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,osfrOID);
			
			index=11;
			VariableBinding vtftOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,93,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,vtftOID);
			
			index=12;
			VariableBinding vtfrOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,114,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,vtfrOID);
					
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	
	public static Map<Short,String> getClientOTU2Performance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=19;
			VariableBinding otu1_uncorrected_words = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,10,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otu1_uncorrected_words);
			
			index=1;
			VariableBinding  otu1_corrected_bit_counter = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_corrected_bit_counter);
			
			index=2;
			VariableBinding  otu1_zeros_corrected_errors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_zeros_corrected_errors);
			
			index=3;
			VariableBinding  otu1_ones_corrected_errors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_ones_corrected_errors);
			
			index=4;
			VariableBinding  otu1_section_monitoring_bip = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_section_monitoring_bip);
					
			index=6;
			VariableBinding  otu1_sm_backward_error_counter = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_sm_backward_error_counter);
			
			index=7;
			VariableBinding  otu1_error_free_seconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_error_free_seconds);
			
			index=8;
			VariableBinding  otu1_error_seconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_error_seconds);
			
			index=9;
			VariableBinding  otu1_background_block_errors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_background_block_errors);	
			
			index=10;
			VariableBinding  otu1_severe_error_seconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_severe_error_seconds);
			
			index=11;
			VariableBinding otu1_unavailable_seconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_unavailable_seconds);
			
			index=12;
			VariableBinding  otu1_path_monitoring_bip = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,35,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otu1_path_monitoring_bip);
			
			index=13;
			VariableBinding otu1_tcm1_counter = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,36,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otu1_tcm1_counter);
			
			index=14;
			VariableBinding  otu1_tcm2_counter = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,37,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otu1_tcm2_counter);
			
			index=15;
			VariableBinding  otu1_pm_backward_error_counter = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otu1_pm_backward_error_counter);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	
	public static Map<Short,String> getLineOTNPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			
			short index=1;
			VariableBinding otnFecUncorrectedWords  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,10,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otnFecUncorrectedWords);
			
			 index=2;
			VariableBinding otnFecCorrectedBitCounter  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otnFecCorrectedBitCounter);
			
			index=3;
			VariableBinding otnFecZerosCorrectedErrors  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otnFecZerosCorrectedErrors);
			
			 index=4;
			VariableBinding otnFecOnesCorrectedErrors  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otnFecOnesCorrectedErrors);
			
			
			index=5;
			VariableBinding otuOTUNearEndBitInterleavedParity  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otuOTUNearEndBitInterleavedParity);
			
			index=6;
			VariableBinding otuOTUNearEndBackwardErrorIndication  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUNearEndBackwardErrorIndication);
			
			index=7;
			VariableBinding otuOTUNearEndErrorFreeSeconds  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUNearEndErrorFreeSeconds);
			
			index=8;	
			VariableBinding otuOTUNearEndErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUNearEndErrorSeconds);
		
			index=9;	
			VariableBinding otuOTUNearEndBackgroundBlockErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUNearEndBackgroundBlockErrors);
		
			index=10;	
			VariableBinding otuOTUNearEndSevereErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUNearEndSevereErrorSeconds);
					
			index=11;
			VariableBinding otuOTUNearEndUnavailableSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUNearEndUnavailableSeconds);
			
			index=12;
			VariableBinding otuOTUFarEndErrorFreeSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,25,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUFarEndErrorFreeSeconds);
			
			index=13;
			VariableBinding otuOTUFarEndErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,26,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUFarEndErrorSeconds);
			
			index=14;
			VariableBinding otuOTUFarEndBackgroundBlockErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUFarEndBackgroundBlockErrors);	
			
			index=15;
			VariableBinding otuOTUFarEndSevereErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUFarEndSevereErrorSeconds);
			
			index=16;
			VariableBinding otuOTUFarEndUnavailableSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOTUFarEndUnavailableSeconds);
			
			index=17;
			VariableBinding otuOduNearEndBitInterleavedParityErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,35,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndBitInterleavedParityErrors);
			
			index=18;
			VariableBinding otuOduNearEndTCM1BIPErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,36,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndTCM1BIPErrors);
			
			index=19;
			VariableBinding otuOduNearEndTCM2BIPErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,37,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndTCM2BIPErrors);
			
			index=20;
			VariableBinding otuOduNearEndIncomingAlignmentErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndIncomingAlignmentErrorSeconds);
			
		
			index=21;
			VariableBinding otuOduNearEndBackwardErrorIndication = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndBackwardErrorIndication);
			
			index=22;
			VariableBinding otuOduNearEndBackwardIncomingAlignmentErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,50,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndBackwardIncomingAlignmentErrorSeconds);
			
			index=23;
			VariableBinding otuOduNearEndErrorFreeSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,52,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndErrorFreeSeconds);
			
						
			index=24;
			VariableBinding otuOduNearEndErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,53,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndErrorSeconds);
			
			index=25;
			VariableBinding otuOduNearEndBackgroundBlockErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,54,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndBackgroundBlockErrors);
			
				
			index=26;
			VariableBinding otuOduNearEndSevereErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,55,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndSevereErrorSeconds);
			
			
			index=27;
			VariableBinding otuOduNearEndUnavailableSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduNearEndUnavailableSeconds);
			
			index=28;
			VariableBinding otuOduFarEndErrorFreeSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otuOduFarEndErrorFreeSeconds);
			
			index=29;
			VariableBinding otuOduFarEndErrorSeconds  = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduFarEndErrorSeconds);
			
			index=30;
			VariableBinding otuOduFarEndBackgroundBlockErrors = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduFarEndBackgroundBlockErrors);
			
			index=31;
			VariableBinding otuOduFarEndSevereErrorSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, otuOduFarEndSevereErrorSeconds);
			
			index=32;
			VariableBinding otuOduFarEndUnavailableSeconds = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,63,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,otuOduFarEndUnavailableSeconds);
						
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	
	
	static short nodeNumber=1;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,long portMasterID,String trafficName,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,short traffinNameID,String clientOrLine){
		if (!"Free".equals(trafficName)) {
			//optical
			switch (clientOrLine) {
			case "client":
				try {
					Map<Short, String> opticalResult = getClientOpticalPerformance(nodeNumber, rackNumber,
							subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMMP100DAO.saveClientOpticalPerformance(portNumber, slotMasterID, portMasterID,
							opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			case "line":
				try {
					Map<Short, String> opticalResult = getLineOpticalPerformance(nodeNumber, rackNumber, subrackNumber,
							slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMMP100DAO.saveLineOpticalPerformance(portNumber, slotMasterID, portMasterID,
							opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}
		//traffic
		//System.out.println("trafficName"+trafficName);
		switch(trafficName){		
		case "STM64":					
			try {
				Map<Short,String> result = getClientSTMPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP100DAO.saveClientSTMPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10Gige":
			try {
				Map<Short,String> result = getGEGFPF10GigePerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP100DAO.saveClientGEGFPF10GigePerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTU2":
			try {
				Map<Short,String> result = getClientOTU2Performance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP100DAO.saveClientOTU2Performance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTN":
			try {
				
				Map<Short,String> result = getLineOTNPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP100DAO.saveLineOTNPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}
