package com.utl.performance.olaplus;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.obaplus.PerformanceOBAPLUSDAO;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;


public class PerformanceOLAPLUSBL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=15000;
	
	public static Map<Short,String> getPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
			Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index = 1;
			VariableBinding tempOID         = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,tempOID);
			
			index = 2;
			VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,inputOID);
			
			index = 3;
			VariableBinding midInOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,midInOID);
			
			index = 4;
			VariableBinding midOutOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,4,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,midOutOID);
			
			index = 5;
			VariableBinding outputOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,outputOID);			
			
			index = 6;//Mode[Stage-1]
			VariableBinding mode1OID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,2,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,mode1OID);
			
			index = 7;//Mode[Stage-2]
			VariableBinding mode2OID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,2,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,mode2OID);
			
			
			index = 8;
			VariableBinding gain1OID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,8,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,gain1OID);
			
						
			index = 9;
			VariableBinding gain2OID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,4,1,1,9,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,gain2OID);
			
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(short indexL : indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	static short nodeNumber=1;
	static short portNumber=0;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP){
		try {
				Map<Short, String> opticalResult = getPerformance(nodeNumber, rackNumber,subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				System.out.println("opticalResult"+opticalResult);
				PerformanceOLAPLUSDAO.savePerformance(slotMasterID, opticalResult, CurrentDate.getCurrentDate());
		} catch (Exception e1) {
				e1.printStackTrace();
		}		
	}


}
