package com.utl.performance.omtp11plus;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.omtp11plus.PerfromanceOMTP11PLUSDAO;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;

public class PerformanceOMTP11PLUSBL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=30000;
	
	public static Map<Short,String> getClientOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding   omtp11PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusXfpInputPower);
			
			index = 2;
			VariableBinding   omtp11PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusXfpOutputPower);
			
			index = 3;
			VariableBinding   omtp11PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusXfpBiasCurrent);
			
			// index  4 is reserved
			
			index = 5;
			VariableBinding   omtp11PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusXfpTemperature);
					
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding  ommp11PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpInputPower);
			
			index = 2;
			VariableBinding  ommp11PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpOutputPower);

			index = 3;
			VariableBinding  ommp11PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpBiasCurrent);
			
			//index = 4 is reserved
			
			index = 5;
			VariableBinding  ommp11PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpTemperature);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getClientSTMPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			
			index=1;
			VariableBinding  ommp11PlusSdhRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,81,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusSdhRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding  ommp11PlusSdhMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,82,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusSdhMsB2BitInterleavedParityErrors);
			
			//index 3-5 is reserved;
			
			index=6;
			VariableBinding   omtp11PlusSdhErrorFreeSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,86,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusSdhErrorFreeSeconds);
			
			index=7;
			VariableBinding   omtp11PlusSdhErrorSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,87,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusSdhErrorSeconds);
			
			index=8;
			VariableBinding   omtp11PlusSdhBackgroundBlockErrors      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,88,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusSdhBackgroundBlockErrors);
			
			index=9;
			VariableBinding   omtp11PlusSdhSevereErrorSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,89,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusSdhSevereErrorSeconds);			
			
			index=10;
			VariableBinding   omtp11PlusSdhUnavailableSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,90,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusSdhUnavailableSeconds);
							
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	public static Map<Short,String> getClient10GWANPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding   omtp11PlusWan10gRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,101,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding   omtp11PlusWan10gMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,102,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gMsB2BitInterleavedParityErrors);
			
			//index 3-5 is reserved;
			
			index=6;
			VariableBinding   omtp11PlusWan10gErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,106,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gErrorFreeSeconds);
			
			index=7;
			VariableBinding   omtp11PlusWan10gErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,107,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gErrorSeconds);
			
			index=8;
			VariableBinding   omtp11PlusWan10gBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,108,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gBackgroundBlockErrors);
			
			index=9;
			VariableBinding   omtp11PlusWan10gSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,109,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gSevereErrorSeconds);
			
			index=10;
			VariableBinding   omtp11PlusWan10gUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,110,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusWan10gUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	public static Map<Short,String> getClient10GLANPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding   omtp11PlusLan10gMacTerminatedFramesTransmitted        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,121,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedFramesTransmitted);
			
			index=2;
			VariableBinding   omtp11PlusLan10gMacTerminatedFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,122,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedFramesReceived);
			
//			index 3 is reserved;
			
			index=4;
			VariableBinding   omtp11PlusLan10gMacTerminatedPauseFramesReceived      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,124,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedPauseFramesReceived);
			
			index=5;
			VariableBinding    omtp11PlusLan10gMacTerminatedUnicastFramesTransmitted      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,125,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusLan10gMacTerminatedUnicastFramesTransmitted);	
			
			index=6;
			VariableBinding   omtp11PlusLan10gMacTerminatedUnicastFramesReceived       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,126,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedUnicastFramesReceived);
			
			index=7;
			VariableBinding   omtp11PlusLan10gMacTerminatedMulticastFramesTransmitted        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,127,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedMulticastFramesTransmitted);
			
			index=8;
			VariableBinding   omtp11PlusLan10gMacTerminatedMulticastFramesReceived       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,128,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedMulticastFramesReceived);
			
			index=9;
			VariableBinding   omtp11PlusLan10gMacTerminatedBroadcastFramesTransmitted       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,129,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedBroadcastFramesTransmitted);
			
			index=10;
			VariableBinding   omtp11PlusLan10gMacTerminatedBroadcastFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,130,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedBroadcastFramesReceived);
			
			//index 11 is reserved;
			
			index=12;
			VariableBinding   omtp11PlusLan10gMacTerminatedUnderSizeFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,132,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedUnderSizeFramesReceived);
			
			//index 13 is reserved;
			
			index=14;
			VariableBinding   omtp11PlusLan10gMacTerminatedOverSizeFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,134,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedOverSizeFramesReceived);
			
			//index 15-17 is reserved;
			
			index=18;
			VariableBinding   omtp11PlusLan10gMacTerminatedFragmentFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,138,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedFragmentFramesReceived);
			
			index=19;
			VariableBinding   omtp11PlusLan10gMacTerminatedFrameCheckSequenceErrorsReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,139,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusLan10gMacTerminatedFrameCheckSequenceErrorsReceived);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	
	public static Map<Short,String> getClientOTU2Performance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  omtp11PlusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, omtp11PlusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   omtp11PlusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding   omtp11PlusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   omtp11PlusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   omtp11PlusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBitInterleavedParityErrors);
			
		
			index=6;
			VariableBinding   omtp11PlusOtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   omtp11PlusOtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   omtp11PlusOtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    omtp11PlusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   omtp11PlusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuErrorSeconds);
			
			index=11;
			VariableBinding   omtp11PlusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   omtp11PlusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   omtp11PlusOtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    omtp11PlusOtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    omtp11PlusOtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   omtp11PlusOtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    omtp11PlusOtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    omtp11PlusOtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     omtp11PlusOduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusOduBitInterleavedParityErrors);
			index=32;
			VariableBinding     omtp11PlusOduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusOduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     omtp11PlusOduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusOduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      omtp11PlusOduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp11PlusOduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      omtp11PlusOduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp11PlusOduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       omtp11PlusOduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      omtp11PlusOduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        omtp11PlusOduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduErrorFreeSeconds);
			
			index=49;
			VariableBinding        omtp11PlusOduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduErrorSeconds);
			
			index=50;
			VariableBinding        omtp11PlusOduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        omtp11PlusOduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduSevereErrorSeconds);
			
			index=52;
			VariableBinding        omtp11PlusOduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         omtp11PlusOduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         omtp11PlusOduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         omtp11PlusOduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         omtp11PlusOduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         omtp11PlusOduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOTNPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  omtp11PlusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, omtp11PlusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   omtp11PlusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding   omtp11PlusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   omtp11PlusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   omtp11PlusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBitInterleavedParityErrors);
			
		
			index=4;
			VariableBinding   omtp11PlusOtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   omtp11PlusOtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   omtp11PlusOtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    omtp11PlusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   omtp11PlusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuErrorSeconds);
			
			index=11;
			VariableBinding   omtp11PlusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   omtp11PlusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   omtp11PlusOtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    omtp11PlusOtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    omtp11PlusOtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   omtp11PlusOtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11PlusOtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    omtp11PlusOtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    omtp11PlusOtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11PlusOtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     omtp11PlusOduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusOduBitInterleavedParityErrors);
			index=32;
			VariableBinding     omtp11PlusOduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusOduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     omtp11PlusOduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11PlusOduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      omtp11PlusOduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp11PlusOduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      omtp11PlusOduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp11PlusOduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       omtp11PlusOduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      omtp11PlusOduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        omtp11PlusOduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduErrorFreeSeconds);
			
			index=49;
			VariableBinding        omtp11PlusOduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduErrorSeconds);
			
			index=50;
			VariableBinding        omtp11PlusOduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        omtp11PlusOduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduSevereErrorSeconds);
			
			index=52;
			VariableBinding        omtp11PlusOduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11PlusOduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         omtp11PlusOduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         omtp11PlusOduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         omtp11PlusOduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         omtp11PlusOduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         omtp11PlusOduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,71,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11PlusOduFarEndUnavailableSeconds);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	static short nodeNumber=1;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,long portMasterID,String trafficName,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,short traffinNameID,String clientOrLine){
		if (!"Free".equals(trafficName)) {
			//optical
			switch (clientOrLine) {
			case "client":
				try {
					Map<Short, String> opticalResult = getClientOpticalPerformance(nodeNumber, rackNumber,subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMTP11PLUSDAO.saveClientOpticalPerformance(portNumber, slotMasterID, portMasterID,opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			case "line":
				try {
					Map<Short, String> opticalResult = getLineOpticalPerformance(nodeNumber, rackNumber, subrackNumber,	slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMTP11PLUSDAO.saveLineOpticalPerformance(portNumber, slotMasterID, portMasterID,	opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}
		//traffic
		switch(trafficName){	
		case "STM64":
			try {
				Map<Short,String> result = getClientSTMPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP11PLUSDAO.saveClientSTMPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10GWAN":
			try {
				Map<Short,String> result = getClient10GWANPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP11PLUSDAO.saveClient10GWANPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10GLAN":
			try {
				Map<Short,String> result = getClient10GLANPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP11PLUSDAO.saveClient10GLANPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTU2":
			try {
				Map<Short,String> result = getClientOTU2Performance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP11PLUSDAO.saveClientOTU2Performance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTN":
			try {
				Map<Short,String> result = getLineOTNPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP11PLUSDAO.saveLineOTNPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}
