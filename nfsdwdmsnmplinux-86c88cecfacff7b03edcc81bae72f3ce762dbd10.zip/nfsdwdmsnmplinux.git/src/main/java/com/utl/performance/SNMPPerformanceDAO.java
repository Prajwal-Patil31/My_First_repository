package com.utl.performance;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ut.connection.pool.DataSource;


public class SNMPPerformanceDAO {
	public static List<List<String>>  getPerformanceCards(long nodeDetailsID) throws Exception{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<List<String>> dwdmMasterDetailsAll=new ArrayList<List<String>>();
		try {
			conn=DataSource.getInstance().getConnection();
			ps=conn.prepareStatement("SELECT slot.dwdm_slot_master_id,slot.card_name,dwdm_port_master_id,traffic_name,rack.rack_number,subrack.subrack_number,slot.slot_number,portm.port_number,portm.port_traffic_type,portm.port_client_line_type FROM node_details node left outer join dwdm_rack_master rack on node.node_details_id=rack.node_details_id left outer join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id left outer join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id left outer join dwdm_port_master portm on slot.dwdm_slot_master_id=portm.dwdm_slot_master_id left outer join dwdm_port_traffic_name traffic on portm.port_traffic_type=traffic.dwdm_port_traffic_name_id where node.node_details_id=? and slot.card_name in ('OPA1PLUS','OPA2PLUS','OPA3PLUS','OPA4PLUS','OBA1PLUS','OBA2PLUS','OBA3PLUS','OBA4PLUS','OLA1PLUS','OLA2PLUS','OLA3PLUS','OLA4PLUS','10GOMTP12PLUS','10GOMTP11PLUS','10GOMTP11TPLUS','10GOMMP81PLUS','10GOMMP82PLUS','OMMP100')");
			ps.setLong(1,nodeDetailsID);
			rs=ps.executeQuery();
			List<String> dwdmMasterDetailsEach;
			while(rs.next()){
					dwdmMasterDetailsEach=new ArrayList<String>();
					dwdmMasterDetailsEach.add(rs.getString("dwdm_slot_master_id"));
					dwdmMasterDetailsEach.add(rs.getString("card_name"));
					dwdmMasterDetailsEach.add(rs.getString("dwdm_port_master_id"));
					dwdmMasterDetailsEach.add(rs.getString("traffic_name"));
					dwdmMasterDetailsEach.add(rs.getString("rack_number"));
					dwdmMasterDetailsEach.add(rs.getString("subrack_number"));
					dwdmMasterDetailsEach.add(rs.getString("slot_number"));
					dwdmMasterDetailsEach.add(rs.getString("port_number"));
					dwdmMasterDetailsEach.add(rs.getString("port_traffic_type"));
					dwdmMasterDetailsEach.add(rs.getString("port_client_line_type"));
					dwdmMasterDetailsAll.add(dwdmMasterDetailsEach);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally{
			if(rs!=null){
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(ps!=null){
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return dwdmMasterDetailsAll;
	}
}
