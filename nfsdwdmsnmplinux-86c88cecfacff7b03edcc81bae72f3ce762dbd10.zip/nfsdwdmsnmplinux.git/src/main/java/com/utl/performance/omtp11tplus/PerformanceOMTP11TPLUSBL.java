package com.utl.performance.omtp11tplus;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.omtp11tplus.PerfromanceOMTP11TPLUSDAO;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;

public class PerformanceOMTP11TPLUSBL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=30000;
	
	/*public static Map<Short,String> getClientOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding   omtp11tplusPlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusPlusXfpInputPower);
			
			index = 2;
			VariableBinding   omtp11tplusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusXfpOutputPower);
			
			index = 3;
			VariableBinding   omtp11tplusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusXfpBiasCurrent);
			
			// index  4 is reserved
			
			index = 5;
			VariableBinding   omtp11tplusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusXfpTemperature);
					
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}*/
	
	public static Map<Short,String> getLineOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding  ommp11tplusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11tplusXfpInputPower);
			
			index = 2;
			VariableBinding  ommp11tplusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11tplusXfpOutputPower);

			index = 3;
			VariableBinding  ommp11tplusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11tplusXfpBiasCurrent);
			
			//index = 4 is reserved
			
			index = 5;
			VariableBinding  ommp11tplusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11tplusXfpTemperature);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}		
	
	public static Map<Short,String> getLineOTNPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  omtp11tplusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, omtp11tplusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   omtp11tplusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding   omtp11tplusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   omtp11tplusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   omtp11tplusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuBitInterleavedParityErrors);
			
		
			index=6;
			VariableBinding   omtp11tplusOtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   omtp11tplusOtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   omtp11tplusOtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    omtp11tplusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusOtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   omtp11tplusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuErrorSeconds);
			
			index=11;
			VariableBinding   omtp11tplusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   omtp11tplusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   omtp11tplusOtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    omtp11tplusOtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusOtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    omtp11tplusOtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusOtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   omtp11tplusOtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  omtp11tplusOtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    omtp11tplusOtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusOtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    omtp11tplusOtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   omtp11tplusOtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     omtp11tplusOduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11tplusOduBitInterleavedParityErrors);
			index=32;
			VariableBinding     omtp11tplusOduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11tplusOduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     omtp11tplusOduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    omtp11tplusOduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      omtp11tplusOduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp11tplusOduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      omtp11tplusOduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     omtp11tplusOduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       omtp11tplusOduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      omtp11tplusOduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        omtp11tplusOduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11tplusOduErrorFreeSeconds);
			
			index=49;
			VariableBinding        omtp11tplusOduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11tplusOduErrorSeconds);
			
			index=50;
			VariableBinding        omtp11tplusOduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11tplusOduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        omtp11tplusOduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11tplusOduSevereErrorSeconds);
			
			index=52;
			VariableBinding        omtp11tplusOduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       omtp11tplusOduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         omtp11tplusOduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11tplusOduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         omtp11tplusOduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11tplusOduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         omtp11tplusOduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11tplusOduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         omtp11tplusOduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11tplusOduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         omtp11tplusOduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,72,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        omtp11tplusOduFarEndUnavailableSeconds);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	static short nodeNumber=1;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,long portMasterID,String trafficName,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,short traffinNameID,String clientOrLine){
		if (!"Free".equals(trafficName)) {
			//optical
			switch (clientOrLine) {			
			case "line":
				try {
					Map<Short, String> opticalResult = getLineOpticalPerformance(nodeNumber, rackNumber, subrackNumber,slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMTP11TPLUSDAO.saveLineOpticalPerformance(portNumber, slotMasterID, portMasterID,opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}
		//traffic
		switch(trafficName){			
		case "OTN":
			try {
				Map<Short,String> result = getLineOTNPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMTP11TPLUSDAO.saveLineOTNPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}
