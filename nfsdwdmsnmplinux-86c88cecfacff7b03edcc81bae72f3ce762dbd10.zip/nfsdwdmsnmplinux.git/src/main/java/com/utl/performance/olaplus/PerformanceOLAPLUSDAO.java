package com.utl.performance.olaplus;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import com.ut.connection.pool.DataSource;

public class PerformanceOLAPLUSDAO {
	
	public static byte savePerformance(long slotMasterID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 9;		
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ola_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,dwdm_slot_master_id, poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?)";	
			psInsert=conn.prepareStatement(query);			
			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}			
			psInsert.setLong(index++, slotMasterID);			
			psInsert.setTimestamp(index++,pollDateTime);			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;

}

}
