package com.utl.performance.ommp82plus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;

public class PerformanceOMMP82PLUSBL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=30000;
	
	public static Map<Short,String> getClientOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  ommp82PlusSfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpInputPower);
			
			index = 2;
			VariableBinding  ommp82PlusSfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpOutputPower);
			
			index = 3;
			VariableBinding  ommp82PlusSfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpBiasCurrent);
			
			// index  4 is reserved
			
			index = 5;
			VariableBinding  ommp82PlusSfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,25,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSfpTemperature);
					
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding  ommp82PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpInputPower);
			
			index = 2;
			VariableBinding  ommp82PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpOutputPower);

			index = 3;
			VariableBinding  ommp82PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpBiasCurrent);
			
			//index = 4 is reserved
			
			index = 5;
			VariableBinding  ommp82PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusXfpTemperature);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result);
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getClientSTMPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding  ommp82PlusSdhRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,121,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding  ommp82PlusSdhMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,122,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhMsB2BitInterleavedParityErrors);
			
//			index 3 is reserved;
			
			index=4;
			VariableBinding  ommp82PlusSdhMsRemoteErrorIndicationErrorCount      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,124,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhMsRemoteErrorIndicationErrorCount);
			
//			index=5 is reserved;
			
			index=6;
			VariableBinding  ommp82PlusSdhErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,126,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhErrorFreeSeconds);
			
			index=7;
			VariableBinding  ommp82PlusSdhErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,127,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhErrorSeconds);
			
			index=8;
			VariableBinding  ommp82PlusSdhBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,128,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhBackgroundBlockErrors);
			
			index=9;
			VariableBinding  ommp82PlusSdhSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,129,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhSevereErrorSeconds);
			
			index=10;
			VariableBinding  ommp82PlusSdhUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,130,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusSdhUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	
	public static Map<Short,String> getGEGFPFPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding ftOID     = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,151,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ftOID);
			
			index=2;
			VariableBinding frOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,152,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,frOID);
			
			index=3;
			VariableBinding pftOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,153,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,pftOID);
			
			index=4;
			VariableBinding pfrOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,154,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,pfrOID);
			
			index=6;
			VariableBinding ucfrOID   = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,156,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ucfrOID);
			
			index=8;
			VariableBinding mfrOID     = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,158,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,mfrOID);
			
			index=10;
			VariableBinding bfrOID   = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,160,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,bfrOID);
			
			index=12;
			VariableBinding usfrOID     = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,162,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,usfrOID);
			
			index=13;
			VariableBinding osftOID      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,163,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,osftOID);
			
			index=14;
			VariableBinding osfrOID      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,164,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,osfrOID);
			
			index=15;
			VariableBinding vtftOID    = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,165,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,vtftOID);
			
			index=16;
			VariableBinding vtfrOID    = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,166,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,vtfrOID);
			
			index=18;
			VariableBinding ffrOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,168,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ffrOID);
			
			index=19;
			VariableBinding fcserOID     = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,169,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,fcserOID);
			
			index=20;
			VariableBinding frwnOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,170,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,frwnOID);
			
			index=31;
			VariableBinding gheOID      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,201,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,gheOID);
			
			index=32;
			VariableBinding gehecOID       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,202,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,gehecOID);
			
			index=33;
			VariableBinding gfwsbOID      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,203,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,gfwsbOID);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getClientOTU1Performance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding ommp82PlusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ommp82PlusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding  ommp82PlusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding  ommp82PlusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding  ommp82PlusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,44,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding  ommp82PlusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,45,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuBitInterleavedParityErrors);
			
			//6 to 8 reserved
			
			index=7;
			VariableBinding  ommp82PlusOtuSMBackwardErrorCounter        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,47,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuSMBackwardErrorCounter);
			
			
			index=9;
			VariableBinding  ommp82PlusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuErrorFreeSeconds);
			
			index=10;
			VariableBinding  ommp82PlusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,50,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuErrorSeconds);
			
			index=11;
			VariableBinding  ommp82PlusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,51,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding  ommp82PlusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,52,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuSevereErrorSeconds);	
			
			index=13;
			VariableBinding  ommp82PlusOtuUnavailableSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,53,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuUnavailableSeconds);
			
			//14 to 30 reserved
			
			index=31;
			VariableBinding  ommp82PlusOduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,81,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOduBitInterleavedParityErrors);
			
			index=32;
			VariableBinding  ommp82PlusOduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,82,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOduTcm1BitInterleavedParityErrors);
			
			index=33;
			VariableBinding  ommp82PlusOduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,83,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ommp82PlusOduTcm2BitInterleavedParityErrors);
			
			//34 to 38 reserved
			
			index=39;
			VariableBinding  ommp82PlusOduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,89,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ommp82PlusOduBackwardErrorIndicationErrorCount);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOTNPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding ommp82PlusOtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,ommp82PlusOtnFecUncorrectedWords);
			
			index=2;
			VariableBinding  ommp82PlusOtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtnFecCorrectedBits);
			
			index=3;
			VariableBinding  ommp82PlusOtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding  ommp82PlusOtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,44,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding  ommp82PlusOtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,45,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuBitInterleavedParityErrors);
			
			index=6;	
			VariableBinding   ommp82PlusOtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,46,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuIncomingAlignmentErrorSeconds);
		
			index=7;	
			VariableBinding   ommp82PlusOtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,47,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuBackwardErrorIndicationErrorCount);
		
			index=8;	
			VariableBinding   ommp82PlusOtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuBackwardIncomingAlignmentErrorSeconds);
					
			index=9;
			VariableBinding  ommp82PlusOtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuErrorFreeSeconds);
			
			index=10;
			VariableBinding  ommp82PlusOtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,50,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuErrorSeconds);
			
			index=11;
			VariableBinding  ommp82PlusOtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,51,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding  ommp82PlusOtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,52,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuSevereErrorSeconds);	
			
			index=13;
			VariableBinding  ommp82PlusOtuUnavailableSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,53,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp82PlusOtuUnavailableSeconds);
			
			
			//14 to 16 reserved			
			
			index=17;
			VariableBinding   ommp82PlusOtuFarEndErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,57,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding   ommp82PlusOtuFarEndErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   ommp82PlusOtuFarEndBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding   ommp82PlusOtuFarEndSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding   ommp82PlusOtuFarEndUnavailableSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp82PlusOtuFarEndUnavailableSeconds);
			
			//22 to 40 reserved			
			index=41;
			VariableBinding    ommp82PlusOduBitInterleavedParityErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,81,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp82PlusOduBitInterleavedParityErrors);
			
			index=42;
			VariableBinding    ommp82PlusOduTcm1BitInterleavedParityErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,82,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp82PlusOduTcm1BitInterleavedParityErrors);
			
			index=43;
			VariableBinding    ommp82PlusOduTcm2BitInterleavedParityErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,83,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp82PlusOduTcm2BitInterleavedParityErrors);
			
			//44 to 47 reserved	
			
			index=48;
			VariableBinding     ommp82PlusOduIncomingAlignmentErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,88,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp82PlusOduIncomingAlignmentErrorSeconds);
			
			index=49;
			VariableBinding     ommp82PlusOduBackwardErrorIndicationErrorCount       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,89,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp82PlusOduBackwardErrorIndicationErrorCount);
			
			//50 to 56 reserved			
			index=56;
			VariableBinding      ommp82PlusOduBackwardIncomingAlignmentErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,96,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     ommp82PlusOduBackwardIncomingAlignmentErrorSeconds);
			
			//57 reserved	
			index=58;
			VariableBinding       ommp82PlusOduErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,98,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      ommp82PlusOduErrorFreeSeconds);
			
			index=59;
			VariableBinding       ommp82PlusOduErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,99,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      ommp82PlusOduErrorSeconds);
			
			index=60;
			VariableBinding      ommp82PlusOduBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,100,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     ommp82PlusOduBackgroundBlockErrors);
			
			index=61;
			VariableBinding       ommp82PlusOduSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,101,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      ommp82PlusOduSevereErrorSeconds);
			
			index=62;
			VariableBinding       ommp82PlusOduUnavailableSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,102,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      ommp82PlusOduUnavailableSeconds);
			
			//64 to 66 reserved	
			
			index=66;
			VariableBinding        ommp82PlusOduFarEndErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,106,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp82PlusOduFarEndErrorFreeSeconds);
			
			index=67;
			VariableBinding        ommp82PlusOduFarEndErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,107,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp82PlusOduFarEndErrorSeconds);
			
			index=68;
			VariableBinding        ommp82PlusOduFarEndBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,108,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp82PlusOduFarEndBackgroundBlockErrors);
			
			index=69;
			VariableBinding        ommp82PlusOduFarEndSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,109,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp82PlusOduFarEndSevereErrorSeconds);
			
			index=70;
			VariableBinding        ommp82PlusOduFarEndUnavailableSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,87,4,1,1,110,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp82PlusOduFarEndUnavailableSeconds);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	

	
	static short nodeNumber=1;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,long portMasterID,String trafficName,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,short traffinNameID,String clientOrLine){
		if (!"Free".equals(trafficName)) {
			//optical
			switch (clientOrLine) {
			case "client":
				try {
					Map<Short, String> opticalResult = getClientOpticalPerformance(nodeNumber, rackNumber,subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMMP82PLUSDAO.saveClientOpticalPerformance(portNumber, slotMasterID, portMasterID,opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			case "line":
				try {
					Map<Short, String> opticalResult = getLineOpticalPerformance(nodeNumber, rackNumber, subrackNumber,
							slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMMP82PLUSDAO.saveLineOpticalPerformance(portNumber, slotMasterID, portMasterID,
							opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}
		//traffic
		switch(trafficName){
		case "STM16":
		case "STM4":
		case "STM1":
			try {
				Map<Short,String> result = getClientSTMPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP82PLUSDAO.saveClientSTMPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "1Gige":
			try {
				Map<Short,String> result = getGEGFPFPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP82PLUSDAO.saveClientGEGFPFPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTU1":
			try {
				Map<Short,String> result = getClientOTU1Performance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP82PLUSDAO.saveClientOTU1Performance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTN":
			try {
				Map<Short,String> result = getLineOTNPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP82PLUSDAO.saveLineOTNPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}
