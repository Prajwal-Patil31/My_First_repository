package com.utl.performance.ommp100;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import com.ut.connection.pool.DataSource;



public class PerfromanceOMMP100DAO {
	
	public static byte saveClientOpticalPerformance(short clientNumber,long slotMasterID,long portMasterID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 5;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp100g_client%s_optical_performance (performance1,performance2,performance3,performance4,performance5,dwdm_slot_master_id, dwdm_port_master_id,poll_date_time) VALUES (?,?,?,?,?,?,?,?)";
			query=String.format(query, clientNumber);
			psInsert=conn.prepareStatement(query);

			
			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setTimestamp(index++,pollDateTime);
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	public static byte saveLineOpticalPerformance(short clientNumber,long slotMasterID,long portMasterID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 5;
		try {
			/*clientNumber = (short) (clientNumber==9?1:2);*/
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp100g_line_optical_performance (performance1,performance2,performance3,performance4,performance5,dwdm_slot_master_id, dwdm_port_master_id,poll_date_time) VALUES (?,?,?,?,?,?,?,?)";
			/*query=String.format(query, clientNumber);*/
			psInsert=conn.prepareStatement(query);

			
			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClientSTMPerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 8;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp100g_client%s_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
			query=String.format(query, clientNumber);
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClientGEGFPF10GigePerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 12;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp100g_client%s_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,performance11,performance12,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			query=String.format(query, clientNumber);
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClientOTU2Performance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 15;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp100g_client%s_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,performance11,performance12,performance13,performance14,performance15,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			query=String.format(query, clientNumber);
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveLineOTNPerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 32;
		try {			
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp100g_line_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,performance11,performance12,performance13,performance14,performance15,performance16,performance17,performance18,performance19,performance20,performance21,performance22,performance23,performance24,performance25,performance26,performance27,performance28,performance29,performance30,performance31,performance32,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			/*query=String.format(query, clientNumber);*/
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
}
