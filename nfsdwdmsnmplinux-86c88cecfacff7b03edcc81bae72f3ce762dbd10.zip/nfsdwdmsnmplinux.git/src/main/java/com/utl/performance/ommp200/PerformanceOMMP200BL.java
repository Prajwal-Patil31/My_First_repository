package com.utl.performance.ommp200;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.ommp200.PerfromanceOMMP200DAO;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.util.CurrentDate;

public class PerformanceOMMP200BL {
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=30000;
	
	public static Map<Short,String> getClientOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding   ommp200XfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200XfpInputPower);
			
			index = 2;
			VariableBinding   ommp200XfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200XfpOutputPower);
			
			index = 3;
			VariableBinding   ommp200XfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200XfpBiasCurrent);
			
			// index  4 is reserved
			
			index = 5;
			VariableBinding   ommp200XfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200XfpTemperature);
					
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOpticalPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index=1;
			VariableBinding  ommp11PlusXfpInputPower        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,1,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpInputPower);
			
			index = 2;
			VariableBinding  ommp11PlusXfpOutputPower       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpOutputPower);

			index = 3;
			VariableBinding  ommp11PlusXfpBiasCurrent       =     new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,3,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpBiasCurrent);
			
			//index = 4 is reserved
			
			index = 5;
			VariableBinding  ommp11PlusXfpTemperature       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,5,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp11PlusXfpTemperature);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			/*System.out.println(nodeIP);
			System.out.println(allVB);
			System.out.println(result)*/;
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getClientSTMPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			short index;
			
			index=1;
			VariableBinding  ommp200SdhRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,81,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200SdhRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding  ommp200SdhMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,82,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp200SdhMsB2BitInterleavedParityErrors);
			
			//index 3-5 is reserved;
			
			index=6;
			VariableBinding  ommp200SdhErrorFreeSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,86,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200SdhErrorFreeSeconds);
			
			index=7;
			VariableBinding   ommp200SdhErrorSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,87,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200SdhErrorSeconds);
			
			index=8;
			VariableBinding   ommp200SdhBackgroundBlockErrors      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,88,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200SdhBackgroundBlockErrors);
			
			index=9;
			VariableBinding   ommp200SdhSevereErrorSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,89,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200SdhSevereErrorSeconds);			
			
			index=10;
			VariableBinding   ommp200SdhUnavailableSeconds      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,90,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200SdhUnavailableSeconds);
							
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	//Ethernet Performance
	public static Map<Short,String> getClient10GWANPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB10WAN=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding   ommp200Wan10gRsB1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,101,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gRsB1BitInterleavedParityErrors);
			
			index=2;
			VariableBinding   ommp200Wan10gMsB2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,102,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gMsB2BitInterleavedParityErrors);
			
			//index 3-5 is reserved;
			
			index=6;
			VariableBinding   ommp200Wan10gErrorFreeSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,106,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gErrorFreeSeconds);
			
			index=7;
			VariableBinding   ommp200Wan10gErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,107,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gErrorSeconds);
			
			index=8;
			VariableBinding   ommp200Wan10gBackgroundBlockErrors       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,108,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gBackgroundBlockErrors);
			
			index=9;
			VariableBinding   ommp200Wan10gSevereErrorSeconds       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,109,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gSevereErrorSeconds);
			
			index=10;
			VariableBinding   ommp200Wan10gUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,110,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10WAN.put(index,   ommp200Wan10gUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB10GWAN=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB10WAN, userDetails);
			Set<Short> indexSet = resultAllVB10GWAN.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB10WAN = resultAllVB10GWAN.get(indexL);
				String value=resultEachVB10WAN.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	public static Map<Short,String> getClient10GLANPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB10GLAN=new HashMap<Short,VariableBinding>();
			short index;
			index=1;
			VariableBinding   ommp200Lan10gMacTerminatedFramesTransmitted        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,121,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedFramesTransmitted);
			
			index=2;
			VariableBinding   ommp200Lan10gMacTerminatedFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,122,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedFramesReceived);
			
//			index 3 is reserved;
			
			index=4;
			VariableBinding   ommp200Lan10gMacTerminatedPauseFramesReceived      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,124,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedPauseFramesReceived);
			
			index=5;
			VariableBinding    ommp200Lan10gMacTerminatedUnicastFramesTransmitted      = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,125,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,    ommp200Lan10gMacTerminatedUnicastFramesTransmitted);	
			
			index=6;
			VariableBinding   ommp200Lan10gMacTerminatedUnicastFramesReceived       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,126,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedUnicastFramesReceived);
			
			index=7;
			VariableBinding   ommp200Lan10gMacTerminatedMulticastFramesTransmitted        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,127,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedMulticastFramesTransmitted);
			
			index=8;
			VariableBinding   ommp200Lan10gMacTerminatedMulticastFramesReceived       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,128,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedMulticastFramesReceived);
			
			index=9;
			VariableBinding   ommp200Lan10gMacTerminatedBroadcastFramesTransmitted       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,129,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedBroadcastFramesTransmitted);
			
			index=10;
			VariableBinding   ommp200Lan10gMacTerminatedBroadcastFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,130,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedBroadcastFramesReceived);
			
			//index 11 is reserved;
			
			index=12;
			VariableBinding   ommp200Lan10gMacTerminatedUnderSizeFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,132,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedUnderSizeFramesReceived);
			
			//index 13 is reserved;
			
			index=14;
			VariableBinding   ommp200Lan10gMacTerminatedOverSizeFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,134,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedOverSizeFramesReceived);
			
			//index 15-17 is reserved;
			
			index=18;
			VariableBinding   ommp200Lan10gMacTerminatedFragmentFramesReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,138,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedFragmentFramesReceived);
			
			index=19;
			VariableBinding   ommp200Lan10gMacTerminatedFrameCheckSequenceErrorsReceived        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,139,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB10GLAN.put(index,   ommp200Lan10gMacTerminatedFrameCheckSequenceErrorsReceived);
			
			
			Map<Short,VariableBinding> resultAllVB10GLAN=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB10GLAN, userDetails);
			Set<Short> indexSet = resultAllVB10GLAN.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB10GLAN = resultAllVB10GLAN.get(indexL);
				String value=resultEachVB10GLAN.getVariable().toString();
				result.put(indexL, value);
			}
			
		} catch (Exception e) {
			throw e;
		}
		return result;
	}	
	
	
	public static Map<Short,String> getClientOTU2Performance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  ommp200OtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp200OtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   ommp200OtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtnFecCorrectedBits);
			
			index=3;
			VariableBinding   ommp200OtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   ommp200OtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   ommp200OtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBitInterleavedParityErrors);
			
		
			index=6;
			VariableBinding   ommp200OtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   ommp200OtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   ommp200OtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    ommp200OtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   ommp200OtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuErrorSeconds);
			
			index=11;
			VariableBinding   ommp200OtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   ommp200OtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   ommp200OtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    ommp200OtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    ommp200OtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   ommp200OtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    ommp200OtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    ommp200OtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     ommp200OduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp200OduBitInterleavedParityErrors);
			index=32;
			VariableBinding     ommp200OduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp200OduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     ommp200OduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp200OduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      ommp200OduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     ommp200OduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      ommp200OduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     ommp200OduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       ommp200OduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      ommp200OduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        ommp200OduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduErrorFreeSeconds);
			
			index=49;
			VariableBinding        ommp200OduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduErrorSeconds);
			
			index=50;
			VariableBinding        ommp200OduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        ommp200OduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduSevereErrorSeconds);
			
			index=52;
			VariableBinding        ommp200OduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         ommp200OduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         ommp200OduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         ommp200OduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         ommp200OduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         ommp200OduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndUnavailableSeconds);
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	public static Map<Short,String> getLineOTNPerformance(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,String> result=new HashMap<Short,String>();
		try {
			Map<Short,VariableBinding> allVB=new HashMap<Short,VariableBinding>();
			
			short index=1;
			VariableBinding  ommp200OtnFecUncorrectedWords       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,11,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index, ommp200OtnFecUncorrectedWords);
			
			index=2;
			VariableBinding   ommp200OtnFecCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtnFecCorrectedBits);
			
			index=3;
			VariableBinding   ommp200OtnFecZerosCorrectedBits       = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,13,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtnFecZerosCorrectedBits);
			
			index=4;
			VariableBinding   ommp200OtnFecOnesCorrectedBits        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,14,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtnFecOnesCorrectedBits);
			
			index=5;
			VariableBinding   ommp200OtuBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,15,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBitInterleavedParityErrors);
			
		
			index=4;
			VariableBinding   ommp200OtuIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,16,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuIncomingAlignmentErrorSeconds);
			
			
			index=7;
			VariableBinding   ommp200OtuBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,17,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBackwardErrorIndicationErrorCount);
			
			
			index=8;
			VariableBinding   ommp200OtuBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,18,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBackwardIncomingAlignmentErrorSeconds);
			
			
			index=9;
			VariableBinding    ommp200OtuErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,19,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuErrorFreeSeconds);
			
			
			index=10;
			VariableBinding   ommp200OtuErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,20,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuErrorSeconds);
			
			index=11;
			VariableBinding   ommp200OtuBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,21,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuBackgroundBlockErrors);
			
			index=12;
			VariableBinding   ommp200OtuSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,22,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuSevereErrorSeconds);
			
			index=13;
			VariableBinding   ommp200OtuUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuUnavailableSeconds);
			
			//index 14-16 to  is reserved;
			
			index=17;
			VariableBinding    ommp200OtuFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,27,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndErrorFreeSeconds);
			
			index=18;
			VariableBinding    ommp200OtuFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,28,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndErrorSeconds);
			
			index=19;
			VariableBinding   ommp200OtuFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,29,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,  ommp200OtuFarEndBackgroundBlockErrors);
			
			index=20;
			VariableBinding    ommp200OtuFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,30,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndSevereErrorSeconds);
			
			index=21;
			VariableBinding    ommp200OtuFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,31,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,   ommp200OtuFarEndUnavailableSeconds);
			
			//index 22-30 to  is reserved;
			
			index=31;
			VariableBinding     ommp200OduBitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp200OduBitInterleavedParityErrors);
			index=32;
			VariableBinding     ommp200OduTcm1BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,42,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp200OduTcm1BitInterleavedParityErrors);
			index=33;
			VariableBinding     ommp200OduTcm2BitInterleavedParityErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,43,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,    ommp200OduTcm2BitInterleavedParityErrors);
		
			//index 34-37 to  is reserved;	
			index=38;
			VariableBinding      ommp200OduIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,48,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     ommp200OduIncomingAlignmentErrorSeconds);
			
			index=39;
			VariableBinding      ommp200OduBackwardErrorIndicationErrorCount        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,49,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,     ommp200OduBackwardErrorIndicationErrorCount);
			
			
			//index 40-45 to  is reserved;	
			
			index=46;
			VariableBinding       ommp200OduBackwardIncomingAlignmentErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,56,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,      ommp200OduBackwardIncomingAlignmentErrorSeconds);
			
			//index 47 to  is reserved;	
			
			index=48;
			VariableBinding        ommp200OduErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,58,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduErrorFreeSeconds);
			
			index=49;
			VariableBinding        ommp200OduErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,59,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduErrorSeconds);
			
			index=50;
			VariableBinding        ommp200OduBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,60,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduBackgroundBlockErrors);
			
			index=51;
			VariableBinding        ommp200OduSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,61,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduSevereErrorSeconds);
			
			index=52;
			VariableBinding        ommp200OduUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,62,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,       ommp200OduUnavailableSeconds);
			
			//index 53 - 55 to  is reserved;	
			
			index=56;
			VariableBinding         ommp200OduFarEndErrorFreeSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,66,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndErrorFreeSeconds);
			
			index=57;
			VariableBinding         ommp200OduFarEndErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,67,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndErrorSeconds);
			
			index=58;
			VariableBinding         ommp200OduFarEndBackgroundBlockErrors        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,68,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndBackgroundBlockErrors);
			
			index=59;
			VariableBinding         ommp200OduFarEndSevereErrorSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,69,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndSevereErrorSeconds);
			
			index=60;
			VariableBinding         ommp200OduFarEndUnavailableSeconds        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,4,1,1,70,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
			allVB.put(index,        ommp200OduFarEndUnavailableSeconds);
			
			
			Map<Short,VariableBinding> resultAllVB=SNMPGet.getSNMPMultipleWithIndex(nodeIP, community,retries, timeOut, allVB, userDetails);
			Set<Short> indexSet = resultAllVB.keySet();
			for(Short indexL: indexSet){
				VariableBinding resultEachVB = resultAllVB.get(indexL);
				String value=resultEachVB.getVariable().toString();
				result.put(indexL, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
	static short nodeNumber=1;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void proccessRequest(long slotMasterID,long portMasterID,String trafficName,short rackNumber,short subrackNumber,short slotNumber,short portNumber,String nodeIP,short traffinNameID,String clientOrLine){
		if (!"Free".equals(trafficName)) {
			//optical
			switch (clientOrLine) {
			case "client":
				try {
					Map<Short, String> opticalResult = getClientOpticalPerformance(nodeNumber, rackNumber,subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMMP200DAO.saveClientOpticalPerformance(portNumber, slotMasterID, portMasterID,opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			case "line":
				try {
					Map<Short, String> opticalResult = getLineOpticalPerformance(nodeNumber, rackNumber, subrackNumber,	slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
					PerfromanceOMMP200DAO.saveLineOpticalPerformance(portNumber, slotMasterID, portMasterID,	opticalResult, CurrentDate.getCurrentDate());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}
		//traffic
		switch(trafficName){	
		case "STM64":
			try {
				Map<Short,String> result = getClientSTMPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP200DAO.saveClientSTMPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10GWAN":
			try {
				Map<Short,String> result = getClient10GWANPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP200DAO.saveClient10GWANPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "10GLAN":
			try {
				Map<Short,String> result = getClient10GLANPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP200DAO.saveClient10GLANPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTU2":
			try {
				Map<Short,String> result = getClientOTU2Performance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP200DAO.saveClientOTU2Performance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "OTN":
			try {
				Map<Short,String> result = getLineOTNPerformance(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, snmpVersionDetailsObj);
				PerfromanceOMMP200DAO.saveLineOTNPerformance(portNumber, slotMasterID, portMasterID, traffinNameID, result, CurrentDate.getCurrentDate());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		}
	}
}
