package com.utl.performance;

import java.util.List;

import javax.swing.JTextArea;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.performance.obaplus.PerformanceOBAPLUSBL;
import com.utl.performance.olaplus.PerformanceOLAPLUSBL;
import com.utl.performance.ommp100.PerformanceOMMP100BL;
import com.utl.performance.ommp40.PerformanceOMMP40BL;
import com.utl.performance.ommp81plus.PerformanceOMMP81PLUSBL;
import com.utl.performance.ommp82plus.PerformanceOMMP82PLUSBL;
import com.utl.performance.omtp100.PerformanceOMTP100BL;
import com.utl.performance.omtp11plus.PerformanceOMTP11PLUSBL;
import com.utl.performance.omtp11tplus.PerformanceOMTP11TPLUSBL;
import com.utl.performance.omtp12plus.PerformanceOMTP12PLUSBL;
import com.utl.performance.opaplus.PerformanceOPAPLUSBL;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class SNMPPerformanceRunnable implements Runnable {
	private String nodeIP;
	private int nodeDetailsID;
	private SNMPPerformancePollDWDM performancePollGuiObj;
	

	public SNMPPerformanceRunnable(String nodeIP, int nodeDetailsID,
			SNMPPerformancePollDWDM performancePollGuiObj) {
		super();
		this.nodeIP = nodeIP;
		this.nodeDetailsID = nodeDetailsID;
		this.performancePollGuiObj=performancePollGuiObj;
	}

	@Override
	public void run(){
		JTextArea messagesArea=performancePollGuiObj.messagesArea;
		//messagesArea.append("started Performance Poll for node : "+nodeIP+" \n");
		System.out.println(	"started Performance Poll for node : "+nodeIP+" \n"); 
		String cardName;
		long dwdmSlotMasterId = 0;
		long dwdmPortMasterId = 0;
		String trafficName = null;
		short rackNumber =1;
		short subrackNumber =1;
		short slotNumber = 1;
		short portNumber = 1;
		short portTrafficTypeID = 0;
		String portClientLineType = null;
		int cardID = 0;
		List<List<String>> dwdmMasterDetailsAll=null;

		try {
			VariableBinding result = null;
			try {
				result = getSystemDescription(nodeIP);
			} catch (Exception e) {
				try {
					result = getSystemDescription(nodeIP);
				} catch (Exception e1) {
				}
			}
			if(result!=null){
				dwdmMasterDetailsAll=SNMPPerformanceDAO.getPerformanceCards(nodeDetailsID);
				Thread currentThreadObj = Thread.currentThread();
				for (List<String> dwdmMasterDetailsEach:dwdmMasterDetailsAll) {
					
					try {
						if(!currentThreadObj.isInterrupted()){
							
							dwdmSlotMasterId = Long.parseLong(dwdmMasterDetailsEach.get(0));
							cardName = dwdmMasterDetailsEach.get(1);
							//System.out.println("cardName"+cardName);
							if(cardName.equals("10GOMTP11PLUS")||cardName.equals("10GOMTP11TPLUS")||cardName.equals("10GOMTP12PLUS")||cardName.equals("10GOMMP82PLUS")||cardName.equals("10GOMMP81PLUS")||cardName.equals("OMMP100")){
								dwdmPortMasterId = Long.parseLong(dwdmMasterDetailsEach.get(2));
								trafficName = dwdmMasterDetailsEach.get(3);
								rackNumber =Short.parseShort(dwdmMasterDetailsEach.get(4));
								subrackNumber =Short.parseShort(dwdmMasterDetailsEach.get(5));
								slotNumber =Short.parseShort(dwdmMasterDetailsEach.get(6));
								portNumber  =Short.parseShort(dwdmMasterDetailsEach.get(7));
								portTrafficTypeID = Short.parseShort(dwdmMasterDetailsEach.get(8));
								portClientLineType = dwdmMasterDetailsEach.get(9);
							}
							else //for obaplus,opaplus,olaplus cards
							{
								dwdmPortMasterId = 0;							
								rackNumber =Short.parseShort(dwdmMasterDetailsEach.get(4));
								subrackNumber =Short.parseShort(dwdmMasterDetailsEach.get(5));
								slotNumber =Short.parseShort(dwdmMasterDetailsEach.get(6));
								portNumber  = 0;							
							}
							//System.out.println(dwdmMasterDetailsEach);

							switch (cardName) {
							/*case "OPA1PLUS":
							case "OPA2PLUS":
							case "OPA3PLUS":
							case "OPA4PLUS":	
								PerformanceOPAPLUSBL.proccessRequest(dwdmSlotMasterId, rackNumber, subrackNumber, slotNumber, (short)0, nodeIP);	
								break;
							case "OBA1PLUS":
							case "OBA2PLUS":
							case "OBA3PLUS":
							case "OBA4PLUS":
								PerformanceOBAPLUSBL.proccessRequest(dwdmSlotMasterId, rackNumber, subrackNumber, slotNumber, (short)0, nodeIP);								
								break;
							case "OLA1PLUS":
							case "OLA2PLUS":
							case "OLA3PLUS":
							case "OLA4PLUS":
								PerformanceOLAPLUSBL.proccessRequest(dwdmSlotMasterId, rackNumber, subrackNumber, slotNumber, (short)0, nodeIP);
								break;
						    case "10GOMTP12PLUS":
								if("line".equals(portClientLineType)){
									portNumber +=1;
								}
								PerformanceOMTP12PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								
								break;
							case "10GOMTP11PLUS":
								if("line".equals(portClientLineType)){
								portNumber +=1;
								}
								PerformanceOMTP11PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								
								break;
							case "10GOMTP11TPLUS":
								if("line".equals(portClientLineType)){
									portNumber +=0;
								}
								PerformanceOMTP11TPLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
						
								break;
							case "10GOMMP81PLUS":
								if("line".equals(portClientLineType)){
									portNumber +=8;
								}
								PerformanceOMMP81PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								
								break;
							case "10GOMMP82PLUS":
								if("line".equals(portClientLineType)){
									portNumber +=8;
								}
								PerformanceOMMP82PLUSBL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								break;
								*/
							case "OMMP100":
								if("line".equals(portClientLineType)){
									portNumber +=10;
								}
								PerformanceOMMP100BL.proccessRequest(dwdmSlotMasterId, dwdmPortMasterId, trafficName, rackNumber, subrackNumber, slotNumber, portNumber, nodeIP, portTrafficTypeID, portClientLineType);
								break;
								
								
							}
						}else{
							//messagesArea.append("Performance Poll Is Not Completed With In Time For : "+nodeIP+" \n");
							System.out.println("Performance Poll Is Not Completed With In Time For : "+nodeIP+" \n");
							
							return;
						}
					}catch (Exception e) {
						System.out.println(nodeIP+"  "+ cardID+"    "+ dwdmSlotMasterId+"   "+e.getMessage());
						e.printStackTrace();
					}
				}
			}else{
				//messagesArea.append("Node is Down : "+nodeIP+" \n");
				System.out.println("Node is Down : "+nodeIP+" \n");
				
			}

		} catch (Exception e1) {
				e1.printStackTrace();
			}
	
		//messagesArea.append("ended Performance Poll for node : "+nodeIP+" \n");
		System.out.println("ended Performance Poll for node : "+nodeIP+" \n");
	}
	
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=10000;
	public static VariableBinding getSystemDescription(String nodeIP) throws Exception{
		VariableBinding result=null;
		try {
			VariableBinding descOID        = new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,1,0}));
			result = SNMPGet.getSNMP(nodeIP, community, retries, timeOut, descOID, new SNMPVersionDetails());
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
	
}
