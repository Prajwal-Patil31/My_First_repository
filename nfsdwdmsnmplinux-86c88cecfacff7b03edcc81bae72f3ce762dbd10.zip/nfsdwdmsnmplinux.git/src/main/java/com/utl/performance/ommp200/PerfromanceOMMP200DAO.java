package com.utl.performance.ommp200;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import com.ut.connection.pool.DataSource;



public class PerfromanceOMMP200DAO {
	
	public static byte saveClientOpticalPerformance(short clientNumber,long slotMasterID,long portMasterID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 5;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_client_optical_performance (performance1,performance2,performance3,performance4,performance5,dwdm_slot_master_id, dwdm_port_master_id,poll_date_time) VALUES (?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			
			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setTimestamp(index++,pollDateTime);
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	public static byte saveLineOpticalPerformance(short clientNumber,long slotMasterID,long portMasterID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 5;
		try {
			
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_line_optical_performance (performance1,performance2,performance3,performance4,performance5,dwdm_slot_master_id, dwdm_port_master_id,poll_date_time) VALUES (?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			
			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClientSTMPerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 10;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_client_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClient10GLANPerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 19;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_client_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,performance11,performance12,performance13,performance14,performance15,performance16,performance17,performance18,performance19,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClient10GWANPerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 10;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_client_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveClientOTU2Performance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 70;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_client_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,performance11,performance12,performance13,performance14,performance15,performance16,performance17,performance18,performance19,performance20,performance21,performance22,performance23,performance24,performance25,performance26,performance27,performance28,performance29,performance30,performance31,performance32,performance33,performance34,performance35,performance36,performance37,performance38,performance39,performance40,performance41,performance42,performance43,performance44,performance45,performance46,performance47,performance48,performance49,performance50,performance51,performance52,performance53,performance54,performance55,performance56,performance57,performance58,performance59,performance60,performance61,performance62,performance63,performance64,performance65,performance66,performance67,performance68,performance69,performance70,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
	
	public static byte saveLineOTNPerformance(short clientNumber,long slotMasterID,long portMasterID,short traffinNameID,Map<Short,String> result,Timestamp pollDateTime) throws Exception{
		Connection conn=null;
		PreparedStatement psInsert=null;
		byte insertStatus=0;
		short columnCount = 70;
		try {
			conn=DataSource.getInstance().getConnection();
			String query = "INSERT INTO dwdm_ommp_200g_line_traffic_performance (performance1,performance2,performance3,performance4,performance5,performance6,performance7,performance8,performance9,performance10,performance11,performance12,performance13,performance14,performance15,performance16,performance17,performance18,performance19,performance20,performance21,performance22,performance23,performance24,performance25,performance26,performance27,performance28,performance29,performance30,performance31,performance32,performance33,performance34,performance35,performance36,performance37,performance38,performance39,performance40,performance41,performance42,performance43,performance44,performance45,performance46,performance47,performance48,performance49,performance50,performance51,performance52,performance53,performance54,performance55,performance56,performance57,performance58,performance59,performance60,performance61,performance62,performance63,performance64,performance65,performance66,performance67,performance68,performance69,performance70,dwdm_slot_master_id, dwdm_port_master_id,port_traffic_type,poll_date_time) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			psInsert=conn.prepareStatement(query);

			String value=null;
			short index=1;
			for(index=1;index<=columnCount;index++){
				value=result.get(index);
				psInsert.setString(index,value);
			}
			
			psInsert.setLong(index++, slotMasterID);
			psInsert.setLong(index++, portMasterID);
			psInsert.setShort(index++, traffinNameID);
			psInsert.setTimestamp(index++,pollDateTime);
			
			insertStatus=(byte) psInsert.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(psInsert!=null){
				try {
					psInsert.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return insertStatus;
	}
}
