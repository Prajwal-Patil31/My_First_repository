package com.utl.trap.receiver.scc;

import java.util.HashMap;
import java.util.Map;

public class SCCAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		//scc alarms only with alarmindex 1/2/3
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.11";
		alarmName="SCC High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.12";
		alarmName="SCC High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.13";
		alarmName="SCC Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
						
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.62";
		alarmName="SCC System Restart";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.63";
		alarmName="Direction Conflict";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.64";
		alarmName="Link Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
