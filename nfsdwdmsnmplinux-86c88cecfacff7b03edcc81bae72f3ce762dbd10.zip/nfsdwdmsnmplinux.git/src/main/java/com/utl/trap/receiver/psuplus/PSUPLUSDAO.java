package com.utl.trap.receiver.psuplus;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.LinkedHashMap;
import java.util.List;

import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class PSUPLUSDAO {
	public static byte updateAlarm(int slotMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_psu_alarm where dwdm_slot_master_id=?");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn.prepareStatement("UPDATE dwdm_psu_alarm SET alarm"+alarmIndex+"=? where dwdm_slot_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, slotMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_psu_alarm(dwdm_slot_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, slotMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	public static LinkedHashMap<Byte, String> getAllAlarmSeverityForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Byte, String> alarmSeverity=new LinkedHashMap<Byte, String>();
		PreparedStatement psSelect=null;
		ResultSet rsSelect=null;
		try {
			
			psSelect=conn.prepareStatement("SELECT * FROM dwdm_psu_alarm_severity where dwdm_slot_master_id=?");
			psSelect.setLong(1, slotMasterID);
			rsSelect=psSelect.executeQuery();
			if (rsSelect.next()) {
				for (byte i = 1; i <= 10; i++) {
					alarmSeverity.put(i, rsSelect.getString("alarm" + i));
				}
			}else{
				for (byte i = 1; i <= 10; i++) {
					alarmSeverity.put(i, "Critical");
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rsSelect!=null){
					rsSelect.close();
				}
				if(psSelect!=null){
					psSelect.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return alarmSeverity;
	}
	
	public static LinkedHashMap<Byte, Byte> getAllAlarmForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Byte, Byte> allAlarmPresentDb=new LinkedHashMap<Byte, Byte>();
		PreparedStatement psSelect=null;
		ResultSet rsSelect=null;
		try {
			
			psSelect=conn.prepareStatement("SELECT * FROM dwdm_psu_alarm where dwdm_slot_master_id=?");
			psSelect.setLong(1, slotMasterID);
			rsSelect=psSelect.executeQuery();
			if (rsSelect.next()) {
				for (byte i = 1; i <= 10; i++) {
					allAlarmPresentDb.put(i, rsSelect.getByte("alarm" + i));
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rsSelect!=null){
					rsSelect.close();
				}
				if(psSelect!=null){
					psSelect.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return allAlarmPresentDb;
	}
	public static String getAlarmSeverity(int slotMasterID,String alarmIndex, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String alarmSeverity="Critical";
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_psu_alarm_severity  where dwdm_slot_master_id=?");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				alarmSeverity=rsForSelect.getString(1);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return alarmSeverity;
	}
	
	public static byte  updateAlarmTrans(int slotMasterID,byte alarmStatus,String alarmName,String alarmSeverity,Timestamp alarmGeneratedTime,Connection conn) throws Exception{
		byte result = 0;
		CallableStatement cstmtForUpdateAlarms = null;
		try {
			cstmtForUpdateAlarms = conn.prepareCall("CALL dwdm_psu_alarm_trans_update(?,?,?,?)");
			cstmtForUpdateAlarms.setInt(1, slotMasterID);
			cstmtForUpdateAlarms.setByte(2, alarmStatus);
			cstmtForUpdateAlarms.setString(3, alarmName);
		//	cstmtForUpdateAlarms.setString(4, alarmSeverity);//no severity
			cstmtForUpdateAlarms.setTimestamp(4, alarmGeneratedTime);
			result=(byte) cstmtForUpdateAlarms.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			if(cstmtForUpdateAlarms!=null){
				cstmtForUpdateAlarms.close();
			}
		}
		return result;
	}
	
	public static void updateJackInOutHistory(boolean jackIn,Connection conn,int slotMasterID,String dateTime,String cardName){
		PreparedStatement psForSelect=null,psForUpdate=null,psForInsert=null,psForGetCardName=null;
		ResultSet rsForSelect=null,rs=null;
		try {
			
			
			psForGetCardName=conn.prepareStatement("SELECT card_name FROM dwdm_slot_master WHERE dwdm_slot_master_id = ?");
			psForGetCardName.setInt(1, slotMasterID);
			rs=psForGetCardName.executeQuery();
            while ( rs.next() ) {
            	cardName = rs.getString("card_name");       
            	System.out.println("jack card is" +cardName);
            }
     //       if (cardName.equals("10GOMTP12") || cardName.equals("10GOMMP82")||cardName.contains("OBA")||cardName.contains("OPA"))
      //      {
			if(jackIn){
				psForSelect=conn.prepareStatement("SELECT *  FROM card_jackin_jackout_history where card_jackin_jackout_history_id=(SELECT max(card_jackin_jackout_history_id)  FROM card_jackin_jackout_history where dwdm_slot_master_id=?)");
				psForSelect.setInt(1, slotMasterID);
				rsForSelect=psForSelect.executeQuery();
				boolean insert=true;
				if(rsForSelect.next()){
					long historyId=rsForSelect.getLong("card_jackin_jackout_history_id");
					String jackOutTime=rsForSelect.getString("jackout_time");
					String jackInTime=rsForSelect.getString("jackin_time");
				//	String prevCardName=rsForSelect.getString("card_name");
				//	if(jackOutTime!=null&&jackInTime==null&&prevCardName.endsWith(cardName)){
					if(jackOutTime!=null&&jackInTime==null){
						insert=false;
						psForUpdate=conn.prepareStatement("update card_jackin_jackout_history set jackin_time=? where card_jackin_jackout_history_id=?");
						psForUpdate.setString(1, dateTime);
						psForUpdate.setLong(2, historyId);
						psForUpdate.executeUpdate();
					}
				}
				if(insert){
				psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackin_time`,card_name)VALUES(?,?,?)");
				//	psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackin_time`)VALUES(?,?)");
					
					psForInsert.setInt(1, slotMasterID);
					psForInsert.setString(2, dateTime);
					psForInsert.setString(3, cardName);
					psForInsert.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackout_time`,card_name)VALUES(?,?,?)");
				//psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackout_time`)VALUES(?,?)");
				psForInsert.setInt(1, slotMasterID);
				psForInsert.setString(2, dateTime);
				psForInsert.setString(3, cardName);
				psForInsert.executeUpdate();
			}
    //        }
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(psForSelect!=null){
					psForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(psForUpdate!=null){
					psForUpdate.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(psForInsert!=null){
					psForInsert.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public static byte updateJack(int slotMasterID, byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null, psForInsert=null, psForUpdate=null;
		ResultSet rsForSelect=null;
		try {
			
			if(alarmStatus==1){
				psForUpdate = conn.prepareStatement("UPDATE dwdm_slot_master SET card_status=?,global_alarm_status=0 where dwdm_slot_master_id=?");
				psForUpdate.setString(1, "removed");
				psForUpdate.setInt(2, slotMasterID);
				psForUpdate.executeUpdate();
			}else if(alarmStatus==0){
				psForUpdate = conn.prepareStatement("UPDATE dwdm_slot_master SET  card_status=? where dwdm_slot_master_id=?");				
				psForUpdate.setString(1, "manage");
				psForUpdate.setInt(2, slotMasterID);
				psForUpdate.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return 1;
	}
	
	public static byte updateMCBCardStatus(LinkedHashMap<Byte, Byte> allAlarmPresentFromDb,ReceivedTrapDetails trapDetails, Connection conn) throws Exception{
		PreparedStatement psForUpdate=null;
		try {
			//PSU-1 Input Fail Source-1 
			byte alarm4=allAlarmPresentFromDb.get((byte)4);
			//PSU-1 Input Fail Source-2 
			byte alarm9=allAlarmPresentFromDb.get((byte)9);
			String mcbStatus="mcbOnOn";
			if(alarm4 == 0 && alarm9 == 0 ){
				mcbStatus="mcbOnOn";
			}else if(alarm4 == 1 && alarm9 == 1 ){
				//mcbStatus="mcbOffOff";//offoff means complete switchoff..how?  srk 10062016
				mcbStatus="mcbOnOn";
			}else if(alarm4 == 1 && alarm9 == 0){
				mcbStatus="mcbOffOn";
			}
			else if(alarm4 == 0 && alarm9 == 1){
				mcbStatus="mcbOnOff";
			}
			//MCB slot
			trapDetails.setSlot((short) 5);
			List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails,conn);
			int slotMasterID=Integer.parseInt(slotDetails.get(1));
			psForUpdate = conn.prepareStatement("update dwdm_slot_master set card_name=? where dwdm_slot_master_id=?");
			psForUpdate.setString(1, mcbStatus);
			psForUpdate.setInt(2, slotMasterID);
			psForUpdate.executeUpdate();
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
		}
		return 1;
	}
}
