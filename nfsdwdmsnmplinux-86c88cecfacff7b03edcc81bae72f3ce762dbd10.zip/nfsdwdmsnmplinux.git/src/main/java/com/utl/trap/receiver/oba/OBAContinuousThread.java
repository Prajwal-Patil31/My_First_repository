package com.utl.trap.receiver.oba;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;

import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class OBAContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedOBATraps;
	static Logger l = Logger.getLogger(OBAContinuousThread.class);
	
	public OBAContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedOBATraps) {
		super("OBA Continuous Thread");
		this.receivedOBATraps = receivedOBATraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOBATraps.take();
				System.out.println("Start OBA");
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OBAAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("OBA TRAPS=============>>>>>>"+slotDetails);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OBADAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OBADAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OBADAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
				
						//check all OBA alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OBADAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OBADAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						l.info("OBA Global Alarm Process Completed......"+status);
					}
				}
			} catch (Exception e) {
				
				l.info("OBA Alarm Processing Error......");
				l.error(e.getMessage(),e);
				
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
