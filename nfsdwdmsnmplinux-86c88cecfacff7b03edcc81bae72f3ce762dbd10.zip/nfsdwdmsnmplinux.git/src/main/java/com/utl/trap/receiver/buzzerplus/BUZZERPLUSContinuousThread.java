package com.utl.trap.receiver.buzzerplus;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.oba.OBADAO;
import com.utl.util.CommonDAO;

public class BUZZERPLUSContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedBUZZERPLUSTraps;
	//static Logger l = Logger.getLogger(BUZZERPLUSContinuousThread.class);
	
	public BUZZERPLUSContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedBUZZERPLUSTraps) {
		super("BUZZER PLUS Continuous Thread");
		this.receivedBUZZERPLUSTraps = receivedBUZZERPLUSTraps;
	}	
	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedBUZZERPLUSTraps.take();
				System.out.println("Start BUZZER PLUS");
				System.out.println(trapDetails);
				byte alarmStatus  = trapDetails.getAlarmStatus();
				String oID        = trapDetails.getOID();
				String[] alarmMiscData = BUZZERPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				//String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
			
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					
						if(alarmIndex.equals("99"))//To get Buzzer card presence/absence notification status
						{						
							BUZZERPLUSDAO.updateJack(slotMasterID, alarmStatus, conn);						
						}
						
				}
			} catch (Exception e) {
				System.out.println("BUZZER PLUS Alarm Processing Error......");
				e.getMessage();
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
