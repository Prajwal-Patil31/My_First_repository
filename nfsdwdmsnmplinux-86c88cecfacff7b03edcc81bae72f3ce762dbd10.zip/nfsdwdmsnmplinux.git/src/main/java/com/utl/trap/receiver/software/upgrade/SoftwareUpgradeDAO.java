package com.utl.trap.receiver.software.upgrade;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

public class SoftwareUpgradeDAO {
	
	
	public static byte  updateSWUpgradeStatus(int slotMasterID,String swUpgradeStatus,Timestamp alarmGeneratedTime,Connection conn) throws Exception{
		byte result = 0;
		PreparedStatement psForInsert=null;
		try {
			psForInsert=conn.prepareStatement("INSERT INTO dwdm_card_software_upgrade_status(dwdm_slot_master_id,software_upgrade_status,status_start_time)VALUES(?,?,?)");
			psForInsert.setInt(1, slotMasterID);				
			psForInsert.setString(2, swUpgradeStatus);			
			psForInsert.setTimestamp(3, alarmGeneratedTime);
			psForInsert.executeUpdate();
			
		} catch (Exception e) {
			throw e;
		}finally{
			if(psForInsert!=null){
				psForInsert.close();
			}
		}
		return result;
	}
}
