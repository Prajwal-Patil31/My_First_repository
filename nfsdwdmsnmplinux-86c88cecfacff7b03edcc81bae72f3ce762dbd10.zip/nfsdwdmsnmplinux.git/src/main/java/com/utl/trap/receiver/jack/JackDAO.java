package com.utl.trap.receiver.jack;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ut.connection.pool.DataSource;

public class JackDAO {
	public static byte updateJack(int slotMasterID, String cardName, byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null, psForInsert=null, psForUpdate=null;
		ResultSet rsForSelect=null;
		try {
			if(alarmStatus==0){
					psForUpdate = conn.prepareStatement("UPDATE dwdm_slot_master SET card_status=?,global_alarm_status=0 where dwdm_slot_master_id=?");
					psForUpdate.setString(1, "removed");
					psForUpdate.setInt(2, slotMasterID);
					psForUpdate.executeUpdate();
					System.out.println("updateJack" + cardName);
					if("BMUPLUS".equals(cardName)){
						doAfterBMUJackOUT(slotMasterID, conn);
					}
			}else if(alarmStatus==1){
				psForUpdate = conn.prepareStatement("UPDATE dwdm_slot_master SET card_name=?, card_status=? where dwdm_slot_master_id=?");
				psForUpdate.setString(1, cardName);
				psForUpdate.setString(2, "manage");
				psForUpdate.setInt(3, slotMasterID);
				psForUpdate.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return 1;
	}
/*	public static void main(String[] args) throws Exception {
		try {
			Connection conn = DataSource.getInstance().getConnection();
			doAfterBMUJackOUT(167, conn);
		} catch (SQLException | IOException | PropertyVetoException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
	public static byte doAfterBMUJackOUT(int slotMasterID, Connection conn) throws Exception{
		PreparedStatement psForSelect=null, psForDelete=null, psForUpdate=null, psForManageUpdate=null,psForUpdateGlobalAlarm=null, psForUpdateMCB=null;
		ResultSet rsForSelect=null;
		try {//
			psForSelect = conn.prepareStatement("SELECT dwdm_slot_master_id,slot_number FROM dwdm_slot_master where dwdm_subrack_master_id = (select dwdm_subrack_master_id FROM dwdm_slot_master where dwdm_slot_master_id=?) and slot_number in (2,3,5)");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect = psForSelect.executeQuery();
			psForUpdate = conn.prepareStatement("UPDATE dwdm_psu_alarm SET `alarm1`=0, `alarm2`=0, `alarm3`=0, `alarm4`=0, `alarm5`=0, `alarm6`=0, `alarm7`=0, `alarm8`=0, `alarm9`=0, `alarm10`=0  where dwdm_slot_master_id=?");
			psForManageUpdate = conn.prepareStatement("UPDATE dwdm_slot_master SET card_status = 'manage'  where dwdm_slot_master_id=?");
			psForDelete = conn.prepareStatement("DELETE FROM dwdm_psu_alarm_trans WHERE dwdm_slot_master_id = ?");
			psForUpdateGlobalAlarm = conn.prepareStatement("update dwdm_slot_master set global_alarm_status=0 where dwdm_slot_master_id=?");
			psForUpdateMCB = conn.prepareStatement("update dwdm_slot_master set card_name='mcbOnOn' where dwdm_slot_master_id=?");
			while ( rsForSelect.next() ) {
				short slotNumber = rsForSelect.getShort("slot_number");
				int slotId = rsForSelect.getInt("dwdm_slot_master_id");	
				if(slotNumber == 5){
					psForUpdateMCB.setInt(1, slotId);
					psForUpdateMCB.executeUpdate();
				}else{
					psForUpdate.setInt(1, slotId);
					psForManageUpdate.setInt(1, slotId);
					psForDelete.setInt(1, slotId);
					psForUpdateGlobalAlarm.setInt(1, slotId);
					psForUpdate.addBatch();
					psForManageUpdate.addBatch();
					psForDelete.addBatch();
					psForUpdateGlobalAlarm.addBatch();
				}
				
			}
			psForUpdate.executeBatch();
			psForManageUpdate.executeBatch();
			psForDelete.executeBatch();
			psForUpdateGlobalAlarm.executeBatch();
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForManageUpdate!=null){
				psForManageUpdate.close();
			}
			if(psForUpdateGlobalAlarm!=null){
				psForUpdateGlobalAlarm.close();
			}
			if(psForDelete!=null){
				psForDelete.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return 1;
	}
	
	public static void updateJackInOutHistory(boolean jackIn,Connection conn,int slotMasterID,String dateTime,String cardName){
		PreparedStatement psForSelect=null,psForUpdate=null,psForInsert=null,psForGetCardName=null;
		ResultSet rsForSelect=null,rs=null;
		try {
			
			
			psForGetCardName=conn.prepareStatement("SELECT card_name FROM dwdm_slot_master WHERE dwdm_slot_master_id = ?");
			psForGetCardName.setInt(1, slotMasterID);
			rs=psForGetCardName.executeQuery();
            while ( rs.next() ) {
            	cardName = rs.getString("card_name");       
            	System.out.println("jack card is" +cardName);
            }
     //       if (cardName.equals("10GOMTP12") || cardName.equals("10GOMMP82")||cardName.contains("OBA")||cardName.contains("OPA"))
      //      {
			if(jackIn){
				psForSelect=conn.prepareStatement("SELECT *  FROM card_jackin_jackout_history where card_jackin_jackout_history_id=(SELECT max(card_jackin_jackout_history_id)  FROM card_jackin_jackout_history where dwdm_slot_master_id=?)");
				psForSelect.setInt(1, slotMasterID);
				rsForSelect=psForSelect.executeQuery();
				boolean insert=true;
				if(rsForSelect.next()){
					long historyId=rsForSelect.getLong("card_jackin_jackout_history_id");
					String jackOutTime=rsForSelect.getString("jackout_time");
					String jackInTime=rsForSelect.getString("jackin_time");
				//	String prevCardName=rsForSelect.getString("card_name");
				//	if(jackOutTime!=null&&jackInTime==null&&prevCardName.endsWith(cardName)){
					if(jackOutTime!=null&&jackInTime==null){
						insert=false;
						psForUpdate=conn.prepareStatement("update card_jackin_jackout_history set jackin_time=? where card_jackin_jackout_history_id=?");
						psForUpdate.setString(1, dateTime);
						psForUpdate.setLong(2, historyId);
						psForUpdate.executeUpdate();
					}
				}
				if(insert){
				psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackin_time`,card_name)VALUES(?,?,?)");
				//	psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackin_time`)VALUES(?,?)");
					
					psForInsert.setInt(1, slotMasterID);
					psForInsert.setString(2, dateTime);
					psForInsert.setString(3, cardName);
					psForInsert.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackout_time`,card_name)VALUES(?,?,?)");
				//psForInsert=conn.prepareStatement("INSERT INTO `card_jackin_jackout_history`(`dwdm_slot_master_id`,`jackout_time`)VALUES(?,?)");
				psForInsert.setInt(1, slotMasterID);
				psForInsert.setString(2, dateTime);
				psForInsert.setString(3, cardName);
				psForInsert.executeUpdate();
			}
    //        }
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(psForSelect!=null){
					psForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(psForUpdate!=null){
					psForUpdate.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				if(psForInsert!=null){
					psForInsert.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
