package com.utl.trap.receiver;

import java.sql.Timestamp;

public class ReceivedTrapDetailsForSWUpgrade {
	private byte node;
	private short rack;
	private short subRack;
	private short slot;
	private byte port;
	private String cardName;
	private String nodeIP;
	private String alarmStatus;
	private Timestamp alarmGeneratedTime;
	private String OID;
	private int portMasterID;
	private String portClientOrLine;
	private int slotMasterID;
	
	public ReceivedTrapDetailsForSWUpgrade(byte node, short rack, short subRack, short slot,
			byte port, String cardName, String nodeIP, String alarmStatus,
			Timestamp alarmGeneratedTime, String oID) {
		super();
		this.node = node;
		this.rack = rack;
		this.subRack = subRack;
		this.slot = slot;
		this.port = port;
		this.cardName = cardName;
		this.nodeIP = nodeIP;
		this.alarmStatus = alarmStatus;
		this.alarmGeneratedTime = alarmGeneratedTime;
		OID = oID;
	}

	
	public ReceivedTrapDetailsForSWUpgrade(byte node, short rack, short subRack, short slot,
			byte port, String cardName, String nodeIP, String alarmStatus,
			Timestamp alarmGeneratedTime, String oID, int portMasterID,
			String portClientOrLine,int slotMasterID) {
		super();
		this.node = node;
		this.rack = rack;
		this.subRack = subRack;
		this.slot = slot;
		this.port = port;
		this.cardName = cardName;
		this.nodeIP = nodeIP;
		this.alarmStatus = alarmStatus;
		this.alarmGeneratedTime = alarmGeneratedTime;
		OID = oID;
		this.portMasterID = portMasterID;
		this.portClientOrLine = portClientOrLine;
		this.slotMasterID = slotMasterID;
	}

	public byte getNode() {
		return node;
	}
	public void setNode(byte node) {
		this.node = node;
	}
	public short getRack() {
		return rack;
	}
	public void setRack(short rack) {
		this.rack = rack;
	}
	public short getSubRack() {
		return subRack;
	}
	public void setSubRack(short subRack) {
		this.subRack = subRack;
	}
	public short getSlot() {
		return slot;
	}
	public void setSlot(short slot) {
		this.slot = slot;
	}
	public byte getPort() {
		return port;
	}
	public void setPort(byte port) {
		this.port = port;
	}
	public String getCardName() {
		return cardName;
	}
	public void setCardName(String cardName) {
		this.cardName = cardName;
	}
	public String getNodeIP() {
		return nodeIP;
	}
	public void setNodeIP(String nodeIP) {
		this.nodeIP = nodeIP;
	}
	public String getAlarmStatus() {
		return alarmStatus;
	}
	public void setAlarmStatus(String alarmStatus) {
		this.alarmStatus = alarmStatus;
	}
	public Timestamp getAlarmGeneratedTime() {
		return alarmGeneratedTime;
	}
	public void setAlarmGeneratedTime(Timestamp alarmGeneratedTime) {
		this.alarmGeneratedTime = alarmGeneratedTime;
	}
	public String getOID() {
		return OID;
	}
	public void setOID(String oID) {
		OID = oID;
	}
	public int getPortMasterID() {
		return portMasterID;
	}
	public void setPortMasterID(int portMasterID) {
		this.portMasterID = portMasterID;
	}
	public String getPortClientOrLine() {
		return portClientOrLine;
	}


	public void setPortClientOrLine(String portClientOrLine) {
		this.portClientOrLine = portClientOrLine;
	}


	public int getSlotMasterID() {
		return slotMasterID;
	}


	public void setSlotMasterID(int slotMasterID) {
		this.slotMasterID = slotMasterID;
	}


	@Override
	public String toString() {
		return "ReceivedTrapDetails [node=" + node + ", rack=" + rack + ", subRack=" + subRack + ", slot=" + slot
				+ ", port=" + port + ", cardName=" + cardName + ", nodeIP=" + nodeIP + ", alarmStatus=" + alarmStatus
				+ ", alarmGeneratedTime=" + alarmGeneratedTime + ", OID=" + OID + ", portMasterID=" + portMasterID
				+ ", portClientOrLine=" + portClientOrLine + ", slotMasterID=" + slotMasterID + "]";
	}
	
}
