package com.utl.trap.receiver.ommp100;

import java.util.HashMap;
import java.util.Map;

public class OMMP100AlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	private static String traffic;
	static{
		//OPTICAL CFP (LINE)
				traffic="OPTICAL";
				alarmIndex="1";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.1";
				alarmName=" CFP Input Power Failure";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="2";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.2";
				alarmName="CFP Output Power Failure";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="3";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.3";
				alarmName="CFP High Temperature";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="4";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.4";
				alarmName="CFP Low Temperature";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});		
				
				alarmIndex="5";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.7";
				alarmName="CFP Input High Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="6";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.8";
				alarmName="CFP Input Low Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});		
			
				
				alarmIndex="7";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.11";
				alarmName="CFP Output High Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="8";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.12";
				alarmName="CFP Output Low Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				
				//OPTICAL SFP (CLIENT)
				traffic="OPTICAL";
				alarmIndex="1";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.20";
				alarmName="SFP Input Power Failure";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="2";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.21";
				alarmName="SFP Output Power Failure";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="3";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.22";
				alarmName="SFP High Temperature";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="4";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.23";
				alarmName="SFP Low Temperature";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
							
				alarmIndex="5";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.26";
				alarmName=" SFP High Bias Current";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="6";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.27";
				alarmName="SFP Low Bias Current";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
						
				alarmIndex="7";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.30";
				alarmName="SFP Input High Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="8";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.31";
				alarmName="SFP Input Low Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
					
				alarmIndex="9";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.34";
				alarmName="SFP Output High Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="10";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.35";
				alarmName="SFP Output Low Power";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
					
				
				//OTU & ODU Line
				traffic="OTU-ODU";
				
				alarmIndex="1";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.44";
				alarmName="OTU Loss of Signal Payload";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="2";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.45";
				alarmName="OTU Loss of Frame";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="3";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.46";
				alarmName="OTU Out of Frame";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="4";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.47";
				alarmName="OTU Loss of Multi Frame";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="5";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.48";
				alarmName="OTU Out of Multi Frame";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
							
				alarmIndex="6";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.50";
				alarmName="OTU Signal Degrade";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="7";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.51";
				alarmName="OTU Alarm Indication Signal";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="8";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.52";
				alarmName="OTU Incoming Alignment Error";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="9";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.53";
				alarmName="OTU Backward Incoming Alignment Error";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="10";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.54";
				alarmName="OTU Backward Defect Indication";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
			
				alarmIndex="11";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.56";
				alarmName="ODU Signal Degrade";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="12";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.57";
				alarmName="ODU Alarm Indication Signal";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="13";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.58";
				alarmName="ODU TCM1 Incoming Alignment Error";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
						
				alarmIndex="14";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.64";
				alarmName="ODU Locked Defect";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="15";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.65";
				alarmName="ODU Open Connection Indication";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="16";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.66";
				alarmName="ODU Backward Defect Indication";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="17";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.67";
				alarmName="ODU TCM1 Backward Incoming Alignment Error";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="18";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.73";
				alarmName="ODU Loss of Frame Loss of Multiframe";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});

				alarmIndex="19";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.74";
				alarmName="OPU Payload Mismatch";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
						
				alarmIndex="20";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.96";
				alarmName="OTU Trace Identifier Mismatch";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="21";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.97";
				alarmName="ODU Trace Identifier Mismatch";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
			
				//SDH STM-64
				traffic="SDH";
				
				alarmIndex="1";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.75";
				alarmName="SDH Loss of Signal Payload";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="2";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.76";
				alarmName="SDH Out of Frame";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="3";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.77";
				alarmName="SDH Loss of Frame";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
								
				alarmIndex="4";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.82";
				alarmName="SDH MS Alarm Indication Signal";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
					
				
				alarmIndex="5";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.84";
				alarmName="SDH MS Remote Defect Indication";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
					
				alarmIndex="6";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.86";
				alarmName="SDH MS B2 Signal Fail";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="7";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.87";
				alarmName="SDH MS B2 Signal Degrade";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});		
				
				
				//Ethernet 10Gig
				traffic="ETHERNET";
				
				alarmIndex="1";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.91";
				alarmName="Ethernet Loss of Signal Payload";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="2";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.92";
				alarmName=" Ethernet Link Failure";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="3";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.93";
				alarmName="Ethernet High BER";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="4";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.94";
				alarmName="Ethernet Local Fault ";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
				alarmIndex="5";
				OID="1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1.95";
				alarmName="Ethernet Remote Fault";
				hide="false";
				alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});	
		
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
