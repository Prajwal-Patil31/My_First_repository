package com.utl.trap.receiver.omtp12plus;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;

import com.utl.util.CommonDAO;


public class OMTP12PLUSRunnable implements Runnable{
	
	private ReceivedTrapDetails trapDetails;
//	static Logger l = Logger.getLogger(OMTP12PLUSRunnable.class);
	public OMTP12PLUSRunnable(ReceivedTrapDetails trapDetails) {
		super();
		this.trapDetails = trapDetails;
	}

	@Override
	public void run() {
		System.out.println(trapDetails);
		
		Connection conn=null;
		try {
			byte alarmStatus    = trapDetails.getAlarmStatus();
			int portNo=trapDetails.getPort();
			int portMasterID    = trapDetails.getPortMasterID();
			String clientOrLine = trapDetails.getPortClientOrLine();
			
			String oID = trapDetails.getOID();
			String[] alarmMiscData = OMTP12PLUSAlarmNames.getDetails(oID);
			
			String alarmIndex = alarmMiscData[0];
			String alarmName  = alarmMiscData[1];
			String hide       = alarmMiscData[2];
			String traffic    = alarmMiscData[3];
			
			if ("false".equals(hide)) {
				
				byte prevAlarmStatus;
				
				conn=DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
			//	portMasterID=CommonDAO.getPortMasterID(Integer.parseInt(slotDetails.get(1)), portNo, conn);
				///code to get portMasterID
			/*	if(portNo>8)
				{
					clientOrLine="line";	
				}
				else
				{
					clientOrLine="client";
				}*/
				
				if("client".equals(clientOrLine)){
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP12PLUSDAO.updateAlarmClientOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP12PLUSDAO.updateAlarmClientTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}else{
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP12PLUSDAO.updateAlarmLineOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP12PLUSDAO.updateAlarmLineTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}
				if(alarmStatus!=prevAlarmStatus){
					System.out.println("INSIDE OMTP12PLUS");
					/*if ("11".equals(alarmIndex) )
					{
						System.out.println("INSIDE OMTP12PLUS OTU-BIAE");
					}*/
					String alarmSeverity = OMTP12PLUSDAO.getAlarmSeverity(portMasterID, alarmIndex, clientOrLine, traffic, conn);
					OMTP12PLUSDAO.updateAlarmTrans(portMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), traffic, clientOrLine, conn);
					
					LinkedHashMap<Short, Byte> allAlarmPresentFromDb =OMTP12PLUSDAO.getAllAlarmForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					LinkedHashMap<Short, String> allAlarmSeverity =OMTP12PLUSDAO.getAllAlarmSeverityForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					byte status = CommonDAO.updateInToDwdmLineCardsGlobalAlarmStatusAlarms(Integer.parseInt(slotDetails.get(1)), allAlarmSeverity, allAlarmPresentFromDb, conn);
					//l.info("OMTP12PLUS Global Alarm Process Completed......"+status);
					//update_global_alarm
					
					/*CallableStatement omtp12plusGlobalAlarmCallable = null;
					omtp12plusGlobalAlarmCallable = conn.prepareCall("CALL update_global_alarm_plus(?,?)");
					omtp12plusGlobalAlarmCallable.setInt(1,Integer.parseInt(slotDetails.get(1)));
					omtp12plusGlobalAlarmCallable.setString(2,trapDetails.getCardName());
					omtp12plusGlobalAlarmCallable.executeQuery();*/
					System.out.println("OMTP12PLUS Global Alarm Process Completed......");
					
					
				}
				
			}
			
		} catch (Exception e) {
			//l.info(e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
