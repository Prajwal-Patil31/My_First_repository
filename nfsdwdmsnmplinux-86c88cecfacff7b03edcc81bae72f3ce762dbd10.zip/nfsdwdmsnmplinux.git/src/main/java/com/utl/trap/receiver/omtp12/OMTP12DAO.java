package com.utl.trap.receiver.omtp12;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.GetDetailsFromPropertiesFile;

public class OMTP12DAO {
	public static List<ReceivedTrapDetails> getReceivedTrapDetailsFromDB() throws Exception{
		PreparedStatement ps=null,psForDelete=null;
		ResultSet rs=null;
		Connection conn = null;
		List<ReceivedTrapDetails> trapReceivedDetailsBeanList=new ArrayList<ReceivedTrapDetails>();
		try {
			short limit = Short.parseShort(GetDetailsFromPropertiesFile.getValue("concurrent.process.trap"));
			StringBuffer query=new StringBuffer("SELECT dwdm_trap_receiver_omtp12_alarm_details_id,`node_number`,`rack_number`,`subrack_number`,`slot_number`,`port_number`,`node_ip_address`,`OID`,`card_name`,`alarm_status`,`dwdm_port_master_id`,`port_client_line_type`,`alarm_generated_time`,dwdm_slot_master_id FROM dwdm_trap_receiver_omtp12_alarm_details group by dwdm_port_master_id limit ");
			query.append(limit);
			conn = DataSource.getInstance().getConnection();
			ps=conn.prepareStatement(query.toString());
			psForDelete=conn.prepareStatement("DELETE FROM `dwdm_trap_receiver_omtp12_alarm_details` WHERE `dwdm_trap_receiver_omtp12_alarm_details_id`=?");
			rs=ps.executeQuery();
			while(rs.next()){
				ReceivedTrapDetails trapReceivedDetailsBean=new ReceivedTrapDetails(rs.getByte("node_number")
						,rs.getShort("rack_number"),rs.getShort("subrack_number"),rs.getShort("slot_number"),rs.getByte("port_number"),rs.getString("card_name"),rs.getString("node_ip_address"),rs.getByte("alarm_status")
						,rs.getTimestamp("alarm_generated_time"),rs.getString("OID"),rs.getInt("dwdm_port_master_id"),rs.getString("port_client_line_type"),rs.getInt("dwdm_slot_master_id"));
				trapReceivedDetailsBeanList.add(trapReceivedDetailsBean);
				psForDelete.setInt(1, rs.getInt("dwdm_trap_receiver_omtp12_alarm_details_id"));
				psForDelete.addBatch();
			}
			psForDelete.executeBatch();
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(ps!=null){
					ps.close();
				}
				if(psForDelete!=null){
					psForDelete.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return trapReceivedDetailsBeanList;
	}
	public static void insertReceivedTrapDetails(ReceivedTrapDetails trapDetails) throws Exception{
		Connection conn=null;
		PreparedStatement psForSelect=null,psForInsert=null;
		ResultSet rsForSelect=null;
		int portNo=0;
		String client_line_type="";
		if(trapDetails.getPort()>1)
		{
			portNo=trapDetails.getPort()-1;
			client_line_type="line";
		}
		else
		{
			portNo=trapDetails.getPort();
			client_line_type="client";
		}
	//	System.out.println("trapDetails.getNodeIP() OMTP12::"+trapDetails.getNodeIP());
	//	System.out.println("trapDetails.getRack() OMTP12::"+trapDetails.getRack());
	//	System.out.println("trapDetails.getSubRack() OMTP12::"+trapDetails.getSubRack());
	//	System.out.println("trapDetails.getSlot() OMTP12::"+trapDetails.getSlot());
	//	System.out.println("Port Number OMTP12::"+portNo);
	//	System.out.println("client_line_type OMTP12::"+client_line_type);
		
		try {
				conn=DataSource.getInstance().getConnection();
				psForSelect=conn.prepareStatement("SELECT node.node_details_id,dwdm_port_master_id,port_client_line_type,slot.dwdm_slot_master_id FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id join dwdm_port_master dport on slot.dwdm_slot_master_id = dport.dwdm_slot_master_id   where node.node_ip_address=? and rack.rack_number=? and subrack.subrack_number=? and slot.slot_number=? and dport.port_number=? and dport.port_client_line_type=?");
				psForSelect.setString(1, trapDetails.getNodeIP());
				psForSelect.setShort(2, trapDetails.getRack());
				psForSelect.setShort(3, trapDetails.getSubRack());
				psForSelect.setShort(4, trapDetails.getSlot());
				psForSelect.setInt(5, portNo);
				psForSelect.setString(6, client_line_type);
				rsForSelect=psForSelect.executeQuery();
	//			System.out.println("trapDetails.getNodeIP() OMTP12 INSIDE::"+trapDetails.getNodeIP());
	//			System.out.println("trapDetails.getRack() OMTP12 INSIDE::"+trapDetails.getRack());
	//			System.out.println("trapDetails.getSubRack() OMTP12 INSIDE::"+trapDetails.getSubRack());
	//			System.out.println("trapDetails.getSlot() OMTP12 INSIDE::"+trapDetails.getSlot());
	//			System.out.println("Port Number OMTP12 INSIDE::"+portNo);
	//			System.out.println("client_line_type OMTP12 INSIDE::"+client_line_type);
				if(rsForSelect.next()){
					psForInsert=conn.prepareStatement("INSERT INTO dwdm_trap_receiver_omtp12_alarm_details(node_number,rack_number,subrack_number,slot_number,port_number,node_ip_address,OID,card_name,alarm_status,dwdm_port_master_id,port_client_line_type,alarm_generated_time,dwdm_slot_master_id)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
					psForInsert.setShort(1, trapDetails.getNode());
					psForInsert.setShort(2, trapDetails.getRack());
					psForInsert.setShort(3, trapDetails.getSubRack());
					psForInsert.setShort(4, trapDetails.getSlot());
					psForInsert.setInt(5, portNo);
					psForInsert.setString(6, trapDetails.getNodeIP());
					psForInsert.setString(7, trapDetails.getOID());
					psForInsert.setString(8, trapDetails.getCardName());
					psForInsert.setByte(9, trapDetails.getAlarmStatus());
					psForInsert.setInt(10, rsForSelect.getInt("dwdm_port_master_id"));
					psForInsert.setString(11, client_line_type);
					psForInsert.setTimestamp(12, trapDetails.getAlarmGeneratedTime());
					psForInsert.setInt(13, rsForSelect.getInt("dwdm_slot_master_id"));
					psForInsert.executeUpdate();
					System.out.println("trapDetails.getNodeIP() OMTP12 AFTER::"+trapDetails.getNodeIP());
					System.out.println("trapDetails.getRack() OMTP12 AFTER::"+trapDetails.getRack());
					System.out.println("trapDetails.getSubRack() OMTP12 AFTER::"+trapDetails.getSubRack());
					System.out.println("trapDetails.getSlot() OMTP12 AFTER::"+trapDetails.getSlot());
					System.out.println("Port Number OMTP12 AFTER::"+portNo);
					System.out.println("client_line_type OMTP12 AFTER::"+client_line_type);
				}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(psForInsert!=null){
					psForInsert.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static byte updateAlarmClientOptical(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp12_10g_client_optical_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp12_10g_client_optical_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp12_10g_client_optical_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static byte updateAlarmClientTraffic(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp12_10g_client_traffic_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp12_10g_client_traffic_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp12_10g_client_traffic_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static byte updateAlarmLineTraffic(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp12_10g_line_traffic_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp12_10g_line_traffic_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp12_10g_line_traffic_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static byte updateAlarmLineOptical(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp12_10g_line_optical_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp12_10g_line_optical_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp12_10g_line_optical_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static String getAlarmSeverity(int portMasterID,String alarmIndex,String clientOrLine,String traffic, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String alarmSeverity="Critical";
		try {
			String tableName;
			if("Client".equals(clientOrLine)){
				if("OPTICAL".equals(traffic)){
					tableName="dwdm_omtp12_10g_client_optical_alarm_severity";
				}else{
					tableName="dwdm_omtp12_10g_client_traffic_alarm_severity";
				}
			}else{
				if("OPTICAL".equals(traffic)){
					tableName="dwdm_omtp12_10g_line_optical_alarm_severity";
				}else{
					tableName="dwdm_omtp12_10g_line_traffic_alarm_severity";
				}
			}
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM "+tableName+"  where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				alarmSeverity=rsForSelect.getString(1);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return alarmSeverity;
	}
	
	public static byte  updateAlarmTrans(int portMasterID,byte alarmStatus,String alarmName,String alarmSeverity,Timestamp alarmGeneratedTime,String traffic,String clientOrLine,Connection conn) throws Exception{
		byte result = 0;
		CallableStatement cstmtForUpdateAlarms = null;
		try {
			cstmtForUpdateAlarms = conn.prepareCall("CALL dwdm_omtp12_10g_alarm_trans_update(?,?,?,?,?,?,?)");
			cstmtForUpdateAlarms.setInt(1, portMasterID);
			cstmtForUpdateAlarms.setByte(2, alarmStatus);
			cstmtForUpdateAlarms.setString(3, alarmName);
			cstmtForUpdateAlarms.setString(4, alarmSeverity);
			cstmtForUpdateAlarms.setTimestamp(5, alarmGeneratedTime);
			cstmtForUpdateAlarms.setString(6, traffic);
			cstmtForUpdateAlarms.setString(7, clientOrLine);
			result=(byte) cstmtForUpdateAlarms.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			if(cstmtForUpdateAlarms!=null){
				cstmtForUpdateAlarms.close();
			}
		}
		return result;
	}
	public static LinkedHashMap<Byte, String> getAllAlarmSeverityForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Byte, String> alarmSeverity=new LinkedHashMap<Byte, String>();
		PreparedStatement ps1Select=null,ps2Select=null,ps3Select=null,ps4Select=null;
		ResultSet rs1Select=null,rs2Select=null,rs3Select=null,rs4Select=null;
		try {
			
			ps1Select=conn.prepareStatement("select * from dwdm_omtp12_10g_client_optical_alarm_severity coa where coa.dwdm_port_master_id=?");
			ps2Select=conn.prepareStatement("select * from dwdm_omtp12_10g_client_traffic_alarm_severity cta where cta.dwdm_port_master_id=?");
			ps3Select=conn.prepareStatement("select * from dwdm_omtp12_10g_line_optical_alarm_severity loa where loa.dwdm_port_master_id=?");
			ps4Select=conn.prepareStatement("select * from dwdm_omtp12_10g_line_traffic_alarm_severity lta where lta.dwdm_port_master_id=?");
			ps1Select.setLong(1, slotMasterID);
			rs1Select=ps1Select.executeQuery();
			if (rs1Select.next()) {
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(i, rs1Select.getString("alarm" + i));
				}
			}else{
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(i, "Critical");
				}
			}
			
			ps2Select.setLong(1, slotMasterID);
			rs2Select=ps2Select.executeQuery();
			byte rowCount=25;
			if (rs2Select.next()) {
				
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(rowCount, rs2Select.getString("alarm" + i));
					rowCount++;
				}
			}else{
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(rowCount, "Critical");
					rowCount++;
				}
			}
			
			ps3Select.setLong(1, slotMasterID);
			rs3Select=ps3Select.executeQuery();
			rowCount=49;
			if (rs3Select.next()) {
				
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(rowCount, rs3Select.getString("alarm" + i));
					rowCount++;
				}
			}else{
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(rowCount, "Critical");
					rowCount++;
				}
			}
			
			
			ps4Select.setLong(1, slotMasterID);
			rs4Select=ps4Select.executeQuery();
			rowCount=73;
			if (rs4Select.next()) {
				
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(rowCount, rs4Select.getString("alarm" + i));
					rowCount++;
				}
			}else{
				for (byte i = 1; i <= 24; i++) {
					alarmSeverity.put(rowCount, "Critical");
					rowCount++;
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rs1Select!=null){
					rs1Select.close();
				}
				if(ps1Select!=null){
					ps1Select.close();
				}
				if(rs2Select!=null){
					rs2Select.close();
				}
				if(ps2Select!=null){
					ps2Select.close();
				}
				if(rs3Select!=null){
					rs3Select.close();
				}
				if(ps3Select!=null){
					ps3Select.close();
				}
				if(rs4Select!=null){
					rs4Select.close();
				}
				if(ps4Select!=null){
					ps4Select.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return alarmSeverity;
	}
	public static LinkedHashMap<Byte, Byte> getAllAlarmForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Byte, Byte> allAlarmPresentDb=new LinkedHashMap<Byte, Byte>();
		PreparedStatement ps1Select=null,ps2Select=null,ps3Select=null,ps4Select=null;
		ResultSet rs1Select=null,rs2Select=null,rs3Select=null,rs4Select=null;
try {
			
			ps1Select=conn.prepareStatement("select * from dwdm_omtp12_10g_client_optical_alarm coa where coa.dwdm_port_master_id=?");
			ps2Select=conn.prepareStatement("select * from dwdm_omtp12_10g_client_traffic_alarm cta where cta.dwdm_port_master_id=?");
			ps3Select=conn.prepareStatement("select * from dwdm_omtp12_10g_line_optical_alarm loa where loa.dwdm_port_master_id=?");
			ps4Select=conn.prepareStatement("select * from dwdm_omtp12_10g_line_traffic_alarm lta where lta.dwdm_port_master_id=?");
			ps1Select.setLong(1, slotMasterID);
			rs1Select=ps1Select.executeQuery();
			if (rs1Select.next()) {
				for (byte i = 1; i <= 24; i++) {
					allAlarmPresentDb.put(i, rs1Select.getByte("alarm" + i));
					
				}
			}
			
			
			ps2Select.setLong(1, slotMasterID);
			rs2Select=ps2Select.executeQuery();
			byte rowCount=25;
			if (rs2Select.next()) {
				
				for (byte i = 1; i <= 24; i++) {
					allAlarmPresentDb.put(rowCount, rs2Select.getByte("alarm" + i));
					
					rowCount++;
					
				}
			}
			
			ps3Select.setLong(1, slotMasterID);
			rs3Select=ps3Select.executeQuery();
			rowCount=49;
			if (rs3Select.next()) {
				
				for (byte i = 1; i <= 24; i++) {
					allAlarmPresentDb.put(rowCount, rs3Select.getByte("alarm" + i));
					
					rowCount++;
				}
			}
			
			
			ps4Select.setLong(1, slotMasterID);
			rs4Select=ps4Select.executeQuery();
			rowCount=73;
			if (rs4Select.next()) {
				
				for (byte i = 1; i <= 24; i++) {
					allAlarmPresentDb.put(rowCount, rs4Select.getByte("alarm" + i));
					
					rowCount++;
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rs1Select!=null){
					rs1Select.close();
				}
				if(ps1Select!=null){
					ps1Select.close();
				}
				if(rs2Select!=null){
					rs2Select.close();
				}
				if(ps2Select!=null){
					ps2Select.close();
				}
				if(rs3Select!=null){
					rs3Select.close();
				}
				if(ps3Select!=null){
					ps3Select.close();
				}
				if(rs4Select!=null){
					rs4Select.close();
				}
				if(ps4Select!=null){
					ps4Select.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return allAlarmPresentDb;
	}
	
	public static  Map<String, ArrayList<String>> getTrafficNames(int slotMasterID,Map<Short,Integer> trafficNamesFromMachine,String cardName,Connection conn) throws Exception{
		PreparedStatement psForGetTrafficNames = null;
		ResultSet rsForGetTrafficNames = null;
		ArrayList<String> alForTrafficNames;	
		Map<String,ArrayList<String>> trafficNamesFromDB = new HashMap<String,ArrayList<String>>();
		Map<Integer,ArrayList<String>> trafficNamesFromDBForUpdate = new HashMap<Integer,ArrayList<String>>();
		String sqlQueryForTrafficNames =null;
		try{
		
		sqlQueryForTrafficNames = "SELECT a.port_client_line_type, a.port_number, a.port_traffic_type,a.dwdm_port_master_id, b.traffic_name from dwdm_port_master as a, dwdm_port_traffic_name as b where a.port_traffic_type=b.dwdm_port_traffic_name_id and a.dwdm_slot_master_id=?";			
		psForGetTrafficNames = conn.prepareStatement(sqlQueryForTrafficNames);
		psForGetTrafficNames.setInt(1, slotMasterID);
		rsForGetTrafficNames = psForGetTrafficNames.executeQuery();
		while (rsForGetTrafficNames.next()) {
			alForTrafficNames=new ArrayList<String>();
			alForTrafficNames.add(rsForGetTrafficNames.getString("port_traffic_type"));
			alForTrafficNames.add(rsForGetTrafficNames.getString("traffic_name"));
			alForTrafficNames.add(rsForGetTrafficNames.getString("dwdm_port_master_id"));
			String key=rsForGetTrafficNames.getString("port_client_line_type")+rsForGetTrafficNames.getString("port_number");
			trafficNamesFromDB.put(key, alForTrafficNames);
		}	
		
		if(trafficNamesFromMachine.size()!=0){										
					sqlQueryForTrafficNames = "SELECT traffic_type_value,dwdm_port_traffic_name_id,traffic_name FROM dwdm_port_traffic_name where card_name=? and client_line_other=?";
					psForGetTrafficNames = conn.prepareStatement(sqlQueryForTrafficNames);
					psForGetTrafficNames.setString(1, cardName);
					psForGetTrafficNames.setString(2, "client");
					rsForGetTrafficNames = psForGetTrafficNames.executeQuery();
					while (rsForGetTrafficNames.next()) {
						alForTrafficNames=new ArrayList<String>();
						int key=Integer.parseInt(rsForGetTrafficNames.getString("traffic_type_value"));						
						String portTrafficNameID=rsForGetTrafficNames.getString("dwdm_port_traffic_name_id");
						String trfficName=rsForGetTrafficNames.getString("traffic_name");
						alForTrafficNames.add(portTrafficNameID);
						alForTrafficNames.add(trfficName);
						trafficNamesFromDBForUpdate.put(key, alForTrafficNames);
					}
				String query="update dwdm_port_master set port_traffic_type=? where port_number=? and dwdm_slot_master_id=? and port_client_line_type=?";
				psForGetTrafficNames = conn.prepareStatement(query);
				for (int i = 1; i <= trafficNamesFromMachine.size(); i++) {
//					alForTrafficNames=new ArrayList<String>();
					int trafficType=trafficNamesFromMachine.get((short)i);
					ArrayList<String> trafficName = trafficNamesFromDBForUpdate.get(trafficType);
					psForGetTrafficNames.setInt(1, Integer.parseInt(trafficName.get(0)));	
//					alForTrafficNames.add(trafficName.get(0));
//					alForTrafficNames.add(trafficName.get(1));
					if(i==2){					
						psForGetTrafficNames.setInt(2,1);
						psForGetTrafficNames.setString(4,"line");
						alForTrafficNames=trafficNamesFromDB.get("line1");
						alForTrafficNames.set(0, trafficName.get(0));
						alForTrafficNames.set(1, trafficName.get(1));
//						trafficNamesFromDB.put("line1", alForTrafficNames);
					}else if (i==3){
						psForGetTrafficNames.setInt(2,2);
						psForGetTrafficNames.setString(4,"line");
						alForTrafficNames=trafficNamesFromDB.get("line2");
						alForTrafficNames.set(0, trafficName.get(0));
						alForTrafficNames.set(1, trafficName.get(1));
					}
					else{
						psForGetTrafficNames.setInt(2,i);
						psForGetTrafficNames.setString(4,"client");
						alForTrafficNames=trafficNamesFromDB.get("client"+i);
						alForTrafficNames.set(0, trafficName.get(0));
						alForTrafficNames.set(1, trafficName.get(1));
//						trafficNamesFromDB.put("client"+i, alForTrafficNames);
					}
					psForGetTrafficNames.setInt(3,slotMasterID);
					psForGetTrafficNames.addBatch();		

				}
				psForGetTrafficNames.executeBatch();
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return trafficNamesFromDB;
	}
	public static void main(String[] args) {
		
	}
}
