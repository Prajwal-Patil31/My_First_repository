package com.utl.trap.receiver.omtp12;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.oba.OBADAO;
import com.utl.util.CommonDAO;


public class OMTP12Runnable implements Runnable{
	
	private ReceivedTrapDetails trapDetails;
	static Logger l = Logger.getLogger(OMTP12Runnable.class);
	public OMTP12Runnable(ReceivedTrapDetails trapDetails) {
		super();
		this.trapDetails = trapDetails;
	}

	@Override
	public void run() {
		l.info(trapDetails);
		
		Connection conn=null;
		try {
			byte alarmStatus    = trapDetails.getAlarmStatus();
			int portNo=trapDetails.getPort();
			int portMasterID    = trapDetails.getPortMasterID();
			String clientOrLine = trapDetails.getPortClientOrLine();
			
			String oID = trapDetails.getOID();
			String[] alarmMiscData = OMTP12AlarmNames.getDetails(oID);
			
			String alarmIndex = alarmMiscData[0];
			String alarmName  = alarmMiscData[1];
			String hide       = alarmMiscData[2];
			String traffic    = alarmMiscData[3];
			
			if ("false".equals(hide)) {
				
				byte prevAlarmStatus;
				
				conn=DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
			//	portMasterID=CommonDAO.getPortMasterID(Integer.parseInt(slotDetails.get(1)), portNo, conn);
				///code to get portMasterID
			/*	if(portNo>8)
				{
					clientOrLine="line";	
				}
				else
				{
					clientOrLine="client";
				}*/
				
				if("client".equals(clientOrLine)){
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP12DAO.updateAlarmClientOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP12DAO.updateAlarmClientTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}else{
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP12DAO.updateAlarmLineOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP12DAO.updateAlarmLineTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}
				if(alarmStatus!=prevAlarmStatus){
					System.out.println("INSIDE OMTP12");
					String alarmSeverity = OMTP12DAO.getAlarmSeverity(portMasterID, alarmIndex, clientOrLine, traffic, conn);
					OMTP12DAO.updateAlarmTrans(portMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), traffic, clientOrLine, conn);
					
					/*LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OMTP12DAO.getAllAlarmForGlobalAlarm(portMasterID, conn);
					LinkedHashMap<Byte, String> allAlarmSeverity =OMTP12DAO.getAllAlarmSeverityForGlobalAlarm(portMasterID, conn);
					byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(Integer.parseInt(slotDetails.get(1)), allAlarmSeverity, allAlarmPresentFromDb, conn);*/
					//l.info("OMTP12 Global Alarm Process Completed......"+status);
					//update_global_alarm
					
					CallableStatement omtp12GlobalAlarmCallable = null;
					omtp12GlobalAlarmCallable = conn.prepareCall("CALL update_global_alarm(?,?)");
					omtp12GlobalAlarmCallable.setInt(1,Integer.parseInt(slotDetails.get(1)));
					omtp12GlobalAlarmCallable.setString(2,trapDetails.getCardName());
					omtp12GlobalAlarmCallable.executeQuery();
					l.info("OMTP12 Global Alarm Process Completed......");
					
					
				}
				
			}
			
		} catch (Exception e) {
			l.info(e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
