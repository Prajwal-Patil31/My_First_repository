package com.utl.trap.receiver.omtp100;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.omtp12plus.OMTP12PLUSDAO;
import com.utl.util.CommonDAO;


public class OMTP100Runnable implements Runnable{
	
	private ReceivedTrapDetails trapDetails;
	static Logger l = Logger.getLogger(OMTP100Runnable.class);
	public OMTP100Runnable(ReceivedTrapDetails trapDetails) {
		super();
		this.trapDetails = trapDetails;
	}

	@Override
	public void run() {
		l.info(trapDetails);
		
		Connection conn=null;
		try {
			byte alarmStatus    = trapDetails.getAlarmStatus();
			int portMasterID    = trapDetails.getPortMasterID();
			String clientOrLine = trapDetails.getPortClientOrLine();
			
			String oID = trapDetails.getOID();
			String[] alarmMiscData = OMTP100AlarmNames.getDetails(oID);
			
			String alarmIndex = alarmMiscData[0];
			String alarmName  = alarmMiscData[1];
			String hide       = alarmMiscData[2];
			String traffic    = alarmMiscData[3];
			
			if ("false".equals(hide)) {
				
				byte prevAlarmStatus;
				
				conn=DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
				///code to get portMasterID
				
				
				
				if("client".equals(clientOrLine)){
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP100DAO.updateAlarmClientOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP100DAO.updateAlarmClientTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}else{
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP100DAO.updateAlarmLineOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP100DAO.updateAlarmLineTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}
				if(alarmStatus!=prevAlarmStatus){
					String alarmSeverity = OMTP100DAO.getAlarmSeverity(portMasterID, alarmIndex, clientOrLine, traffic, conn);
					OMTP100DAO.updateAlarmTrans(portMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), traffic, clientOrLine, conn);
				
//update_global_alarm
					LinkedHashMap<Short, Byte> allAlarmPresentFromDb =OMTP100DAO.getAllAlarmForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					LinkedHashMap<Short, String> allAlarmSeverity =OMTP100DAO.getAllAlarmSeverityForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					System.out.println("100g alarms "+allAlarmPresentFromDb);
					System.out.println("100g alarm severity "+allAlarmSeverity);
					byte status = CommonDAO.updateInToDwdmLineCardsGlobalAlarmStatusAlarms(Integer.parseInt(slotDetails.get(1)), allAlarmSeverity, allAlarmPresentFromDb, conn);
				
					/*CallableStatement omtp100GlobalAlarmCallable = null;
					omtp100GlobalAlarmCallable = conn.prepareCall("CALL update_global_alarm_plus(?,?)");
					omtp100GlobalAlarmCallable.setInt(1,Integer.parseInt(slotDetails.get(1)));
					omtp100GlobalAlarmCallable.setString(2,trapDetails.getCardName());
					omtp100GlobalAlarmCallable.executeQuery();*/
					l.info("OMTP100 Global Alarm Process Completed......");
				
				}
				
			}
			
		} catch (Exception e) {
			l.info(e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
