package com.utl.trap.receiver.opa;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.FiberCutStatusDAO;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.opa.OPADAO;
import com.utl.trap.receiver.osc.OSCDAO;
import com.utl.util.CommonDAO;

public class OPAContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedOPATraps;
	static Logger l = Logger.getLogger(OPAContinuousThread.class);
	
	public OPAContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedOPATraps) {
		super("OPA Continuous Thread");
		this.receivedOPATraps = receivedOPATraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOPATraps.take();
				System.out.println("Start OPA");
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OPAAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				LinkedHashMap<Byte, Byte> allAlarmPresentFromDbforFiber = null;
		//		String fiberNodeIP = trapDetails.getNodeIP();
				 
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("OPA TRAPS=============>>>>>>"+slotDetails);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OPADAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OPADAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OPADAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						
						//check all OPA alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OPADAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OPADAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						l.info("OPA Global Alarm Process Completed......"+status);
						
						allAlarmPresentFromDbforFiber = allAlarmPresentFromDb;
					}
					
					//fiber cut alarm updation in mesh topology
					if (alarmIndex.equals("1"))//ip fail alarm index is 1
					{
					  int nodeId =	Integer.parseInt(slotDetails.get(0));
					  byte oscNumber = 0;
					  byte fiberCutStatus=0;
					  String fiberCardName = slotDetails.get(3);
					  if (fiberCardName.equals("OPA1"))	
					  {
						  oscNumber = 1;
					  }else if (fiberCardName.equals("OPA2"))	
					  {
						  oscNumber = 2;
					  }else if (fiberCardName.equals("OPA3"))	
					  {
						  oscNumber = 3;
					  }
					  if(alarmStatus==1){
						  byte oscIPF = OSCDAO.getOSCIPFAlarm(nodeId, oscNumber, conn);
						  if(oscIPF == 1){
							  fiberCutStatus = 1;
						  }
					  }
						byte topLineFiberUpdate=FiberCutStatusDAO.updateFiberCutStatus(nodeId, oscNumber, fiberCutStatus, conn);
						l.info("OPA Alarm topline fiber cut Process Completed......status "+topLineFiberUpdate +" updated "+ fiberCutStatus);
					}
					
				}
			} catch (Exception e) {
				l.info("OPA Alarm Processing Error......");
				l.error(e.getMessage(),e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
