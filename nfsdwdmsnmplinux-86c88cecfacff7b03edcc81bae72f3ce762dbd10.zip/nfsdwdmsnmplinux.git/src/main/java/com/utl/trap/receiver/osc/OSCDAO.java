package com.utl.trap.receiver.osc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.LinkedHashMap;

public class OSCDAO {
	public static byte updateAlarm(int slotMasterID,int oscPortNumber, String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_osc_alarm where dwdm_slot_master_id=? and dwdm_osc_number=?");
			psForSelect.setInt(1, slotMasterID);
			psForSelect.setInt(2, oscPortNumber);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn.prepareStatement("UPDATE dwdm_osc_alarm SET alarm"+alarmIndex+"=? where dwdm_slot_master_id=? and dwdm_osc_number=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, slotMasterID);
					psForUpdate.setInt(3, oscPortNumber);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_osc_alarm(dwdm_slot_master_id,dwdm_osc_number,alarm"+alarmIndex+")VALUES(?,?,?)");
				psForInsert.setInt(1, slotMasterID);
				psForInsert.setInt(2, oscPortNumber);
				psForInsert.setByte(3, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static LinkedHashMap<Short, Short> getAllAlarmForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Short, Short> allAlarmPresentDb=new LinkedHashMap<Short, Short>();
		PreparedStatement ps1Select=null,ps2Select=null,ps3Select=null,ps4Select=null;
		ResultSet rs1Select=null,rs2Select=null,rs3Select=null,rs4Select=null;
		try {
			
			ps1Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm where dwdm_slot_master_id=? and dwdm_osc_number=1");
			ps2Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm where dwdm_slot_master_id=? and dwdm_osc_number=2");
			ps3Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm where dwdm_slot_master_id=? and dwdm_osc_number=3");
			ps4Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm where dwdm_slot_master_id=? and dwdm_osc_number=4");

			ps1Select.setLong(1, slotMasterID);
			rs1Select=ps1Select.executeQuery();
			if (rs1Select.next()) {
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(i, rs1Select.getShort("alarm" + i));				
				}
			}
			else{
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(i,(short) 0);				
				}
			}
			ps2Select.setLong(1, slotMasterID);
			rs2Select=ps2Select.executeQuery();
			Short rowCount=36;
			if (rs2Select.next()) {
				
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(rowCount, rs2Select.getShort("alarm" + i));				
					rowCount++;
					
				}
			}
			else{
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(rowCount,(short)0);				
					rowCount++;
				}
			}
			
			ps3Select.setLong(1, slotMasterID);
			rs3Select=ps3Select.executeQuery();
			rowCount=71;
			if (rs3Select.next()) {
				
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(rowCount, rs3Select.getShort("alarm" + i));			
					rowCount++;
				}
			}
			else{
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(rowCount,(short)0);				
					rowCount++;
				}
			}
			
			ps4Select.setLong(1, slotMasterID);
			rs4Select=ps4Select.executeQuery();
			rowCount=106;
			if (rs4Select.next()) {
				
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(rowCount, rs4Select.getShort("alarm" + i));			
					rowCount++;
				}
			}
			else{
				for (Short i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(rowCount,(short)0);				
					rowCount++;
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rs1Select!=null){
					rs1Select.close();
				}
				if(ps1Select!=null){
					ps1Select.close();
				}
				if(rs2Select!=null){
					rs2Select.close();
				}
				if(ps2Select!=null){
					ps2Select.close();
				}
				if(rs3Select!=null){
					rs3Select.close();
				}
				if(ps3Select!=null){
					ps3Select.close();
				}
				if(rs4Select!=null){
					rs4Select.close();
				}
				if(ps4Select!=null){
					ps4Select.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return allAlarmPresentDb;
	}
	
	public static LinkedHashMap<Short, String> getAllAlarmSeverityForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Short, String> alarmSeverity=new LinkedHashMap<Short, String>();
		PreparedStatement ps1Select=null,ps2Select=null,ps3Select=null,ps4Select=null;
		ResultSet rs1Select=null,rs2Select=null,rs3Select=null,rs4Select=null;
		try {
			
			ps1Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm_severity where dwdm_slot_master_id=? and dwdm_osc_number=1");
			ps2Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm_severity where dwdm_slot_master_id=? and dwdm_osc_number=2");
			ps3Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm_severity where dwdm_slot_master_id=? and dwdm_osc_number=3");
			ps4Select=conn.prepareStatement("SELECT * FROM dwdm_osc_alarm_severity where dwdm_slot_master_id=? and dwdm_osc_number=4");
			
			
			ps1Select.setLong(1, slotMasterID);
			rs1Select=ps1Select.executeQuery();
			if (rs1Select.next()) {
				for (Short i = 1; i <= 35; i++) {
					alarmSeverity.put(i, rs1Select.getString("alarm" + i));				
				}
			}else{
				for (Short i = 1; i <= 35; i++) {
					alarmSeverity.put(i, "Critical");				
				}
			}
			
			ps2Select.setLong(1, slotMasterID);
			rs2Select=ps2Select.executeQuery();
			Short rowCount=36;
			if (rs2Select.next()) {
				
				for (Short i = 1; i <= 35; i++) {
					alarmSeverity.put(rowCount, rs2Select.getString("alarm" + i));			
					rowCount++;
				}
			}else{
				for (Short i = 1; i <= 35; i++) {
					alarmSeverity.put(rowCount, "Critical");				
					rowCount++;
				}
			}
			
			ps3Select.setLong(1, slotMasterID);
			rs3Select=ps3Select.executeQuery();
			rowCount=71;
			if (rs3Select.next()) {
				
				for (Short i = 1; i <= 35; i++) {
					alarmSeverity.put(rowCount, rs3Select.getString("alarm" + i));				
					rowCount++;
				}
			}else{
				for (Short i = 1; i <= 35; i++) {
					alarmSeverity.put(rowCount, "Critical");				
					rowCount++;
				}
			}
			
			
			ps4Select.setLong(1, slotMasterID);
			rs4Select=ps4Select.executeQuery();
			rowCount=106;
			if (rs4Select.next()) {
				
				for (byte i = 1; i <= 35; i++) {
					alarmSeverity.put(rowCount, rs4Select.getString("alarm" + i));				
					rowCount++;
				}
			}else{
				for (byte i = 1; i <= 35; i++) {
					alarmSeverity.put(rowCount, "Critical");				
					rowCount++;
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rs1Select!=null){
					rs1Select.close();
				}
				if(ps1Select!=null){
					ps1Select.close();
				}
				if(rs2Select!=null){
					rs2Select.close();
				}
				if(ps2Select!=null){
					ps2Select.close();
				}
				if(rs3Select!=null){
					rs3Select.close();
				}
				if(ps3Select!=null){
					ps3Select.close();
				}
				if(rs4Select!=null){
					rs4Select.close();
				}
				if(ps4Select!=null){
					ps4Select.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return alarmSeverity;
	}
	public static String getAlarmSeverity(int slotMasterID,int oscPortNumber,String alarmIndex, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String alarmSeverity="Critical";
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_osc_alarm_severity  where dwdm_slot_master_id=? and dwdm_osc_number=?");
			psForSelect.setInt(1, slotMasterID);
			psForSelect.setInt(2, oscPortNumber);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				alarmSeverity=rsForSelect.getString(1);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return alarmSeverity;
	}
	
	public static byte  updateAlarmTrans(int slotMasterID,int oscPortNumber,byte alarmStatus,String alarmName,String alarmSeverity,Timestamp alarmGeneratedTime,Connection conn) throws Exception{
		byte result = 0;
		CallableStatement cstmtForUpdateAlarms = null;
		try {
			cstmtForUpdateAlarms = conn.prepareCall("CALL dwdm_osc_alarm_trans_update(?,?,?,?,?,?)");
			cstmtForUpdateAlarms.setInt(1, slotMasterID);
			cstmtForUpdateAlarms.setInt(2, oscPortNumber);
			cstmtForUpdateAlarms.setByte(3, alarmStatus);
			cstmtForUpdateAlarms.setString(4, alarmName);
			cstmtForUpdateAlarms.setString(5, alarmSeverity);
			cstmtForUpdateAlarms.setTimestamp(6, alarmGeneratedTime);
			result=(byte) cstmtForUpdateAlarms.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			if(cstmtForUpdateAlarms!=null){
				cstmtForUpdateAlarms.close();
			}
		}
		return result;
	}
	
	public static byte getOSCIPFAlarm(int nodeId,byte oscNumber, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		byte oscIPF = 0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm23 FROM dwdm_osc_alarm where dwdm_osc_number=? and dwdm_slot_master_id=(SELECT slot.dwdm_slot_master_id FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id  where node.node_details_id=? and rack.rack_number=1 and subrack.subrack_number=2 and slot.slot_number=254)");
			psForSelect.setInt(1, oscNumber);
			psForSelect.setInt(2, nodeId);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				oscIPF = rsForSelect.getByte(1);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return oscIPF;
	}
}
