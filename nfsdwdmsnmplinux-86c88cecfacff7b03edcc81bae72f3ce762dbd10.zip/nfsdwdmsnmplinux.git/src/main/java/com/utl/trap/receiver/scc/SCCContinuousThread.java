package com.utl.trap.receiver.scc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class SCCContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedSCCTraps;
	//static Logger l = Logger.getLogger(SCCContinuousThread.class);
	
	public SCCContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedSCCTraps) {
		super("SCC Continuous Thread");
		this.receivedSCCTraps = receivedSCCTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedSCCTraps.take();
				System.out.println("Start SCC");
				System.out.println(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
			//	int slotMasterID= trapDetails.getSlotMasterID();
			//	int oscPortNumber = trapDetails.getPort();
				
				String[] alarmMiscData = SCCAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);					
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					
					byte prevAlarmStatus=SCCDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					System.out.println("prevAlarmStatus SCC::"+prevAlarmStatus);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = SCCDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						System.out.println("alarmSeverity SCC::"+alarmSeverity);
						SCCDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						System.out.println("alarmSeverity SCC After updateAlarmTrans::"+alarmSeverity);
					}
				}
			} catch (Exception e) {
				//l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
