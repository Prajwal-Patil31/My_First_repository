package com.utl.trap.receiver.fanplus;

import java.util.HashMap;
import java.util.Map;

import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.Variable;

import com.utl.trap.receiver.TrapSender;

public class FANTest {
	public static void main(String[] args) {
		byte fanNumber = 0;
		byte fanTray = 1;
		short slot = 17;
		short subRack = 4;
		short rack = 4;
		byte node = 1;
		
		Map<String,Variable> OIDList = new HashMap<String, Variable>();
		OIDList.put("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.3."+node+"."+rack+"."+subRack+"."+slot+"."+fanTray+"."+fanNumber , new Integer32(0));
		
		fanNumber = 1; 
		
		OIDList.put("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.4."+node+"."+rack+"."+subRack+"."+slot+"."+fanTray+"."+fanNumber , new Integer32(0));
		
		fanNumber = 2; 
		
		OIDList.put("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.4."+node+"."+rack+"."+subRack+"."+slot+"."+fanTray+"."+fanNumber , new Integer32(0));
		
		fanNumber = 3; 
		
		OIDList.put("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.4."+node+"."+rack+"."+subRack+"."+slot+"."+fanTray+"."+fanNumber , new Integer32(0));
		
		fanNumber = 0; 

		OIDList.put("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.5."+node+"."+rack+"."+subRack+"."+slot+"."+fanTray+"."+fanNumber , new Integer32(1));
		
		
		TrapSender.sendSnmpV2Trap(OIDList);
	}

}