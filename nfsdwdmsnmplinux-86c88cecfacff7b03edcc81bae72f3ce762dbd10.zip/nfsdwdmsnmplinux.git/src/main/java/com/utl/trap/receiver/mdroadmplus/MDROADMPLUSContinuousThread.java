package com.utl.trap.receiver.mdroadmplus;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.obaplus.OBAPLUSDAO;
import com.utl.util.CommonDAO;

public class MDROADMPLUSContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedMDROADMPLUSTraps;
	//static Logger l = Logger.getLogger(MDROADMPLUSContinuousThread.class);
	
	public MDROADMPLUSContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedMDROADMTraps) {
		super("MDROADM Continuous Thread");
		this.receivedMDROADMPLUSTraps = receivedMDROADMTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedMDROADMPLUSTraps.take();
				System.out.println("Start MDROADMPLUS");
				System.out.println(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = MDROADMPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=MDROADMPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = MDROADMPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						MDROADMPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
					
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =MDROADMPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =MDROADMPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						System.out.println("MDROADMPLUS Global Alarm Process Completed......"+status);
					
					
					}
				}
			} catch (Exception e) {
				//l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
