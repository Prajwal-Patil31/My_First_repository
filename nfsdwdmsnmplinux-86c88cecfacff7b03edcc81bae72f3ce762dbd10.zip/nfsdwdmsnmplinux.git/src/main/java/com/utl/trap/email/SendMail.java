/*
 * Created on May 23, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.utl.trap.email;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
//import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
//import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
//import java.io.*;
import javax.mail.*;
import javax.mail.internet.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

import com.ut.connection.pool.DataSource;

//import javax.swing.plaf.*;
//import java.awt.event.*;
import java.io.*;
import java.security.Timestamp;

/**
 * @author melias
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SendMail extends JFrame
implements ActionListener
{
	
	
	 JButton clearButton;
	 JTextArea messagesArea;
	 JScrollPane messagesScroll;
	 JTextField hostIDField, communityField, OIDField, valueField, enterpriseField, agentField;
	 JLabel authorLabel, hostIDLabel, communityLabel, OIDLabel, valueLabel, enterpriseLabel, agentLabel, genericTrapLabel, specificTrapLabel;
	 JComboBox valueTypeBox, genericTrapBox, specificTrapBox;

	PipedReader errorReader;
    PipedWriter errorWriter;
    Thread readerThread;

    MenuBar theMenubar;
    Menu fileMenu;
    MenuItem aboutItem, quitItem;

	
	
	public static Connection connection=null;
	ResultSet rs, rs1, rs2= null;
	String csTo = "";
	String csSubject = "";
	String csRouteNum = "";
	int count=0;
	//String csTrapIP = "192.168.21.1";
	//String csTrapAlarmType = "System Down";
	//String csTrapAlarmSeverity = "Critical";
	//String csTrapAlarmStatus = "ON";
	String csTrapIP = null;
	String csTrapAlarmType = null;
	String csTrapAlarmSeverity = null;
    String csTrapAlarmStatus = null;
	SimpleDateFormat simpleformat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	Date dCurrTime = new Date();
	String csTrapTimeStamp = simpleformat.format(dCurrTime);	
	String csTrapInfo = "";
	static boolean error=true;	
	
	private class WindowCloseAdapter extends WindowAdapter
    {
        public void windowClosing(WindowEvent e)
        {
           // readerThread.interrupt();
            System.exit(0);
        }
    };
    
    private void setUpDisplay()
    {

    	  this.setTitle("UTL DWDM EMS - Send Mail Service");

      this.getRootPane().setBorder(new BevelBorder(BevelBorder.RAISED));

      // set fonts to smaller-than-normal size, for compaction!
      /*
      FontUIResource appFont = new FontUIResource("SansSerif", Font.PLAIN, 10);
      UIDefaults defaults = UIManager.getLookAndFeelDefaults();
      Enumeration keys = defaults.keys();

      while (keys.hasMoreElements())
      {
          String nextKey = (String)(keys.nextElement());
          if ((nextKey.indexOf("font") > -1) || (nextKey.indexOf("Font") > -1))
          {
              UIManager.put(nextKey, appFont);
          }
      }
      */
      // add WindowCloseAdapter to catch window close-box closings
      addWindowListener(new WindowCloseAdapter());
      theMenubar = new MenuBar();
      this.setMenuBar(theMenubar);
      fileMenu = new Menu("File");

      aboutItem = new MenuItem("About...");
      aboutItem.setActionCommand("about");
      aboutItem.addActionListener(this);
      fileMenu.add(aboutItem);
      fileMenu.addSeparator();

      quitItem = new MenuItem("Quit");
      quitItem.setActionCommand("quit");
      quitItem.addActionListener(this);
      fileMenu.add(quitItem);

      theMenubar.add(fileMenu);
      authorLabel = new JLabel(" United Telecoms Limited ");
      authorLabel.setFont(new Font("SansSerif", Font.ROMAN_BASELINE, 12));

      clearButton = new JButton("Clear messages");
      clearButton.setActionCommand("clear messages");
      clearButton.addActionListener(this);

      messagesArea = new JTextArea(10,60);
      messagesScroll = new JScrollPane(messagesArea);

      // now set up display
      // set params for layout manager
      GridBagLayout  theLayout = new GridBagLayout();
      GridBagConstraints c = new GridBagConstraints();

      c.gridwidth = 1;
      c.gridheight = 1;
      c.fill = GridBagConstraints.NONE;
      c.ipadx = 0;
      c.ipady = 0;
      c.insets = new Insets(2,2,2,2);
      c.anchor = GridBagConstraints.CENTER;
      c.weightx = 0;
      c.weighty = 0;

      JPanel messagesPanel = new JPanel();
      messagesPanel.setLayout(theLayout);

      c.gridx = 1;
      c.gridy = 1;
      c.anchor = GridBagConstraints.WEST;
      JLabel messagesLabel = new JLabel("Send Mail...");
      theLayout.setConstraints(messagesLabel, c);
      messagesPanel.add(messagesLabel);

      c.gridx = 2;
      c.gridy = 1;
      c.anchor = GridBagConstraints.EAST;
      theLayout.setConstraints(clearButton, c);
      messagesPanel.add(clearButton);

      c.fill = GridBagConstraints.BOTH;
      c.gridx = 1;
      c.gridy = 2;
      c.gridwidth = 2;
      c.weightx = .5;
      c.weighty = .5;
      c.anchor = GridBagConstraints.CENTER;
      theLayout.setConstraints(messagesScroll, c);
      messagesPanel.add(messagesScroll);

      c.gridwidth = 1;
      c.weightx = 0;
      c.weighty = 0;

      this.getContentPane().setLayout(theLayout);

      c.fill = GridBagConstraints.BOTH;
      c.gridx = 1;
      c.gridy = 1;
      c.weightx = .5;
      c.weighty = .5;
      theLayout.setConstraints(messagesPanel, c);
      this.getContentPane().add(messagesPanel);

      c.fill = GridBagConstraints.NONE;
      c.gridx = 1;
      c.gridy = 2;
      c.weightx = 0;
      c.weighty = 0;
      theLayout.setConstraints(authorLabel, c);
      this.getContentPane().add(authorLabel);
    }


    public void actionPerformed(ActionEvent theEvent)
    // respond to button pushes, menu selections
    {
        String command = theEvent.getActionCommand();

        if (command == "quit")
        {
            readerThread.interrupt();
            System.exit(0);
        }

        if (command == "clear messages")
        {
            messagesArea.setText("");
        }

        if (command == "about")
        {
            //AboutDialog aboutDialog = new AboutDialog(this);
        }
    }

    public SendMail() //Constructor
    {
    	setUpDisplay();    	
    }
   
	public void MailDetails()
	{		
		String csMailServerIpaddress = "", csFromEmailId = "",csAlarmName="",csNodeIP="",csAlarmSeverity="",csNodeLocation="";	
		String csCardName="",csCircleName = "",csMessageText = "",csOccurTime="",csPassword="",csAlarmStatus="",csMailAck="",csNodeType="";
		
		int iMailStatus = 0;
		int iMailServerPortNumber = 0;
		int iSlotMasterid = 0,iSendTransId=0;
		java.sql.Timestamp csOccurTimeStamp;
		
		try
		{
			 //For Database Connection
			connection=DataSource.getInstance().getConnection();
	        
			Statement stMain= connection.createStatement();
	 		String qryMain="SELECT * FROM mail_server_config";
	 		rs= stMain.executeQuery(qryMain);
	 		while(rs.next())
	 		{
	 			csMailServerIpaddress = rs.getString("mail_server_ipaddress");
	 			iMailServerPortNumber = rs.getInt("mail_server_port_number");
	 			iMailStatus = rs.getInt("mail_server_active_status");
	 			csFromEmailId = rs.getString("mail_server_email_id");
	 			csPassword = "utldwdm4321";
	 		}
	 		
	 		if (iMailStatus == 1)
	 		{
	 			 // SENDING MAIL TO CONCERNED PERSONS 	& Updating into History
		 		Statement stSub= connection.createStatement();		 		
		 		String qrySub= "select con.dwdm_slot_master_id,cd.circle_location_name,ne.node_location,ne.node_ip_address,ne.node_type,ne.node_channel_number,dm.slot_number,con.card_name,con.alarm_type,trans.alarm_severity,trans.alarm_status,trans.alarm_occure_time,trans.mail_acknowledge,con.mail_server_recipient_email_id,trans.mail_alarm_send_trans_id From nfsdwdmdb.mail_server_recipient_config con Inner join nfsdwdmdb.mail_alarm_send_trans trans on con.dwdm_slot_master_id=trans.dwdm_slot_master_id and con.alarm_type=trans.alarm_type and con.mail_send_status=1 inner join dwdm_slot_master dm on con.dwdm_slot_master_id=dm.dwdm_slot_master_id inner join dwdm_subrack_master dsm on dsm.dwdm_subrack_master_id=dm.dwdm_subrack_master_id inner join dwdm_rack_master drm on dsm.dwdm_rack_master_id=drm.dwdm_rack_master_id inner join node_details ne on drm.node_details_id=ne.node_details_id inner join circle_details cd on ne.circle_details_id=cd.circle_details_id";
		 		rs1= stSub.executeQuery(qrySub);
		 		while(rs1.next())
		 		{
		 			csTo = rs1.getString("mail_server_recipient_email_id");
		 			csAlarmName = rs1.getString("alarm_type");
		 			csNodeIP = rs1.getString("node_ip_address");		 			
		 			csAlarmSeverity = rs1.getString("alarm_severity");
		 			csNodeLocation = rs1.getString("node_location");
		 			csCardName = rs1.getString("card_name");
		 			csCircleName = rs1.getString("circle_location_name");		 			
		 		//	csOccurTime =  new SimpleDateFormat("dd/mm/yyyy HH:mm:ss").format(rs1.getTimestamp("alarm_occure_time"));
		 			csNodeType = rs1.getString("node_type");
		 			csOccurTimeStamp = rs1.getTimestamp("alarm_occure_time");
		 			System.out.println("csOccurTimeStamp is"+csOccurTimeStamp);
		 			SimpleDateFormat outDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 			csOccurTime = outDateFormat.format(csOccurTimeStamp);
		 			
		 			iSlotMasterid = rs1.getInt("dwdm_slot_master_id");
		 			iSendTransId = rs1.getInt("mail_alarm_send_trans_id");
		 			csMailAck = rs1.getString("mail_acknowledge");
		 			csAlarmStatus = rs1.getString("alarm_status");
					csSubject="UTL-NFS-DWDM-EMS Alert: "+csAlarmSeverity+" Alarm Received from "+csNodeIP;
					
					String csFinalCardName = csCardName.replace("PLUS","");
					
					csMessageText = "CircleName: "+csCircleName+", NodeIP: "+csNodeIP+", NodeLocation: "+csNodeLocation+", NodeType: "+csNodeType+",CardName: "+csFinalCardName+", AlarmName: "+csAlarmName+", AlarmSeverity: "+csAlarmSeverity+", AlarmTime: "+csOccurTime+" ";
				
					if (csMailAck.equals("sending"))
					{
				     	int iSendMailStatus = SendAlarmMail(csFromEmailId, csPassword, csTo ,csSubject, csMessageText);		
				     	if (iSendMailStatus == 0)
				     	{
				     		InsertIntoSendMailAlarmHistory(iSlotMasterid,csAlarmName,csAlarmSeverity,csAlarmStatus,csOccurTimeStamp,"Sent");
				     		try
				     	    {
				     	      
				     	      String query = "update mail_alarm_send_trans set mail_acknowledge = ? where mail_alarm_send_trans_id = ?";
				     	      PreparedStatement preparedStmt = connection.prepareStatement(query);
				     	      preparedStmt.setString(1, "Sent");
				     	      preparedStmt.setInt(2, iSendTransId);			     	   
				     	      preparedStmt.executeUpdate();				     	      
				     	      
				     	    }
				     	    catch (Exception e)
				     	    {
				     	      System.err.println("Got an exception! ");
				     	      System.err.println(e.getMessage());
				     	    }
				     		
				     	}
				     	else
				     		InsertIntoSendMailAlarmHistory(iSlotMasterid,csAlarmName,csAlarmSeverity,csAlarmStatus,csOccurTimeStamp,"Fail");
				     		
				     		
				     	count++;
					}
					
		 		}	 		
	 		}
	 		error=true;    
	 		System.out.println("Mail Has Been Sent Successfully to these many people..."+count);
	 		
		}
		catch(SQLException ex)
		{
			ex.printStackTrace();
		}
		catch(Exception ee)
		{
			ee.printStackTrace();
		}
		finally
		{
		      try 
			  {
		        if(connection != null)
		        	connection.close();
		      } 
		      catch(SQLException e) {}
		 }
	}
	
	public static int SendAlarmMail(final String csFromEmailId, final String csPassword, String csTo, String csSub, String csMessageText)
	{	
		int iMsgStatus = 0;	    
		// Recipient's email ID needs to be mentioned.
    //    String to = "sramakrishna@utlindia.com";

        // Sender's email ID needs to be mentioned
    //    String from = "rksunkara15@gmail.com";

		System.out.println("csFromEmailId...." + csFromEmailId);
		System.out.println("csToEmailId...." + csTo);
		System.out.println("csSub...." + csSub);
		System.out.println("csMessageText...." + csMessageText);
        // Get system properties
        Properties properties = System.getProperties();

        properties.put("mail.smtp.starttls.enable", "true"); 
        properties.put("mail.smtp.host", "smtp.gmail.com");

        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        Authenticator authenticator = new Authenticator () {
              public PasswordAuthentication getPasswordAuthentication(){
                  return new PasswordAuthentication(csFromEmailId,csPassword);//userid and password for "from" email address 
              }
          };

          Session session = Session.getDefaultInstance( properties , authenticator);  
        try{
           
           MimeMessage message = new MimeMessage(session);        
           message.setFrom(new InternetAddress(csFromEmailId));         
           message.addRecipient(Message.RecipientType.TO,
                                    new InternetAddress(csTo));         
           message.setSubject(csSub);         
           message.setText(csMessageText);
           // Send message
           Transport.send(message);          
           System.out.println("Sent message successfully....");
        }catch (MessagingException mex) {
           iMsgStatus = 1;//send email failed
           System.out.println("Sent message failed....");
           mex.printStackTrace(System.out);
        }
 	
	return iMsgStatus;
}
	
	public void InsertIntoSendMailAlarmHistory(int iSlotMasterid,String csAlarmName,String csSeverity,String csAlarmStatus,java.sql.Timestamp csOccurtime,String csAck)
	{
		try
		{
			Statement stSub1= connection.createStatement();				 			
	    	String qrySub1="INSERT INTO mail_alarm_send_history (dwdm_slot_master_id, alarm_type, alarm_severity, alarm_status, alarm_occure_time, mail_acknowledge) VALUES ('"+iSlotMasterid+"', '"+ csAlarmName+ "', '"+csSeverity+"', '"+csAlarmStatus+"', '"+csOccurtime+"', '"+csAck+"')";
	    	int i = stSub1.executeUpdate(qrySub1);	
	    	if (i==1)
	    	{
	    		System.out.println("Records inserted into sendmailalarmhistory successfully");
	    	}
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		SendMail sm = new SendMail();
		while (error==true)
        {	
			error=false;
			sm.MailDetails();			
        }
		sm.pack();
		sm.setSize(700,500);
		sm.setVisible(true);	
		//sm.SendAlarmMail("rksunkara15@gmail.com", "geethika19","rksunkara15@gmail.com","This is the Test Mail", " Hello How are you?");
	}

	
}
