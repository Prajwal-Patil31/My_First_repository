package com.utl.trap.receiver.ommp82;

import java.util.HashMap;
import java.util.Map;

public class OMMP82AlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	private static String traffic;
	static{
		//OPTICAL XFP (LINE)
		traffic="OPTICAL";
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.1";
		alarmName=" XFP Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.2";
		alarmName="XFP Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.3";
		alarmName="XFP High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.4";
		alarmName="XFP Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.5";
		alarmName="XFP High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.6";
		alarmName="XFP Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.7";
		alarmName=" XFP High Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.8";
		alarmName="XFP Low Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.9";
		alarmName="XFP High Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.10";
		alarmName="XFP Low Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.11";
		alarmName="XFP Input High Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.12";
		alarmName="XFP Input Low Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.13";
		alarmName="XFP Input High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.14";
		alarmName="XFP Input Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.15";
		alarmName="XFP Output High Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.16";
		alarmName="XFP Output Low Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.17";
		alarmName="XFP Output High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.18";
		alarmName="XFP Output Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.19";
		alarmName="XFP High Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.20";
		alarmName="XFP Low Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.21";
		alarmName="XFP High Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.22";
		alarmName="XFP Low Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.23";
		alarmName="XFP Presence Absence Notification";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		
		//OPTICAL SFP (CLIENT)
		traffic="OPTICAL";
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.41";
		alarmName="SFP Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.42";
		alarmName="SFP Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.43";
		alarmName="SFP High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.44";
		alarmName="SFP Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.45";
		alarmName="SFP High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.46";
		alarmName="SFP Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.47";
		alarmName=" SFP High Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.48";
		alarmName="SFP Low Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.49";
		alarmName="SFP High Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.50";
		alarmName="SFP Low Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.51";
		alarmName="SFP Input High Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.52";
		alarmName="SFP Input Low Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.53";
		alarmName="SFP Input High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.54";
		alarmName="SFP Input Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.55";
		alarmName="SFP Output High Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.56";
		alarmName="SFP Output Low Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.57";
		alarmName="SFP Output High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.58";
		alarmName="SFP Output Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.59";
		alarmName="SFP High Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.60";
		alarmName="SFP Low Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.61";
		alarmName="SFP High Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.62";
		alarmName="SFP Low Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.63";
		alarmName="SFP Presence Absence Notification";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.64";
		alarmName="SFP Transmit Fault Presence Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		
		
		//OTU & ODU Line
		traffic="OTU-ODU";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.81";
		alarmName="OTU Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.82";
		alarmName="OTU Loss of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.83";
		alarmName="OTU Out of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.84";
		alarmName="OTU Loss of Multi Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.85";
		alarmName="OTU Out of Multi Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.86";
		alarmName="OTU Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.87";
		alarmName="OTU Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.88";
		alarmName="OTU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.89";
		alarmName="OTU Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.90";
		alarmName="OTU Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.91";
		alarmName="OTU Backward Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.92";
		alarmName="OTU Backward Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
			
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.111";
		alarmName="ODU Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.112";
		alarmName="ODU Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.113";
		alarmName="ODU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.114";
		alarmName="ODU Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.115";
		alarmName="ODU Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.116";
		alarmName="ODU Locked Defect Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.117";
		alarmName="ODU Open Connection Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.118";
		alarmName="ODU Backward Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.119";
		alarmName="ODU Backward Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.120";
		alarmName="ODU Loss of Frame Loss of Multiframe Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});

		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.121";
		alarmName="OPU Payload Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.122";
		alarmName="Och Loss of Payload Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//SDH STM-1/4/16
		traffic="SDH";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.141";
		alarmName="SDH Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.142";
		alarmName="SDH Out of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.143";
		alarmName="SDH Loss of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.144";
		alarmName="SDH RS Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.145";
		alarmName="SDH RS Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.146";
		alarmName="SDH AU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.147";
		alarmName="SDH AU Loss of Pointer Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.148";
		alarmName="SDH MS Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.149";
		alarmName="SDH MS Remote Error Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.150";
		alarmName="SDH MS Remote Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.151";
		alarmName="SDH MS Remote Failure Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.152";
		alarmName="SDH MS B2 Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.153";
		alarmName="SDH MS B2 Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.154";
		alarmName="SDH Loss of Sequence Synchronisation Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.155";
		alarmName="SDH Lower Order Payload Label Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.156";
		alarmName="SDH Lower Order Path Unequipped Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//Ethernet GIG-E GFP-F GFP-T
		traffic="ETHERNET";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.171";
		alarmName="Ethernet Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.172";
		alarmName=" Ethernet Loss Of Signal Sync Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.173";
		alarmName="Ethernet Link Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.174";
		alarmName="Ethernet Auto Negotiation Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.175";
		alarmName="Ethernet Frame Check Sequence Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.176";
		alarmName="Ethernet Carrier Status Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.177";
		alarmName="Ethernet High BER Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.178";
		alarmName="Ethernet Local Fault Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.179";
		alarmName="Ethernet Remote Fault Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
	
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.211";
		alarmName="GFP CSF Signal Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.212";
		alarmName="GFP CSF Link Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.213";
		alarmName="GFP Core Header Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.214";
		alarmName="GFP Extention Header Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});			
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.175";
		alarmName="Ethernet FrameCheck Sequence Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//FC-100/FC-200
		
		traffic="FC";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.191";
		alarmName="FC Transmit Display Invert Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.192";
		alarmName="FC Transmit DLOLB Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.193";
		alarmName="FC Transmit Sync Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.194";
		alarmName="FC Receive DLOLB Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.195";
		alarmName="FC Receive Sync Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.196";
		alarmName="FC Receive XDET Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.197";
		alarmName="FC Receive ASD Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1.198";
		alarmName="FC Receive LCV Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		
		
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
