package com.utl.trap.receiver.opa;

import java.util.HashMap;
import java.util.Map;

public class OPAAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		
		/*IOP Failure
		OOP Failure
		IOP Out of Range
		OOP Out of Range
		Degraded IOP
		Degraded OOP
		Low IOP*/
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.1";
		alarmName="Optical Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.12";
		alarmName="Optical Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.53";
		alarmName="Input Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.54";
		alarmName="Output Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.9";
		alarmName="Optical Low Input Power Warning (Degraded)";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.20";
		alarmName="Optical Low Output Power Warning (Degraded)";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.5";
		alarmName="Optical Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		/*alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.1";
		alarmName="Optical Input Power Failure Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.2";
		alarmName="Optical Input Power Failure Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.3";
		alarmName="Optical High Input Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.4";
		alarmName="Optical High Input Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.5";
		alarmName="Optical Low Input Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.6";
		alarmName="Optical Low Input Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.7";
		alarmName="Optical High Input Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.8";
		alarmName="Optical High Input Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.9";
		alarmName="Optical Low Input Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.10";
		alarmName="Optical Low Input Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.11";
		alarmName="Optical Output Power Failure Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.12";
		alarmName="Optical Output Power Failure Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.13";
		alarmName="Optical High Output Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.14";
		alarmName="Optical High Output Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.15";
		alarmName="Optical Low Output Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.16";
		alarmName="Optical Low Output Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.17";
		alarmName="Optical High Output Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.18";
		alarmName="Optical High Output Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.19";
		alarmName="Optical Low Output Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.20";
		alarmName="Optical Low Output Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.21";
		alarmName="Module High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.22";
		alarmName="Module Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.23";
		alarmName="Module High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.24";
		alarmName="Module Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="25";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.25";
		alarmName="Pump 1 High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="26";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.26";
		alarmName="Pump 2 High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="27";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.27";
		alarmName="Pump 1 Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="28";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.28";
		alarmName="Pump 2 Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="29";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.29";
		alarmName="Pump 1 High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="30";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.30";
		alarmName="Pump 2 High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="31";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.31";
		alarmName="Pump 1 Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="32";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.32";
		alarmName="Pump 2 Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="33";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.33";
		alarmName="Pump 1 High Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="34";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.34";
		alarmName="Pump 2 High Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="35";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.35";
		alarmName="Pump 1 Low Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="36";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.36";
		alarmName="Pump 2 Low Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="37";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.37";
		alarmName="Pump 1 High Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="38";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.38";
		alarmName="Pump 2 High Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="39";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.39";
		alarmName="Pump 1 Low Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="40";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.40";
		alarmName="Pump 2 Low Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="41";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.41";
		alarmName="Pump 1 High Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="42";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.42";
		alarmName="Pump 2 High Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="43";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.43";
		alarmName="Pump 1 Low Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="44";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.44";
		alarmName="Pump 2 Low Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="45";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.45";
		alarmName="Pump 1 High Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="46";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.46";
		alarmName="Pump 2 High Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="47";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.47";
		alarmName="Pump 1 Low Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="48";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.48";
		alarmName="Pump 2 Low Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="49";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.49";
		alarmName="Variable Optical Attenuator High Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="50";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.50";
		alarmName="Variable Optical Attenuator Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="51";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.51";
		alarmName="Variable Optical Attenuator High Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="52";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.52";
		alarmName="Variable Optical Attenuator Low Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="53";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.53";
		alarmName="Input Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="54";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.54";
		alarmName="Output Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="55";
		OID="1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1.55";
		alarmName="Pump Bias Current Alarm ";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});*/
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
