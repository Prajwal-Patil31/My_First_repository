package com.utl.trap.receiver.buzzerplus;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class BUZZERPLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static int getBuzzerStatus(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber, short interfaceNumber,SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,61,1,1,1,2,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
	//	System.out.println(OID);
		int buzzerStatus = 0;
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			buzzerStatus =resultEachV.toInt();
		} catch (Exception e) {
			throw e;
		}
		return buzzerStatus;		
	}
	
}
