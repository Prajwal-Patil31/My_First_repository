package com.utl.trap.receiver.osc;

import java.util.HashMap;
import java.util.Map;

public class OSCAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
				
		//osc alarms
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.21";
		alarmName="SFP High Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.22";
		alarmName="SFP High Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.23";
		alarmName="SFP Low Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.24";
		alarmName="SFP Low Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.25";
		alarmName="SFP High Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.26";
		alarmName="SFP High Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.27";
		alarmName="SFP Low Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.28";
		alarmName="SFP Low Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.29";
		alarmName="SFP High Output Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.30";
		alarmName="SFP High Output Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.31";
		alarmName="SFP Low Output Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.32";
		alarmName="SFP Low Output Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});

		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.33";
		alarmName="SFP High Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.34";
		alarmName="SFP High Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.35";
		alarmName="SFP Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.36";
		alarmName="SFP Low Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.37";
		alarmName="SFP Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.38";
		alarmName="SFP Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.39";
		alarmName="SFP High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.40";
		alarmName="SFP High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.41";
		alarmName="SFP Absence";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.42";
		alarmName="SFP Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.43";
		alarmName="SFP Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.11";
		alarmName="SCC High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="25";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.13";
		alarmName="SCC Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
						
		alarmIndex="35";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.64";
		alarmName="Link Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
