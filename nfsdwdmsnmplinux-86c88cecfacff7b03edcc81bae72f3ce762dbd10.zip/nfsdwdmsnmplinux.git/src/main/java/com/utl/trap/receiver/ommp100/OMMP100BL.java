package com.utl.trap.receiver.ommp100;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.trap.receiver.ommp81plus.OMMP81PLUSDAO;

public class OMMP100BL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=15000;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	
	
	public static void retrievePortTrafficNames(short nodeNumber,byte rackNumber,short subrackNumber,byte slotNumber,String nodeIP, String cardName, int slotMasterID, Connection conn) throws Exception{	
		try {	
			Map<Short, Integer> trafficValuesFromMachine =  getOMMP100TrafficNames(nodeNumber, rackNumber, subrackNumber, slotNumber ,  nodeIP, snmpVersionDetailsObj);
			
			//update in database and return traffic names
			OMMP100DAO.getTrafficNames(slotMasterID, trafficValuesFromMachine, cardName, conn);
		} catch (Exception e) {
			throw e;
		}
	}
	
	public static Map<Short,Integer> getOMMP100TrafficNames(short nodeNumber,byte rackNumber,short subrackNumber,byte slotNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		Map<Short,Integer> result=new HashMap<Short,Integer>();
		try {
			List<VariableBinding> allVB=new ArrayList<VariableBinding>();
			VariableBinding esOID=null;
			byte portNumber;
			for (int i = 1; i <= 10; i++) {
				portNumber=(byte) i;
				esOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,88,2,1,1,12,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
				allVB.add(esOID);
			}
			List<VariableBinding> resultAllVB=SNMPGet.getSNMPMultiple(nodeIP, community,retries, timeOut, allVB, userDetails);
			for(VariableBinding resultEachVB:resultAllVB){
				short index=(short) resultEachVB.getOid().get(19);
				int value =resultEachVB.getVariable().toInt();
				result.put(index, value);
			}
		} catch (Exception e) {
			throw e;
		}
		return result;
	}
}
