package com.utl.trap.receiver.opa;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class OPABL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfOPA(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber, SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,4,2,1,1,183,nodeNumber,rackNumber,subrackNumber,slotNumber}));
		System.out.println(OID);
		String cardName = "OPA";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getOPACardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getOPACardName(int directionNumber){
		String cardName = "OPA";
		switch (directionNumber) {
		case 1:
			cardName="OPA1";
			break;
		case 2:
			cardName="OPA2";
			break;
		case 3:
			cardName="OPA3";
			break;
		}
		return cardName;
	}
}
