package com.utl.trap.receiver.ommp82plus;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.omtp12.OMTP12DAO;
import com.utl.util.CommonDAO;

public class OMMP82PLUSRunnable implements Runnable{
	
	private ReceivedTrapDetails trapDetails;
	//static Logger l = Logger.getLogger(OMMP82PLUSRunnable.class);
	public OMMP82PLUSRunnable(ReceivedTrapDetails trapDetails) {
		super();
		this.trapDetails = trapDetails;
	}

	@Override
	public void run() {
		System.out.println(trapDetails);
		
		Connection conn=null;
		try {
			byte alarmStatus = trapDetails.getAlarmStatus();
			int portNo=trapDetails.getPort();
			int portMasterID = trapDetails.getPortMasterID();
			String clientOrLine = trapDetails.getPortClientOrLine();
			int slotMasterID = trapDetails.getSlotMasterID();
			
			String oID = trapDetails.getOID();
			String[] alarmMiscData = OMMP82PLUSAlarmNames.getDetails(oID);
			
			String alarmIndex = alarmMiscData[0];
			String alarmName  = alarmMiscData[1];
			String hide       = alarmMiscData[2];
			String traffic    = alarmMiscData[3];
			
			//here change alarmIndex, alarmName for slice alarms if oid contains 87.3.1.1.1.130
			if (oID.startsWith("1.3.6.1.4.1.18036.1.1.1.87.3.1.1.1.130"))
			{
				if (portNo==1 || portNo==2 || portNo==3 || portNo==4)
				{
					clientOrLine = "line";//Line2
					int alarmIn = 39 + portNo;//alarm table index 40,41,42,43
					alarmIndex =  Integer.toString(alarmIn);
					alarmName = "LOFLOM Slice" + Integer.toString(portNo);
					
				}else if (portNo==5 || portNo==6 || portNo==7 || portNo==8)
				{
					clientOrLine = "line";//Line1
					int alarmIn = 31 + portNo;//alarm table index 36,37,38,39
					alarmIndex =  Integer.toString(alarmIn);
					int portNoReverse = portNo-4;//alarm name not reqd 5,6,7,8
					alarmName = "LOFLOM Slice" + Integer.toString(portNoReverse);
				}
			}
			
			if ("false".equals(hide)) {
				
				byte prevAlarmStatus;
				
				conn=DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
				/*portMasterID=CommonDAO.getPortMasterID(Integer.parseInt(slotDetails.get(1)), portNo, conn);
				///code to get portMasterID
				if(portNo>8)
				{
					clientOrLine="line";	
				}
				else
				{
					clientOrLine="client";
				}*/
				if("client".equals(clientOrLine)){
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMMP82PLUSDAO.updateAlarmClientOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMMP82PLUSDAO.updateAlarmClientTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}else{
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMMP82PLUSDAO.updateAlarmLineOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMMP82PLUSDAO.updateAlarmLineTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}
				if(alarmStatus!=prevAlarmStatus){
					String alarmSeverity = OMMP82PLUSDAO.getAlarmSeverity(portMasterID, alarmIndex, clientOrLine, traffic, conn);
				//	System.out.println("portMasterID::"+portMasterID);
					OMMP82PLUSDAO.updateAlarmTrans(portMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), traffic, clientOrLine, conn);
					
					LinkedHashMap<Short, Byte> allAlarmPresentFromDb =OMMP82PLUSDAO.getAllAlarmForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					LinkedHashMap<Short, String> allAlarmSeverity =OMMP82PLUSDAO.getAllAlarmSeverityForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					byte status = CommonDAO.updateInToDwdmLineCardsGlobalAlarmStatusAlarms(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
					/*CallableStatement ommp82plusGlobalAlarmCallable = null;
					ommp82plusGlobalAlarmCallable = conn.prepareCall("CALL update_global_alarm_plus(?,?)");
					ommp82plusGlobalAlarmCallable.setInt(1,Integer.parseInt(slotDetails.get(1)));
					ommp82plusGlobalAlarmCallable.setString(2,trapDetails.getCardName());
					ommp82plusGlobalAlarmCallable.executeQuery();					
					l.info("OMMP82PLUS Global Alarm Process Completed......");*/
				}
				
			}
			
		} catch (Exception e) {
			//l.info(e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}


