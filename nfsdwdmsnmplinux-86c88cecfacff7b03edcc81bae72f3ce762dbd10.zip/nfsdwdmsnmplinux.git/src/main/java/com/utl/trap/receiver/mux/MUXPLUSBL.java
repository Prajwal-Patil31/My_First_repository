package com.utl.trap.receiver.mux;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class MUXPLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfMUXPLUS(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber, byte interfaceNumber,SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,171,1,1,1,25,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		System.out.println(OID);
		String cardName = "mux_plus";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getMUXPlusCardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getMUXPlusCardName(int directionNumber){
		String cardName = "mux_plus";
		switch (directionNumber) {
		case 1:
			cardName="MUX1PLUS";
			break;
		case 2:
			cardName="MUX2PLUS";
			break;
		case 3:
			cardName="MUX3PLUS";
			break;
		case 4:
			cardName="MUX4PLUS";
			break;
		}
		return cardName;
	}
}
