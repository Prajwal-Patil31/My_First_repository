package com.utl.trap.receiver.ola;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.FiberCutStatusDAO;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.ola.OLADAO;
import com.utl.trap.receiver.osc.OSCDAO;
import com.utl.util.CommonDAO;

public class OLAContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedOLATraps;
	static Logger l = Logger.getLogger(OLAContinuousThread.class);
	
	public OLAContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedOLATraps) {
		super("OLA Continuous Thread");
		this.receivedOLATraps = receivedOLATraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOLATraps.take();
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OLAAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("OLA TRAPS=============>>>>>>"+slotDetails);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OLADAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OLADAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OLADAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						
						//check all OLA alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OLADAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OLADAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						l.info("OLA Global Alarm Process Completed......"+status);
					}
					
					//fiber cut alarm updation in mesh topology
					if (alarmIndex.equals("1"))//ip fail alarm index is 1
					{
					  int nodeId =	Integer.parseInt(slotDetails.get(0));
					  byte oscNumber = 0;
					  byte fiberCutStatus=0;
					  String fiberCardName = slotDetails.get(3);
					  if (fiberCardName.equals("OLA1"))	
					  {
						  oscNumber = 1;
					  }else if (fiberCardName.equals("OLA2"))	
					  {
						  oscNumber = 2;
					  }
					  if(alarmStatus==1){
						  byte oscIPF = OSCDAO.getOSCIPFAlarm(nodeId, oscNumber, conn);
						  if(oscIPF == 1){
							  fiberCutStatus = 1;
						  }
					  }
					  byte topLineFiberUpdate=FiberCutStatusDAO.updateFiberCutStatus(nodeId, oscNumber, fiberCutStatus, conn);
					  l.info("OLA Alarm topline fiber cut Process Completed......status "+topLineFiberUpdate +" updated "+ fiberCutStatus);
					}
				}
				
				
			} catch (Exception e) {
				l.info("OLA Alarm Processing Error......");
				l.error(e.getMessage(),e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
