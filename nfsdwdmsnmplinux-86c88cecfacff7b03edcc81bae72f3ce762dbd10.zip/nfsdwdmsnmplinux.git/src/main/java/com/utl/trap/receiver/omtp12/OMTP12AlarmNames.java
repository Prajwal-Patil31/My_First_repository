package com.utl.trap.receiver.omtp12;

import java.util.HashMap;
import java.util.Map;

public class OMTP12AlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	private static String traffic;
	static{
		//OPTICAL
		traffic="OPTICAL";
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.1";
		alarmName=" XFP Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.2";
		alarmName="XFP Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.3";
		alarmName="XFP High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.4";
		alarmName="XFP Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.5";
		alarmName="XFP High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.6";
		alarmName="XFP Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.7";
		alarmName=" XFP High Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.8";
		alarmName="XFP Low Bias Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.9";
		alarmName="XFP High Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.10";
		alarmName="XFP Low Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.11";
		alarmName="XFP Input High Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.12";
		alarmName="XFP Input Low Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.13";
		alarmName="XFP Input High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.14";
		alarmName="XFP Input Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.15";
		alarmName="XFP Output High Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.16";
		alarmName="XFP Output Low Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.17";
		alarmName="XFP Output High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.18";
		alarmName="XFP Output Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.19";
		alarmName="XFP High Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.20";
		alarmName="XFP Low Supply Voltage Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.21";
		alarmName="XFP High Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.22";
		alarmName="XFP Low Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.23";
		alarmName="XFP Presence Absence Notification";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//OTU & ODU Line
		traffic="OTU-ODU";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.31";
		alarmName="OTU Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.32";
		alarmName="OTU Loss of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.33";
		alarmName="OTU Out of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.34";
		alarmName="OTU Loss of Multi Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.35";
		alarmName="OTU Out of Multi Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.36";
		alarmName="OTU Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.37";
		alarmName="OTU Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.38";
		alarmName="OTU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.39";
		alarmName="OTU Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.40";
		alarmName="OTU Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.41";
		alarmName="OTU Backward Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.42";
		alarmName="OTU Backward Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.51";
		alarmName="ODU Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.52";
		alarmName="ODU Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.53";
		alarmName="ODU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.54";
		alarmName="ODU Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.55";
		alarmName="ODU Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.56";
		alarmName="ODU Locked Defect Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.57";
		alarmName="ODU Open Connection Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.58";
		alarmName="ODU Backward Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.59";
		alarmName="ODU Backward Incoming Alignment Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.60";
		alarmName="OPU Payload Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.61";
		alarmName="Och Loss of Payload Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//SDH
		traffic="SDH";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.71";
		alarmName="SDH Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.72";
		alarmName="SDH Out of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.73";
		alarmName="SDH Loss of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.74";
		alarmName="SDH RS Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.75";
		alarmName="SDH RS Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.76";
		alarmName="SDH AU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.77";
		alarmName="SDH AU Loss of Pointer Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.78";
		alarmName="SDH MS Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.79";
		alarmName="SDH MS Remote Error Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.80";
		alarmName="SDH MS Remote Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.81";
		alarmName="SDH MS Remote Failure Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.82";
		alarmName="SDH MS B2 Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.83";
		alarmName="SDH MS B2 Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.84";
		alarmName="SDH Loss of Sequence Synchronisation Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.85";
		alarmName="SDH Higher Order Payload Label Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.86";
		alarmName="SDH Higher Order Path Unequipped Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//WAN
		traffic="WAN";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.95";
		alarmName="WAN10G Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.96";
		alarmName="WAN10G Out of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.97";
		alarmName="WAN10G Loss of Frame Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.98";
		alarmName="WAN10G RS Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.99";
		alarmName="WAN10G RS Trace Identifier Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.100";
		alarmName="WAN10G AU Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.101";
		alarmName="WAN10G AU Loss of Pointer Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.102";
		alarmName="WAN10G MS Alarm Indication Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.103";
		alarmName="WAN10G MS Remote Error Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.104";
		alarmName="WAN10G MS Remote Defect Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.105";
		alarmName="WAN10G MS Remote Failure Indication Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.106";
		alarmName="WAN10G MS B2 Signal Fail Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.107";
		alarmName="WAN10G MS B2 Signal Degrade Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.108";
		alarmName="WAN10G Loss of Sequence Synchronisation Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.109";
		alarmName="WAN10G Higher Order Payload Label Mismatch Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.110";
		alarmName="WAN10G Higher Order Path Unequipped Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		
		//LAN
		traffic="LAN";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.121";
		alarmName="LAN10G Loss of Signal Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.122";
		alarmName="LAN10G Loss of Signal Sync Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.123";
		alarmName="LAN10G Link Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.124";
		alarmName="LAN10G Frame Check Sequence Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.125";
		alarmName="LAN10G Carrier Status Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.126";
		alarmName="LAN10G High BER Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.127";
		alarmName="LAN10G Local Fault Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.128";
		alarmName="LAN10G Remote Fault Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//FC
		traffic="FC";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.141";
		alarmName="FC Transmit Display Invert Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.142";
		alarmName="FC Transmit DLOLB Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.143";
		alarmName="FC Transmit Sync Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.144";
		alarmName="FC Receive DLOLB Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.145";
		alarmName="FC Receive Sync Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.146";
		alarmName="FC Receive XDET Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.147";
		alarmName="FC Receive ASD Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.148";
		alarmName="FC Receive LCV Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//GFP
		traffic="GFP";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.161";
		alarmName="GFP Signal Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.162";
		alarmName="GFP Link Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.163";
		alarmName="GFP Core Header Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1.164";
		alarmName="GFP Extention Header Error Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
