package com.utl.trap.receiver.fanplusnew;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class FANPLUSNEWContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedFANPLUSNEWTraps;
	//static Logger l = Logger.getLogger(FANPLUSContinuousThread.class);
	
	public FANPLUSNEWContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedFANPLUSNEWTraps) {
		super("FAN PLUS_NEW Continuous Thread");
		this.receivedFANPLUSNEWTraps = receivedFANPLUSNEWTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedFANPLUSNEWTraps.take();
				System.out.println("Start FAN");
				System.out.println(trapDetails);
          
				byte prevTray1Status = 0;
				byte prevTray2Status = 0;
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				byte fanNumber = trapDetails.getPort();
				byte fanTray = trapDetails.getFanTray();
				short subrackNumber = trapDetails.getSubRack();
				String alarmIndex = "0";
				
				conn = DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
				int subrackMasterID=Integer.parseInt(slotDetails.get(2));
				
                //0 indicates present with green
				//1 indicates absent with gray
				//2 indicates standby with yellow
				String alarmName = "NO";
				if(oID.startsWith("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.3")){///Change OID for new fan tray-----dheeraj
					//if alarm status is 0 present 
					//if alarm status is 1 absent
					switch(fanTray){
					case 1:
						alarmIndex = "1";//tray1 active standby - database field
					
						prevTray2Status = FANPLUSNEWDAO.getTraystatus(subrackMasterID, "2", conn);
						 if(prevTray2Status == 0 && alarmStatus != 1)
								alarmStatus = 2;//tray1 is standby- if tray2 is active
						if (alarmStatus==1 || alarmStatus==2){
							alarmName = "Fan Tray-1 Absence";			
							
						}
						if (alarmStatus==0)
						 alarmName = "Fan Tray-1 Present";
						
						FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, alarmStatus, conn);
						break;
					case 2:
						alarmIndex = "2";//tray2 active standby - database field
					
						prevTray1Status = FANPLUSNEWDAO.getTraystatus(subrackMasterID, "1", conn);
					    if(prevTray1Status == 0 && alarmStatus != 1)
							alarmStatus = 2;//tray2 is standby- if tray1 is active
						if (alarmStatus==1 || alarmStatus==2){
							alarmName = "Fan Tray-2 Absence";							
						}
						
						if (alarmStatus==0)
							 alarmName = "Fan Tray-2 Present";
						
						FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, alarmStatus, conn);
						break;
					}
					
				}else if(oID.startsWith("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.4")){
					switch(fanTray){
					case 1:
						switch(fanNumber){
						case 1:
							alarmIndex = "1_fan1";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-1 Faulty";
							break;
						case 2:
							alarmIndex = "1_fan2";
					
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-2 Faulty";
							break;
						case 3:
							alarmIndex = "1_fan3";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-3 Faulty";
							break;
						case 4:
							alarmIndex = "1_fan4";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-4 Faulty";
							break;
						case 5:
							alarmIndex = "1_fan5";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-5 Faulty";
							break;
						case 6:
							alarmIndex = "1_fan6";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-6 Faulty";
							break;
						case 7:
							alarmIndex = "1_fan7";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-1 Fan-7 Faulty";
							break;
						case 8:
							alarmIndex = "1_fan8";
					
						if (alarmStatus==1 || alarmStatus==0)
							alarmName = "Tray-1 Fan-8 Faulty";
						break;
						}
						break;
					case 2:
						switch(fanNumber){
						case 1:
							alarmIndex = "2_fan1";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-1 Faulty";
							break;
						case 2:
							alarmIndex = "2_fan2";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-2 Faulty";
							break;
						case 3:
							alarmIndex = "2_fan3";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-3 Faulty";
							break;
						case 4:
							alarmIndex = "2_fan4";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-4 Faulty";
							break;
						case 5:
							alarmIndex = "2_fan5";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-5 Faulty";
							break;
						
						case 6:
							alarmIndex = "2_fan6";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-6 Faulty";
							break;
						case 7:
							alarmIndex = "2_fan7";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-7 Faulty";
							break;
						case 8:
							alarmIndex = "2_fan8";
						
							if (alarmStatus==1 || alarmStatus==0)
								alarmName = "Tray-2 Fan-8 Faulty";
							break;
						}
					
					FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, alarmStatus, conn);
					}	
				}else if(oID.startsWith("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.5")){
					//if alarm status is 0 inactive(standby) 
					//if alarm status is 1 active i.e.timestamp
					switch(fanTray){
					case 1:
						alarmIndex = "1";//tray1 active standby - database field
						prevTray1Status = FANPLUSNEWDAO.getTraystatus(subrackMasterID, "1", conn);
						
						if (alarmStatus==0 && prevTray1Status==1)
							System.out.println("Fan tray1 is absent... dont do anything");
						else if (alarmStatus==1 && prevTray1Status==1)
							System.out.println("Fan tray1 is absent... dont do anything");
						else if (alarmStatus==0 && prevTray1Status!=1 )						
							FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, (byte)2, conn);						
						else if (alarmStatus==1 && prevTray1Status!=1)
							FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, (byte)0, conn);
						
						
						
						break;
						
					case 2:
						alarmIndex = "2";//tray2 active standby - database field
						
						prevTray2Status = FANPLUSNEWDAO.getTraystatus(subrackMasterID, "2", conn);
						
						if (alarmStatus==0 && prevTray2Status==1)							
							System.out.println("Fan tray2 is absent... dont do anything");
						else if (alarmStatus==0 && prevTray2Status==1)							
							System.out.println("Fan tray2 is absent... dont do anything");
						else if (alarmStatus==0 && prevTray2Status!=1 )
							FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, (byte)2, conn);
						else if (alarmStatus==1 && prevTray2Status!=1 )
							FANPLUSNEWDAO.updateAlarm(subrackMasterID, alarmIndex, (byte)0, conn);
						
						
					break;
				}
				}
				
				if(!alarmName.equals("NO"))
					FANPLUSNEWDAO.updateAlarmTrans(subrackMasterID, alarmStatus,alarmName, subrackNumber, fanTray, fanNumber, trapDetails.getAlarmGeneratedTime(), conn);
				
				
			} catch (Exception e) {
				//l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
