package com.utl.trap.receiver;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FiberCutStatusDAO {
	public static byte updateFiberCutStatus(int nodeId,byte oscNumber,byte fiberCutStatus, Connection conn) throws Exception {
		PreparedStatement ps = null;
		byte updateStatus = 0;
		/*SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date=new Date();
		String startTime=sdf.format(date);
		String stopTime=sdf.format(date);*/
		
		try {
			String directionType = getNodeDirectionType(nodeId, oscNumber, conn);
			if (directionType!=null) {
				String query;
				/*if ("parent".equals(directionType)) {
					 query = "UPDATE `mesh_topology` SET fiber_cut_1=?,fiber_down_time=?,fiber_up_time=? WHERE `parent_node_id`=? and `parent_node_osc_id`=? and fiber_down_time is null and fiber_up_time is null";
				} else {
					 query = "UPDATE `mesh_topology` SET fiber_cut_2=?,fiber_down_time=?,fiber_up_time=? WHERE `child_node_id`=? and `child_node_osc_id`=? and fiber_down_time is null and fiber_up_time is null";
				} */
				
				if ("parent".equals(directionType)) {
					 query = "UPDATE `mesh_topology` SET fiber_cut_1=? WHERE `parent_node_id`=? and `parent_node_osc_id`=?";
				} else {
					 query = "UPDATE `mesh_topology` SET fiber_cut_2=? WHERE `child_node_id`=? and `child_node_osc_id`=?";
				} 
				
				ps = conn.prepareStatement(query);
				ps.setByte(1, fiberCutStatus);
				ps.setInt(2, nodeId);
				ps.setInt(3, oscNumber);														
			
				updateStatus = (byte) ps.executeUpdate();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return updateStatus;
	}
	
	public static void storeFiberCutStatus(int nodeId,byte fiberCutStatus, Connection conn) throws Exception {
		PreparedStatement psForSelect=null;
		PreparedStatement psForInsert=null;
		PreparedStatement psForUpdate=null;
		PreparedStatement psForSelectNodeId=null;
		ResultSet rsForSelect=null;
		ResultSet rsForSelectNodeId=null;
		try {
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date=new Date();
			String strTime=sdf.format(date);
			psForSelectNodeId=conn.prepareStatement("SELECT parent_node_id FROM mesh_topology where parent_node_id=?");
			psForSelectNodeId.setInt(1, nodeId);
			rsForSelectNodeId=psForSelectNodeId.executeQuery();
			if(rsForSelectNodeId.next()){
				//long nodeID=rsForSelectNodeId.getLong("mesh_topology_id");
				if (fiberCutStatus==1) {
					psForSelect = conn
							.prepareStatement("SELECT parent_node_id FROM fiber_cut_status_report where parent_node_id=? and fiber_cut_up_time is null");
					psForSelect.setLong(1, nodeId);
					rsForSelect = psForSelect.executeQuery();
					if(!rsForSelect.next()){
						psForInsert=conn.prepareStatement("INSERT INTO `fiber_cut_status_report`(`parent_node_id`,`fiber_cut_down_time`)VALUES(?,?)");
						psForInsert.setLong(1, nodeId);
						psForInsert.setString(2, strTime);
						psForInsert.executeUpdate();
					}
				}else{				
					psForUpdate=conn.prepareStatement("update fiber_cut_status_report set fiber_cut_up_time=? where parent_node_id =? and fiber_cut_up_time is null");
					psForUpdate.setString(1, strTime);
					psForUpdate.setLong(2, nodeId);
					psForUpdate.executeUpdate();
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(rsForSelectNodeId!=null){
					rsForSelectNodeId.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
				if(psForInsert!=null){
					psForInsert.close();
				}
				if(psForUpdate!=null){
					psForUpdate.close();
				}
				if(psForSelectNodeId!=null){
					psForSelectNodeId.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}

	}
	
	public static String getNodeDirectionType(int nodeId,byte oscNumber, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String type=null;
		try {
			psForSelect=conn.prepareStatement("SELECT count(*) as count FROM mesh_topology where parent_node_id=? and parent_node_osc_id=? union SELECT count(*) as count FROM mesh_topology where child_node_id=? and child_node_osc_id=?");
			psForSelect.setInt(1, nodeId);
			psForSelect.setByte(2, oscNumber);
			psForSelect.setInt(3, nodeId);
			psForSelect.setByte(4, oscNumber);
			rsForSelect=psForSelect.executeQuery();
			byte i=1;
			while(rsForSelect.next()){
				if (i==1&&rsForSelect.getByte(1)==1){
					type = "parent";
				}else if(rsForSelect.getByte(1)==1){
					type = "child";
				}
				i++;
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return type;
	}
	
	public static List<String> getOPAOrOLASlotDetails(int nodeId,byte oscNumber, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		List<String> slotDetails = new ArrayList<String>();
		try {
			psForSelect=conn.prepareStatement("SELECT slot.dwdm_slot_master_id,card_name FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id  where node.node_details_id=? and (card_name like ? or card_name like ?)");
			psForSelect.setInt(1, nodeId);
			psForSelect.setString(2, "OLA"+oscNumber);
			psForSelect.setString(3, "OPA"+oscNumber);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				slotDetails.add(rsForSelect.getString(1));
				slotDetails.add(rsForSelect.getString(2));
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return slotDetails;
	}
	
	public static List<String> getOPAPLUSOrOLAPLUSSlotDetails(int nodeId,byte oscNumber, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		List<String> slotDetails = new ArrayList<String>();
		try {
			psForSelect=conn.prepareStatement("SELECT slot.dwdm_slot_master_id,card_name FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id  where node.node_details_id=? and (card_name like ? or card_name like ?)");
			psForSelect.setInt(1, nodeId);
			psForSelect.setString(2, "OLA"+oscNumber+"PLUS");
			psForSelect.setString(3, "OPA"+oscNumber+"PLUS");
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				slotDetails.add(rsForSelect.getString(1));
				slotDetails.add(rsForSelect.getString(2));
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return slotDetails;
	}
}
