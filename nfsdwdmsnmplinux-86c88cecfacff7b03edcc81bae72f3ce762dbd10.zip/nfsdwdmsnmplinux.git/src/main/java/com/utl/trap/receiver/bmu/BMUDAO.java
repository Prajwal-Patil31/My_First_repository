package com.utl.trap.receiver.bmu;

import java.sql.Connection;
import java.sql.PreparedStatement;


public class BMUDAO {
	public static void updateInToDwdmSlotMasterGlobalAlarmStatus(int slotMasterID,int nodeID,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForUpdate=null;
		PreparedStatement psForUpdateNodeDetails=null;
		try {
				psForUpdate = conn.prepareStatement("UPDATE dwdm_slot_master SET global_alarm_status=? where dwdm_slot_master_id=?");
				psForUpdate.setByte(1, alarmStatus);
				psForUpdate.setInt(2, slotMasterID);
				psForUpdate.executeUpdate();
				
				psForUpdateNodeDetails = conn.prepareStatement("UPDATE node_details SET global_alarm_status=? where node_details_id=?");
				psForUpdateNodeDetails.setByte(1, alarmStatus);
				psForUpdateNodeDetails.setInt(2, nodeID);
				psForUpdateNodeDetails.executeUpdate();
		}catch (Exception e) {
			throw e;
		}finally{			
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForUpdateNodeDetails!=null){
				psForUpdateNodeDetails.close();
			}
		}
	}
}
