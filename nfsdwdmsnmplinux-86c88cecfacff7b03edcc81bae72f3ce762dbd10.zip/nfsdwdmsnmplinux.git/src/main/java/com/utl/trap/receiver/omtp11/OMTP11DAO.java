package com.utl.trap.receiver.omtp11;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.GetDetailsFromPropertiesFile;

public class OMTP11DAO {
	public static List<ReceivedTrapDetails> getReceivedTrapDetailsFromDB() throws Exception{
		PreparedStatement ps=null,psForDelete=null;
		ResultSet rs=null;
		Connection conn = null;
		List<ReceivedTrapDetails> trapReceivedDetailsBeanList=new ArrayList<ReceivedTrapDetails>();
		try {
			short limit = Short.parseShort(GetDetailsFromPropertiesFile.getValue("concurrent.process.trap"));
			StringBuffer query=new StringBuffer("SELECT dwdm_trap_receiver_omtp11_alarm_details_id,`node_number`,`rack_number`,`subrack_number`,`slot_number`,`port_number`,`node_ip_address`,`OID`,`card_name`,`alarm_status`,`dwdm_port_master_id`,`port_client_line_type`,`alarm_generated_time`,dwdm_slot_master_id FROM dwdm_trap_receiver_omtp11_alarm_details group by dwdm_port_master_id limit ");
			query.append(limit);
			conn = DataSource.getInstance().getConnection();
			ps=conn.prepareStatement(query.toString());
			psForDelete=conn.prepareStatement("DELETE FROM `dwdm_trap_receiver_omtp11_alarm_details` WHERE `dwdm_trap_receiver_omtp11_alarm_details_id`=?");
			rs=ps.executeQuery();
			while(rs.next()){
				ReceivedTrapDetails trapReceivedDetailsBean=new ReceivedTrapDetails(rs.getByte("node_number")
						,rs.getShort("rack_number"),rs.getShort("subrack_number"),rs.getShort("slot_number"),rs.getByte("port_number"),rs.getString("card_name"),rs.getString("node_ip_address"),rs.getByte("alarm_status")
						,rs.getTimestamp("alarm_generated_time"),rs.getString("OID"),rs.getInt("dwdm_port_master_id"),rs.getString("port_client_line_type"),rs.getInt("dwdm_slot_master_id"));
				trapReceivedDetailsBeanList.add(trapReceivedDetailsBean);
				psForDelete.setInt(1, rs.getInt("dwdm_trap_receiver_omtp11_alarm_details_id"));
				psForDelete.addBatch();
			}
			psForDelete.executeBatch();
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(rs!=null){
					rs.close();
				}
				if(ps!=null){
					ps.close();
				}
				if(psForDelete!=null){
					psForDelete.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return trapReceivedDetailsBeanList;
	}
	public static void insertReceivedTrapDetails(ReceivedTrapDetails trapDetails) throws Exception{
		Connection conn=null;
		PreparedStatement psForSelect=null,psForInsert=null;
		ResultSet rsForSelect=null;
		try {
				conn=DataSource.getInstance().getConnection();
				psForSelect=conn.prepareStatement("SELECT node.node_details_id,dwdm_port_master_id,port_client_line_type FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id join dwdm_port_master dport on slot.dwdm_slot_master_id = dport.dwdm_slot_master_id   where node_ip_address=? and rack.rack_number=? and subrack.subrack_number=? and slot.slot_number=? and dport.port_number=?");
				psForSelect.setString(1, trapDetails.getNodeIP());
				psForSelect.setShort(2, trapDetails.getRack());
				psForSelect.setShort(3, trapDetails.getSubRack());
				psForSelect.setShort(4, trapDetails.getSlot());
				psForSelect.setShort(5, trapDetails.getPort());
				rsForSelect=psForSelect.executeQuery();
				if(rsForSelect.next()){
					psForInsert=conn.prepareStatement("INSERT INTO `dwdm_trap_receiver_omtp11_alarm_details`(`node_number`,`rack_number`,`subrack_number`,`slot_number`,`port_number`,`node_ip_address`,`OID`,`card_name`,`alarm_status`,`dwdm_port_master_id`,`port_client_line_type`,`alarm_generated_time`)VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
					psForInsert.setShort(1, trapDetails.getNode());
					psForInsert.setShort(2, trapDetails.getRack());
					psForInsert.setShort(3, trapDetails.getSubRack());
					psForInsert.setShort(4, trapDetails.getSlot());
					psForInsert.setShort(5, trapDetails.getPort());
					psForInsert.setString(6, trapDetails.getNodeIP());
					psForInsert.setString(7, trapDetails.getOID());
					psForInsert.setString(8, trapDetails.getCardName());
					psForInsert.setByte(9, trapDetails.getAlarmStatus());
					psForInsert.setInt(10, rsForSelect.getInt("dwdm_port_master_id"));
					psForInsert.setString(11, rsForSelect.getString("port_client_line_type"));
					psForInsert.setTimestamp(12, trapDetails.getAlarmGeneratedTime());
					psForInsert.executeUpdate();
				}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(psForInsert!=null){
					psForInsert.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static byte updateAlarmClientOptical(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp11_10g_client_optical_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp11_10g_client_optical_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp11_10g_client_optical_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static byte updateAlarmClientTraffic(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp11_10g_client_traffic_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp11_10g_client_traffic_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp11_10g_client_traffic_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static byte updateAlarmLineTraffic(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp11_10g_line_traffic_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp11_10g_line_traffic_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp11_10g_line_traffic_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static byte updateAlarmLineOptical(int portMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_omtp11_10g_line_optical_alarm where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn
							.prepareStatement("UPDATE dwdm_omtp11_10g_line_optical_alarm SET alarm"
									+ alarmIndex
									+ "=? where dwdm_port_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, portMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_omtp11_10g_line_optical_alarm(dwdm_port_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, portMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static String getAlarmSeverity(int portMasterID,String alarmIndex,String clientOrLine,String traffic, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String alarmSeverity="Critical";
		try {
			String tableName;
			if("Client".equals(clientOrLine)){
				if("OPTICAL".equals(traffic)){
					tableName="dwdm_omtp11_10g_client_optical_alarm_severity";
				}else{
					tableName="dwdm_omtp11_10g_client_traffic_alarm_severity";
				}
			}else{
				if("OPTICAL".equals(traffic)){
					tableName="dwdm_omtp11_10g_line_optical_alarm_severity";
				}else{
					tableName="dwdm_omtp11_10g_line_traffic_alarm_severity";
				}
			}
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM "+tableName+"  where dwdm_port_master_id=?");
			psForSelect.setInt(1, portMasterID);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				alarmSeverity=rsForSelect.getString(1);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return alarmSeverity;
	}
	
	public static byte  updateAlarmTrans(int portMasterID,byte alarmStatus,String alarmName,String alarmSeverity,Timestamp alarmGeneratedTime,String traffic,String clientOrLine,Connection conn) throws Exception{
		byte result = 0;
		CallableStatement cstmtForUpdateAlarms = null;
		try {
			cstmtForUpdateAlarms = conn.prepareCall("CALL dwdm_omtp11_10g_alarm_trans_update(?,?,?,?,?,?,?)");
			cstmtForUpdateAlarms.setInt(1, portMasterID);
			cstmtForUpdateAlarms.setByte(2, alarmStatus);
			cstmtForUpdateAlarms.setString(3, alarmName);
			cstmtForUpdateAlarms.setString(4, alarmSeverity);
			cstmtForUpdateAlarms.setTimestamp(5, alarmGeneratedTime);
			cstmtForUpdateAlarms.setString(6, traffic);
			cstmtForUpdateAlarms.setString(7, clientOrLine);
			result=(byte) cstmtForUpdateAlarms.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			if(cstmtForUpdateAlarms!=null){
				cstmtForUpdateAlarms.close();
			}
		}
		return result;
	}
	
	public static void main(String[] args) {
		
	}
}
