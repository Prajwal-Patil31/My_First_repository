package com.utl.trap.receiver.ommp100;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.GetDetailsFromPropertiesFile;

public class OMMP100ContinuousThread extends Thread{
	
	private Short THREAD_POOL_SIZE;
	static Logger l = Logger.getLogger(OMMP100ContinuousThread.class);
	private ThreadPoolExecutor threadPool=null;
	public OMMP100ContinuousThread(){
		super("OMMP100 Continuous Thread");
		try {
			THREAD_POOL_SIZE=Short.parseShort(GetDetailsFromPropertiesFile.getValue("concurrent.process.trap"));
		} catch (Exception e) {
			l.info("Unable to load info.properties "+e.getMessage());
			e.printStackTrace();
		} 
		threadPool=(ThreadPoolExecutor) Executors.newFixedThreadPool(THREAD_POOL_SIZE);
	}
	@Override
	public void run() {
		while(true){
			try{
				List<ReceivedTrapDetails> trapReceivedDetailsBeanList=OMMP100DAO.getReceivedTrapDetailsFromDB();
				Collection<Future<?>> futures = new LinkedList<Future<?>>();
				for(ReceivedTrapDetails trapReceivedDetailsBean:trapReceivedDetailsBeanList){
					OMMP100Runnable runnable=new OMMP100Runnable(trapReceivedDetailsBean);
					futures.add(threadPool.submit(runnable));
				}
				for (Future<?> future:futures) {
				    future.get();
				}
				try {
					if (trapReceivedDetailsBeanList.size()==0) {
						Thread.sleep(1000);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}catch(Exception e){
				l.info(e);
			}
		}
	}
}
