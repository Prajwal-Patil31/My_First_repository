package com.utl.trap.receiver.bmu;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.ut.connection.pool.DataSource;
import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.trap.receiver.ReceivedTrapDetailsForBMU;
import com.utl.trap.receiver.buzzerplus.BUZZERPLUSBL;
import com.utl.trap.receiver.mdroadmplus.MDROADMPLUSBL;
import com.utl.util.CommonDAO;

public class BMUContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetailsForBMU> receivedBMUTraps;
	static Logger l = Logger.getLogger(BMUContinuousThread.class);
	
	public BMUContinuousThread(
			BlockingQueue<ReceivedTrapDetailsForBMU> receivedBMUTraps) {
		super("BMU Continuous Thread");
		this.receivedBMUTraps = receivedBMUTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetailsForBMU trapBMUDetails = receivedBMUTraps.take();
				System.out.println("Start BMU");
				l.info(trapBMUDetails);
				String alarmStatus    = trapBMUDetails.getAlarmStatus();
				String oID          = trapBMUDetails.getOID();
				String nodeIP = trapBMUDetails.getNodeIP();
				String[] alarmMiscData = BMUAlarmNames.getDetails(oID);
				
				String hide       = alarmMiscData[2];
				 
				byte alarmGlobalforBMU = 0;
				if(alarmStatus.equals("minor")){
					alarmGlobalforBMU = 2;
				}
				else if(alarmStatus.equals("major") || alarmStatus.equals("critical")  || alarmStatus.equals("critical+major")){
					alarmGlobalforBMU = 4;
				}
				else if(alarmStatus.equals("normal")){
					alarmGlobalforBMU = 0;
				}
				else if(alarmStatus.equals("major+minor") || alarmStatus.equals("critical+major+minor") || alarmStatus.equals("critical+minor") ){
					alarmGlobalforBMU = 6;
				}
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetailsForBMU(trapBMUDetails, conn);
					System.out.println("BMU TRAPS=============>>>>>>"+slotDetails);
					int nodeID=Integer.parseInt(slotDetails.get(0));
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					//check all BMU alarms and severity from DB to update global
					BMUDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID,nodeID,alarmGlobalforBMU, conn);
					l.info("BMU Global Alarm Process Completed......");
					}
				
				if(alarmGlobalforBMU > 0 )
				{
					int buzzerMuteStatus  = 0;
					
					buzzerMuteStatus = BUZZERPLUSBL.getBuzzerStatus(nodeIP, (byte)1, (short)1,(short) 1,(short) 1, (short)4, new SNMPVersionDetails());
					if (buzzerMuteStatus  != 2)
					{
					
						CallableStatement cstmtForUpdateBuzzerMute = null;
						Connection connBuzzer = null;
						byte result = 0;
						try{
							// call stored procedure to clear buzzer on mute
							
							connBuzzer=DataSource.getInstance().getConnection();
							
							cstmtForUpdateBuzzerMute = connBuzzer.prepareCall("CALL buzzer_update(?)");
							cstmtForUpdateBuzzerMute.setString(1, nodeIP);
							result=(byte) cstmtForUpdateBuzzerMute.executeUpdate();
							
						}
						catch (Exception e) {
							l.info(e);
						}finally{
							if(cstmtForUpdateBuzzerMute!=null){
								cstmtForUpdateBuzzerMute.close();
							}
							if(connBuzzer!=null){
								connBuzzer.close();
							}
						}
					}
				}
			} catch (Exception e) {
				
				l.info("BMU Alarm Processing Error......");
				l.error(e.getMessage(),e);
				
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
