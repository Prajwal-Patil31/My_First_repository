package com.utl.trap.receiver.fanplus;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;

public class FANPLUSDAO {
	public static byte updateAlarm(int slotMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT shelf_tray"+alarmIndex+" FROM dwdm_fan_alarm where dwdm_subrack_master_id=?");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn.prepareStatement("UPDATE dwdm_fan_alarm SET shelf_tray"+alarmIndex+"=? where dwdm_subrack_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, slotMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_fan_alarm(dwdm_subrack_master_id,shelf_tray"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, slotMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}

	public static byte getTraystatus(int slotMasterID,String alarmIndex ,Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevTrayAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT shelf_tray"+alarmIndex+" FROM dwdm_fan_alarm where dwdm_subrack_master_id=?");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevTrayAlarmStatus=rsForSelect.getByte(1);
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevTrayAlarmStatus;
	}

	public static byte  updateAlarmTrans(int subrackMasterID,int alarmStatus ,String alarmName,int shelfNumber,int trayNumber,int fanNumber,Timestamp alarmGeneratedTime,Connection conn) throws Exception{
		byte result = 0;
		CallableStatement cstmtForUpdateAlarms = null;
		try {
			cstmtForUpdateAlarms = conn.prepareCall("CALL dwdm_fan_alarms_trans_update(?,?,?,?,?,?,?)");
			cstmtForUpdateAlarms.setInt(1, subrackMasterID);			
			cstmtForUpdateAlarms.setString(2, alarmName);
			cstmtForUpdateAlarms.setInt(3, shelfNumber);
			cstmtForUpdateAlarms.setInt(4, trayNumber);
			cstmtForUpdateAlarms.setInt(5, fanNumber);
			cstmtForUpdateAlarms.setTimestamp(6, alarmGeneratedTime);
			cstmtForUpdateAlarms.setInt(7, alarmStatus);
			result=(byte) cstmtForUpdateAlarms.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			if(cstmtForUpdateAlarms!=null){
				cstmtForUpdateAlarms.close();
			}
		}
		return result;
	}
}
