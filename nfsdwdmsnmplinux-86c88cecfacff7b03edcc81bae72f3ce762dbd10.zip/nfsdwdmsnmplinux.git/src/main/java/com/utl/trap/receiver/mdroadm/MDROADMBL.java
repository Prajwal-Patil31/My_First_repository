package com.utl.trap.receiver.mdroadm;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class MDROADMBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfMantis(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber,byte directionNumber, byte portType, byte channelNumber, SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,2,1,1,1,23,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber, portType,channelNumber}));
		System.out.println(OID);
		String cardName = "mantis";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getMDROADCardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getMDROADCardName(int directionNumber){
		String cardName = "mantis";
		switch (directionNumber) {
		case 1:
			cardName="MD-ROADM-DIR-1";
			break;
		case 2:
			cardName="MD-ROADM-DIR-2";
			break;
		case 3:
			cardName="MD-ROADM-DIR-3";
			break;
		case 4:
			cardName="MD-ROADM-DIR-4";
			break;
		}
		return cardName;
	}
}
