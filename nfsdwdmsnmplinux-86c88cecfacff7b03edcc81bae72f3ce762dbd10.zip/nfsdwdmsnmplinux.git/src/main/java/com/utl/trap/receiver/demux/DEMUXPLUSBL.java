package com.utl.trap.receiver.demux;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class DEMUXPLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfDEMUXPLUS(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber, byte interfaceNumber,SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,181,1,1,1,25,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		System.out.println(OID);
		String cardName = "demux_plus";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getDEMUXPlusCardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getDEMUXPlusCardName(int directionNumber){
		String cardName = "demux_plus";
		switch (directionNumber) {
		case 1:
			cardName="DEMUX1PLUS";
			break;
		case 2:
			cardName="DEMUX2PLUS";
			break;
		case 3:
			cardName="DEMUX3PLUS";
			break;
		case 4:
			cardName="DEMUX4PLUS";
			break;
		}
		return cardName;
	}
}
