package com.utl.trap.receiver.jack;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;

import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;
import com.utl.util.UpdateTrafficForLineCards;

public class JackContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedJackTraps;
	//static Logger l = Logger.getLogger(JackContinuousThread.class);
	
	public JackContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedJackTraps) {
		super("Jack Continuous Thread");
		this.receivedJackTraps = receivedJackTraps;
	}

	@Override
	public void run() {
		//System.out.println("Start1 Jack");
		
		while(true){
			Connection conn = null;
			boolean jackIn=false;
			try {
				ReceivedTrapDetails trapDetails = receivedJackTraps.take();
				System.out.println("Start4 Jack:::::::::::::::::"+trapDetails.toString());
				System.out.println(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String cardName  = trapDetails.getCardName();
				System.out.println("Card Name >>>>>>>>>>>>>>>>>>>>>>>>> "+cardName);
				
		//		String oID          = trapDetails.getOID();
		//		String[] alarmMiscData = JackAlarmNames.getDetails(oID);
		//		String alarmIndex = alarmMiscData[0];
		//		String alarmName  = JackCardNames.getDetails(oID);
		//		String hide       = alarmMiscData[2];
		//		System.out.println("Slot alarmIndex "+alarmIndex);
		//		if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					System.out.println("CONN");
					
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("slotDetails "+slotDetails);
					int nodeID = Integer.parseInt(slotDetails.get(1));
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					System.out.println("Slot Master ID "+slotMasterID);
					if(alarmStatus == 0){//jack out
						cardName = slotDetails.get(3);
					}
					JackDAO.updateJack(slotMasterID, cardName, alarmStatus, conn);
					
					 //store card jack in jack out history
			        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
					Date date=new Date();
					String dateTime=sdf.format(date);
					
					if (alarmStatus == 1)
						jackIn = true;
					
					
					  JackDAO.updateJackInOutHistory(jackIn, conn, slotMasterID, dateTime,cardName);
					  
					if (jackIn == true){
						UpdateTrafficForLineCards.refreshTrafficForAllLineCards((short)1, trapDetails.getRack(), trapDetails.getSubRack(), trapDetails.getSlot(), trapDetails.getNodeIP(), cardName, slotMasterID, conn);
					}
					/*byte prevAlarmStatus=JackDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = JackDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						JackDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
					}*/
		//		}
			} catch (Exception e) {
				//l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
