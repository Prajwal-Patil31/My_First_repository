package com.utl.trap.receiver.opaplus;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class OPAPLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfOPAPLUS(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber, byte interfaceNumber,SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,141,1,1,1,38,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		System.out.println(OID);
		String cardName = "OPAPLUS";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getOPAPLUSCardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getOPAPLUSCardName(int directionNumber){
		String cardName = "OPAPLUS";
		switch (directionNumber) {
		case 1:
			cardName="OPA1PLUS";
			break;
		case 2:
			cardName="OPA2PLUS";
			break;
		case 3:
			cardName="OPA3PLUS";
			break;
		case 4:
			cardName="OPA4PLUS";
			break;
		}
		return cardName;
	}
}
