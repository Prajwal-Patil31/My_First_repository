package com.utl.trap.receiver.fan;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class FANContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedFANTraps;
	static Logger l = Logger.getLogger(FANContinuousThread.class);
	
	public FANContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedFANTraps) {
		super("FAN Continuous Thread");
		this.receivedFANTraps = receivedFANTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedFANTraps.take();
				System.out.println("Start FAN");
				l.info(trapDetails);

				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				byte fanNumber = trapDetails.getPort();
				byte fanTray = trapDetails.getFanTray();
				short subrackNumber = trapDetails.getSubRack();
				String alarmIndex = "0";

				String alarmName;
				if(oID.startsWith("1.3.6.1.4.1.18036.1.1.1.10.2.1.1.1.4")){
					switch(fanTray){
					case 1:
						alarmIndex = "1";
						break;
					case 2:
						alarmIndex = "2";
						break;
					}
				}else if(oID.startsWith("1.3.6.1.4.1.18036.1.1.1.10.2.1.1.1.5")){
					switch(fanTray){
					case 1:
						switch(fanNumber){
						case 1:
							alarmIndex = "3";
							break;
						case 2:
							alarmIndex = "4";
							break;
						case 3:
							alarmIndex = "5";
							break;
						}
						break;
					case 2:
						switch(fanNumber){
						case 1:
							alarmIndex = "6";
							break;
						case 2:
							alarmIndex = "7";
							break;
						case 3:
							alarmIndex = "8";
							break;
						}
						break;
					}
				}else if(oID.startsWith("1.3.6.1.4.1.18036.1.1.1.10.2.1.1.1.6")){

				}

				conn = DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
				int slotMasterID=Integer.parseInt(slotDetails.get(1));
				byte prevAlarmStatus=FANDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);

				/*if(alarmStatus!=prevAlarmStatus){
					String alarmSeverity = FANDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
					FANDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
				}*/
			} catch (Exception e) {
				l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
