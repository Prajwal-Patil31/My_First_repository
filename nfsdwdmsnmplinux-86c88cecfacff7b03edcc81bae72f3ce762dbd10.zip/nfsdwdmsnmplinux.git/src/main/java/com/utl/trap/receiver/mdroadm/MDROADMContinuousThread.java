package com.utl.trap.receiver.mdroadm;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class MDROADMContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedMDROADMTraps;
	static Logger l = Logger.getLogger(MDROADMContinuousThread.class);
	
	public MDROADMContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedMDROADMTraps) {
		super("MDROADM Continuous Thread");
		this.receivedMDROADMTraps = receivedMDROADMTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedMDROADMTraps.take();
				System.out.println("Start MDROADM");
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = MDROADMAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=MDROADMDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = MDROADMDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						MDROADMDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
					}
				}
			} catch (Exception e) {
				l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
