package com.utl.trap.receiver.obaplus;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;

import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.CommonDAO;

public class OBAPLUSContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedOBAPLUSTraps;
	//static Logger l = Logger.getLogger(OBAPLUSContinuousThread.class);
	
	public OBAPLUSContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedOBAPLUSTraps) {
		super("OBAPLUS Continuous Thread");
		this.receivedOBAPLUSTraps = receivedOBAPLUSTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOBAPLUSTraps.take();
				System.out.println("Start OBAPLUS");
				System.out.println(trapDetails);
				//l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OBAPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("OBAPLUS TRAPS=============>>>>>>"+slotDetails);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OBAPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OBAPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OBAPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
				
						//check all OBAPLUS alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OBAPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OBAPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						//l.info("OBAPLUS Global Alarm Process Completed......"+status);
					}
				}
			} catch (Exception e) {
				
				//l.info("OBAPLUS Alarm Processing Error......");
				System.out.println("OBAPLUS Alarm Processing Error......");
				e.getMessage();
				//l.error(e.getMessage(),e);
				
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
