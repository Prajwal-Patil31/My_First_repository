package com.utl.trap.receiver.osc;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.FiberCutStatusDAO;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.obaplus.OBAPLUSDAO;
import com.utl.trap.receiver.ola.OLADAO;
import com.utl.trap.receiver.olaplus.OLAPLUSDAO;
import com.utl.trap.receiver.opa.OPADAO;
import com.utl.trap.receiver.opaplus.OPAPLUSDAO;
import com.utl.util.CommonDAO;

public class OSCContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedSCCTraps;
	//static Logger l = Logger.getLogger(OSCContinuousThread.class);
	
	public OSCContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedSCCTraps) {
		super("SCC Continuous Thread");
		this.receivedSCCTraps = receivedSCCTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedSCCTraps.take();
				System.out.println("Start SCC-OSC");
				System.out.println(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
			//	int slotMasterID= trapDetails.getSlotMasterID();
				int oscPortNumber = trapDetails.getPort();
				
				String[] alarmMiscData = OSCAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				alarmName = "OSC" + oscPortNumber + " "+alarmName;
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);					
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					
				//	if (!alarmIndex.equals("35"))//other than link fail alarm index
				//	{
					
							byte prevAlarmStatus=OSCDAO.updateAlarm(slotMasterID, oscPortNumber, alarmIndex, alarmStatus, conn);
					//		System.out.println("prevAlarmStatus SCC-OSC::"+prevAlarmStatus);
							
							if(alarmStatus!=prevAlarmStatus){
								String alarmSeverity = OSCDAO.getAlarmSeverity(slotMasterID,oscPortNumber, alarmIndex, conn);
						//		System.out.println("alarmSeverity SCC-OSC::"+alarmSeverity);
								OSCDAO.updateAlarmTrans(slotMasterID, oscPortNumber, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						//		System.out.println("alarmSeverity SCC-OSC After updateAlarmTrans::"+alarmSeverity);
							}
							
							//check all OBAPLUS alarms and severity from DB to update global
							LinkedHashMap<Short, Short> allAlarmPresentFromDb =OSCDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
							LinkedHashMap<Short, String> allAlarmSeverity =OSCDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
							byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatusSCCOSCAlarms(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
							System.out.println("SCC-OSC Global Alarm Process Completed.....alarmIndex."+alarmIndex);
				//	}
				//	else if (alarmIndex.equals("35"))//link fail alarm index
					if (alarmIndex.equals("35"))//link fail alarm index
					{
						byte fiberCutStatus=alarmStatus;					
				    	 int nodeId = Integer.parseInt(slotDetails.get(0));
				    	 byte oscNumber = (byte) oscPortNumber;
				   // 	 int amplifierSlotId;
				   // 	 String cardName;
				 //   	 byte amplifierAlarm = 0;
					//	  String fiberCardName = slotDetails.get(3);
						  /*	  
						  if(alarmStatus==1){							
							///OPAPLUS & OLAPLUS	
							 						 
							 List<String> listOPAPLUSOrOLAPLUSSlotDetails = FiberCutStatusDAO.getOPAPLUSOrOLAPLUSSlotDetails(nodeId, oscNumber, conn);
							 amplifierSlotId = Integer.parseInt(listOPAPLUSOrOLAPLUSSlotDetails.get(0));
							 cardName = listOPAPLUSOrOLAPLUSSlotDetails.get(1);
							 amplifierAlarm = 0;
							 if(cardName.contains("OLA")){
								 amplifierAlarm = OLAPLUSDAO.getOLAPLUSIPFAlarm(amplifierSlotId, conn);
							 }else if(cardName.contains("OPA")){
								 amplifierAlarm = OPAPLUSDAO.getOPAPLUSIPFAlarm(amplifierSlotId, conn);
							 }
							 
							 
							  byte oscIPF = OSCDAO.getOSCIPFAlarm(nodeId, oscNumber, conn);
							  if(oscIPF == 1){
								  fiberCutStatus = 1;
							  }
							  else
							  {
								  fiberCutStatus = 0;
							  }
						  }					*/	
				    	
						  byte fiberUpdate=FiberCutStatusDAO.updateFiberCutStatus(nodeId, oscNumber, fiberCutStatus, conn);
						  System.out.println("OSC Alarm topline fiber cut Process Completed......"+fiberUpdate);
						  
						  FiberCutStatusDAO.storeFiberCutStatus(nodeId, fiberCutStatus, conn);
						  
						  
					}
				}
			} catch (Exception e) {
				//l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
