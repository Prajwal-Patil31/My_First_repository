package com.utl.trap.receiver.ommp200;

import java.util.HashMap;
import java.util.Map;

public class OMMP200AlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	private static String traffic;
	static{
		//OPTICAL
		/*traffic="OPTICAL";
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.1";
		alarmName=" XFP Input Power Failure";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.2";
		alarmName="XFP Output Power Failure";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.3";
		alarmName="XFP High Temperature";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.4";
		alarmName="XFP Low Temperature";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.5";
		alarmName="XFP High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.6";
		alarmName="XFP Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.7";
		alarmName=" XFP High Bias Current";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.8";
		alarmName="XFP Low Bias Current";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.71.3.1.1.1.9";
		alarmName="XFP High Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.10";
		alarmName="XFP Low Bias Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		*/
		/*alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.11";
		alarmName="XFP Input High Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.12";
		alarmName="XFP Input Low Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.13";
		alarmName="XFP Input High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.14";
		alarmName="XFP Input Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.15";
		alarmName="XFP Output High Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.16";
		alarmName="XFP Output Low Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.17";
		alarmName="XFP Output High Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.18";
		alarmName="XFP Output Low Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.19";
		alarmName="XFP High Supply Voltage";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.20";
		alarmName="XFP Low Supply Voltage";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.21";
		alarmName="XFP High Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.22";
		alarmName="XFP Low Supply Voltage Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.23";
		alarmName="XFP Absence";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		//OTU & ODU Line
		traffic="OTU-ODU";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.81";
		alarmName="OTU Loss of Signal Payload";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.82";
		alarmName="OTU Loss of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.83";
		alarmName="OTU Out of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		/*alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.34";
		alarmName="OTU Loss of Multi Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.35";
		alarmName="OTU Out of Multi Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.36";
		alarmName="OTU Signal Fail";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.37";
		alarmName="OTU Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.38";
		alarmName="OTU Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.39";
		alarmName="OTU Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.40";
		alarmName="OTU Trace Identifier Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.41";
		alarmName="OTU Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.42";
		alarmName="OTU Backward Defect Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.51";
		alarmName="ODU Signal Fail";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.52";
		alarmName="ODU Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.53";
		alarmName="ODU Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.54";
		alarmName="ODU TCM1 Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.55";
		alarmName="ODU TCM2 Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.56";
		alarmName="ODU TCM3 Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.57";
		alarmName="ODU TCM4 Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.58";
		alarmName="ODU TCM5 Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.59";
		alarmName="ODU TCM6 Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.60";
		alarmName="ODU Trace Identifier Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.61";
		alarmName="ODU Locked Defect";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.62";
		alarmName="ODU Open Connection Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="25";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.63";
		alarmName="ODU Backward Defect Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="26";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.64";
		alarmName="ODU TCM1 Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="27";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.65";
		alarmName="ODU TCM2 Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="28";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.66";
		alarmName="ODU TCM3 Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="29";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.67";
		alarmName="ODU TCM4 Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="30";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.68";
		alarmName="ODU TCM5 Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="31";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.69";
		alarmName="ODU TCM6 Backward Incoming Alignment Error";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="32";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.70";
		alarmName="OPU Payload Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="33";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.71";
		alarmName="Och Loss of Payload";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		//SDH
		/*traffic="SDH";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.81";
		alarmName="SDH Loss of Signal Payload";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.82";
		alarmName="SDH Out of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.83";
		alarmName="SDH Loss of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.84";
		alarmName="SDH RS Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.85";
		alarmName="SDH RS Trace Identifier Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.86";
		alarmName="SDH AU Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.87";
		alarmName="SDH AU Loss of Pointer";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.88";
		alarmName="SDH MS Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.89";
		alarmName="SDH MS Remote Error Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.90";
		alarmName="SDH MS Remote Defect Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.91";
		alarmName="SDH MS Remote Failure Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.92";
		alarmName="SDH MS B2 Signal Fail";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.93";
		alarmName="SDH MS B2 Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		/*alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.94";
		alarmName="SDH Loss of Sequence Synchronisation";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.95";
		alarmName="SDH Higher Order Path Payload Label Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.96";
		alarmName="SDH Higher Order Path Unequipped";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});*/
		
		
		//100G Ethernet
		traffic="100GEthernet";
				
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.141";
		alarmName="Loss of Signal Payload";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.142";
		alarmName="Loss of Lock";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
			
								
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.143";
		alarmName="High BER";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.144";
		alarmName="Local Fault";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
				
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1.145";
		alarmName="Remote Fault";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
