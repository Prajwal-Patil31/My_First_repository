package com.utl.trap.receiver.jack;

public class JackCardNames {	
	private static String jackCardName;
	private static String cardName;
	
	public static String getCardName(String jackCardName) {
		jackCardName=jackCardName.toUpperCase();
		if(jackCardName.equals("BA_EDFA")){
	    	cardName = "OBA";
		}
		else if(jackCardName.equals("PA_EDFA")){
	    	cardName = "OPA";
		}
		else if(jackCardName.equals("ILA_EDFA")){
	    	cardName = "OLA";
		}
		else if(jackCardName.equals("OMMP81")){
	    	cardName = "10GOMMP81";
		}
		else if(jackCardName.equals("OMMP82")){
	    	cardName = "10GOMMP82";
		}
		else if(jackCardName.equals("OMTP11")){
	    	cardName = "10GOMTP11";
		}
		else if(jackCardName.equals("OMTP11T")){
	    	cardName = "10GOMTP11T";
		}
		else if(jackCardName.equals("OMTP12")){
	    	cardName = "10GOMTP12";
		}
		else if(jackCardName.equals("OMMP81_PLUS")){
	    	cardName = "10GOMMP81PLUS";
		}
		else if(jackCardName.equals("OMMP82_PLUS")){
	    	cardName = "10GOMMP82PLUS";
		}
		else if(jackCardName.equals("OMTP11_PLUS")){
	    	cardName = "10GOMTP11PLUS";
		}
		else if(jackCardName.equals("OMTP100_11_PLUS")){
	    	cardName = "100GOMTP11PLUS";
		}
		else if(jackCardName.equals("OMMP101")){
	    	cardName = "OMMP100";
		}
		else if(jackCardName.equals("OMMP4041_PLUS")){
	    	cardName = "40GOMMP41PLUS";
		}
		else if(jackCardName.equals("OMTP11T_PLUS")){
	    	cardName = "10GOMTP11TPLUS";
		}
		else if(jackCardName.equals("OMTP12_PLUS")){
	    	cardName = "10GOMTP12PLUS";
		}
		else if(jackCardName.equals("BA_EDFA_PLUS")){
	    	cardName = "OBAPLUS";
		}
		else if(jackCardName.equals("PA_EDFA_PLUS")){
	    	cardName = "OPAPLUS";
		}
		else if(jackCardName.equals("ILA_EDFA_PLUS")){
	    	cardName = "OLAPLUS";
		}		
		else if(jackCardName.equals("MUX_PLUS")){
	    	cardName = "MUXPLUS";
		}
		else if(jackCardName.equals("DEMUX_PLUS")){
	    	cardName = "DEMUXPLUS";
		}
		else if(jackCardName.equals("SCU_PLUS")){
	    	cardName = "SCUPLUS";
		}
		else if(jackCardName.equals("BMU_PLUS")){
	    	cardName = "BMUPLUS";
		}else if(jackCardName.equals("MANTIS_PLUS")){
	    	cardName = "MANTISPLUS";
		}else{
			cardName=jackCardName;
		}
		return cardName;
	}
	
	
}
