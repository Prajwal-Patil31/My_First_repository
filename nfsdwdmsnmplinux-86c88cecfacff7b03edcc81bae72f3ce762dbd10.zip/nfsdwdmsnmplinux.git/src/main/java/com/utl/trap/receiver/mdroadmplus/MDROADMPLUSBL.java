package com.utl.trap.receiver.mdroadmplus;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class MDROADMPLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfMantisPlus(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber,byte directionNumber, byte portType, byte channelNumber, SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,191,1,1,1,39,nodeNumber,rackNumber,subrackNumber,slotNumber,directionNumber, portType,channelNumber}));
		System.out.println(OID);
		String cardName = "mantisplus";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getMDROADPlusCardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getMDROADPlusCardName(int directionNumber){
		String cardName = "mantisplus";
		switch (directionNumber) {
		case 1:
			cardName="MD-ROADMPLUS-DIR-1";
			break;
		case 2:
			cardName="MD-ROADMPLUS-DIR-2";
			break;
		case 3:
			cardName="MD-ROADMPLUS-DIR-3";
			break;
		case 4:
			cardName="MD-ROADMPLUS-DIR-4";
			break;
		}
		return cardName;
	}
}
