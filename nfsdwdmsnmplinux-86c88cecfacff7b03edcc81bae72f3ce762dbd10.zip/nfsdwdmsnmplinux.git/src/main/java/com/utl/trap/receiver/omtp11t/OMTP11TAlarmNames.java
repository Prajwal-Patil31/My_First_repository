package com.utl.trap.receiver.omtp11t;

import java.util.HashMap;
import java.util.Map;

public class OMTP11TAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	private static String traffic;
	static{
		//OPTICAL
		traffic="OPTICAL";
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.2";
		alarmName="High Input Optical Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.3";
		alarmName="Low Input Optical Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.4";
		alarmName="High Input Optical Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.5";
		alarmName="Low Input Optical Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.6";
		alarmName="Input Optical Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.7";
		alarmName="High Output Optical Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.8";
		alarmName="Low Output Optical Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.9";
		alarmName="Output Optical Power";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//SDH
		traffic="SDH";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.10";
		alarmName="Lose Of Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.11";
		alarmName="Lose Of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.12";
		alarmName="Out Of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.13";
		alarmName="Loss Of Pointer";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.14";
		alarmName="MS Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.15";
		alarmName="MS Remote Defect Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.16";
		alarmName="B2 Signal Fail";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.17";
		alarmName="B2 Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//WAN
		traffic="WAN";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.18";
		alarmName="Lose Of Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.19";
		alarmName="Lose Of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.20";
		alarmName="Out Of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.21";
		alarmName="Loss Of Pointer";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.22";
		alarmName="MS Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.23";
		alarmName="MS Remote Defect Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.24";
		alarmName="B2 Signal Fail";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.25";
		alarmName="B2 Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//OTU
		traffic="OTU";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.26";
		alarmName="Lose Of Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.27";
		alarmName="Out Of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.28";
		alarmName="Out Of Multi Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.29";
		alarmName="OTU Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.30";
		alarmName="ODU Signal Degrade";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.31";
		alarmName="Lose Of Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.32";
		alarmName="Lose Of Multi Frame";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.33";
		alarmName="ODU Open Connection Indication";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.34";
		alarmName="OTU Trace Identifier Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.35";
		alarmName="ODU Trace Identifier Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.36";
		alarmName="OTU Backward Defect Indicator";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.37";
		alarmName="ODU Backward Defect Indicator";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.38";
		alarmName="ODU Alarm Indication Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.39";
		alarmName="ODU Locked Defect";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.40";
		alarmName="Payload Mismatch";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//LAN
		traffic="LAN";
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.41";
		alarmName="Lose Of Signal";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.42";
		alarmName="Lose Of Signal Sync";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.43";
		alarmName="High Bit Errors";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.44";
		alarmName="Local Fault";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.45";
		alarmName="Remote Fault";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		//OPTICAL Continuation
		traffic="OPTICAL";
				
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.46";
		alarmName="High Output Optical Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.47";
		alarmName="Low Output Optical Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.48";
		alarmName="High Module Optical Temperature";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.49";
		alarmName="High Module Optical Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.50";
		alarmName="Low Module Optical Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.51";
		alarmName="Low Module Optical Temperature";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.52";
		alarmName="High Bias Optical Current";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.53";
		alarmName="High Bias Optical Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.54";
		alarmName="Low Bias Optical Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.7.2.2.55";
		alarmName="Low Bias Optical Current";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide,traffic});
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
