package com.utl.trap.receiver.omtp11t;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;

import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.util.GetDetailsFromPropertiesFile;

public class OMTP11TContinuousThread extends Thread{
	
	private Short THREAD_POOL_SIZE;
	static Logger l = Logger.getLogger(OMTP11TContinuousThread.class);
	private ThreadPoolExecutor threadPool=null;
	public OMTP11TContinuousThread(){
		super("OMTP11T Continuous Thread");
		try {
			THREAD_POOL_SIZE=Short.parseShort(GetDetailsFromPropertiesFile.getValue("concurrent.process.trap"));
		} catch (Exception e) {
			l.info("Unable to load info.properties "+e.getMessage());
			e.printStackTrace();
		} 
		threadPool=(ThreadPoolExecutor) Executors.newFixedThreadPool(THREAD_POOL_SIZE);
	}
	@Override
	public void run() {
		while(true){
			try{
				List<ReceivedTrapDetails> trapReceivedDetailsBeanList=OMTP11TDAO.getReceivedTrapDetailsFromDB();
				Collection<Future<?>> futures = new LinkedList<Future<?>>();
				for(ReceivedTrapDetails trapReceivedDetailsBean:trapReceivedDetailsBeanList){
					OMTP11TRunnable runnable=new OMTP11TRunnable(trapReceivedDetailsBean);
					futures.add(threadPool.submit(runnable));
				}
				for (Future<?> future:futures) {
				    future.get();
				}
				try {
					if (trapReceivedDetailsBeanList.size()==0) {
						Thread.sleep(1000);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}catch(Exception e){
				l.info(e);
			}
		}
	}
}
