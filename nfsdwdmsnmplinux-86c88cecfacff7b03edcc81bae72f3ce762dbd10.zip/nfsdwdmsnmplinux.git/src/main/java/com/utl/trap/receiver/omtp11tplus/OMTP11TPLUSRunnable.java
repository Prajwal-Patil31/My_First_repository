package com.utl.trap.receiver.omtp11tplus;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.omtp11plus.OMTP11PLUSDAO;
import com.utl.util.CommonDAO;


public class OMTP11TPLUSRunnable implements Runnable{
	
	private ReceivedTrapDetails trapDetails;
	//static Logger l = Logger.getLogger(OMTP11TPLUSRunnable.class);
	public OMTP11TPLUSRunnable(ReceivedTrapDetails trapDetails) {
		super();
		this.trapDetails = trapDetails;
	}

	@Override
	public void run() {
		System.out.println(trapDetails);
		
		Connection conn=null;
		try {
			byte alarmStatus    = trapDetails.getAlarmStatus();
			int portMasterID    = trapDetails.getPortMasterID();
			String clientOrLine = trapDetails.getPortClientOrLine();
			
			String oID = trapDetails.getOID();
			String[] alarmMiscData = OMTP11TPLUSAlarmNames.getDetails(oID);
			
			String alarmIndex = alarmMiscData[0];
			String alarmName  = alarmMiscData[1];
			String hide       = alarmMiscData[2];
			String traffic    = alarmMiscData[3];
			
			if ("false".equals(hide)) {
				
				byte prevAlarmStatus;
				
				conn=DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
				///code to get portMasterID
				
				
				
				if("client".equals(clientOrLine)){
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP11TPLUSDAO.updateAlarmClientOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP11TPLUSDAO.updateAlarmClientTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}else{
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMTP11TPLUSDAO.updateAlarmLineOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMTP11TPLUSDAO.updateAlarmLineTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}
				if(alarmStatus!=prevAlarmStatus){
					String alarmSeverity = OMTP11TPLUSDAO.getAlarmSeverity(portMasterID, alarmIndex, clientOrLine, traffic, conn);
					OMTP11TPLUSDAO.updateAlarmTrans(portMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), traffic, clientOrLine, conn);
				
//update_global_alarm
					
					LinkedHashMap<Short, Byte> allAlarmPresentFromDb =OMTP11TPLUSDAO.getAllAlarmForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					LinkedHashMap<Short, String> allAlarmSeverity =OMTP11TPLUSDAO.getAllAlarmSeverityForGlobalAlarm(Integer.parseInt(slotDetails.get(1)), conn);
					byte status = CommonDAO.updateInToDwdmLineCardsGlobalAlarmStatusAlarms(Integer.parseInt(slotDetails.get(1)), allAlarmSeverity, allAlarmPresentFromDb, conn);
				
					
					/*CallableStatement omtp11tplusGlobalAlarmCallable = null;
					omtp11tplusGlobalAlarmCallable = conn.prepareCall("CALL update_global_alarm_plus(?,?)");
					omtp11tplusGlobalAlarmCallable.setInt(1,Integer.parseInt(slotDetails.get(1)));
					omtp11tplusGlobalAlarmCallable.setString(2,trapDetails.getCardName());
					omtp11tplusGlobalAlarmCallable.executeQuery();*/
					System.out.println("OMTP11tPLUS Global Alarm Process Completed......");
				}
				
			}
			
		} catch (Exception e) {
			//l.info(e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
