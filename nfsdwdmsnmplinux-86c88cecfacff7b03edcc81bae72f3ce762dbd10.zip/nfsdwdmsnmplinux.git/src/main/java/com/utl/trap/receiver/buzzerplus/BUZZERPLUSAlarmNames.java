package com.utl.trap.receiver.buzzerplus;

import java.util.HashMap;
import java.util.Map;

public class BUZZERPLUSAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		
		alarmIndex="99";
		OID="1.3.6.1.4.1.18036.1.1.1.61.2.1.1.1.1";
		alarmName="Buzzer Card Presence Absence Notification Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});	
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
