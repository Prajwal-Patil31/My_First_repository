package com.utl.trap.receiver.oba;

import java.util.HashMap;
import java.util.Map;

public class OBAAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		
		/*IOP Failure
		OOP Failure
		IOP Out of Range
		OOP Out of Range
		Degraded IOP
		Degraded OOP
		Low IOP*/
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.1";
		alarmName="Optical Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.6";
		alarmName="Optical Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.31";
		alarmName="Input Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.32";
		alarmName="Output Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.5";
		alarmName="Optical Low Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.10";
		alarmName="Optical Low Output Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.3";
		alarmName="Optical Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		/*alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.1";
		alarmName="Optical Input Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.2";
		alarmName="Optical High Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.3";
		alarmName="Optical Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.4";
		alarmName="Optical High Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.5";
		alarmName="Optical Low Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.6";
		alarmName="Optical Output Power Failure Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.7";
		alarmName="Optical High Output Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.8";
		alarmName="Optical Low Output Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.9";
		alarmName="Optical High Output Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.10";
		alarmName="Optical Low Output Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.11";
		alarmName="Module High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.12";
		alarmName="Module Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.13";
		alarmName="Module High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.14";
		alarmName="Module Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.15";
		alarmName="Pump High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.16";
		alarmName="Pump Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.17";
		alarmName="Pump High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.18";
		alarmName="Pump Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.19";
		alarmName="Pump High Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.20";
		alarmName="Pump Low Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.21";
		alarmName="Pump High Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.22";
		alarmName="Pump Low Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.23";
		alarmName="Pump High Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.24";
		alarmName="Pump Low Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="25";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.25";
		alarmName="Pump High Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="26";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.26";
		alarmName="Pump Low Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="27";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.27";
		alarmName="Variable Optical Attenuator High Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="28";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.28";
		alarmName="Variable Optical Attenuator Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="29";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.29";
		alarmName="Variable Optical Attenuator High Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="30";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.30";
		alarmName="Variable Optical Attenuator Low Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="31";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.31";
		alarmName="Input Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="32";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.32";
		alarmName="Output Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="33";
		OID="1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1.33";
		alarmName="Pump Bias Current Alarm ";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});*/
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
