package com.utl.trap.receiver.ommp81;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.omtp12.OMTP12DAO;
import com.utl.util.CommonDAO;

public class OMMP81Runnable implements Runnable{
	
	private ReceivedTrapDetails trapDetails;
	static Logger l = Logger.getLogger(OMMP81Runnable.class);
	public OMMP81Runnable(ReceivedTrapDetails trapDetails) {
		super();
		this.trapDetails = trapDetails;
	}

	@Override
	public void run() {
		l.info(trapDetails);
		
		Connection conn=null;
		try {
			byte alarmStatus = trapDetails.getAlarmStatus();
			int portNo=trapDetails.getPort();
			int portMasterID = trapDetails.getPortMasterID();
			String clientOrLine = trapDetails.getPortClientOrLine();
			int slotMasterID = trapDetails.getSlotMasterID();
			
			String oID = trapDetails.getOID();
			String[] alarmMiscData = OMMP81AlarmNames.getDetails(oID);
			
			String alarmIndex = alarmMiscData[0];
			String alarmName  = alarmMiscData[1];
			String hide       = alarmMiscData[2];
			String traffic    = alarmMiscData[3];
			
			if ("false".equals(hide)) {
				
				byte prevAlarmStatus;
				
				conn=DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
				/*portMasterID=CommonDAO.getPortMasterID(Integer.parseInt(slotDetails.get(1)), portNo, conn);
				///code to get portMasterID
				if(portNo>8)
				{
					clientOrLine="line";	
				}
				else
				{
					clientOrLine="client";
				}*/
				if("client".equals(clientOrLine)){
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMMP81DAO.updateAlarmClientOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMMP81DAO.updateAlarmClientTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}else{
					if("OPTICAL".equals(traffic)){
						prevAlarmStatus = OMMP81DAO.updateAlarmLineOptical(portMasterID, alarmIndex, alarmStatus, conn);
					}else{
						prevAlarmStatus = OMMP81DAO.updateAlarmLineTraffic(portMasterID, alarmIndex, alarmStatus, conn);
					}
				}
				if(alarmStatus!=prevAlarmStatus){
					String alarmSeverity = OMMP81DAO.getAlarmSeverity(portMasterID, alarmIndex, clientOrLine, traffic, conn);
					System.out.println("portMasterID::"+portMasterID);
					OMMP81DAO.updateAlarmTrans(portMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), traffic, clientOrLine, conn);
					
					/*LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OMMP81DAO.getAllAlarmForGlobalAlarm(portMasterID, conn);
					LinkedHashMap<Byte, String> allAlarmSeverity =OMMP81DAO.getAllAlarmSeverityForGlobalAlarm(portMasterID, conn);
					byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);*/
					CallableStatement ommp81GlobalAlarmCallable = null;
					ommp81GlobalAlarmCallable = conn.prepareCall("CALL update_global_alarm(?,?)");
					ommp81GlobalAlarmCallable.setInt(1,Integer.parseInt(slotDetails.get(1)));
					ommp81GlobalAlarmCallable.setString(2,trapDetails.getCardName());
					ommp81GlobalAlarmCallable.executeQuery();					
					l.info("OMMP81 Global Alarm Process Completed......");
				}
				
			}
			
		} catch (Exception e) {
			l.info(e);
		}finally{
			if(conn!=null){
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}


