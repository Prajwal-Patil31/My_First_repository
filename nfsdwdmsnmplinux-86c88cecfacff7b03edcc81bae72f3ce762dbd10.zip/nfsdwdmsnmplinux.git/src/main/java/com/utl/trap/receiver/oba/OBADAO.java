package com.utl.trap.receiver.oba;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.LinkedHashMap;

public class OBADAO {
	public static byte updateAlarm(int slotMasterID,String alarmIndex,byte alarmStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null,psForInsert=null,psForUpdate=null;
		ResultSet rsForSelect=null;
		byte prevAlarmStatus=0;
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_oba_alarm where dwdm_slot_master_id=?");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect=psForSelect.executeQuery();

			if(rsForSelect.next()){
				prevAlarmStatus=rsForSelect.getByte(1);
				if (prevAlarmStatus!=alarmStatus) {
					psForUpdate = conn.prepareStatement("UPDATE dwdm_oba_alarm SET alarm"+alarmIndex+"=? where dwdm_slot_master_id=?");
					psForUpdate.setByte(1, alarmStatus);
					psForUpdate.setInt(2, slotMasterID);
					psForUpdate.executeUpdate();
				}
			}else{
				psForInsert=conn.prepareStatement("INSERT INTO dwdm_oba_alarm(dwdm_slot_master_id,alarm"+alarmIndex+")VALUES(?,?)");
				psForInsert.setInt(1, slotMasterID);
				psForInsert.setByte(2, alarmStatus);
				psForInsert.executeUpdate();
			}
		}catch (Exception e) {
			throw e;
		}finally{
			if(psForUpdate!=null){
				psForUpdate.close();
			}
			if(psForInsert!=null){
				psForInsert.close();
			}
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return prevAlarmStatus;
	}
	
	public static String getAlarmSeverity(int slotMasterID,String alarmIndex, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String alarmSeverity="Critical";
		try {
			psForSelect=conn.prepareStatement("SELECT alarm"+alarmIndex+" FROM dwdm_oba_alarm_severity  where dwdm_slot_master_id=?");
			psForSelect.setInt(1, slotMasterID);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				alarmSeverity=rsForSelect.getString(1);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			if(rsForSelect!=null){
				rsForSelect.close();
			}
			if(psForSelect!=null){
				psForSelect.close();
			}
		}
		return alarmSeverity;
	}
	
	public static LinkedHashMap<Byte, String> getAllAlarmSeverityForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Byte, String> alarmSeverity=new LinkedHashMap<Byte, String>();
		PreparedStatement psSelect=null;
		ResultSet rsSelect=null;
		try {
			
			psSelect=conn.prepareStatement("SELECT * FROM dwdm_oba_alarm_severity where dwdm_slot_master_id=?");
			psSelect.setLong(1, slotMasterID);
			rsSelect=psSelect.executeQuery();
			if (rsSelect.next()) {
				for (byte i = 1; i <= 35; i++) {
					alarmSeverity.put(i, rsSelect.getString("alarm" + i));
				}
			}else{
				for (byte i = 1; i <= 35; i++) {
					alarmSeverity.put(i, "Critical");
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rsSelect!=null){
					rsSelect.close();
				}
				if(psSelect!=null){
					psSelect.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return alarmSeverity;
	}
	
	public static LinkedHashMap<Byte, Byte> getAllAlarmForGlobalAlarm(long slotMasterID,Connection conn) throws Exception{
		LinkedHashMap<Byte, Byte> allAlarmPresentDb=new LinkedHashMap<Byte, Byte>();
		PreparedStatement psSelect=null;
		ResultSet rsSelect=null;
		try {
			
			psSelect=conn.prepareStatement("SELECT * FROM dwdm_oba_alarm where dwdm_slot_master_id=?");
			psSelect.setLong(1, slotMasterID);
			rsSelect=psSelect.executeQuery();
			if (rsSelect.next()) {
				for (byte i = 1; i <= 35; i++) {
					allAlarmPresentDb.put(i, rsSelect.getByte("alarm" + i));
				}
			}
		} catch (Exception e) {
			
			throw e;
		}finally{
			try {
				if(rsSelect!=null){
					rsSelect.close();
				}
				if(psSelect!=null){
					psSelect.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return allAlarmPresentDb;
	}
	
	public static byte  updateAlarmTrans(int slotMasterID,byte alarmStatus,String alarmName,String alarmSeverity,Timestamp alarmGeneratedTime,Connection conn) throws Exception{
		byte result = 0;
		CallableStatement cstmtForUpdateAlarms = null;
		try {
			cstmtForUpdateAlarms = conn.prepareCall("CALL dwdm_oba_alarm_trans_update(?,?,?,?,?)");
			cstmtForUpdateAlarms.setInt(1, slotMasterID);
			cstmtForUpdateAlarms.setByte(2, alarmStatus);
			cstmtForUpdateAlarms.setString(3, alarmName);
			cstmtForUpdateAlarms.setString(4, alarmSeverity);
			cstmtForUpdateAlarms.setTimestamp(5, alarmGeneratedTime);
			result=(byte) cstmtForUpdateAlarms.executeUpdate();
		} catch (Exception e) {
			throw e;
		}finally{
			if(cstmtForUpdateAlarms!=null){
				cstmtForUpdateAlarms.close();
			}
		}
		return result;
	}
}
