package com.utl.trap.receiver;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Vector;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import javax.swing.JTextArea;
//import org.apache.log4j.Logger;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.PDU;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.test.MultiThreadedTrapReceiver;
import com.ut.connection.pool.DataSource;
import com.utl.snmp4j.SNMPVersionDetails;
import com.utl.trap.receiver.fan.FANContinuousThread;
import com.utl.trap.receiver.fanplus.FANPLUSContinuousThread;
import com.utl.trap.receiver.fanplusnew.FANPLUSNEWContinuousThread;
import com.utl.trap.receiver.jack.JackCardNames;
import com.utl.trap.receiver.jack.JackContinuousThread;
import com.utl.trap.receiver.mdroadm.MDROADMBL;
import com.utl.trap.receiver.mdroadm.MDROADMContinuousThread;
import com.utl.trap.receiver.mdroadmplus.MDROADMPLUSBL;
import com.utl.trap.receiver.mdroadmplus.MDROADMPLUSContinuousThread;
import com.utl.trap.receiver.mux.MUXPLUSBL;
import com.utl.trap.receiver.oba.OBABL;
import com.utl.trap.receiver.oba.OBAContinuousThread;
import com.utl.trap.receiver.obaplus.OBAPLUSBL;
import com.utl.trap.receiver.obaplus.OBAPLUSContinuousThread;
import com.utl.trap.receiver.ola.OLABL;
import com.utl.trap.receiver.ola.OLAContinuousThread;
import com.utl.trap.receiver.olaplus.OLAPLUSBL;
import com.utl.trap.receiver.olaplus.OLAPLUSContinuousThread;
import com.utl.trap.receiver.ommp100.OMMP100ContinuousThread;
import com.utl.trap.receiver.ommp100.OMMP100DAO;
import com.utl.trap.receiver.ommp200.OMMP200ContinuousThread;
import com.utl.trap.receiver.ommp40.OMMP40ContinuousThread;
import com.utl.trap.receiver.ommp40.OMMP40DAO;
import com.utl.trap.receiver.ommp400.OMMP400ContinuousThread;
import com.utl.trap.receiver.ommp400.OMMP400DAO;
import com.utl.trap.receiver.ommp81.OMMP81ContinuousThread;
import com.utl.trap.receiver.ommp81.OMMP81DAO;
import com.utl.trap.receiver.ommp81plus.OMMP81PLUSContinuousThread;
import com.utl.trap.receiver.ommp81plus.OMMP81PLUSDAO;
import com.utl.trap.receiver.ommp82.OMMP82ContinuousThread;
import com.utl.trap.receiver.ommp82.OMMP82DAO;
import com.utl.trap.receiver.ommp82plus.OMMP82PLUSContinuousThread;
import com.utl.trap.receiver.ommp82plus.OMMP82PLUSDAO;
import com.utl.trap.receiver.omtp100.OMTP100ContinuousThread;
import com.utl.trap.receiver.omtp100.OMTP100DAO;
import com.utl.trap.receiver.omtp11.OMTP11ContinuousThread;
import com.utl.trap.receiver.omtp11.OMTP11DAO;
import com.utl.trap.receiver.omtp11plus.OMTP11PLUSContinuousThread;
import com.utl.trap.receiver.omtp11plus.OMTP11PLUSDAO;
import com.utl.trap.receiver.omtp11tplus.OMTP11TPLUSContinuousThread;
import com.utl.trap.receiver.omtp11tplus.OMTP11TPLUSDAO;
import com.utl.trap.receiver.omtp12.OMTP12ContinuousThread;
import com.utl.trap.receiver.omtp12.OMTP12DAO;
import com.utl.trap.receiver.omtp12plus.OMTP12PLUSContinuousThread;
import com.utl.trap.receiver.omtp12plus.OMTP12PLUSDAO;
import com.utl.trap.receiver.opa.OPABL;
import com.utl.trap.receiver.opa.OPAContinuousThread;
import com.utl.trap.receiver.opaplus.OPAPLUSBL;
import com.utl.trap.receiver.opaplus.OPAPLUSContinuousThread;
import com.utl.trap.receiver.osc.OSCContinuousThread;
import com.utl.trap.receiver.psu.PSUContinuousThread;
import com.utl.trap.receiver.psuplus.PSUPLUSContinuousThread;
import com.utl.trap.receiver.scc.SCCContinuousThread;
import com.utl.trap.receiver.software.upgrade.SoftwareUpgradeContinuousThread;
import com.utl.trap.receiver.bmu.BMUContinuousThread;
import com.utl.trap.receiver.buzzerplus.BUZZERPLUSContinuousThread;
import com.utl.trap.receiver.demux.DEMUXPLUSBL;
import com.utl.util.CurrentDate;

public class StoreTrapInToDB extends Thread{
	
	//static Logger l = Logger.getLogger(StoreTrapInToDB.class);
	BlockingQueue<CommandResponderEvent> receivedTrap;
	//BlockingQueue<ReceivedTrapDetails> receivedOBATrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedOBAPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	//BlockingQueue<ReceivedTrapDetails> receivedOPATrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedOPAPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	//BlockingQueue<ReceivedTrapDetails> receivedOLATrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedOLAPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	//BlockingQueue<ReceivedTrapDetails> receivedMDROADMTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedMDROADMPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	//BlockingQueue<ReceivedTrapDetails> receivedPSUTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedPSUPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();	
	BlockingQueue<ReceivedTrapDetails> receivedBUZZERPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();	
	//BlockingQueue<ReceivedTrapDetails> receivedFANTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedFANPLUSTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedSCCTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedOSCTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetails> receivedJackTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	BlockingQueue<ReceivedTrapDetailsForBMU> receivedBMUTrap=new LinkedBlockingQueue<ReceivedTrapDetailsForBMU>();	
	BlockingQueue<ReceivedTrapDetailsForSWUpgrade> receivedSoftwareUpgradeTrap=new LinkedBlockingQueue<ReceivedTrapDetailsForSWUpgrade>();
	//BlockingQueue<ReceivedTrapDetails> receivedFANPLUSNEWTrap=new LinkedBlockingQueue<ReceivedTrapDetails>();
	
	//private long displayCounter = 1;
	//public JTextArea messagesArea = MultiThreadedTrapReceiver.multiThreadedTrapReceiverObj.messagesArea;	
	public StoreTrapInToDB(BlockingQueue<CommandResponderEvent> receivedTrap) {
		super("Store Trap In To DB");
		this.receivedTrap = receivedTrap;
		//POC comment ...thread problems ..collecting from inserted tables
		
		/*new OMTP11ContinuousThread().start();
		new OMTP12ContinuousThread().start();
		new OMMP81ContinuousThread().start();
		new OMMP82ContinuousThread().start();*/
		
		
		new OMTP11PLUSContinuousThread().start();
		//new OMTP100ContinuousThread().start();
		new OMTP11TPLUSContinuousThread().start();	
		new OMTP12PLUSContinuousThread().start();	
		new OMMP81PLUSContinuousThread().start();		
		//new OMMP40ContinuousThread().start();		
		new OMMP82PLUSContinuousThread().start();
		
		new OMMP100ContinuousThread().start();
		//new OMTP100ContinuousThread().start();
		//new OMMP200ContinuousThread().start();
		//new OMMP400ContinuousThread().start();
		
		
		
	/*	new OBAContinuousThread(receivedOBATrap).start();
		new OPAContinuousThread(receivedOPATrap).start();
		new OLAContinuousThread(receivedOLATrap).start();*/
		
		new OBAPLUSContinuousThread(receivedOBAPLUSTrap).start();		
		new OPAPLUSContinuousThread(receivedOPAPLUSTrap).start();		
		new OLAPLUSContinuousThread(receivedOLAPLUSTrap).start();
	//	new MDROADMContinuousThread(receivedMDROADMTrap).start();
		new MDROADMPLUSContinuousThread(receivedMDROADMPLUSTrap).start();
		//new PSUContinuousThread(receivedPSUTrap).start();
		new PSUPLUSContinuousThread(receivedPSUPLUSTrap).start();
		new BUZZERPLUSContinuousThread(receivedBUZZERPLUSTrap).start();
	//	new FANContinuousThread(receivedFANTrap).start();
		new FANPLUSContinuousThread(receivedFANPLUSTrap).start();
		//new FANPLUSNEWContinuousThread(receivedFANPLUSNEWTrap).start();
		new SCCContinuousThread(receivedSCCTrap).start();
		new OSCContinuousThread(receivedOSCTrap).start();
		new JackContinuousThread(receivedJackTrap).start();
		new BMUContinuousThread(receivedBMUTrap).start();
		new SoftwareUpgradeContinuousThread(receivedSoftwareUpgradeTrap).start();
	}

	@Override
	public void run() {
		while(true){
			try {
				
			/*	displayCounter++;
				 if (displayCounter > 100)
				 	 {
				 		 messagesArea.setText("");
				 		 displayCounter = 1;
				 	 }*/
				 
				ReceivedTrapDetails trapDetails=null;
				ReceivedTrapDetailsForBMU trapDetailsforbmu=null;
				ReceivedTrapDetailsForSWUpgrade trapDetailsforswupgrade = null;
				CommandResponderEvent responderEvent = receivedTrap.take();
			//	Timestamp dateAndTime = CurrentDate.getCurrentDate();
				Timestamp dateAndTime = null;
				String sendingAddress = responderEvent.getPeerAddress().toString();
				String nodeIP = sendingAddress.split("/")[0];
				PDU trapPDU = responderEvent.getPDU();
				Vector<? extends VariableBinding> trapVariableBindings = trapPDU.getVariableBindings();
				for(VariableBinding eachTrapVB:trapVariableBindings){
					OID trapHOSTDATEOID = eachTrapVB.getOid();
					String trapOIDString = trapHOSTDATEOID.toString();
					String alarmHostDateTime = null;
					if(trapOIDString.startsWith("1.3.6.1.2.1.25.1.2.0"))
					{
						alarmHostDateTime = eachTrapVB.getVariable().toString();
						String s1= alarmHostDateTime;
					//	String s1="07:e0:0c:1e:0a:06:34:00:2b:05:1e"; //30-12-2016 10:06:52
				        s1 = s1.replaceAll(":", "");
				        String year = s1.substring(0, 4);
				        String month = s1.substring(4, 6);
				        int iMonth = Integer.parseInt(month, 16) - 1;
				        String day = s1.substring(6, 8);
				        String hour = s1.substring(8, 10);
				        String minute = s1.substring(10, 12);
				        String second = s1.substring(12, 14);
				        Calendar cal = Calendar.getInstance();
				        cal.set(Calendar.YEAR, Integer.parseInt(year, 16));
				        cal.set(Calendar.MONTH, iMonth);
				        cal.set(Calendar.DAY_OF_MONTH, Integer.parseInt(day, 16));
				        cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hour, 16));
				        cal.set(Calendar.MINUTE, Integer.parseInt(minute, 16));
				        cal.set(Calendar.SECOND, Integer.parseInt(second, 16));
				    //    System.out.println(cal.getTime());
				        Date date =  cal.getTime();        
				        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");        
				        System.out.println(dateFormat.format(date));
				        dateAndTime = new java.sql.Timestamp(date.getTime());
					}
				}
				
				for(VariableBinding eachTrapVB:trapVariableBindings){
					OID trapOID = eachTrapVB.getOid();
					String trapOIDString = trapOID.toString();						
							
					if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.7.2.1.1.1")){
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "10GOMTP11";
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						OMTP11DAO.insertReceivedTrapDetails(trapDetails);
						System.out.println(trapDetails.toString()+"\n");
						//messagesArea.append(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.71.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "10GOMTP11PLUS";
						System.out.println("%%%%%%%%%%%%%%%%%%%%%% 10GOMTP11 PLUS alarm trap %%%%%%%%%%%%%%%");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						OMTP11PLUSDAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}/*else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.123.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "100GOMTP11PLUS";
						System.out.println("%%%%%%%%%%%%%%%%%%%%%% 100GOMTP11PLUS alarm trap %%%%%%%%%%%%%%%");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						OMTP100DAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}*/else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.72.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "10GOMTP11TPLUS";
						System.out.println("%%%%%%%%%%%%%%%%%%%%%% 10GOMTP11 T PLUS alarm trap %%%%%%%%%%%%%%%");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMTP11TPLUSDAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}	else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.13.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						
						String cardName = "10GOMTP12";
						System.out.println("%%%%%%%%%%%%%%%%%%%%%% 10GOMTP12 alarm trap %%%%%%%%%%%%%%%");
						
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						OMTP12DAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.73.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						
						String cardName = "10GOMTP12PLUS";
						System.out.println("%%%%%%%%%%%%%%%%%%%%%% 10GOMTP12PLUS alarm trap %%%%%%%%%%%%%%%");
						
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println("10GOMTP12PLUS trapDetails "+trapDetails);
						OMTP12PLUSDAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.86.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "10GOMMP81PLUS";
						System.out.println("####################### 10GOMMP81PLUS alarm trap ##################");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMMP81PLUSDAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}/*else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.86.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "40GOMMP41PLUS";
						System.out.println("####################### 40GOMMP41PLUS alarm trap ##################");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMMP40DAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}*/
					
					else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.14.3.1.1.1")){
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "10GOMMP82";
						System.out.println("####################### 10GOMMP82 alarm trap ##################");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMMP82DAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.87.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "10GOMMP82PLUS";
						System.out.println("####################### 10GOMMP82PLUS alarm trap ##################");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMMP82PLUSDAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.88.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OMMP100";
						System.out.println("####################### OMMP100 alarm trap ##################");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMMP100DAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}/*else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.90.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OMMP400";
						System.out.println("####################### OMMP400 alarm trap ##################");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						System.out.println(trapDetails);
						OMMP400DAO.insertReceivedTrapDetails(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}*/else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.3.3.1.1.1")){
					//	byte port = (byte) trapOID.removeLast();
						byte port = 0;//no port for OBA
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OBA";
						System.out.println("|-|-|-|-|-|-|-|-||||||| OBA alarm trap |||||||||-|-|-|-|-|-|-|");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
				//		receivedOBATrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.131.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
					//	byte port = 0;//no port for OBAPLUS
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OBAPLUS";
						System.out.println("|-|-|-|-|-|-|-|-||||||| OBAPLUS alarm trap |||||||||-|-|-|-|-|-|-|");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						receivedOBAPLUSTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.4.3.1.1.1")){
					//	byte port = (byte) trapOID.removeLast();
						byte port = 0;//no port for OPA
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OPA";
						System.out.println("|o|o|o|o|o|o|o|||||||| OPA alarm trap |||||||||o|o|o|o|o|o|o|");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
				//		receivedOPATrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.141.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
					//	byte port = 0;//no port for OPAPLUS
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OPAPLUS";
						System.out.println("|o|o|o|o|o|o|o|||||||| OPAPLUS alarm trap |||||||||o|o|o|o|o|o|o|");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						receivedOPAPLUSTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.5.3.1.1.1")){
//						byte port = (byte) trapOID.removeLast();
						byte port = 0;//no port for OLA
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OLA";
						System.out.println("|x|x|x|x|x|x|x|||||||| OLA alarm trap ||||||||||x|x|x|x|x|x|");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
					//	receivedOLATrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1")){
						System.out.println("trapOIDString OID >>>>>>>>>>>> "+trapOIDString);
						byte port = (byte) trapOID.removeLast();
			//			byte port = 0;//no port for OLAPLUS
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "OLAPLUS";
						System.out.println("|x|x|x|x|x|x|x|||||||| OLAPLUS alarm trap ||||||||||x|x|x|x|x|x|");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						receivedOLAPLUSTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.2.3.1.1.1")){
						byte channelno = (byte) trapOID.removeLast();
						byte port = (byte) trapOID.removeLast();
						byte directionno = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "MANTIS";
						System.out.println("RRRRRRRRRRRRRRRRRRRRRR  MANTIS (MD-ROADM) alarm trap RRRRRRRRRRRRRRRRRRRRRR");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
					//	receivedMDROADMTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.191.3.1.1.1")){
						byte channelno = (byte) trapOID.removeLast();
						byte port = (byte) trapOID.removeLast();
						byte directionno = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "MANTISPLUS";
						System.out.println("RRRRRRRRRRRRRRRRRRRRRR  MANTIS PLUS (MD-ROADM) alarm trap RRRRRRRRRRRRRRRRRRRRRR");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
						receivedMDROADMPLUSTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.11.1.1.1.1")){
						byte iono = (byte) trapOID.removeLast();
						byte psuno = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "PSU-"+psuno;
						System.out.println("PPPPPPPPPPPPPPPPPPPPP   PSU alarm trap  PPPPPPPPPPPPPPPPPPPPP");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						if (cardName.equals("PSU-1"))
							slot = 2;//PSU-1
						else if(cardName.equals("PSU-2"))
						    slot = 3;//PSU-2
						
					
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, psuno, cardName, nodeIP, alarmStatus, dateAndTime, OID);
					//	receivedPSUTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1")){
						//byte iono = (byte) trapOID.removeLast();
						byte sourceno = (byte) trapOID.removeLast();
						byte psuno = (byte) trapOID.removeLast();
						if(psuno == 2)
							psuno = 1;
						else if(psuno == 3)
							psuno = 2;
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "PSU-"+psuno;
						System.out.println("PPPPPPPPPPPPPPPPPPPPP   PSU PLUS alarm trap  PPPPPPPPPPPPPPPPPPPPP");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						if (cardName.equals("PSU-1"))
							slot = 2;//PSU-1
						else if(cardName.equals("PSU-2"))
						    slot = 3;//PSU-2							
						//trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, psuno, cardName, nodeIP, alarmStatus, dateAndTime, OID);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, sourceno, cardName, nodeIP, alarmStatus, dateAndTime, OID);
						receivedPSUPLUSTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.61.2.1.1.1")){ //buzzer plus
							byte port = (byte) trapOID.removeLast();								
							short slot = (short) trapOID.removeLast();
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "BUZZER";
							System.out.println("BBBBBBBBBBBB   BUZZER PLUS alarm trap  BBBBBBBBBBBB");
						//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
							String alarmStrStatus = eachTrapVB.getVariable().toString();
							byte alarmStatus = Byte.valueOf(alarmStrStatus);
							if (cardName.equals("BUZZER"))
								slot = 4;								
							trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot,port, cardName, nodeIP, alarmStatus, dateAndTime, OID);
							receivedBUZZERPLUSTrap.add(trapDetails);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.10.2.1.1.1")){
						byte fanNumber = (byte) trapOID.removeLast();
						byte fanTray = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "FAN";
						System.out.println("******************  FAN alarm trap **********************");
					//	byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, fanNumber, cardName, nodeIP, alarmStatus, dateAndTime, OID);
						trapDetails.setFanTray(fanTray);
					//	receivedFANTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1")){
						byte fanNumber = (byte) trapOID.removeLast();
						byte fanTray = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "FANPLUS";
						System.out.println("******************  FAN PLUS Alarm trap **********************");
						//byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, fanNumber, cardName, nodeIP, alarmStatus, dateAndTime, OID);
						trapDetails.setFanTray(fanTray);
						receivedFANPLUSTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}
					/*else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.613.2.1.1.1")){//////Card-id need to be changed later -dheeraj
						
						byte fanNumber = (byte) trapOID.removeLast();
						byte fanTray = (byte) trapOID.removeLast();
						short slot = (short) trapOID.removeLast();
						
						short subRack = (short) trapOID.removeLast();
						short rack = (short) trapOID.removeLast();
						byte node = (byte) trapOID.removeLast();
						String OID = trapOID.toString();
						String cardName = "FANPLUSNEW";
						System.out.println("******************  FAN PLUS NEW Alarm trap **********************");
						//byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						String alarmStrStatus = eachTrapVB.getVariable().toString();
						byte alarmStatus = Byte.valueOf(alarmStrStatus);
						
						trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, fanNumber, cardName, nodeIP, alarmStatus, dateAndTime, OID);
						trapDetails.setFanTray(fanTray);
						receivedFANPLUSNEWTrap.add(trapDetails);
						//messagesArea.append(trapDetails.toString()+"\n");
						System.out.println(trapDetails.toString()+"\n");
					}*/
					
					///dheeraj
					
					
					else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1")){
					      if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.3.")){
							//Jack-In card register trap
							byte port = 1;
							short slot = (short) trapOID.removeLast();
							byte interfaceNumber = 0;
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardRcvdName = eachTrapVB.getVariable().toString(); //only on jack-in (card register)						
							String cardName = JackCardNames.getCardName(cardRcvdName);
							/*if("MANTIS".equals(cardName)){
								cardName = MDROADMBL.getDirectionOfMantis(nodeIP, node, rack, subRack, slot, (byte)1, (byte)2, (byte)0, new SNMPVersionDetails());
							}*/
							if("MANTISPLUS".equals(cardName)){
								cardName = MDROADMPLUSBL.getDirectionOfMantisPlus(nodeIP, node, rack, subRack, slot, (byte)0, (byte)0, (byte)0, new SNMPVersionDetails());
							}
							else if("OBA".equals(cardName)){
								cardName = OBABL.getDirectionOfOBA(nodeIP, node, rack, subRack, slot, new SNMPVersionDetails());
							}
							else if("OBAPLUS".equals(cardName)){
								cardName = OBAPLUSBL.getDirectionOfOBAPLUS(nodeIP, node, rack, subRack, slot,interfaceNumber, new SNMPVersionDetails());
							}
							else if("OPA".equals(cardName)){
								cardName = OPABL.getDirectionOfOPA(nodeIP, node, rack, subRack, slot, new SNMPVersionDetails());
							}
							else if("OPAPLUS".equals(cardName)){
								cardName = OPAPLUSBL.getDirectionOfOPAPLUS(nodeIP, node, rack, subRack, slot,interfaceNumber, new SNMPVersionDetails());
							}
							else if("OLA".equals(cardName)){
								cardName = OLABL.getDirectionOfOLA(nodeIP, node, rack, subRack, slot, new SNMPVersionDetails());
							}
							else if("OLAPLUS".equals(cardName)){
								cardName = OLAPLUSBL.getDirectionOfOLAPLUS(nodeIP, node, rack, subRack, slot,interfaceNumber, new SNMPVersionDetails());
							}
							else if("MUXPLUS".equals(cardName)){
								cardName = MUXPLUSBL.getDirectionOfMUXPLUS(nodeIP, node, rack, subRack, slot,interfaceNumber, new SNMPVersionDetails());
							}
							else if("DEMUXPLUS".equals(cardName)){
								cardName = DEMUXPLUSBL.getDirectionOfDEMUXPLUS(nodeIP, node, rack, subRack, slot,interfaceNumber, new SNMPVersionDetails());
							}
							
							byte alarmStatus = 1;
							//byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
						//	System.out.println(cardRcvdName+"::jack in trap ::"+cardName);
							System.out.println("jack in (card register) trap ++++++++++++++++++++++++++++++++++++++++++++++");
						//	System.out.println("jack in trap OID"+trapOIDString);
							trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus, dateAndTime, OID);
							receivedJackTrap.add(trapDetails);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.2.")){
							//Jack-Out trap
							byte port = 1;
							short slot = (short) trapOID.removeLast();
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "DONTUSE"; // no card name on jack-out
							String jackStatus = eachTrapVB.getVariable().toString();
							byte alarmStatus = Byte.valueOf(jackStatus);
							System.out.println("jack out trap ------------------------------------------------- ");
						//	System.out.println("jackStatus "+alarmStatus);
							trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus, dateAndTime, OID);
							receivedJackTrap.add(trapDetails);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.61")){
							//BMU alarm trap
							byte port = (byte) trapOID.removeLast();
							short slot = (short) trapOID.removeLast();
							if(slot == 254) // added code on 13/12/2016
								slot = 1;							
							short subRack = (short) trapOID.removeLast();
							if(subRack == 2)
								subRack = 1;	
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "BMUPLUS"; // card name BMUPLUS change on 13/12/2016
							String jackStatus = eachTrapVB.getVariable().toString();
							String alarmStatus = String.valueOf(jackStatus);
							System.out.println("bmu alarm trap ------------------------------------------------- ");
						//	System.out.println("jackStatus "+alarmStatus);
							trapDetailsforbmu=new ReceivedTrapDetailsForBMU(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus, dateAndTime, OID);
							receivedBMUTrap.add(trapDetailsforbmu);
							//messagesArea.append(trapDetailsforbmu.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.64")){
							//SCC link failure alarm trap
							byte port = (byte) trapOID.removeLast(); //This is the Direction Number
							short slot = (short) trapOID.removeLast();
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "SCC";
							String jackStatus = eachTrapVB.getVariable().toString();
							byte alarmStatus = Byte.valueOf(jackStatus);
							System.out.println("osc fiber cut link failure alarm trap ------------------------------------------------- ");
						//	System.out.println("jackStatus "+alarmStatus);
							trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus, dateAndTime, OID);
							receivedOSCTrap.add(trapDetails);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.65")){
							
							//software upgrade status trap
							
						//	byte port = (byte) trapOID.removeLast(); 							
							byte port = 0;//no port for software upgrade status
							short slot = (short) trapOID.removeLast();
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "NO";// no card name on software upgrade status trap
							String upgradeStatus = eachTrapVB.getVariable().toString();
							String swupgradeStatus = String.valueOf(upgradeStatus);
							System.out.println("software upgrade status trap ------------------------------------------------- ");
						
							trapDetailsforswupgrade=new ReceivedTrapDetailsForSWUpgrade(node, rack, subRack, slot, port, cardName, nodeIP, swupgradeStatus, dateAndTime, OID);
							receivedSoftwareUpgradeTrap.add(trapDetailsforswupgrade);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
							
						}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.1")){
							//Jack-in trap not used
							System.out.println("Jack-in trap not used ---------------------------------- ");
						}else if(trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.11")||trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.12")||trapOIDString.startsWith("1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.13")){
							byte port = 0;//no port for SCC
							short slot = (short) trapOID.removeLast();
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "SCC";
							System.out.println("sssssssssssssssssssssss SCC alarm trap ssssssssssssssssssssssssss");
							String jackStatus = eachTrapVB.getVariable().toString();
							byte alarmStatus = Byte.valueOf(jackStatus);
							trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
							receivedSCCTrap.add(trapDetails);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						}
						else {		//osc alarms					
							byte port = (byte) trapOID.removeLast();
							short slot = (short) trapOID.removeLast();
							short subRack = (short) trapOID.removeLast();
							short rack = (short) trapOID.removeLast();
							byte node = (byte) trapOID.removeLast();
							String OID = trapOID.toString();
							String cardName = "SCC";
							System.out.println("sssssssssssssssssssssss OSC alarm trap ssssssssssssssssssssssssss");
							
							String jackStatus = eachTrapVB.getVariable().toString();
							byte alarmStatus = Byte.valueOf(jackStatus);
							//byte alarmStatus = (byte) eachTrapVB.getVariable().toInt();
							
							//System.out.println("sssssssssssssssss alarm status ---> "+alarmStatus);
							trapDetails=new ReceivedTrapDetails(node, rack, subRack, slot, port, cardName, nodeIP, alarmStatus,dateAndTime, OID);
							receivedOSCTrap.add(trapDetails);
							//messagesArea.append(trapDetails.toString()+"\n");
							System.out.println(trapDetails.toString()+"\n");
						}
					}
				}
		/*		CallableStatement cstmtForUpdateBuzzerMute = null;
				Connection connBuzzer = null;
				byte result = 0;
				try{
					// call stored procedure to clear buzzer on mute
					
					connBuzzer=DataSource.getInstance().getConnection();
					
					cstmtForUpdateBuzzerMute = connBuzzer.prepareCall("CALL buzzer_update(?)");
					cstmtForUpdateBuzzerMute.setString(1, nodeIP);
					result=(byte) cstmtForUpdateBuzzerMute.executeUpdate();
					
				}
				catch (Exception e) {
					l.info(e);
				}finally{
					if(cstmtForUpdateBuzzerMute!=null){
						cstmtForUpdateBuzzerMute.close();
					}
					if(connBuzzer!=null){
						connBuzzer.close();
					}
				}*/
			} catch (Exception e) {
				//l.info(e);
			}
			
		}
	}
}
