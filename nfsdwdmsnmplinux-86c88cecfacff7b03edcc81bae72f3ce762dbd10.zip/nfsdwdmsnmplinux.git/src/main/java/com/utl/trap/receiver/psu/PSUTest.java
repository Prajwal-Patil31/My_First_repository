package com.utl.trap.receiver.psu;

import java.util.HashMap;
import java.util.Map;

import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.Variable;

import com.utl.trap.receiver.TrapSender;

public class PSUTest {

	public static void main(String[] args) {
		byte sourceno = 1;
		byte psuno = 2;
		short slot = 2;
		short subRack = 1;
		short rack = 1;
		byte node = 1;
		
		Map<String,Variable> OIDList = new HashMap<String, Variable>();
		OIDList.put("1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.6."+node+"."+rack+"."+subRack+"."+slot+"."+psuno+"."+sourceno , new Integer32(1));
		sourceno = 2;
		OIDList.put("1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.6."+node+"."+rack+"."+subRack+"."+slot+"."+psuno+"."+sourceno , new Integer32(0));
		
		TrapSender.sendSnmpV2Trap(OIDList);
	}

}
