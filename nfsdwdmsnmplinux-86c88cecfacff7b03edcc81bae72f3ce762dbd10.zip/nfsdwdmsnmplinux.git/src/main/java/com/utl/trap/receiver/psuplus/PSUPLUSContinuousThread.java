package com.utl.trap.receiver.psuplus;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.jack.JackDAO;
import com.utl.util.CommonDAO;

public class PSUPLUSContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedPSUPLUSTraps;
	//static Logger l = Logger.getLogger(PSUPLUSContinuousThread.class);
	
	public PSUPLUSContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedPSUTraps) {
		super("PSU PLUS Continuous Thread");
		this.receivedPSUPLUSTraps = receivedPSUTraps;
	}

	/*@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedPSUPLUSTraps.take();
				System.out.println("Start PSU PLUS");
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				int portNo			= trapDetails.getPort();
				String[] alarmMiscData = PSUPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					
						if(alarmIndex.equals("8"))//To get PSU card presence/absence notification status
						{
							int psuslotMasterID = 0;
							if (portNo == 1)//psu-1 slotmasterid based on bmu
								psuslotMasterID = slotMasterID;
							else if (portNo == 2)//psu-2 slotmasterid based on bmu
								psuslotMasterID = slotMasterID;	
							
							PSUPLUSDAO.updateJack(psuslotMasterID, alarmStatus, conn);
						
						}
						else
						{
						byte prevAlarmStatus=PSUPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
						
						if(alarmStatus!=prevAlarmStatus){
							String alarmSeverity = PSUPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
							PSUPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
					
							
							//check all PSU alarms and severity from DB to update global
							LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =PSUPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
							LinkedHashMap<Byte, String> allAlarmSeverity =PSUPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
							byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
							l.info("PSU PLUS Global Alarm Process Completed......"+status);
													
						}
					}
				}
			} catch (Exception e) {
				l.info("PSU PLUS Alarm Processing Error......");
				l.error(e.getMessage(),e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}*/
	@Override
	public void run() {
		while(true){
			Connection conn = null;
			boolean jackIn=false;
			try {
				ReceivedTrapDetails trapDetails = receivedPSUPLUSTraps.take();
				System.out.println("Start PSU PLUS");
				System.out.println(trapDetails);
				byte alarmStatus  = trapDetails.getAlarmStatus();
				String oID        = trapDetails.getOID();
				int sourceNo	  = trapDetails.getPort();
				String cardName   = trapDetails.getCardName();
				String[] alarmMiscData = PSUPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if (sourceNo == 2)
				{					
					if (alarmIndex.equals("1"))
					{					
						alarmIndex = "6";
						
					}else if (alarmIndex.equals("2"))
					{					
						alarmIndex = "7";
					
					}else if (alarmIndex.equals("3"))
					{					
						alarmIndex = "8";
					
					}else if (alarmIndex.equals("4"))
					{					
						alarmIndex = "9";
						
					
					}else if (alarmIndex.equals("5"))
					{					
						alarmIndex = "10";	
						if(alarmStatus == 1)
							alarmStatus = 2;
						
					}
					alarmName+=" For Source-2";
				}else{
					
					alarmName+=" For Source-1";
					if (alarmIndex.equals("5"))
					{
						if(alarmStatus == 1)
							alarmStatus = 2;
					}
				}
							
				
				 //store card jack in jack out history
		        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				Date date=new Date();
				String dateTime=sdf.format(date);
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					
						if(alarmIndex.equals("99"))//To get PSU card presence/absence notification status
						{
							/*int psuslotMasterID = 0;
							if (portNo == 1)//psu-1 slotmasterid based on bmu
								psuslotMasterID = slotMasterID;
							else if (portNo == 2)//psu-2 slotmasterid based on bmu
								psuslotMasterID = slotMasterID;	*/
							
							PSUPLUSDAO.updateJack(slotMasterID, alarmStatus, conn);
							
							if (alarmStatus == 0)
								jackIn = true;
							
							
							PSUPLUSDAO.updateJackInOutHistory(jackIn, conn, slotMasterID, dateTime,cardName);
						
						}
						else
						{
						byte prevAlarmStatus=PSUPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
						
						if(alarmStatus!=prevAlarmStatus){
							String alarmSeverity = PSUPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
							PSUPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
					
							
							//check all PSU alarms and severity from DB to update global
							LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =PSUPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
							LinkedHashMap<Byte, String> allAlarmSeverity =PSUPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
							byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
							
							if ("PSU-1".equals(cardName)) {
								//Update MCB Status
								PSUPLUSDAO.updateMCBCardStatus(allAlarmPresentFromDb, trapDetails, conn);
							}
							System.out.println("PSU PLUS Global Alarm Process Completed......"+status);
													
						}
					}
				}
			} catch (Exception e) {
				System.out.println("PSU PLUS Alarm Processing Error......");
				e.getMessage();
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
