package com.utl.trap.receiver.omtp12;

import java.sql.Connection;
import java.util.HashMap;
import java.util.Map;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class OMTP12PLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=15000;
	static SNMPVersionDetails snmpVersionDetailsObj=new SNMPVersionDetails();
	public static void retrievePortTrafficNames(short nodeNumber,byte rackNumber,short subrackNumber,byte slotNumber,String nodeIP, String cardName, int slotMasterID, Connection conn) throws Exception{	
		try {	
			byte portNumber =1;
			int value =  getPortTraffic(nodeNumber, rackNumber, subrackNumber, slotNumber, portNumber ,  nodeIP, snmpVersionDetailsObj);
			Map<Short, Integer> trafficValuesFromMachine= new HashMap<Short, Integer>();
			trafficValuesFromMachine.put((short)portNumber, value);
			
			//update in database and return traffic names
			OMTP12DAO.getTrafficNames(slotMasterID, trafficValuesFromMachine, cardName, conn );
		} catch (Exception e) {
			throw e;
		}
	}

	
	public static int getPortTraffic(short nodeNumber,byte rackNumber,short subrackNumber,byte slotNumber,byte portNumber,String nodeIP,SNMPVersionDetails userDetails) throws Exception{
		VariableBinding inputOID        = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,73,2,1,1,41,nodeNumber,rackNumber,subrackNumber,slotNumber,portNumber}));
		VariableBinding resultVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, inputOID, userDetails);
		return resultVB.getVariable().toInt();
	}
}
