package com.utl.trap.receiver.opaplus;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.FiberCutStatusDAO;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.opa.OPAAlarmNames;
import com.utl.trap.receiver.opa.OPADAO;
import com.utl.trap.receiver.opaplus.OPAPLUSDAO;
import com.utl.trap.receiver.osc.OSCDAO;
import com.utl.util.CommonDAO;

public class OPAPLUSContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedOPAPLUSTraps;
	//static Logger l = Logger.getLogger(OPAPLUSContinuousThread.class);
	
	public OPAPLUSContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedOPAPLUSTraps) {
		super("OPAPLUS Continuous Thread");
		this.receivedOPAPLUSTraps = receivedOPAPLUSTraps;
	}

	@Override
	/*public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOPAPLUSTraps.take();
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OPAPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				LinkedHashMap<Byte, Byte> allAlarmPresentFromDbforFiber = null;
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OPAPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OPAPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OPAPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						
						//check all OPAPLUS alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OPAPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OPAPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						l.info("OPAPLUS Global Alarm Process Completed......"+status);
					}
					//fiber cut alarm updation in mesh topology
					if (alarmIndex.equals("1"))//ip fail alarm index is 1
					{
					  int fiberSourceNodeId =	Integer.parseInt(slotDetails.get(0));
					  int fiberSourceOSCId = 1;
					  byte fiberLinkStatus=0;
					  String fiberCardName = slotDetails.get(3);
					  if (fiberCardName.equals("OPA1PLUS"))	
					  {
						  fiberSourceOSCId = 1;
					  }else if (fiberCardName.equals("OPA2PLUS"))	
					  {
						  fiberSourceOSCId = 2;
					  }else if (fiberCardName.equals("OPA3PLUS"))	
					  {
						  fiberSourceOSCId = 3;
					  }
						if(alarmStatus==0){
							if(allAlarmPresentFromDbforFiber.get((byte)2)==1||allAlarmPresentFromDbforFiber.get((byte)3)==1||allAlarmPresentFromDbforFiber.get((byte)4)==1||allAlarmPresentFromDbforFiber.get((byte)5)==1||allAlarmPresentFromDbforFiber.get((byte)6)==1||allAlarmPresentFromDbforFiber.get((byte)7)==1){
								fiberLinkStatus=9;
							}
						}else{
							fiberLinkStatus=alarmStatus;
						}
						byte topLineFiberUpdate=FiberCutStatusDAO.updateTopFiberCutStatus(fiberCardName, fiberSourceNodeId, fiberSourceOSCId, fiberLinkStatus, conn);
						byte downLineFiberUpdate=FiberCutStatusDAO.updateDownFiberCutStatus(fiberCardName, fiberSourceNodeId, fiberSourceOSCId, fiberLinkStatus, conn);
						l.info("OPA Alarm topline fiber cut Process Completed......"+topLineFiberUpdate);
						l.info("OPA Alarm downline fiber cut Process Completed......"+downLineFiberUpdate);
					}
				}
			} catch (Exception e) {
				l.info("OPAPLUS Alarm Processing Error......");
				l.error(e.getMessage(),e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}*/
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOPAPLUSTraps.take();
				System.out.println("Start OPAPLUS");
				System.out.println(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OPAPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				LinkedHashMap<Byte, Byte> allAlarmPresentFromDbforFiber = null;
		//		String fiberNodeIP = trapDetails.getNodeIP();
				 
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("OPAPLUS TRAPS=============>>>>>>"+slotDetails);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OPAPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OPAPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OPAPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						
						//check all OPA PLUS alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OPAPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OPAPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						System.out.println("OPAPLUS Global Alarm Process Completed......"+status);
						
						allAlarmPresentFromDbforFiber = allAlarmPresentFromDb;
					}
					
					//fiber cut alarm updation in mesh topology
					if (alarmIndex.equals("1"))//ip fail alarm index is 1
					{
					  int nodeId =	Integer.parseInt(slotDetails.get(0));
					  byte oscNumber = 0;
					  byte fiberCutStatus=0;
					  String fiberCardName = slotDetails.get(3);
					  if (fiberCardName.equals("OPA1PLUS"))	
					  {
						  oscNumber = 1;
					  }else if (fiberCardName.equals("OPA2PLUS"))	
					  {
						  oscNumber = 2;
					  }else if (fiberCardName.equals("OPA3PLUS"))	
					  {
						  oscNumber = 3;
					  }else if (fiberCardName.equals("OPA4PLUS"))	
					  {
						  oscNumber = 4;
					  }
					  if(alarmStatus==1){
						  byte oscIPF = OSCDAO.getOSCIPFAlarm(nodeId, oscNumber, conn);
						  if(oscIPF == 1){
							  fiberCutStatus = 1;
						  }
						  else
						  {
							  fiberCutStatus = 0;
						  }
					  }
									  
						byte topLineFiberUpdate=FiberCutStatusDAO.updateFiberCutStatus(nodeId, oscNumber, fiberCutStatus, conn);
						System.out.println("OPAPLUS Alarm topline fiber cut Process Completed......status "+topLineFiberUpdate +" updated "+ fiberCutStatus);
					}
					
				}
			} catch (Exception e) {
				System.out.println("OPAPLUS Alarm Processing Error......");
				e.getMessage();
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}

}
