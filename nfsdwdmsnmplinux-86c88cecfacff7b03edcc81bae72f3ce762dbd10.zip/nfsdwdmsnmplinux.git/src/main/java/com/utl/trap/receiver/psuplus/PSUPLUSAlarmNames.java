package com.utl.trap.receiver.psuplus;

import java.util.HashMap;
import java.util.Map;

public class PSUPLUSAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.3";
		alarmName="Output Power Failure";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.4";
		alarmName="Input Over Voltage";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.5";
		alarmName="Input Under Voltage";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.6";
		alarmName="Input Power Failure";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.7";
		alarmName="Pre Warn Under Voltage";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		
		alarmIndex="99";
		OID="1.3.6.1.4.1.18036.1.1.1.56.1.1.1.1.8";
		alarmName="Card Presence Absence Notification Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});	
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
