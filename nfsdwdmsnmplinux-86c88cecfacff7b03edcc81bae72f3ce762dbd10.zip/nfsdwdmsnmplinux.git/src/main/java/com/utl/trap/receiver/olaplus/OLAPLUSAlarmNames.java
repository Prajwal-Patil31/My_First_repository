package com.utl.trap.receiver.olaplus;

import java.util.HashMap;
import java.util.Map;

public class OLAPLUSAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		
		/*IOP Failure
		OOP Failure
		IOP Out of Range
		OOP Out of Range
		Degraded IOP
		Degraded OOP
		Low IOP*/
		
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.1";
		alarmName="Input Power Failure Alarm [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.12";
		alarmName="Output Power Failure Alarm [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.53";
		alarmName="Input Out of Range Alarm [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.54";
		alarmName="Output Out of Range Alarm [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.9";
		alarmName="Degraded Input Optical Power [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.20";
		alarmName="Degraded Optical Output Power [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.5";
		alarmName="Low Input Power Alarm [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.21";
		alarmName="EDFA High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		//new alarms added for FAT
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.2";
		alarmName="Input Power Failure Alarm [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.11";
		alarmName="Output Power Failure Alarm [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.55";
		alarmName="Input Out of Range Alarm [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.56";
		alarmName="Output Out of Range Alarm [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.10";
		alarmName="Degraded Input Optical Power [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.19";
		alarmName="Degraded Optical Output Power [Stage-1]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.6";
		alarmName="Low Input Power Alarm [Stage-2]";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		/*alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.1.0";
		alarmName="Optical Input Power Failure Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.2.0";
		alarmName="Optical Input Power Failure Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.3.0";
		alarmName="Optical High Input Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.4.0";
		alarmName="Optical High Input Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.5.0";
		alarmName="Optical Low Input Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="6";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.6.0";
		alarmName="Optical Low Input Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="7";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.7.0";
		alarmName="Optical High Input Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="8";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.8.0";
		alarmName="Optical High Input Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="9";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.9.0";
		alarmName="Optical Low Input Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="10";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.10.0";
		alarmName="Optical Low Input Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="11";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.11.0";
		alarmName="Optical Output Power Failure Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="12";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.12.0";
		alarmName="Optical Output Power Failure Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="13";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.13.0";
		alarmName="Optical High Output Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="14";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.14.0";
		alarmName="Optical High Output Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="15";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.15.0";
		alarmName="Optical Low Output Power Alarm for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="16";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.16.0";
		alarmName="Optical Low Output Power Alarm for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="17";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.17.0";
		alarmName="Optical High Output Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="18";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.18.0";
		alarmName="Optical High Output Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="19";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.19.0";
		alarmName="Optical Low Output Power Warning for Stage 1";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="20";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.20.0";
		alarmName="Optical Low Output Power Warning for Stage 2";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="21";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.21.0";
		alarmName="Module High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="22";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.22.0";
		alarmName="Module Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="23";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.23.0";
		alarmName="Module High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="24";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.24.0";
		alarmName="Module Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="25";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.25.0";
		alarmName="Pump 1 High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="26";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.26.0";
		alarmName="Pump 2 High Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="27";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.27.0";
		alarmName="Pump 1 Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="28";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.28.0";
		alarmName="Pump 2 Low Temperature Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="29";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.29.0";
		alarmName="Pump 1 High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="30";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.30.0";
		alarmName="Pump 2 High Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="31";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.31.0";
		alarmName="Pump 1 Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="32";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.32.0";
		alarmName="Pump 2 Low Temperature Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="33";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.33.0";
		alarmName="Pump 1 High Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="34";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.34.0";
		alarmName="Pump 2 High Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="35";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.35.0";
		alarmName="Pump 1 Low Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="36";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.36.0";
		alarmName="Pump 2 Low Operating Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="37";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.37.0";
		alarmName="Pump 1 High Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="38";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.38.0";
		alarmName="Pump 2 High Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="39";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.39.0";
		alarmName="Pump 1 Low Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="40";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.40.0";
		alarmName="Pump 2 Low Operating Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="41";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.41.0";
		alarmName="Pump 1 High Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="42";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.42.0";
		alarmName="Pump 2 High Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="43";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.43.0";
		alarmName="Pump 1 Low Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="44";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.44.0";
		alarmName="Pump 2 Low Thermo Electric Cooler Current Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="45";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.45.0";
		alarmName="Pump 1 High Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="46";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.46.0";
		alarmName="Pump 2 High Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="47";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.47.0";
		alarmName="Pump 1 Low Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="48";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.48.0";
		alarmName="Pump 2 Low Thermo Electric Cooler Current Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="49";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.49.0";
		alarmName="Variable Optical Attenuator High Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="50";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.50.0";
		alarmName="Variable Optical Attenuator Low Input Power Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="51";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.51.0";
		alarmName="Variable Optical Attenuator High Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="52";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.52.0";
		alarmName="Variable Optical Attenuator Low Input Power Warning";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="53";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.53.0";
		alarmName="Input Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="54";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.54.0";
		alarmName="Output Out of Range Alarm";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="55";
		OID="1.3.6.1.4.1.18036.1.1.1.151.3.1.1.1.55.0";
		alarmName="Pump Bias Current Alarm ";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});*/
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
