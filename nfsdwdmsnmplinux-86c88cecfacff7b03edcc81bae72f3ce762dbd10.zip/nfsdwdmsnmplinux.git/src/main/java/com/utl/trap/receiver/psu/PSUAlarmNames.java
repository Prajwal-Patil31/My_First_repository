package com.utl.trap.receiver.psu;

import java.util.HashMap;
import java.util.Map;

public class PSUAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.11.1.1.1.1.3";
		alarmName="Output Health Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.11.1.1.1.1.4";
		alarmName="Input Over Voltage Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.11.1.1.1.1.5";
		alarmName="Input Voltage Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="4";
		OID="1.3.6.1.4.1.18036.1.1.1.11.1.1.1.1.6";
		alarmName="Input Power Failure Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="5";
		OID="1.3.6.1.4.1.18036.1.1.1.11.1.1.1.1.7";
		alarmName="Prewarn Under Voltage Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
