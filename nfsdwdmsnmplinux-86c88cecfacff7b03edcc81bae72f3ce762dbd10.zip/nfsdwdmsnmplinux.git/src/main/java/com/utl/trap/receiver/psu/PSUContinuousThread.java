package com.utl.trap.receiver.psu;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.oba.OBADAO;
import com.utl.util.CommonDAO;

public class PSUContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedPSUTraps;
	static Logger l = Logger.getLogger(PSUContinuousThread.class);
	
	public PSUContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedPSUTraps) {
		super("PSU Continuous Thread");
		this.receivedPSUTraps = receivedPSUTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedPSUTraps.take();
				System.out.println("Start PSU");
				l.info(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = PSUAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=PSUDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = PSUDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						PSUDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
				
						
						//check all PSU alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =PSUDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =PSUDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						l.info("PSU Global Alarm Process Completed......"+status);
												
					}
				}
			} catch (Exception e) {
				l.info("PSU Alarm Processing Error......");
				l.error(e.getMessage(),e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
