package com.utl.trap.receiver.bmu;

import java.util.HashMap;
import java.util.Map;

public class BMUAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.1.3.1.1.1.61";
		alarmName="BMU Alarm Severity Indication Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
