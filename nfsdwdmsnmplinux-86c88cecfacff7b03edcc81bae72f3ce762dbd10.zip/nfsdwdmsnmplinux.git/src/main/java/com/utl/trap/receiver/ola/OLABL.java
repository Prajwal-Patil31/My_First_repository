package com.utl.trap.receiver.ola;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class OLABL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfOLA(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber, SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,5,2,1,1,183,nodeNumber,rackNumber,subrackNumber,slotNumber}));
		System.out.println(OID);
		String cardName = "OLA";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getOLACardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getOLACardName(int directionNumber){
		String cardName = "OLA";
		switch (directionNumber) {
		case 1:
			cardName="OLA1";
			break;
		case 2:
			cardName="OLA2";
			break;
		case 3:
			cardName="OLA3";
			break;
		}
		return cardName;
	}
}
