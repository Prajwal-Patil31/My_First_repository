package com.utl.trap.receiver.fanplus;

import java.util.HashMap;
import java.util.Map;

public class FANPLUSAlarmNames {
	private static final Map<String,String[]> alarmNames=new HashMap<String,String[]>();
	private static String OID;
	private static String alarmName;
	private static String alarmIndex;
	private static String hide;
	static{
		alarmIndex="1";
		OID="1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.3";
		alarmName="Fan Tray Present Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="2";
		OID="1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.4";
		alarmName="Fan Present Status in Fan Tray";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
		
		alarmIndex="3";
		OID="1.3.6.1.4.1.18036.1.1.1.66.2.1.1.1.5";
		alarmName="Active Fan Tray Status";
		hide="false";
		alarmNames.put(OID, new String[]{alarmIndex,alarmName,hide});
	}
	
	public static Map<String, String[]> getAlarmNames() {
		return alarmNames;
	}
	
	public static String[] getDetails(String OID){
		return alarmNames.get(OID);
	}
}
