package com.utl.trap.receiver.software.upgrade;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.ReceivedTrapDetailsForBMU;
import com.utl.trap.receiver.ReceivedTrapDetailsForSWUpgrade;
import com.utl.trap.receiver.bmu.BMUContinuousThread;
import com.utl.util.CommonDAO;

public class SoftwareUpgradeContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetailsForSWUpgrade> receivedSoftwareUpgradeStatusTraps;
	//static Logger l = Logger.getLogger(BMUContinuousThread.class);
	
	public SoftwareUpgradeContinuousThread(
			BlockingQueue<ReceivedTrapDetailsForSWUpgrade> receivedSoftwareUpgradeStatusTraps) {
		super("Software Upgrade Continuous Thread");
		this.receivedSoftwareUpgradeStatusTraps = receivedSoftwareUpgradeStatusTraps;
	}
	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetailsForSWUpgrade trapSWDetails = receivedSoftwareUpgradeStatusTraps.take();
				System.out.println("Start software upgrade status traps");
				System.out.println(trapSWDetails);
			
			//	String oID          = trapDetails.getOID();				
				String swUpgradeStatus  = trapSWDetails.getAlarmStatus();
						
				conn = DataSource.getInstance().getConnection();
				List<String> slotDetails = CommonDAO.getSlotDetailsForSWUpgrade(trapSWDetails, conn);					
				int slotMasterID=Integer.parseInt(slotDetails.get(1));
				
				SoftwareUpgradeDAO.updateSWUpgradeStatus(slotMasterID,  swUpgradeStatus,  trapSWDetails.getAlarmGeneratedTime(), conn);
			
			} catch (Exception e) {
				//l.info(e);
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
