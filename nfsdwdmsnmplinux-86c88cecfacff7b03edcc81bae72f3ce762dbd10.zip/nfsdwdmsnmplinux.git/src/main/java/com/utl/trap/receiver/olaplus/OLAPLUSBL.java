package com.utl.trap.receiver.olaplus;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class OLAPLUSBL {
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getDirectionOfOLAPLUS(String nodeIP,byte nodeNumber, short rackNumber,short subrackNumber,short slotNumber,byte interfaceNumber, SNMPVersionDetails versionDetails) throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,151,1,1,1,38,nodeNumber,rackNumber,subrackNumber,slotNumber,interfaceNumber}));
		System.out.println(OID);
		String cardName = "OLAPLUS";
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID, versionDetails);
			Variable resultEachV = resultEachVB.getVariable();
			cardName = getOLAPLUSCardName(resultEachV.toInt());
		} catch (Exception e) {
			throw e;
		}
		return cardName;		
	}
	public static String getOLAPLUSCardName(int directionNumber){
		String cardName = "OLAPLUS";
		switch (directionNumber) {
		case 1:
			cardName="OLA1PLUS";
			break;
		case 2:
			cardName="OLA2PLUS";
			break;
		case 3:
			cardName="OLA3PLUS";
			break;
		case 4:
			cardName="OLA4PLUS";
			break;
		}
		return cardName;
	}
}
