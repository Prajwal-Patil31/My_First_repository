package com.utl.trap.receiver.olaplus;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.BlockingQueue;

//import org.apache.log4j.Logger;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.FiberCutStatusDAO;
import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.olaplus.OLAPLUSDAO;
import com.utl.trap.receiver.osc.OSCDAO;
import com.utl.util.CommonDAO;

public class OLAPLUSContinuousThread extends Thread{
	
	private BlockingQueue<ReceivedTrapDetails> receivedOLAPLUSTraps;
	//static Logger l = Logger.getLogger(OLAPLUSContinuousThread.class);
	
	public OLAPLUSContinuousThread(
			BlockingQueue<ReceivedTrapDetails> receivedOLAPLUSTraps) {
		super("OLAPLUS Continuous Thread");
		this.receivedOLAPLUSTraps = receivedOLAPLUSTraps;
	}

	@Override
	public void run() {
		while(true){
			Connection conn = null;
			try {
				ReceivedTrapDetails trapDetails = receivedOLAPLUSTraps.take();
				//l.info(trapDetails);
				System.out.println(trapDetails);
				byte alarmStatus    = trapDetails.getAlarmStatus();
				String oID          = trapDetails.getOID();
				
				String[] alarmMiscData = OLAPLUSAlarmNames.getDetails(oID);
				
				String alarmIndex = alarmMiscData[0];
				String alarmName  = alarmMiscData[1];
				String hide       = alarmMiscData[2];
				LinkedHashMap<Byte, Byte> allAlarmPresentFromDbforFiber = null;
				
				if ("false".equals(hide)) {
					conn = DataSource.getInstance().getConnection();
					List<String> slotDetails = CommonDAO.getSlotDetails(trapDetails, conn);
					System.out.println("OLAPLUS TRAPS=============>>>>>>"+slotDetails);
					int slotMasterID=Integer.parseInt(slotDetails.get(1));
					byte prevAlarmStatus=OLAPLUSDAO.updateAlarm(slotMasterID, alarmIndex, alarmStatus, conn);
					
					if(alarmStatus!=prevAlarmStatus){
						String alarmSeverity = OLAPLUSDAO.getAlarmSeverity(slotMasterID, alarmIndex, conn);
						OLAPLUSDAO.updateAlarmTrans(slotMasterID, alarmStatus, alarmName, alarmSeverity, trapDetails.getAlarmGeneratedTime(), conn);
						
						//check all OLAPLUS alarms and severity from DB to update global
						LinkedHashMap<Byte, Byte> allAlarmPresentFromDb =OLAPLUSDAO.getAllAlarmForGlobalAlarm(slotMasterID, conn);
						LinkedHashMap<Byte, String> allAlarmSeverity =OLAPLUSDAO.getAllAlarmSeverityForGlobalAlarm(slotMasterID, conn);
						byte status = CommonDAO.updateInToDwdmSlotMasterGlobalAlarmStatus(slotMasterID, allAlarmSeverity, allAlarmPresentFromDb, conn);
						//l.info("OLAPLUS Global Alarm Process Completed......"+status);
						System.out.println("OLAPLUS Global Alarm Process Completed......"+status);
					}
					//fiber cut alarm updation in mesh topology
					if (alarmIndex.equals("1"))//ip fail alarm index is 1
					{
					  int nodeId =	Integer.parseInt(slotDetails.get(0));
					  byte oscNumber = 0;
					  byte fiberCutStatus=0;
					  String fiberCardName = slotDetails.get(3);
					  if (fiberCardName.equals("OLA1PLUS"))	
					  {
						  oscNumber = 1;
					  }else if (fiberCardName.equals("OLA2PLUS"))	
					  {
						  oscNumber = 2;
					  }
					  else if (fiberCardName.equals("OLA3PLUS"))	
					  {
						  oscNumber = 3;
					  }
					  else if (fiberCardName.equals("OLA4PLUS"))	
					  {
						  oscNumber = 4;
					  }
					  if(alarmStatus==1){
						  byte oscIPF = OSCDAO.getOSCIPFAlarm(nodeId, oscNumber, conn);
						  if(oscIPF == 1){
							  fiberCutStatus = 1;
						  }
						  else
						  {
							  fiberCutStatus = 0; 
						  }
					  }
					  byte topLineFiberUpdate=FiberCutStatusDAO.updateFiberCutStatus(nodeId, oscNumber, fiberCutStatus, conn);
					  System.out.println("OLA Alarm topline fiber cut Process Completed......status "+topLineFiberUpdate +" updated "+ fiberCutStatus);
					}
				}
			} catch (Exception e) {
				//l.info("OLAPLUS Alarm Processing Error......");
				//l.error(e.getMessage(),e);
				System.out.println("OLAPLUS Alarm Processing Error......");
				e.getMessage();
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
}
