package com.utl.snmp4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;

public class SNMPGet {
	public static final short port=161;
	private static List<VariableBinding> getSNMPV2c(String nodeIP,String community,byte retries,int timeOut,List<VariableBinding> bindings) throws Exception{
		List<VariableBinding> results=new ArrayList<VariableBinding>();
		Snmp snmp = null;
		DefaultUdpTransportMapping transport=null;
		try {
			//Target Address
			StringBuffer addressBuffer=new StringBuffer(nodeIP);
			addressBuffer.append("/");
			addressBuffer.append(port);
			Address targetAddress = new UdpAddress(addressBuffer.toString());
			//Transport Mapping
			transport = new DefaultUdpTransportMapping();
			//Snmp Obj
			snmp = new Snmp(transport);
			transport.listen();
			// setting up target
			CommunityTarget target = new CommunityTarget();
			target.setCommunity(new OctetString(community));
			target.setAddress(targetAddress);
			target.setRetries(retries);
			target.setTimeout(timeOut);
			target.setVersion(SnmpConstants.version2c);
			// creating PDU
			PDU pdu = new PDU();
			pdu.addAll(bindings);
			pdu.setType(PDU.GET);
			//When the request ID is not set or set to zero, the message processing model will generate a unique request ID for the PDU when sent.
			pdu.setRequestID(new Integer32(0));
			// sending request
			ResponseEvent response = snmp.get(pdu, target);
			PDU responsePDU =response.getResponse();
			if(responsePDU!=null){
				int errorStatus = responsePDU.getErrorStatus();
				int errorIndex = responsePDU.getErrorIndex();
				String errorStatusText = responsePDU.getErrorStatusText();
				Vector<? extends VariableBinding> responseVariableBindings = responsePDU.getVariableBindings();
				if (errorStatus == PDU.noError) {
					for (VariableBinding vb : responseVariableBindings) {
						results.add(vb);
					}
				}else{
					//Problem
					StringBuilder excMessage=new StringBuilder(errorStatusText);
					if(errorIndex!=0){
						errorIndex = errorIndex-1;
					}
					excMessage.append(" for OID ("+responseVariableBindings.get(errorIndex).getOid()+") "+nodeIP);
					throw new SNMPException(errorStatus,errorIndex,errorStatusText,excMessage.toString());
				}
			}else{
				throw new Exception("Request timed out "+nodeIP);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(transport!=null){
					transport.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if(snmp!=null){
					snmp.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return results;
	}
	private static List<VariableBinding> getSNMPV2cMultiple(String nodeIP,String community,byte retries,int timeOut,List<VariableBinding> bindings) throws Exception{
		List<VariableBinding> results=new ArrayList<VariableBinding>();
		Snmp snmp = null;
		DefaultUdpTransportMapping transport=null;
		
		try {
			//Target Address
			StringBuffer addressBuffer=new StringBuffer(nodeIP);
			addressBuffer.append("/");
			addressBuffer.append(port);
			Address targetAddress = new UdpAddress(addressBuffer.toString());
			//Transport Mapping
			transport = new DefaultUdpTransportMapping();
			//Snmp Obj
			snmp = new Snmp(transport);
			transport.listen();
			// setting up target
			CommunityTarget target = new CommunityTarget();
			target.setCommunity(new OctetString(community));
			target.setAddress(targetAddress);
			target.setRetries(retries);
			target.setTimeout(timeOut);
			target.setVersion(SnmpConstants.version2c);
			// creating PDU
			for (VariableBinding singleOID : bindings) {
				/*OID aa = vb.getOid();
				System.out.println("oid is "+aa);
				VariableBinding singleOID = new VariableBinding(new OID(aa));*/
									
			PDU pdu = new PDU();
			pdu.add(singleOID);//Single OID one by one from Multiple OIDS
			pdu.setType(PDU.GET);
			//When the request ID is not set or set to zero, the message processing model will generate a unique request ID for the PDU when sent.
			pdu.setRequestID(new Integer32(0));
			// sending request
			ResponseEvent response = snmp.get(pdu, target);
			PDU responsePDU =response.getResponse();
			if(responsePDU!=null){
				int errorStatus = responsePDU.getErrorStatus();
				int errorIndex = responsePDU.getErrorIndex();
				String errorStatusText = responsePDU.getErrorStatusText();
				Vector<? extends VariableBinding> responseVariableBindings = responsePDU.getVariableBindings();
				if (errorStatus == PDU.noError || errorStatus == PDU.genErr) {
					for (VariableBinding vbresult : responseVariableBindings) {
						results.add(vbresult);
					}
				}else{
					//Problem
					StringBuilder excMessage=new StringBuilder(errorStatusText);
					if(errorIndex!=0){
						errorIndex = errorIndex-1;
					}
					excMessage.append(" for OID ("+responseVariableBindings.get(errorIndex).getOid()+") "+nodeIP);
					System.out.println("Error Status Message is "+errorStatusText);
					throw new SNMPException(errorStatus,errorIndex,errorStatusText,excMessage.toString());
				}
			}else{
				throw new Exception("Request timed out "+nodeIP);
			}
			}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(transport!=null){
					transport.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if(snmp!=null){
					snmp.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return results;
	}
	private static Map<Short,VariableBinding> getSNMPV2cMultipleWithIndex(String nodeIP,String community,byte retries,int timeOut,Map<Short,VariableBinding> bindings) throws Exception{
		Map<Short,VariableBinding> results=new HashMap<Short,VariableBinding>();
		Snmp snmp = null;
		DefaultUdpTransportMapping transport=null;
		try {
			//Target Address
			StringBuffer addressBuffer=new StringBuffer(nodeIP);
			addressBuffer.append("/");
			addressBuffer.append(port);
			Address targetAddress = new UdpAddress(addressBuffer.toString());
			//Transport Mapping
			transport = new DefaultUdpTransportMapping();
			//Snmp Obj
			snmp = new Snmp(transport);
			transport.listen();
			// setting up target
			CommunityTarget target = new CommunityTarget();
			target.setCommunity(new OctetString(community));
			target.setAddress(targetAddress);
			target.setRetries(retries);
			target.setTimeout(timeOut);
			target.setVersion(SnmpConstants.version2c);
			Set<Short> indexSet = bindings.keySet();
			for(short index:indexSet){
				VariableBinding singleOID=bindings.get(index);
				// creating PDU
				PDU pdu = new PDU();
				pdu.add(singleOID);
				pdu.setType(PDU.GET);
				//When the request ID is not set or set to zero, the message processing model will generate a unique request ID for the PDU when sent.
				pdu.setRequestID(new Integer32(0));
				// sending request
				ResponseEvent response = snmp.get(pdu, target);
				PDU responsePDU =response.getResponse();
				if(responsePDU!=null){
					int errorStatus = responsePDU.getErrorStatus();
					int errorIndex = responsePDU.getErrorIndex();
					String errorStatusText = responsePDU.getErrorStatusText();
			
					if (errorStatus == PDU.noError || errorStatus == PDU.genErr ) {
						results.put(index, responsePDU.get(0));
					}else{
						//Problem
						StringBuilder excMessage=new StringBuilder(errorStatusText);
						excMessage.append(" for OID ("+singleOID.getOid()+") "+nodeIP);
						throw new SNMPException(errorStatus,errorIndex,errorStatusText,excMessage.toString());
					}
				}else{
					throw new Exception("Request timed out "+nodeIP);
				}
			}
			
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(transport!=null){
					transport.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if(snmp!=null){
					snmp.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return results;
	}
	
	private static VariableBinding getSNMPV2c(String nodeIP,String community,byte retries,int timeOut,VariableBinding binding) throws Exception{
		List<VariableBinding> allVB=new ArrayList<VariableBinding>();
		allVB.add(binding);
		List<VariableBinding> results=getSNMPV2c(nodeIP, community, retries, timeOut, allVB);
		return results.get(0);
	}
	
	public static VariableBinding getSNMP(String nodeIP,String community,byte retries,int timeOut,VariableBinding binding,SNMPVersionDetails versionDetails) throws Exception{
		return getSNMPV2c(nodeIP, community, retries, timeOut, binding);
	}
	
	public static List<VariableBinding> getSNMP(String nodeIP,String community,byte retries,int timeOut,List<VariableBinding> bindings,SNMPVersionDetails versionDetails) throws Exception{
		return getSNMPV2c(nodeIP, community, retries, timeOut, bindings);
	}
	public static Map<Short,VariableBinding> getSNMPMultipleWithIndex(String nodeIP,String community,byte retries,int timeOut,Map<Short,VariableBinding> bindings,SNMPVersionDetails versionDetails) throws Exception{
		return getSNMPV2cMultipleWithIndex(nodeIP, community, retries, timeOut, bindings);
	}
	public static List<VariableBinding> getSNMPMultiple(String nodeIP,String community,byte retries,int timeOut,List<VariableBinding> bindings,SNMPVersionDetails userDetails) throws Exception{
		return getSNMPV2cMultiple(nodeIP, community, retries, timeOut, bindings);
	}
	public static void main(String[] args) {
		
		List<VariableBinding> allVB=new ArrayList<VariableBinding>();
		
		//*************************************************************
		//system mib with balakrishna pc mib2
		
	/*	VariableBinding sysDesc=new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,1,0}));
		VariableBinding sysObjectId=new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,2,0}));
		VariableBinding sysUpTime=new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,3,0}));
		VariableBinding sysContact=new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,4,0}));
		VariableBinding sysName=new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,5,0}));
		VariableBinding sysLocat=new VariableBinding(new OID(new int[]{1,3,6,1,2,1,1,6,0}));
					
		allVB.add(sysName);
		allVB.add(sysObjectId);
		allVB.add(sysUpTime);
		allVB.add(sysContact);
		allVB.add(sysName);
		allVB.add(sysLocat);
		*/
		
		
		//*************************************************************
		//Person Mib
				
				VariableBinding personName=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,1,1}));
				VariableBinding personAge=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,1,2}));
				VariableBinding personContact=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,1,3}));
			
							
				allVB.add(personName);
				allVB.add(personAge);
				allVB.add(personContact);
		
			
		//*************************************************************
		//oba performance
		
		/*VariableBinding wbainput=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,3,4,1,1,1,1,1,1,11}));
		VariableBinding wbaoutput=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,3,4,1,1,2,1,1,1,11}));
					
		allVB.add(wbainput);
		allVB.add(wbaoutput);*/
		
		//*************************************************************
		//ommp82 port traffics zig zag
		/*for (int i = 4; i <= 6; i++) {
			int portNumber= i;
			VariableBinding esOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,14,2,1,1,41,1,1,1,8,portNumber}));
			allVB.add(esOID);
		}
		for (int i = 1; i <= 3; i++) {
			int portNumber= i;
			VariableBinding esOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,14,2,1,1,41,1,1,1,8,portNumber}));
			allVB.add(esOID);
		}
		for (int i = 7; i <= 8; i++) {
			int portNumber= i;
			VariableBinding esOID = new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,14,2,1,1,41,1,1,1,8,portNumber}));
			allVB.add(esOID);
		}
		*/
		try {
			//balakrishna pc with snmp
		//	List<VariableBinding> results=getSNMPV2c("192.168.21.63", "public", (byte) 0, 5000, allVB);
		
			List<VariableBinding> results=getSNMPV2c("192.168.21.152", "public", (byte) 0, 5000, allVB);
			
			for(VariableBinding each:results){
			//	System.out.println(each.getOid()+"   "+each.getVariable().toInt());
				System.out.println(each.getOid()+"   "+each.getVariable().toString());
			}
			System.out.println(results);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
