package com.utl.snmp4j;
import java.io.IOException;

import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
public class snmpSetValue {


	public static void main(String args[]) throws Exception {

		snmpSetValue snmpset = new snmpSetValue();
		snmpset.init();

		ResponseEvent responseEvent =
		snmpset.set("127.0.0.1", 10000, "private", SnmpConstants.version1, ".1.3.6.1.2.1.1.5.0", "elias");
		//snmpset.set("127.0.0.1", 10000, "private", SnmpConstants.version2c, ".1.3.6.1.2.1.1.1.0", "elias");
		
		System.out.println(responseEvent.getResponse());

		snmpset.destroy();
	}


	private Snmp snmp = null;

	public snmpSetValue() {
	}

	public void init() throws IOException {

		TransportMapping transportMapping = new DefaultUdpTransportMapping();
		transportMapping.listen();

		this.snmp = new Snmp(transportMapping);
	}

	public void destroy() throws IOException {

		if (this.snmp != null) {

			this.snmp.close();
			this.snmp = null;
		}
	}

	public ResponseEvent set(String host, long timeout, String community, int version, String oid, String variableText) throws IOException {

		CommunityTarget communityTarget =
				new CommunityTarget(GenericAddress.parse("udp:" + host + "/1612"), new OctetString(community));
		communityTarget.setRetries(0);
		communityTarget.setTimeout(timeout);
		communityTarget.setVersion(version);

		PDU pdu = new PDU();
		pdu.add(new VariableBinding(new OID(oid), new OctetString(variableText)));
		pdu.setType(PDU.SET);

		return snmp.set(pdu, communityTarget);
	}
}