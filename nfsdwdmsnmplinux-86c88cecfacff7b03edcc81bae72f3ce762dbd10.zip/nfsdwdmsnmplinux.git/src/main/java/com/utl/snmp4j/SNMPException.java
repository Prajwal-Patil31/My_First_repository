package com.utl.snmp4j;

public class SNMPException extends Exception{
	private int errorStatus;
	private int errorIndex;
	private String errorStatusText;
	private String message;
	public SNMPException(int errorStatus, int errorIndex,
			String errorStatusText, String message) {
		super(message);
		this.errorStatus = errorStatus;
		this.errorIndex = errorIndex;
		this.errorStatusText = errorStatusText;
		this.message = message;
	}
	public int getErrorStatus() {
		return errorStatus;
	}
	public void setErrorStatus(int errorStatus) {
		this.errorStatus = errorStatus;
	}
	public int getErrorIndex() {
		return errorIndex;
	}
	public void setErrorIndex(int errorIndex) {
		this.errorIndex = errorIndex;
	}
	public String getErrorStatusText() {
		return errorStatusText;
	}
	public void setErrorStatusText(String errorStatusText) {
		this.errorStatusText = errorStatusText;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}
