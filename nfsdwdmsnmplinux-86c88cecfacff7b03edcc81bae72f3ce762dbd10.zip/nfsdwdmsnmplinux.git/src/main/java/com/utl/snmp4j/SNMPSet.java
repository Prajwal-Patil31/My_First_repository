package com.utl.snmp4j;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.snmp4j.CommunityTarget;
import org.snmp4j.PDU;
import org.snmp4j.Snmp;
import org.snmp4j.event.ResponseEvent;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.Integer32;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;

public class SNMPSet {
	public static final short port=1612;
	private static List<VariableBinding> setSNMPV2c(String nodeIP,String community,byte retries,int timeOut,List<VariableBinding> bindings) throws Exception{
		List<VariableBinding> results=new ArrayList<VariableBinding>();
		Snmp snmp = null;
		DefaultUdpTransportMapping transport=null;
		try {
			//Target Address
			StringBuffer addressBuffer=new StringBuffer(nodeIP);
			addressBuffer.append("/");
			addressBuffer.append(port);
			Address targetAddress = new UdpAddress(addressBuffer.toString());
			//Transport Mapping
			transport = new DefaultUdpTransportMapping();
			//Snmp Obj
			snmp = new Snmp(transport);
			transport.listen();
			// setting up target
			CommunityTarget target = new CommunityTarget();
			target.setCommunity(new OctetString(community));
			target.setAddress(targetAddress);
			target.setRetries(retries);
			target.setTimeout(timeOut);
			target.setVersion(SnmpConstants.version2c);
			// creating PDU
			PDU pdu = new PDU();
			pdu.addAll(bindings);
			pdu.setType(PDU.SET);
			//When the request ID is not set or set to zero, the message processing model will generate a unique request ID for the PDU when sent.
			pdu.setRequestID(new Integer32(0));
			// sending request
			ResponseEvent response = snmp.send(pdu, target);
			PDU responsePDU =response.getResponse();
			if(responsePDU!=null){
				int errorStatus = responsePDU.getErrorStatus();
				int errorIndex = responsePDU.getErrorIndex();
				String errorStatusText = responsePDU.getErrorStatusText();
				Vector<? extends VariableBinding> responseVariableBindings = responsePDU.getVariableBindings();
				if (errorStatus == PDU.noError) {
					for (VariableBinding vb : responseVariableBindings) {
						results.add(vb);
					}
				}else{
					//Problem
					StringBuilder excMessage=new StringBuilder(errorStatusText);
					System.out.println(responseVariableBindings);
					excMessage.append(" for OID ("+responseVariableBindings.get(errorIndex-1).getOid()+") "+nodeIP);
					throw new SNMPException(errorStatus,errorIndex,errorStatusText,excMessage.toString());
				}
			}else{
				throw new Exception("Request timed out "+nodeIP);
			}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(transport!=null){
					transport.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				if(snmp!=null){
					snmp.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return results;
	}
	private static VariableBinding setSNMPV2c(String nodeIP,String community,byte retries,int timeOut,VariableBinding binding) throws Exception{
		List<VariableBinding> bindingsList=new ArrayList<VariableBinding>();
		bindingsList.add(binding);
		List<VariableBinding> results= setSNMPV2c(nodeIP, community, retries, timeOut, bindingsList);
		return results.get(0);
	}
	
	public static VariableBinding setSNMP(String nodeIP,String community,byte retries,int timeOut,VariableBinding binding,SNMPVersionDetails versionDetails) throws Exception{
		return setSNMPV2c(nodeIP, community, retries, timeOut, binding);
	}
	public static List<VariableBinding> setSNMP(String nodeIP,String community,byte retries,int timeOut,List<VariableBinding> bindings,SNMPVersionDetails versionDetails) throws Exception{
		return setSNMPV2c(nodeIP, community, retries, timeOut, bindings);
	}
	public static void main(String[] args) {
		List<VariableBinding> allVB=new ArrayList<VariableBinding>();
		
		OctetString name = new OctetString("Patil");
		OctetString age = new OctetString("26");
		OctetString contact = new OctetString("Belgavi");
		
		
		//Integer32 value=new Integer32(1);
	/*	VariableBinding sysDesc=new VariableBinding(new OID(".1.3.6.1.2.1.1.5.0"),var);
		allVB.add(sysDesc);*/
		VariableBinding personName=new VariableBinding(new OID(".1.3.6.1.4.1.18036.1.1.1.1.1"),name);
		allVB.add(personName);
		//VariableBinding personAge=new VariableBinding(new OID(".1.3.6.1.4.1.18036.1.1.1.1.2"),age);
		//allVB.add(personAge);
	//	VariableBinding personContact=new VariableBinding(new OID(".1.3.6.1.4.1.18036.1.1.1.1.3"),contact);
	//	allVB.add(personContact);
		try {
			setSNMPV2c("127.0.0.1", "private", (byte) 0, 2000, allVB);
		} catch (Exception e) {
			 if (e instanceof SNMPException) {
				 SNMPException snmpExce = (SNMPException) e;
					System.out.println(snmpExce.getMessage());
					System.out.println(snmpExce.getErrorStatus());
				}
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}
