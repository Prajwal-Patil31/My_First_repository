package com.utl.snmp4j;

public class SNMPVersionDetails {

}
