package com.utl.dao;

import java.beans.PropertyVetoException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ut.connection.pool.DataSource;

public class NodeGneDetails {
	public  static List<String> getAllNodeIPAddresses() throws Exception{
		Connection conn=null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		List<String> allNodeIPlist=new ArrayList<String>();
		try {
			conn = DataSource.getInstance().getConnection();
			ps=conn.prepareStatement("SELECT router_gateway_gne_ip_address FROM node_details where node_gne='1'");
			rs=ps.executeQuery();
			while(rs.next()){
				allNodeIPlist.add(rs.getString("router_gateway_gne_ip_address"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		} catch (PropertyVetoException e) {
			e.printStackTrace();
			throw e;
		}finally{
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return allNodeIPlist;
	}
	
	public static  void updateNodeGneStatus(String nodeIP,byte nodeGneStatus,Connection conn) throws Exception{
		PreparedStatement ps=null;
		PreparedStatement psDwdm=null;
	//	String cardName="SCC";
		String sccCardStatus="manage";
		try {
			ps=conn.prepareStatement("update node_details set node_gne_status=? where router_gateway_gne_ip_address=?");
			ps.setByte(1, nodeGneStatus);
			ps.setString(2, nodeIP);
			ps.executeUpdate();
			if(nodeGneStatus==0){
				sccCardStatus = "removed";
			}
		//	psDwdm=conn.prepareStatement("update dwdm_master set card_name=? where node_details_id=(SELECT node_details_id FROM node_details where node_ip_address=?) and slot_number=75");
			psDwdm=conn.prepareStatement("UPDATE dwdm_slot_master d join dwdm_subrack_master dw on d.dwdm_subrack_master_id=dw.dwdm_subrack_master_id  join dwdm_rack_master dwd  on dw.dwdm_rack_master_id=dwd.dwdm_rack_master_id join node_details nd on dwd.node_details_id=nd.node_details_id   SET d.card_status=? WHERE nd.router_gateway_gne_ip_address=?  AND  d.card_name='scc'");
			psDwdm.setString(1, sccCardStatus);
			psDwdm.setString(2, nodeIP);
			psDwdm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally{
			try {
				if (ps != null) {
					ps.close();
				}
				/*if (psDwdm != null) {
					psDwdm.close();
				}*/
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
		
	public static  void storeNodeGneSyncAlarmStatus(String nodeIP,byte nodeGneStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		PreparedStatement psForInsert=null;
		PreparedStatement psForUpdate=null;
		PreparedStatement psForSelectNodeId=null;
		ResultSet rsForSelect=null;
		ResultSet rsForSelectNodeId=null;
		long nodeID = 0;
		try {
						
			psForSelectNodeId=conn.prepareStatement("SELECT node_details_id FROM node_details where router_gateway_gne_ip_address=?");
			psForSelectNodeId.setString(1, nodeIP);
			rsForSelectNodeId=psForSelectNodeId.executeQuery();
			if(rsForSelectNodeId.next()){
				 nodeID=rsForSelectNodeId.getLong("node_details_id");
			}
				
					psForSelect = conn.prepareStatement("SELECT node_details_id FROM node_sync_alarm_status where node_details_id=?");
					psForSelect.setLong(1, nodeID);
					rsForSelect = psForSelect.executeQuery();
					if(!rsForSelect.next()){
						psForInsert=conn.prepareStatement("INSERT INTO `node_sync_alarm_status`(`node_details_id`,`node_sync_alarm_status`)VALUES(?,?)");
						psForInsert.setLong(1, nodeID);
						psForInsert.setInt(2, 0);
						psForInsert.executeUpdate();
					
				}else{				
					psForUpdate=conn.prepareStatement("update node_sync_alarm_status set node_sync_alarm_status=? where node_details_id =?");
					psForUpdate.setInt(1, 0);
					psForUpdate.setLong(2, nodeID);
					psForUpdate.executeUpdate();
				}
		
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(rsForSelectNodeId!=null){
					rsForSelectNodeId.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
				if(psForInsert!=null){
					psForInsert.close();
				}
				if(psForUpdate!=null){
					psForUpdate.close();
				}
				if(psForSelectNodeId!=null){
					psForSelectNodeId.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public static  void storeNodeGneStatus(String nodeIP,byte nodeGneStatus, Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		PreparedStatement psForInsert=null;
		PreparedStatement psForUpdate=null;
		PreparedStatement psForSelectNodeId=null;
		ResultSet rsForSelect=null;
		ResultSet rsForSelectNodeId=null;
		try {
			SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date=new Date();
			String strTime=sdf.format(date);
			psForSelectNodeId=conn.prepareStatement("SELECT node_details_id FROM node_details where router_gateway_gne_ip_address=?");
			psForSelectNodeId.setString(1, nodeIP);
			rsForSelectNodeId=psForSelectNodeId.executeQuery();
			if(rsForSelectNodeId.next()){
				long nodeID=rsForSelectNodeId.getLong("node_details_id");
				if (nodeGneStatus==0  ) {
					psForSelect = conn
							.prepareStatement("SELECT node_details_id FROM node_gne_status_report where node_details_id=? and node_gne_up_time is null");
					psForSelect.setLong(1, nodeID);
					rsForSelect = psForSelect.executeQuery();
					if(!rsForSelect.next()){
						psForInsert=conn.prepareStatement("INSERT INTO `node_gne_status_report`(`node_details_id`,`node_gne_down_time`)VALUES(?,?)");
						psForInsert.setLong(1, nodeID);
						psForInsert.setString(2, strTime);
						psForInsert.executeUpdate();
					}
				}else{				
					psForUpdate=conn.prepareStatement("update node_gne_status_report set node_gne_up_time=? where node_details_id =? and node_gne_up_time is null");
					psForUpdate.setString(1, strTime);
					psForUpdate.setLong(2, nodeID);
					psForUpdate.executeUpdate();
				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(rsForSelectNodeId!=null){
					rsForSelectNodeId.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
				if(psForInsert!=null){
					psForInsert.close();
				}
				if(psForUpdate!=null){
					psForUpdate.close();
				}
				if(psForSelectNodeId!=null){
					psForSelectNodeId.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
