package com.utl.dao.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JTextArea;

import com.ut.connection.pool.DataSource;
import com.utl.dao.NodeDetails;
import com.utl.dao.NodeGneDetails;
import com.utl.snmp4j.SNMPVersionDetails;

public class NodeGneStatusPoll implements Runnable{
	
	private String nodeIP;
	String nodeGneStatusStr;
	
	//private String nodeStatus;
	SNMPVersionDetails versionDetails;
	JTextArea messagesArea;
	
	private static final Map<String,Byte> prevNodeGneStatusMap=new HashMap<String,Byte>();
	public NodeGneStatusPoll(String nodeIP, String nodeGneStatusStr){
		this.nodeIP=nodeIP;		
		this.nodeGneStatusStr=nodeGneStatusStr;
		//this.messagesArea=messagesArea;
		//this.nodeStatus=nodeStatus;
	}
	
	@Override
	public void run() {		
		nodeGneStatusStr="down";		
		byte nodeGneStatus=1;
		try {
			GetSystemDescriptionForGNE.getSystemDescription(nodeIP, versionDetails);		
			nodeGneStatusStr="up";			
		} catch (Exception e) {
			e.printStackTrace();
			try {
				GetSystemDescriptionForGNE.getSystemDescription(nodeIP, versionDetails);			
				nodeGneStatusStr="down";
			} catch (Exception e1) {
				e1.printStackTrace();
				nodeGneStatus=0;			
			}
		}
		
		  System.out.println(nodeIP+" "+nodeGneStatusStr+"\n");		
		
		Byte prevNodeGneStatus=prevNodeGneStatusMap.get(nodeIP);

			Connection conn=null;
			try {
				conn = DataSource.getInstance().getConnection();
				NodeGneDetails.updateNodeGneStatus(nodeIP, nodeGneStatus,conn);
				
				if (nodeGneStatus==0  )
					NodeGneDetails.storeNodeGneSyncAlarmStatus(nodeIP, nodeGneStatus,conn);
				
				if(prevNodeGneStatus==null||prevNodeGneStatus!=nodeGneStatus){
					NodeGneDetails.storeNodeGneStatus(nodeIP, nodeGneStatus,conn);
				}	
				prevNodeGneStatusMap.put(nodeIP, nodeGneStatus );
			
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
	}
	
	

}
