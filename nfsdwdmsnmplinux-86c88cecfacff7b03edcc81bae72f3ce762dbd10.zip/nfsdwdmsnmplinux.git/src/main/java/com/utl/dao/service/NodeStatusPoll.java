package com.utl.dao.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JTextArea;

import com.ut.connection.pool.DataSource;
import com.utl.dao.NodeDetails;
import com.utl.snmp4j.SNMPVersionDetails;

public class NodeStatusPoll implements Runnable{
	
	private String nodeIP;
	String nodeStatusStr;
	//private String nodeStatus;
	SNMPVersionDetails versionDetails;
	JTextArea messagesArea;
	private static final Map<String,Byte> prevNodeStatusMap=new HashMap<String,Byte>();
	public NodeStatusPoll(String nodeIP,String nodeStatusStr){
		this.nodeIP=nodeIP;
		this.nodeStatusStr=nodeStatusStr;
		//this.messagesArea=messagesArea;
		//this.nodeStatus=nodeStatus;
	}
	
	@Override
	public void run() {
		nodeStatusStr="down";
		byte nodeStatus=1;
		try {
			GetSystemDescription.getSystemDescription(nodeIP, versionDetails);
			nodeStatusStr="up";
		} catch (Exception e) {
			e.printStackTrace();
			try {
				GetSystemDescription.getSystemDescription(nodeIP, versionDetails);
				nodeStatusStr="down";
			} catch (Exception e1) {
				e1.printStackTrace();
				nodeStatus=0;
			}
		}
		//messagesArea.append(nodeIP+" "+nodeStatusStr+"\n");
		  System.out.println(nodeIP+" "+nodeStatusStr+"\n");
		
		Byte prevNodeStatus=prevNodeStatusMap.get(nodeIP);

			Connection conn=null;
			try {
				conn = DataSource.getInstance().getConnection();
				NodeDetails.updateNodeStatus(nodeIP, nodeStatus,conn);
				
				if (nodeStatus==0)
					NodeDetails.storeNodeSyncAlarmStatus(nodeIP, nodeStatus,conn);
				
				if(prevNodeStatus==null||prevNodeStatus!=nodeStatus){
					NodeDetails.storeNodeStatus(nodeIP, nodeStatus,conn);
				}
				prevNodeStatusMap.put(nodeIP, nodeStatus);
			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(conn!=null){
					try {
						conn.close();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
	}
	
	

}
