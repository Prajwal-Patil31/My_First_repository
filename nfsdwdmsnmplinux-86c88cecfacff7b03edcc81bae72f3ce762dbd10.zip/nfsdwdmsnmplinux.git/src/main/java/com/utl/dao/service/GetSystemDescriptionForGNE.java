package com.utl.dao.service;

import org.snmp4j.smi.OID;
import org.snmp4j.smi.Variable;
import org.snmp4j.smi.VariableBinding;

import com.utl.snmp4j.SNMPGet;
import com.utl.snmp4j.SNMPVersionDetails;

public class GetSystemDescriptionForGNE {
		
	private final static String community="public";
	private final static byte retries=0;
	private final static short timeOut=5000;
	public static String getSystemDescription(String nodeIP,SNMPVersionDetails versionDetails)  throws Exception{
		VariableBinding OID=new VariableBinding(new OID(new int[]{1,3,6,1,4,1,18036,1,1,1,1,1,1,1,12,1,1,2,254,0}));
	//	.1.3.6.1.4.1.18036.1.1.1.1.1.1.1.12.1.1.2.254.0
		String receiveResult=null;
		try {
			VariableBinding resultEachVB=SNMPGet.getSNMP(nodeIP, community, retries, timeOut, OID,  versionDetails);
			receiveResult = resultEachVB.getVariable().toString();
		} catch (Exception e) {
			throw e;
		}
		return receiveResult;		
	}
}
