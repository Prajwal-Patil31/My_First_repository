package com.utl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.ut.connection.pool.DataSource;

public class ServiceSettings {
	public static short[] getServiceSettings() throws Exception{
		Connection conn = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		short intervals[]=new short[2];
		try{
			conn = DataSource.getInstance().getConnection();
			ps=conn.prepareStatement("SELECT node_status_polling_minutes,performance_status_polling_minutes FROM service_settings limit 1");

			rs=ps.executeQuery();
			
			if (rs.next()) {			
				intervals[0]=rs.getShort("node_status_polling_minutes");
				intervals[1]=rs.getShort("performance_status_polling_minutes");
			}else{
				intervals[0]=1;
				intervals[1]=15;
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		return intervals;
	}
	
	public static String[] getServiceSettingsForSocket() throws Exception{
		Connection conn = null;
		PreparedStatement ps=null;
		ResultSet rs=null;
		String nodeIP[]=new String[2];
		try{
			conn = DataSource.getInstance().getConnection();
			ps=conn.prepareStatement("SELECT retreive_perfromance_ip,retreive_alarm_ip FROM service_settings limit 1");

			rs=ps.executeQuery();
			
			if (rs.next()) {			
				nodeIP[0]=rs.getString("retreive_perfromance_ip");
				nodeIP[1]=rs.getString("retreive_alarm_ip");
			}
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		return nodeIP;
	}
}
