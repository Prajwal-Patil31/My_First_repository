package com.utl.util;

import java.sql.Connection;

import com.utl.trap.receiver.ommp100.OMMP100BL;
import com.utl.trap.receiver.ommp81plus.OMMP81PLUSBL;
import com.utl.trap.receiver.ommp82plus.OMMP82PLUSBL;
import com.utl.trap.receiver.omtp11plus.OMTP11PLUSBL;
import com.utl.trap.receiver.omtp12.OMTP12PLUSBL;

public class UpdateTrafficForLineCards {
	public static void refreshTrafficForAllLineCards(short nodeNumber,short rackNumber,short subrackNumber,short slotNumber,String nodeIP, String cardName, int slotMasterID,Connection conn) throws Exception{
		try {


			switch(cardName){
			case "10GOMTP11PLUS":
				try {
					OMTP11PLUSBL.retrievePortTrafficNames(nodeNumber, (byte)rackNumber, subrackNumber, (byte)slotNumber, nodeIP, cardName, slotMasterID,conn);
				} catch (Exception e) {
					throw e;
				}
				break;
			case "10GOMTP12PLUS":
				try {
					OMTP12PLUSBL.retrievePortTrafficNames(nodeNumber, (byte)rackNumber, subrackNumber, (byte)slotNumber, nodeIP, cardName, slotMasterID,conn);
				} catch (Exception e) {
					throw e;
				}
				break;
			case "10GOMMP81PLUS":
				try {
					OMMP81PLUSBL.retrievePortTrafficNames(nodeNumber, (byte)rackNumber, subrackNumber, (byte)slotNumber, nodeIP, cardName, slotMasterID,conn);
				} catch (Exception e) {
					throw e;
				}
				break;
			case "10GOMMP82PLUS":
				try {
					OMMP82PLUSBL.retrievePortTrafficNames(nodeNumber, (byte)rackNumber, subrackNumber, (byte)slotNumber, nodeIP, cardName, slotMasterID,conn);
				} catch (Exception e) {
					throw e;
				}
				break;
			case "OMMP100":
				try {
					OMMP100BL.retrievePortTrafficNames(nodeNumber, (byte)rackNumber, subrackNumber, (byte)slotNumber, nodeIP, cardName, slotMasterID,conn);
				} catch (Exception e) {
					throw e;
				}
				break;
			}
			

		} catch (Exception e) {
			throw e;
		}
		
	}
}
