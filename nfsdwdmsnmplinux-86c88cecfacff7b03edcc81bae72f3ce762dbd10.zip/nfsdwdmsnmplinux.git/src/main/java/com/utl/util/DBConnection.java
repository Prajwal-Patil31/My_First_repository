package com.utl.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	
    static String dbname = "nfsdwdmdb";
    
 	
 // get mySql database connection 
    public static Connection getMYSQLDBConn() throws ClassNotFoundException, SQLException,IOException {

    	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		InputStream file =classLoader.getResourceAsStream("/database.properties");

    	
		Properties databaseProp = new Properties();
		databaseProp.load(file);
		String ip=databaseProp.getProperty("mysql.server.ip");
		String port=databaseProp.getProperty("mysql.server.port");
		String user=databaseProp.getProperty("mysql.server.user");
		String password=databaseProp.getProperty("mysql.server.password");
        Connection conn = null;
        String url = "jdbc:mysql://"+ip+":"+port+"/";
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection(url + dbname+"?zeroDateTimeBehavior=convertToNull&autoReconnect=true&useSSL=false",user,password);
        return conn;
    }
    
    // get mySql database connection 
    public static Connection getDBConnectionOSNR() throws ClassNotFoundException, SQLException,IOException {

    	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
		//InputStream file =classLoader.getResourceAsStream("/database.properties");

    	
		//Properties databaseProp = new Properties();
		//databaseProp.load(file);
		String ip="localhost";
		String port="3306";
		String user="root";
		String password="admin";
        Connection conn = null;
        String url = "jdbc:mysql://"+ip+":"+port+"/";
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection(url + dbname+"?zeroDateTimeBehavior=convertToNull",user,password);
        return conn;
    }
 
}