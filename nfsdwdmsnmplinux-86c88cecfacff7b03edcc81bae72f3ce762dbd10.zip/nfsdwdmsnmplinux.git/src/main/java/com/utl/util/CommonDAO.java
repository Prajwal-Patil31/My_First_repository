package com.utl.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

//import org.apache.log4j.Logger;


import com.utl.trap.receiver.ReceivedTrapDetails;
import com.utl.trap.receiver.ReceivedTrapDetailsForBMU;
import com.utl.trap.receiver.ReceivedTrapDetailsForSWUpgrade;

public class CommonDAO {
	
	//static Logger l = Logger.getLogger(CommonDAO.class);
	
	public static byte updateInToDwdmSlotMasterGlobalAlarmStatus(long dwdmSlotMasterID,
			LinkedHashMap<Byte, String> alarmSeverity,
			LinkedHashMap<Byte, Byte> alarms, Connection conn) throws Exception {
		PreparedStatement ps = null;
		byte alarmStatus = 0;
		byte alarmValue;
		String alarmSeverityValue;
		byte updateStatus=0;
		
		try {
			System.out.println("Update Global Alarm For Card In DWDM Slot Master");
			System.out.println("alarms.size() outside::"+alarms.size());
			for (byte alarm = 1; alarm <= alarms.size(); alarm++) {
		//		System.out.println("alarms.size()::"+alarms.size());
		//		System.out.println("dwdmSlotMasterID::"+dwdmSlotMasterID);
				alarmValue = alarms.get(alarm);
		//		System.out.println("alarmValue::"+alarmValue);
				if (alarmValue != 0) {
					alarmSeverityValue = alarmSeverity.get(alarm);
					switch (alarmSeverityValue) {
					case "Critical":
						alarmStatus = 1;
						break;
					case "Major":
						if (alarmStatus != 1) {
							alarmStatus = 2;
						}
						break;
					case "Minor":
						if (alarmStatus != 1 && alarmStatus != 2) {
							alarmStatus = 3;
						}
						break;
					case "Deferred":
						if (alarmStatus != 1 && alarmStatus != 2
								&& alarmStatus != 3) {
							alarmStatus = 4;
						}
						break;
					case "Inhibit":
						if (alarmStatus != 1 && alarmStatus != 2
								&& alarmStatus != 3 && alarmStatus != 4) {
							alarmStatus = 0;
						}
						break;
					}
				}
			}
			
			ps = conn
					.prepareStatement("update dwdm_slot_master set global_alarm_status=? where dwdm_slot_master_id=?");
			ps.setByte(1, alarmStatus);
			ps.setLong(2, dwdmSlotMasterID);
			updateStatus=(byte) ps.executeUpdate();
		} catch (Exception e1) {
			System.out.println("Update Global Alarm For Card In DWDM Slot Master Error");
			e1.getMessage();
			throw e1;
		}
		try {

			if (ps != null) {
				ps.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updateStatus;
	}
	
	public static byte updateInToDwdmSlotMasterGlobalAlarmStatusSCCOSCAlarms(long dwdmSlotMasterID,
			LinkedHashMap<Short, String> alarmSeverity,
			LinkedHashMap<Short, Short> alarms, Connection conn) throws Exception {
		PreparedStatement ps = null;
		byte alarmStatus = 0;
		Short alarmValue;
		String alarmSeverityValue;
		byte updateStatus=0;
		
		try {
			System.out.println("Update Global Alarm For Card In DWDM Slot Master");
			System.out.println("alarms.size() outside::"+alarms.size());
			for (Short alarm = 1; alarm <= alarms.size(); alarm++) {
		//		System.out.println("alarms.size()::"+alarms.size());
		//		System.out.println("dwdmSlotMasterID::"+dwdmSlotMasterID);
				alarmValue = alarms.get(alarm);
		//		System.out.println("alarmValue::"+alarmValue);
				if (alarmValue != 0) {
					alarmSeverityValue = alarmSeverity.get(alarm);
					switch (alarmSeverityValue) {
					case "Critical":
						alarmStatus = 1;
						break;
					case "Major":
						if (alarmStatus != 1) {
							alarmStatus = 2;
						}
						break;
					case "Minor":
						if (alarmStatus != 1 && alarmStatus != 2) {
							alarmStatus = 3;
						}
						break;
					case "Deferred":
						if (alarmStatus != 1 && alarmStatus != 2
								&& alarmStatus != 3) {
							alarmStatus = 4;
						}
						break;
					case "Inhibit":
						if (alarmStatus != 1 && alarmStatus != 2
								&& alarmStatus != 3 && alarmStatus != 4) {
							alarmStatus = 0;
						}
						break;
					}
				}
			}
			
			ps = conn
					.prepareStatement("update dwdm_slot_master set global_alarm_status=? where dwdm_slot_master_id=?");
			ps.setByte(1, alarmStatus);
			ps.setLong(2, dwdmSlotMasterID);
			updateStatus=(byte) ps.executeUpdate();
		} catch (Exception e1) {
			System.out.println("Update Global Alarm For Card In DWDM Slot Master Error");
			e1.getMessage();
			throw e1;
		}
		try {

			if (ps != null) {
				ps.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updateStatus;
	}
	public static byte updateInToDwdmLineCardsGlobalAlarmStatusAlarms(long dwdmSlotMasterID,
			LinkedHashMap<Short, String> alarmSeverity,
			LinkedHashMap<Short, Byte> alarms, Connection conn) throws Exception {
		PreparedStatement ps = null;
		byte alarmStatus = 0;
		Byte alarmValue;
		String alarmSeverityValue;
		byte updateStatus=0;
		
		try {
			System.out.println("Update Global Alarm For Card In DWDM Slot Master");
			System.out.println("alarms.size() outside::"+alarms.size());
			for (Short alarm = 1; alarm <= alarms.size(); alarm++) {
		//		System.out.println("alarms.size()::"+alarms.size());
		//		System.out.println("dwdmSlotMasterID::"+dwdmSlotMasterID);
				alarmValue = alarms.get(alarm);
		//		System.out.println("alarmValue::"+alarmValue);
				if (alarmValue != 0) {
					alarmSeverityValue = alarmSeverity.get(alarm);
					switch (alarmSeverityValue) {
					case "Critical":
						alarmStatus = 1;
						break;
					case "Major":
						if (alarmStatus != 1) {
							alarmStatus = 2;
						}
						break;
					case "Minor":
						if (alarmStatus != 1 && alarmStatus != 2) {
							alarmStatus = 3;
						}
						break;
					case "Deferred":
						if (alarmStatus != 1 && alarmStatus != 2
								&& alarmStatus != 3) {
							alarmStatus = 4;
						}
						break;
					case "Inhibit":
						if (alarmStatus != 1 && alarmStatus != 2
								&& alarmStatus != 3 && alarmStatus != 4) {
							alarmStatus = 0;
						}
						break;
					}
				}
			}
			
			ps = conn
					.prepareStatement("update dwdm_slot_master set global_alarm_status=? where dwdm_slot_master_id=?");
			ps.setByte(1, alarmStatus);
			ps.setLong(2, dwdmSlotMasterID);
			updateStatus=(byte) ps.executeUpdate();
		} catch (Exception e1) {
			System.out.println("Update Global Alarm For Card In DWDM Slot Master Error");
			e1.getMessage();
			throw e1;
		}
		try {

			if (ps != null) {
				ps.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return updateStatus;
	}
	
	public static List<String> getSlotDetails(ReceivedTrapDetails trapDetails,Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		List<String> slotDetails=null;
		try {
			if(trapDetails!=null){
				psForSelect=conn.prepareStatement("SELECT node.node_details_id,dwdm_slot_master_id,card_name,subrack.dwdm_subrack_master_id FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id  where node_ip_address=? and rack.rack_number=? and subrack.subrack_number=? and slot.slot_number=?");
				psForSelect.setString(1, trapDetails.getNodeIP());
	//			System.out.println("trapDetails.getNodeIP()::"+trapDetails.getNodeIP());
				psForSelect.setShort(2, trapDetails.getRack());
	//			System.out.println("trapDetails.getRack()::"+trapDetails.getRack());
				psForSelect.setShort(3, trapDetails.getSubRack());
	//			System.out.println("trapDetails.getSubRack()::"+trapDetails.getSubRack());
				psForSelect.setShort(4, trapDetails.getSlot());
	//			System.out.println("trapDetails.getSlot()::"+trapDetails.getSlot());
				rsForSelect=psForSelect.executeQuery();
				if(rsForSelect.next()){
					slotDetails=new ArrayList<String>();
					slotDetails.add(rsForSelect.getString("node_details_id"));
				//	System.out.println("rsForSelect.getString(node_details_id)::"+rsForSelect.getString("node_details_id"));
					slotDetails.add(rsForSelect.getString("dwdm_slot_master_id"));
					slotDetails.add(rsForSelect.getString("dwdm_subrack_master_id"));
				//	System.out.println("rsForSelect.getString(dwdm_slot_master_id)::"+rsForSelect.getString("dwdm_slot_master_id"));
					slotDetails.add(rsForSelect.getString("card_name"));
				}
			}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return slotDetails;
	}
	
	public static List<String> getSlotDetailsForBMU(ReceivedTrapDetailsForBMU trapDetails,Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		List<String> slotDetails=null;
		try {
			if(trapDetails!=null){
				psForSelect=conn.prepareStatement("SELECT node.node_details_id,dwdm_slot_master_id FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id  where node_ip_address=? and rack.rack_number=? and subrack.subrack_number=? and slot.slot_number=?");
				psForSelect.setString(1, trapDetails.getNodeIP());
		//		System.out.println("trapDetails.getNodeIP()::"+trapDetails.getNodeIP());
				psForSelect.setShort(2, trapDetails.getRack());
		//		System.out.println("trapDetails.getRack()::"+trapDetails.getRack());
				psForSelect.setShort(3, trapDetails.getSubRack());
		//		System.out.println("trapDetails.getSubRack()::"+trapDetails.getSubRack());
				psForSelect.setShort(4, trapDetails.getSlot());
		//		System.out.println("trapDetails.getSlot()::"+trapDetails.getSlot());
				rsForSelect=psForSelect.executeQuery();
				if(rsForSelect.next()){
					slotDetails=new ArrayList<String>();
					slotDetails.add(rsForSelect.getString("node_details_id"));
			//		System.out.println("rsForSelect.getString(node_details_id)::"+rsForSelect.getString("node_details_id"));
					slotDetails.add(rsForSelect.getString("dwdm_slot_master_id"));
			//		System.out.println("rsForSelect.getString(dwdm_slot_master_id)::"+rsForSelect.getString("dwdm_slot_master_id"));
				}
			}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return slotDetails;
	}
	
	public static List<String> getSlotDetailsForSWUpgrade(ReceivedTrapDetailsForSWUpgrade trapDetails,Connection conn) throws Exception{
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		List<String> slotDetails=null;
		try {
			if(trapDetails!=null){
				psForSelect=conn.prepareStatement("SELECT node.node_details_id,dwdm_slot_master_id FROM node_details node join dwdm_rack_master rack on node.node_details_id=rack.node_details_id join dwdm_subrack_master subrack on rack.dwdm_rack_master_id=subrack.dwdm_rack_master_id join dwdm_slot_master slot on subrack.dwdm_subrack_master_id=slot.dwdm_subrack_master_id  where node_ip_address=? and rack.rack_number=? and subrack.subrack_number=? and slot.slot_number=?");
				psForSelect.setString(1, trapDetails.getNodeIP());
		//		System.out.println("trapDetails.getNodeIP()::"+trapDetails.getNodeIP());
				psForSelect.setShort(2, trapDetails.getRack());
		//		System.out.println("trapDetails.getRack()::"+trapDetails.getRack());
				psForSelect.setShort(3, trapDetails.getSubRack());
		//		System.out.println("trapDetails.getSubRack()::"+trapDetails.getSubRack());
				psForSelect.setShort(4, trapDetails.getSlot());
		//		System.out.println("trapDetails.getSlot()::"+trapDetails.getSlot());
				rsForSelect=psForSelect.executeQuery();
				if(rsForSelect.next()){
					slotDetails=new ArrayList<String>();
					slotDetails.add(rsForSelect.getString("node_details_id"));
			//		System.out.println("rsForSelect.getString(node_details_id)::"+rsForSelect.getString("node_details_id"));
					slotDetails.add(rsForSelect.getString("dwdm_slot_master_id"));
			//		System.out.println("rsForSelect.getString(dwdm_slot_master_id)::"+rsForSelect.getString("dwdm_slot_master_id"));
				}
			}
		} catch (Exception e) {
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return slotDetails;
	}
	public static int getPortMasterID(int slotMasterID,int port,Connection conn) throws Exception
	{
		int portMasterID=0;
		int portNo=0;
		PreparedStatement psForSelect=null;
		ResultSet rsForSelect=null;
		String port_client_line_type=null;
		if(port>8)
		{
			port_client_line_type="line";
			portNo=port-8;
		}
		else
		{
			port_client_line_type="client";
			portNo=port;
		}
		try
		{
			psForSelect=conn.prepareStatement("SELECT dwdm_port_master_id FROM dwdm_port_master where dwdm_slot_master_id=? and port_number=? and port_client_line_type=?");
			psForSelect.setInt(1, slotMasterID);
			psForSelect.setInt(2, portNo);
			psForSelect.setString(3, port_client_line_type);
			rsForSelect=psForSelect.executeQuery();
			if(rsForSelect.next()){
				portMasterID=rsForSelect.getInt("dwdm_port_master_id");
			}
			
		}
		catch (Exception e) {
			throw e;
		}finally{
			try {
				if(rsForSelect!=null){
					rsForSelect.close();
				}
				if(psForSelect!=null){
					psForSelect.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return portMasterID;
	}
}
