package com.utl.util;

import java.util.ArrayList;
import java.util.List;

public class ArrayToStringArray {
	public static List<StringArray> convertDoubleDimensionToList(String[][] result){
		List<StringArray> convertedResult=new ArrayList<StringArray>();
		if(result!=null){
		for(int i=0;i<result.length;i++){
			List<String> eachRowList=new ArrayList<String>();
			for(int j=0;j<result[i].length;j++){
				eachRowList.add(result[i][j]);
			}
			convertedResult.add(new StringArray(eachRowList));
		}
		}
		return convertedResult;
	}
	
	public static List<String> convertSingleDimensionToList(String[] result){
		List<String> convertedResult=new ArrayList<String>();
		if(result!=null){
		for(int i=0;i<result.length;i++){
			convertedResult.add(result[i]);
		}
		}
		return convertedResult;
	}
	
	public static int[] convertListToSingleDimensionInt(List<Integer> result){
		int[] convertedResult=new int[result.size()];
		Integer eachI;
		if(result!=null){
		for(int i=0;i<result.size();i++){
			eachI=result.get(i);
			if(eachI!=null)
			convertedResult[i]=eachI;
		}
	}
		return convertedResult;
	}
	
	public static byte[] convertListToSingleDimensionByte(List<Byte> result){
		byte[] convertedResult=new byte[result.size()];
		Byte eachB;
		if(result!=null){
		for(int i=0;i<result.size();i++){
			eachB=result.get(i);
			if(eachB!=null)
			convertedResult[i]=eachB;
		}
	}
		return convertedResult;
	}
	
	public static String[] convertListToSingleDimensionString(List<String> result){
		String[] convertedResult=new String[result.size()];
		if(result!=null){
		for(int i=0;i<result.size();i++){
			convertedResult[i]=result.get(i);
		}
		}
		return convertedResult;
	}
	
	public static List<Integer> convertSingleDimensionIntToList(int[] result){
		List<Integer> convertedResult=new ArrayList<Integer>();
		if(result!=null){
		for(int i=0;i<result.length;i++){
			convertedResult.add(result[i]);
		}
		}
		return convertedResult;
	}
	
	public static List<Double> convertSingleDimensionDoubleToList(double[] result){
		List<Double> convertedResult=new ArrayList<Double>();
		if(result!=null){
		for(int i=0;i<result.length;i++){
			convertedResult.add(result[i]);
		}
		}
		return convertedResult;
	}
	
	public static List<byte[]> convertDoubleDimensionByteToList(byte[][] result){
		List<byte[]> convertedResult=new ArrayList<byte[]>();
		if(result!=null){
		for(int i=0;i<result.length;i++){
			convertedResult.add(result[i]);
		}
		}
		return convertedResult;
	}
}
