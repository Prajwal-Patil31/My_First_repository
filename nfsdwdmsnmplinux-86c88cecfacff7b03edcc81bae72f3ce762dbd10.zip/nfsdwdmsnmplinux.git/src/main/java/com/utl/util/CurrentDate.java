package com.utl.util;

import java.sql.Timestamp;

public class CurrentDate {
	public static Timestamp getCurrentDate() {
	    java.util.Date today = new java.util.Date();
	    return new Timestamp(today.getTime());
	}
	public static void main(String a[]){
		System.out.println(getCurrentDate());
	}
}
