package com.utl.util;
import java.util.*;
public class ConvertingStringToHashMap {

	public HashMap<Integer,String> convertStringToHashmap(String converString)
	{
		converString = converString.substring(0, converString.length()-1);           //remove curly brackets
		String[] keyValuePairs = converString.split(",");              //split the string to creat key-value pairs
		HashMap<Integer,String> map = new HashMap<>();               

		for(String pair : keyValuePairs)                        //iterate over the pairs
		{
		    String[] entry = pair.split(":");                   //split the pairs to get key and value 
		    map.put(Integer.parseInt(entry[0].trim()), entry[1].trim());          //add them to the hashmap and trim whitespaces
		}
		return map;
	}
	
}
