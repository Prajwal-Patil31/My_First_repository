package com.utl.util;

import java.io.InputStream;
import java.util.Properties;

public class GetDetailsFromPropertiesFile {
	static Properties info = null;

	public static String getValue(String key) throws Exception{
		if(info==null){
			String resourceName = "info.properties"; // could also be a constant
			ClassLoader loader = Thread.currentThread().getContextClassLoader();
			try(InputStream resourceStream = loader.getResourceAsStream(resourceName)) {
				info=new Properties();
				info.load(resourceStream);
			}
		}
		return (String)info.get(key);
	}
}
