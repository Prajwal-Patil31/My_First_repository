
package com.utl.util;

import java.util.ArrayList;
import java.util.List;


public class StringArray {

    private List<String> item;

    public List<String> getItem() {
        if (item == null) {
            item = new ArrayList<String>();
        }
        return this.item;
    }

    public StringArray(List<String> item) {
		super();
		this.item = item;
	}

	public void setItem(List<String> item) {
         this.item=item;
    }
}
