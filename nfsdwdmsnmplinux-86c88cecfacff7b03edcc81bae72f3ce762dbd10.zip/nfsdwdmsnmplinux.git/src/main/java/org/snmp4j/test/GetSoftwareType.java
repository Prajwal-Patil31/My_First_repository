package org.snmp4j.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class GetSoftwareType {
	public static String getType() throws IOException{
		String softwareType = null;
		try {
			InputStream file = new FileInputStream("networkType.properties");
			Properties dwdmInfo = new Properties();
			dwdmInfo.load(file);
			softwareType = (String) dwdmInfo.get("software");
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		return softwareType;
	}
	public static String getServerIP() throws IOException{
		String serverIP = null;
		try {
			InputStream file = new FileInputStream("networkType.properties");
			Properties dwdmInfo = new Properties();
			dwdmInfo.load(file);
			serverIP = (String) dwdmInfo.get("emsip");
		} catch (IOException e) {
			e.printStackTrace();
			throw e;
		}
		return serverIP;
	}
}
