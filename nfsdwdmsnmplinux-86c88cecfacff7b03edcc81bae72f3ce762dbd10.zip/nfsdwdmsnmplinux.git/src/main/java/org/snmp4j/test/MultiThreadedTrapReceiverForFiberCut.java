/*_############################################################################
  _## 
  _##  SNMP4J 2 - MultiThreadedTrapReceiver.java  
  _## 
  _##  Copyright (C) 2003-2013  Frank Fock and Jochen Katz (SNMP4J.org)
  _##  
  _##  Licensed under the Apache License, Version 2.0 (the "License");
  _##  you may not use this file except in compliance with the License.
  _##  You may obtain a copy of the License at
  _##  
  _##      http://www.apache.org/licenses/LICENSE-2.0
  _##  
  _##  Unless required by applicable law or agreed to in writing, software
  _##  distributed under the License is distributed on an "AS IS" BASIS,
  _##  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  _##  See the License for the specific language governing permissions and
  _##  limitations under the License.
  _##  
  _##########################################################################*/

package org.snmp4j.test;

import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.net.BindException;
import java.net.ServerSocket;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import org.snmp4j.CommandResponder;
import org.snmp4j.CommandResponderEvent;
import org.snmp4j.MessageDispatcherImpl;
import org.snmp4j.Snmp;
import org.snmp4j.TransportMapping;
import org.snmp4j.mp.MPv1;
import org.snmp4j.mp.MPv2c;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.SecurityModels;
import org.snmp4j.security.SecurityProtocols;
import org.snmp4j.security.USM;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.GenericAddress;
import org.snmp4j.smi.OctetString;
import org.snmp4j.smi.TcpAddress;
import org.snmp4j.smi.UdpAddress;
import org.snmp4j.transport.DefaultTcpTransportMapping;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.MultiThreadedMessageDispatcher;
import org.snmp4j.util.ThreadPool;

import com.ut.connection.pool.DataSource;
import com.utl.trap.receiver.StoreTrapInToDB;
import com.utl.trap.receiver.StoreTrapInToDBForFiberCut;

import org.snmp4j.test.GetSoftwareType;
import org.snmp4j.test.DebugInformationTrapReceiver;


public class MultiThreadedTrapReceiverForFiberCut implements CommandResponder, Runnable{


  // initialize Log4J logging
/*
  static {
    LogFactory.setLogFactory(new Log4jLogFactory());
    BER.setCheckSequenceLength(false);
  }
*/ public static MultiThreadedTrapReceiverForFiberCut multiThreadedTrapReceiverObj;
    ////For window
	JButton clearButton;
    public JTextArea messagesArea;
    public static JScrollPane messagesScroll;
    MenuBar theMenubar;
    Menu fileMenu;
    MenuItem aboutItem, quitItem;
    PipedReader errorReader;
    PipedWriter errorWriter;
    static Thread readerThread;
    private MenuItem debugItem;     
    JTextField hostIDField, communityField, OIDField, valueField, enterpriseField, agentField;
    JLabel authorLabel, hostIDLabel, communityLabel, OIDLabel, valueLabel, enterpriseLabel, agentLabel, genericTrapLabel, specificTrapLabel;
    JComboBox valueTypeBox, genericTrapBox, specificTrapBox;
    /////////////////////////    
	
    static ThreadPoolExecutor executorServiceObj=null;
    static ServerSocket serverSocketObj=null;
    
  private MultiThreadedMessageDispatcher dispatcher;
  private Snmp snmp = null;
  private Address listenAddress;
  private ThreadPool threadPool;

  private int n = 0;
  private long start = -1;
 // private long displayCounter = 1;
  private final static byte THREAD_POOL_SIZE=20;//if ems change 20 to 50
  // WindowCloseAdapter to catch window close-box closings
  private class WindowCloseAdapter extends WindowAdapter
  { 
      public void windowClosing(WindowEvent e)
      {   
    	if (readerThread!=null) {
				readerThread.interrupt();
		}
    	 if(serverSocketObj!=null){
         	try {
					serverSocketObj.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
         }
		System.exit(0);
      }
  };

  public MultiThreadedTrapReceiverForFiberCut() {
//    BasicConfigurator.configure();
	  try
      {
		
			//setIconImage(Toolkit.getDefaultToolkit().getImage(MultiThreadedTrapReceiver.class.getResource("/icons/utl.PNG")));
        	System.setProperty("com.mchange.v2.log.MLog",
    				"com.mchange.v2.log.FallbackMLog");
    		System.setProperty(
    				"com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL",
    				"SEVERE");
          // setUpDisplay();
    
    	
      /*     errorReader = new PipedReader();
            errorWriter = new PipedWriter(errorReader);
            
           readerThread = new Thread(this);
            readerThread.setName("SNMPTrapReceiverDWDM");
            readerThread.start();
*/
        
            
            
		  
		 /* this.addWindowListener(new WindowAdapter() {
	  		public void windowIconified(WindowEvent e){	
	  	    	setVisible(false);    	
	  	    }
			});*/
      }
	  catch(Exception e)
      {
		  
      }
	/*   catch(BindException e)
      {
          messagesArea.append("Problem starting Trap Test: " + e.toString() + "\n");
          JOptionPane.showMessageDialog(this, "Problem with starting Trap Receiver .Address  already bind", "DWDM 10G Trap Receiver", JOptionPane.WARNING_MESSAGE);
          System.exit(0);
      }
      catch(Exception e)
      {
          messagesArea.append("Problem starting Trap Test: " + e.toString() + "\n");
          JOptionPane.showMessageDialog(this, "Problem with starting Trap Receiver ."+e.toString(), "DWDM 10G Trap Receiver", JOptionPane.WARNING_MESSAGE);
          System.exit(0);
      }*/
  }

  
  //for adding window
  private void setUpDisplay()
  {   
    /*  this.setTitle("UTL - MP - 0072 Spectrum DWDM Trap Service");
          
      this.getRootPane().setBorder(new BevelBorder(BevelBorder.RAISED));
      
    
      addWindowListener(new WindowCloseAdapter());

      
      theMenubar = new MenuBar();
      this.setMenuBar(theMenubar);
      fileMenu = new Menu("File");
      
      aboutItem = new MenuItem("About");
      aboutItem.setActionCommand("about");
      aboutItem.addActionListener(this);

      
      debugItem = new MenuItem("Debug");
      debugItem.setActionCommand("debug");
      debugItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				DebugInformationTrapReceiver dialog = new DebugInformationTrapReceiver();
			}
		});

      
      
      fileMenu.addSeparator();
      
      quitItem = new MenuItem("Quit");
      quitItem.setActionCommand("quit");
      quitItem.addActionListener( this);
      fileMenu.add(quitItem);
      
      theMenubar.add(fileMenu);
      
      
      authorLabel = new JLabel("Version 1.0");
      authorLabel.setFont(new Font("SansSerif", Font.ITALIC, 12));
          
      
      clearButton = new JButton("Clear messages");
      clearButton.setActionCommand("clear messages");
      clearButton.addActionListener(this);
      
      messagesArea = new JTextArea(10,60);
      messagesScroll = new JScrollPane(messagesArea);
            
      // now set up display
    
      // set params for layout manager
      GridBagLayout  theLayout = new GridBagLayout();
      GridBagConstraints c = new GridBagConstraints();
      
      c.gridwidth = 1;
      c.gridheight = 1;
      c.fill = GridBagConstraints.NONE;
      c.ipadx = 0;
      c.ipady = 0;
      c.insets = new Insets(2,2,2,2);
      c.anchor = GridBagConstraints.CENTER;
      c.weightx = 0;
      c.weighty = 0;              
      
      JPanel messagesPanel = new JPanel();
      messagesPanel.setLayout(theLayout);
      
      c.gridx = 1;
      c.gridy = 1;
      c.anchor = GridBagConstraints.WEST;
      JLabel messagesLabel = new JLabel("Received traps:");
      theLayout.setConstraints(messagesLabel, c);
      messagesPanel.add(messagesLabel);
      
      c.gridx = 2;
      c.gridy = 1;
      c.anchor = GridBagConstraints.EAST;
      theLayout.setConstraints(clearButton, c);
      messagesPanel.add(clearButton);
      
      c.fill = GridBagConstraints.BOTH;
      c.gridx = 1;
      c.gridy = 2;
      c.gridwidth = 2;
      c.weightx = .5;
      c.weighty = .5;
      c.anchor = GridBagConstraints.CENTER;
      theLayout.setConstraints(messagesScroll, c);
      messagesPanel.add(messagesScroll);      
      
      c.gridwidth = 1;
      c.weightx = 0;
      c.weighty = 0;
      
      this.getContentPane().setLayout(theLayout);      
      
      c.fill = GridBagConstraints.BOTH;
      c.gridx = 1;
      c.gridy = 1;
      c.weightx = .5;
      c.weighty = .5;
      theLayout.setConstraints(messagesPanel, c);
      this.getContentPane().add(messagesPanel);
      
      c.fill = GridBagConstraints.NONE;
      c.gridx = 1;
      c.gridy = 2;
      c.weightx = 0;
      c.weighty = 0;
      theLayout.setConstraints(authorLabel, c);
      this.getContentPane().add(authorLabel);*/
  }
    
  public void actionPerformed(ActionEvent theEvent) 
  {
      String command = theEvent.getActionCommand();      
  
      if (command == "quit")
      {
          readerThread.interrupt();
          System.exit(0);
      }          
      if (command == "clear messages")
      {
          messagesArea.setText("");
      }      
      if (command == "about")
      {
          //AboutDialog aboutDialog = new AboutDialog(this);
      }
  }
  
  //////////////
  
  private void init() throws IOException {
    threadPool = ThreadPool.create("Trap", 2);
    dispatcher =
        new MultiThreadedMessageDispatcher(threadPool,
                                           new MessageDispatcherImpl());
    listenAddress =
        GenericAddress.parse(System.getProperty("snmp4j.listenAddress",
                                                "udp:0.0.0.0/162"));
    TransportMapping<? extends Address> transport;
    if (listenAddress instanceof UdpAddress) {
      transport = new DefaultUdpTransportMapping((UdpAddress)listenAddress);
    }
    else {
      transport = new DefaultTcpTransportMapping((TcpAddress)listenAddress);
    }
    snmp = new Snmp(dispatcher, transport);
    snmp.getMessageDispatcher().addMessageProcessingModel(new MPv1());
    snmp.getMessageDispatcher().addMessageProcessingModel(new MPv2c());
    snmp.getMessageDispatcher().addMessageProcessingModel(new MPv3());
    USM usm = new USM(SecurityProtocols.getInstance(),
                      new OctetString(MPv3.createLocalEngineID()), 0);
    SecurityModels.getInstance().addSecurityModel(usm);
    snmp.listen();
  }

  public void run() {
    try {
      init();
      snmp.addCommandResponder(this);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    
    /*int numChars;
    char[] charArray = new char[256];
    
    try
    {
        while (!readerThread.isInterrupted() && ((numChars = errorReader.read(charArray, 0, charArray.length)) != -1))
        {
            messagesArea.append("Problem receiving trap or inform:\n");
            messagesArea.append(new String(charArray, 0, numChars));
            messagesArea.append("\n\n");
        }
    }
    catch(IOException e)
    {
        messagesArea.append("Problem receiving errors; error reporter exiting!");
    }*/
    
  }

  public static void main(String[] args) {
	
	  try
	  {
		 /* System.setProperty("com.mchange.v2.log.MLog",
					"com.mchange.v2.log.FallbackMLog");
			System.setProperty(
					"com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL",
					"SEVERE");*/
			
		    ///for window
		  /*  String softwareType=null;
        	try {
				softwareType = GetSoftwareType.getType();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null,e.getMessage(),"Trap receiver service", JOptionPane.ERROR_MESSAGE);
	        	System.exit(0);
			}*/
        	serverSocketObj=new ServerSocket(9994); 
        	executorServiceObj = (ThreadPoolExecutor) Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        	multiThreadedTrapReceiverObj = new MultiThreadedTrapReceiverForFiberCut();
        	//multiThreadedTrapReceiverObj.pack();
        	//multiThreadedTrapReceiverObj.setSize(700,500);
        	
        	System.out.println("=================================================");        	
        	System.out.println("UTL-MP-0072 Spectrum DWDM Trap Fiber Cut Service");
        	System.out.println("=================================================");   
       
        	/*if("u/system/t/management/l/element".equals(softwareType)){
        		
        		multiThreadedTrapReceiverObj.setVisible(true);
        		
        	}else{
        		TrayIconForSNMPTrapReceiver trayIcon=new TrayIconForSNMPTrapReceiver();
            	trayIcon.createAndShowTrayIcon(multiThreadedTrapReceiverObj);
            	multiThreadedTrapReceiverObj.setVisible(false);
        	}*/
	
	  }catch (IOException e) {
	  	//JOptionPane.showMessageDialog(null, "Trap receiver service already running..",e.getMessage(), JOptionPane.ERROR_MESSAGE);
		 // e.getMessage();
		  System.out.println("Trap receiver service already running..");
		  System.exit(0);
	  }
	  catch (Exception e)
	  {
	  	//JOptionPane.showMessageDialog(null,e.getMessage(), "Trap Receiver", JOptionPane.ERROR_MESSAGE);
		//  e.getMessage();
		 System.out.println("Trap Receiver");
	  	System.exit(0);
	  }	  
	
	  
	  StoreTrapInToDBForFiberCut threadStoreTrap=new StoreTrapInToDBForFiberCut(receivedTrap);
	  threadStoreTrap.start();
	  
	  MultiThreadedTrapReceiverForFiberCut multithreadedtrapreceiver = new  MultiThreadedTrapReceiverForFiberCut();
	  multithreadedtrapreceiver.run();	
	  
  }
  static BlockingQueue<CommandResponderEvent> receivedTrap=new LinkedBlockingQueue<CommandResponderEvent>();

  
  public void processPdu(CommandResponderEvent event) {
	// System.out.println("---------");
	  System.out.println("Processed " +
              ((double)(System.currentTimeMillis() - start)/ 1000 +
              "/s, total="+n));
//	  StoreTrapInToDB threadStoreTrap=new StoreTrapInToDB(receivedTrap);
//	 MultiThreadedTrapReceiverObj.messagesArea.append(StoreTrapInToDB.trapOIDString+"\n");
	/* multiThreadedTrapReceiverObj.messagesArea.append(receivedTrap.toString()+"\n");
	 
	 displayCounter++;
	 if (displayCounter > 25)
	 	 {
	 		 multiThreadedTrapReceiverObj.messagesArea.setText("");
	 		 displayCounter = 1;
	 	 }*/
	 
  /*  if (start < 0) {
      start = System.currentTimeMillis()-1;
    }*/
    n++;
   /* if ((n % 5 == 1)) {
      System.out.println("Processed " +
                         ((double)(System.currentTimeMillis() - start)/ 1000 +
                         "/s, total="+n));
    	
    }*/
    try {
		receivedTrap.add(event);
		
		
	} catch (Exception e) {
		e.printStackTrace();
	}
  }
   
}
