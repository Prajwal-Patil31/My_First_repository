package org.snmp4j.test;

import java.awt.BorderLayout;
import java.awt.Dialog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class DebugInformationTrapReceiver extends JDialog {

	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		try {
			DebugInformationTrapReceiver dialog = new DebugInformationTrapReceiver();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			
			UpdateTrapDebugInformation task=new UpdateTrapDebugInformation(textArea, chckbxThread, chckbxTrap);
			Timer t=new Timer();
			t.schedule(task,0, 5000);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}*/
	private  JCheckBox chckbxThread;
	private  JCheckBox chckbxTrap;
	private  JTextArea textArea;
	private Timer timerObj;

	/**
	 * Create the dialog.
	 */
	public DebugInformationTrapReceiver() {
		//super(MultiThreadedTrapReceiver.multiThreadedTrapReceiverObj,"",Dialog.ModalityType.APPLICATION_MODAL);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 619, 451);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		/*JScrollPane scrollPane = new JScrollPane();
		getContentPane().add(scrollPane);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));*/
		
		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		panel_1.add(scrollPane, BorderLayout.CENTER);
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);

		JPanel panel_2 = new JPanel();
		getContentPane().add(panel_2, BorderLayout.SOUTH);
		
		JPanel panel_3 = new JPanel();
		getContentPane().add(panel_3, BorderLayout.NORTH);
		
		JLabel lblNewLabel = new JLabel("Debugging Information");
		panel_3.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Start");
		panel_2.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				UpdateTrapDebugInformation task=new UpdateTrapDebugInformation(textArea, chckbxThread, chckbxTrap);
				timerObj=new Timer();
				timerObj.schedule(task,0, 5000);
			}
		});
		JButton btnStop = new JButton("stop");
		btnStop.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				timerObj.cancel();
			}
		});
		panel_2.add(btnStop);
		
		JButton btnClear = new JButton("clear");
		panel_2.add(btnClear);
		btnClear.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				textArea.setText("");
			}
		});
		chckbxThread = new JCheckBox("Thread");
		chckbxThread.setSelected(true);
		panel_2.add(chckbxThread);
		
		chckbxTrap = new JCheckBox("Trap");
		chckbxTrap.setSelected(true);
		panel_2.add(chckbxTrap);


		setVisible(true);
		
		
		/*getContentPane().setLayout(null);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBounds(0, 233, 442, 33);
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}*/
	}
	
}

class UpdateTrapDebugInformation extends TimerTask {
	private JTextArea textArea;
	private JCheckBox chckbxThread;
	private JCheckBox chckbxTrap;
	
	public UpdateTrapDebugInformation(JTextArea textArea, JCheckBox chckbxThread,
			JCheckBox chckbxTrap) {
		this.textArea = textArea;
		this.chckbxThread = chckbxThread;
		this.chckbxTrap = chckbxTrap;
	}

	@Override
	public void run() {
		System.out.println("running-----");
		textArea.append("Begin\n");
		if(chckbxThread.isSelected()){
			textArea.append("Thread\n");
		}
		if(chckbxTrap.isSelected()){
			textArea.append("Trap\n");
		}
		textArea.append("End\n");
	}
	
}
