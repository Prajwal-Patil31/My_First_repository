package org.snmp4j.test;

import java.awt.AWTException;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class TrayIconForSNMPTrapReceiver {
public void createAndShowTrayIcon(final MultiThreadedTrapReceiver MultiThreadedTrapReceiverObj){
	if (!SystemTray.isSupported()) 
	{
		System.out.println("SystemTray is not supported");
		return;
	}
	final PopupMenu popupForTray = new PopupMenu();
	Image image = Toolkit.getDefaultToolkit().getImage(TrayIconForSNMPTrapReceiver.class.getResource("/icons/utl_node_alarm.png"));
	final SystemTray tray = SystemTray.getSystemTray();
	final TrayIcon trayIcon;

	// Create a popup menu components
	MenuItem aboutItem = new MenuItem("About");
	Menu displayMenu = new Menu("Display");
	MenuItem openItem = new MenuItem("Open");
	MenuItem exitItem = new MenuItem("Exit");

	//Add components to popup menu
	popupForTray.add(aboutItem);
	popupForTray.addSeparator();
	popupForTray.add(displayMenu);
	displayMenu.add(openItem);
	popupForTray.add(exitItem);
	trayIcon = new TrayIcon(image, "UTL LCT Trap Receiver Service", popupForTray);				
	trayIcon.setPopupMenu(popupForTray);

	try 
	{
		tray.add(trayIcon);
	} 
	catch (AWTException e) 
	{
		System.out.println("TrayIcon could not be added.");
		return;
	}
	
	aboutItem.addActionListener(new ActionListener() 
	{
		public void actionPerformed(ActionEvent e) 
		{
			JOptionPane.showMessageDialog(null,"  UTL MP-0072 Spectrum \n  [DWDM Trap Service] \n     Version 1.0");
		}
	});

/*	openItem.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			//MultiThreadedTrapReceiverObj.setVisible(true);
			//MultiThreadedTrapReceiverObj.setExtendedState(Frame.NORMAL);
		}
	});
	
	exitItem.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			//MultiThreadedTrapReceiverObj.dispose();
			System.exit(0);
		}
	});		*/
}
}
