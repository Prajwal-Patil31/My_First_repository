package in.utl.noa.ogm;

import com.syncleus.ferma.AbstractEdgeFrame;
import com.syncleus.ferma.annotations.InVertex;
import com.syncleus.ferma.annotations.OutVertex;
import com.syncleus.ferma.annotations.Property;

public abstract class Knows extends AbstractEdgeFrame {
    @Property("years")
    public abstract void setYears(int years);
  
    @Property("years")
    public abstract int getYears();
  
    @InVertex
    public abstract Person getIn();
  
    @OutVertex
    public abstract Person getOut();
}