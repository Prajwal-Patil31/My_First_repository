package in.utl.noa.model;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import in.utl.noa.config.WebMvcBaseTestConfig;
import in.utl.noa.config.WebMvcJpaSecTestConfig;
//import in.utl.noa.config.WebSecurityConfig;
import in.utl.noa.security.rbac.authentication.NAuthenticationProvider;
import in.utl.noa.security.rbac.authentication.NUserDetails;
//import in.utl.noa.controller.UserProfileContoller;
import in.utl.noa.global.fault.service.FaultService;
import in.utl.noa.mdsal.service.MDSALService;

@WebMvcTest
@EnableWebMvc
@ContextConfiguration(classes = WebMvcBaseTestConfig.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
/* @ComponentScan({"in.utl.noa.service", "in.utl.noa.model"}) */
/* @AutoConfigureTestEntityManager */
public class MockMvcWithUds {
    
    @Autowired
    private MockMvc mockMvc;
    
    @Autowired
    private WebApplicationContext wac;

    @Autowired
    private UserDetailsService userDetails;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeAll
    public void setup()
    {
        mockMvc = MockMvcBuilders
            .webAppContextSetup(wac)
            .apply(springSecurity())
            .build();
    }

    @Test
    void listRestApi() throws Exception {
        UserDetails user = this.userDetails.loadUserByUsername("admin");
    
        mockMvc.perform(get("/api/profile").with(user(user)))
               .andExpect(status().isOk());
        
        /* mockMvc.perform(get("/api/profile")
               .contentType("application/json"))
               .andExpect(status().isOk()); */
    }
}
