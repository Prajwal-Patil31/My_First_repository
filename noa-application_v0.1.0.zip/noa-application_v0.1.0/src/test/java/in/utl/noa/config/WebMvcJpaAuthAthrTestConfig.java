package in.utl.noa.config;

import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureDataJpa;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.config.annotation.EnableWebMvc;
//import in.utl.noa.controller.UserProfileContoller;
import in.utl.noa.security.rbac.authentication.NUserDetails;
import in.utl.noa.security.rbac.authorization.WebSecurityService;
import in.utl.noa.global.fault.service.FaultService;
import in.utl.noa.mdsal.service.MDSALService;

@TestConfiguration
@EnableWebSecurity
@EnableWebMvc
/* @EntityScan
@EnableJpaAuditing
@EnableJpaRepositories
@EnableTransactionManagement
@IntegrationComponentScan
@EnableCaching 
@EnableAutoConfiguration */
@AutoConfigureDataJpa
@Order(Ordered.HIGHEST_PRECEDENCE)
public class WebMvcJpaAuthAthrTestConfig extends WebSecurityConfigurerAdapter {

    @MockBean
    private FaultService faultService;

    @MockBean
    private MDSALService mdsalService;
    
    private NUserDetails userDetails;

    private WebSecurityService webSecurity;

    public WebMvcJpaAuthAthrTestConfig() {
        super();
        userDetails = new NUserDetails();
        webSecurity = new WebSecurityService();
    }
    
    @Bean
    public NUserDetails userDetails() {
        return userDetails;
    }

    @Bean
    public WebSecurityService webSecurity() {
        return webSecurity;
    }
    
    @Override
    public void configure(final WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/resources/**");
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
            //.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
            .authorizeRequests()
                .antMatchers("/", "/index", "/error", "/built/**", "/*.css", "/images/**", "/lib/**").permitAll()
                .antMatchers("/logout").permitAll()
                .antMatchers("/api/profile").authenticated()
                .antMatchers("/api/**").access("@webSecurity.check(authentication, request)")
                .anyRequest().authenticated()
                .and()
            .httpBasic()
                .and()
            .logout(logout -> logout
                .permitAll()
                .logoutSuccessHandler((request, response, authentication) -> {
                    response.setStatus(HttpServletResponse.SC_OK);
                }))
            .csrf().disable();
    }
}