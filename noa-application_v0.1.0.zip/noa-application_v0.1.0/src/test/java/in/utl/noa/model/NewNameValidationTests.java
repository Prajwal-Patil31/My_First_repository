package in.utl.noa.model;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.opendaylight.infrautils.metrics.internal.Configuration;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
import org.springframework.boot.test.autoconfigure.OverrideAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.http.MediaType;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;

import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import org.springframework.web.context.WebApplicationContext;

import in.utl.noa.account.user.model.UserAccountRepository;
import in.utl.noa.account.user.model.UserAccount;
import in.utl.noa.config.WebMvcJpaAuthAthrTestConfig;
import in.utl.noa.security.rbac.role.model.RoleRepository;
import in.utl.noa.security.rbac.role.model.Role;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import com.fasterxml.jackson.databind.ObjectMapper;

@WebMvcTest
@ContextConfiguration(classes = WebMvcJpaAuthAthrTestConfig.class)
@Configuration
@OverrideAutoConfiguration(enabled = false)
@ImportAutoConfiguration(value = { RepositoryRestMvcAutoConfiguration.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class NewNameValidationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext wac;

    @Autowired
    private UserAccountRepository userRepo;

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private UserDetailsService userDetails;

    @BeforeAll
    public void setup() {
        mockMvc = MockMvcBuilders
        .webAppContextSetup(wac)
        .apply(springSecurity())
        .build();
    }

    @Test
    @DisplayName("Validate Usernames of newly Created User")
    public void validatingUsernameForNewUser() throws Exception {

        UserAccount testUser;

        UserDetails user = this.userDetails.loadUserByUsername("admin");

        ObjectMapper mapper = new ObjectMapper();

        testUser = userRepo.findByUserName("newUser");

        if(testUser == null) {
            UserAccount newUser = new UserAccount("newUser", "password");

            mockMvc.perform(post("/api/security-users")
                        .with(user(user))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(newUser))
                        .accept(MediaType.APPLICATION_JSON));

            UserAccount test = userRepo.findByUserName("newUser");
            assertNotNull(test);
        }
    }

    @Test
    @DisplayName("Validate Role Name of newly Created Role")
    public void validatingRolenameforNewRole() throws Exception {

        Role testRole;

        UserDetails user = this.userDetails.loadUserByUsername("admin");

        ObjectMapper mapper = new ObjectMapper();

        testRole = roleRepo.findByRoleName("newRole");

        if(testRole == null) {
            Role newRole = new Role("newRole");

            mockMvc.perform(post("/api/security-roles")
                        .with(user(user))
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(newRole))
                        .accept(MediaType.APPLICATION_JSON));

            Role test = roleRepo.findByRoleName("newRole");
            assertNotNull(test);
        }
    }
}