package in.utl.noa.ogm;

import java.util.List;

import com.syncleus.ferma.AbstractVertexFrame;
import com.syncleus.ferma.annotations.Adjacency;
import com.syncleus.ferma.annotations.Incidence;
import com.syncleus.ferma.annotations.Property;

public abstract class Person extends AbstractVertexFrame {
    @Property("name")
    public abstract String getName();
  
    @Property("name")
    public abstract void setName(String name);
  
    @Adjacency(label = "knows")
    public abstract List<Person> getKnowsPeople();
  
    @Incidence(label = "knows")
    public abstract List<Knows> getKnows();
  
    @Incidence(label = "knows")
    public abstract Knows addKnows(Person friend);
  
    public List<? extends Person> getFriendsNamedBill() {
        return this.traverse(input -> input.out("knows").has("name", "bill")).toList(Person.class);
    }
  }