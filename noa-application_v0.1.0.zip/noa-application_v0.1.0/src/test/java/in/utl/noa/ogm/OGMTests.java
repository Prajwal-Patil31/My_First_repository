package in.utl.noa.ogm;

import static org.junit.jupiter.api.Assertions.fail;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;

import com.syncleus.ferma.DelegatingFramedGraph;
import com.syncleus.ferma.FramedGraph;

import org.apache.tinkerpop.gremlin.structure.Graph;
import org.apache.tinkerpop.gremlin.tinkergraph.structure.TinkerGraph;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import junit.framework.Assert;

class OGMTests {

    @BeforeAll
    static void initAll() {
    }

    @BeforeEach
    void init() {
    }

    @Test
    public void testAnnotatedTyping() {
        Set<Class<?>> types = new HashSet<Class<?>>(Arrays.asList(new Class<?>[]{
                      Person.class,
                      Programmer.class,
                      Knows.class}));
        Graph graph = TinkerGraph.open();
      
        //implies annotated mode
        FramedGraph fg = new DelegatingFramedGraph(graph, true, types);
      
        Person jeff = fg.addFramedVertex(Programmer.class);
        jeff.setName("Jeff");
      
        Person julia = fg.addFramedVertex(Person.class);
        julia.setName("Julia");
        julia.addKnows(jeff);
      
        Person juliaAgain = fg.traverse((g) -> g.V().has("name", "Julia")).next(Person.class);
        Person jeffAgain = juliaAgain.getKnowsPeople().get(0);
      
        Assert.assertTrue(Programmer.class.isAssignableFrom(jeffAgain.getClass()));
        Assert.assertTrue(Person.class.isAssignableFrom(juliaAgain.getClass()));
    }


    @AfterEach
    void tearDown() {
    }

    @AfterAll
    static void tearDownAll() {
    }

}
