package in.utl.noa.ogm;

public abstract class Programmer extends Person {

}