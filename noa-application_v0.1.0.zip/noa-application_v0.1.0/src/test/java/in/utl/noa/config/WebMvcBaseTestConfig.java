package in.utl.noa.config;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import in.utl.noa.global.fault.service.FaultService;
//import in.utl.noa.controller.UserProfileContoller;
import in.utl.noa.mdsal.service.MDSALService;

@TestConfiguration
@EnableWebSecurity
@EnableWebMvc
@Order(Ordered.HIGHEST_PRECEDENCE)
public class WebMvcBaseTestConfig extends WebSecurityConfigurerAdapter {

    @MockBean
    private FaultService faultService;

    @MockBean
    private MDSALService mdsalService;
    
}