package in.utl.noa.model;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.opendaylight.infrautils.metrics.internal.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.data.rest.RepositoryRestMvcAutoConfiguration;
import org.springframework.boot.test.autoconfigure.OverrideAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;


import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import in.utl.noa.config.WebMvcJpaWAuthNAthrTestConfig;
import in.utl.noa.security.rbac.role.model.RoleRepository;
import in.utl.noa.security.rbac.role.model.Role;

@WebMvcTest
@ContextConfiguration(classes = WebMvcJpaWAuthNAthrTestConfig.class)
@Configuration
@OverrideAutoConfiguration(enabled = false)
@ImportAutoConfiguration(value = { RepositoryRestMvcAutoConfiguration.class })
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class WebMvcTestWithMockMvc {
    
    @Autowired
    private MockMvc mockMvc;
    
    @Autowired
    private WebApplicationContext wac;

    @Autowired
    private UserDetailsService userDetails;

    @BeforeAll
    public void setup()
    {
        mockMvc = MockMvcBuilders
            .webAppContextSetup(wac)
            .apply(springSecurity())
            .build();
    }

    @Test
    /* @WithMockUser(username = "admin", password = "pass", roles = "Administrator") */
    void listRestApi() throws Exception {
        UserDetails user = this.userDetails.loadUserByUsername("admin");
    
        /* Controller Test */
        /* mockMvc.perform(get("/api/profile").with(user(user)))
               .andExpect(status().isOk());

        /* mockMvc.perform(get("/api/profile")
               .contentType("application/json"))
               .andExpect(status().isOk()); */
        
        /* Repository Test */
        Role role = new Role("SpringTest");
        ObjectMapper mapper = new ObjectMapper();

        mockMvc.perform(post("/api/security-roles")
               .with(user(user))
               .contentType(MediaType.APPLICATION_JSON)
               .content(mapper.writeValueAsString(role))
               .accept(MediaType.APPLICATION_JSON))
               .andExpect(status().isCreated());
    }
}
