/**@module App */

'use strict';
import React from 'react';
import {BrowserRouter} from "react-router-dom";

import AppLayout from './layout/AppLayout';
import LoginLayout from './layout/LoginLayout';

import { AuthProvider, AuthConsumer } from './utility/AuthContext';
import { GlobalSpinner, GlobalSpinnerProvider } from './utility/GlobalSpinner';
import { RouteRediretProvider } from './utility/RouteRedirect';
import { NotificationProvider } from './utility/NotificationContext';
import { GlobalThemeConsumer, GlobalThemeProvider } from './utility/GlobalThemeContext';
import { ThemeProvider } from 'styled-components';
import { MenuContextProvider } from './utility/MenuContext';

/**
 * Component for the Application. implements App Layout{@link AppLayout}
 * or Login Layout{@link LoginLayout} 
 * 
 * @class
 * @augments React.Component
*/
class App extends React.Component {
	
	constructor(props) {
		super(props);
	}

	/**
	 * Renders a view based on User Authentication State.
	 * invokes Login Layout{@link LoginLayout} for login.
	*/
	render() {
		return (
				<BrowserRouter>
				<RouteRediretProvider>
				<GlobalSpinnerProvider>
				<AuthProvider>
					<AuthConsumer>
						{({ isAuth, login, logout }) => (
							<div>
							<GlobalSpinner />
							{isAuth ?
								<GlobalThemeProvider>
								<GlobalThemeConsumer>
								{({theme, changeTheme}) => (
									<NotificationProvider>
										<ThemeProvider theme={theme === 'light' ? lightTheme : darkTheme}>
												<MenuContextProvider>
													<AppLayout/>
												</MenuContextProvider>
										</ThemeProvider>
									</NotificationProvider>
								)}
								</GlobalThemeConsumer>
								</GlobalThemeProvider>
								 : <LoginLayout/>
							}
							</div>
						)}
					</AuthConsumer>
				</AuthProvider>
				</GlobalSpinnerProvider>
				</RouteRediretProvider>
				</BrowserRouter>
		)
	}
}

const lightTheme = {
    background: '#FFFFFF',
	buttonBg: '#2699FB',
	buttonTextColor: '#000000',
	textsColor: 'black',
	menuColor: 'black',
	menuTextsColor: 'black',
	buttonTextColor: 'black'
}

const darkTheme = {
    background: '#1d1f28',
	buttonBg: '#d4173d',
	buttonTextColor: '#FF0000',
	textsColor: 'white',
	menuColor: 'white',
	menuTextsColor: 'white',
	buttonTextColor: 'white'
}

export default App;