import React, { useContext, useEffect, useState } from 'react';
import { Grid } from 'semantic-ui-react';

import 'semantic-ui-css/semantic.min.css';

import { cardDurationItem, cardKeyItem, fullHeight, completeWidth } from '../../../constants'

import NoaTable from '../../../widget/NoaTable';
import NoaCard from '../../../widget/NoaCard';
import { NoaContainer} from '../../../widget/NoaWidgets';

import NoaProgressBar from '../../../widget/NoaProgressBar';
import { MenuContext } from '../../../utility/MenuContext';
import '../../../index.css';
import { FaultOverviewChart } from '../../../Dashboard';
import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';

const FaultsSummary = () => {
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const menuContext = useContext(MenuContext);

    const [alarmSummary, setAlarmSummary] = useState({});
    const [alarmDistribution, setAlarmDistribution] = useState({});
    const [topFaults, setTopFaults] = useState([]);
    const [recentFaults, setRecentFaults] = useState([]);

    const getAlarmSummary = () => {
        NoaClient.get(
            "/api/global/fault/summary",
            (response) => {
                let responseData = response.data;
                setAlarmSummary(responseData);
            });
    }

    const getAlarmDistribution = () => {
        NoaClient.get(
            "/api/global/fault/distribution",
            (response) => {
                let responseData = response.data;
                setAlarmDistribution(responseData);
            });
    }

    const getTopFaults = () => {
        NoaClient.get(
            "/api/global/fault/top",
            (response) => {
                let responseData = response.data;
                setTopFaults(responseData);
            });
    }

    const getRecentFaults = () => {
        NoaClient.get(
            "/api/global/fault/recent",
            (response) => {
                let responseData = response.data;
                setRecentFaults(responseData);
            });
    }
    
    useEffect(() => {
        NoaClient(context,redirectContext);
        menuContext.setActiveItem(0);
        getAlarmSummary();
        getAlarmDistribution();
        getTopFaults();
        getRecentFaults();
    },[]);

    const alarmColors = ['#FB4E4E','#F6A609','#667EFF','#FFDB1F','#66B2FF'];
    const eventColors = ['#1A374D','#6998AB','#406882','#B1D0E0'];
    return (
        <NoaContainer style={Object.assign({}, fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <NoaCard title={"Alarm/Event Summary"} renderDuration={true}>
                            <NoaContainer style={{textAlign: "center",width: "100%"}}>
                            {Object.keys(alarmSummary).length > 0 ? 
                            <Grid columns={2} stackable>
                                <Grid.Column width={8}>
                                    <NoaContainer style={{textAlign: "center"}}>
                                        <FaultOverviewChart data={alarmSummary["alarms-summary"]} listData={alarmSummary["alarms-summary"]} colors={alarmColors} label={"225 Alarms"}/>
                                    </NoaContainer>
                                </Grid.Column>

                                <Grid.Column width={8}>
                                    <NoaContainer style={{textAlign: "center"}}>
                                        <FaultOverviewChart data={alarmSummary["events-summary"]} listData={alarmSummary["events-summary"]} colors={eventColors} label={"225 Events"}/>
                                    </NoaContainer>
                                </Grid.Column>
                            </Grid>
                            :""}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>

                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Alarm/Event Distribution"}>
                            <NoaContainer style={Object.assign({padding:"2em"},completeWidth)}>
                            {Object.keys(alarmDistribution).length > 0 ? 
                                <Grid columns={3} stackable>
                                    {Object.keys(alarmDistribution).map((item,index) => (
                                        <Grid.Column computer={index == 1 || index == 4? 6 : 5} tablet={8} mobile={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                                                        <p style={cardKeyItem}>Top {item} by Active Alarms</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1} style={{paddingTop:"1em"}}>
                                                    <Grid.Column width={16}>
                                                        <NoaContainer style={{textAlign: "center"}}>
                                                            {alarmDistribution[item].map((faultValues) => (
                                                                <NoaProgressBar data={faultValues} title={null}/>
                                                            ))}
                                                        </NoaContainer>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                    ))}
                                </Grid>
                            :""}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>

                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                    <Grid columns={2} relaxed="very" stackable verticalAlign="middle">
                        <Grid.Column computer={8} tablet={16} mobile={16}>
                            <NoaCard title={"Recent Faults"} renderDuration={true} durationComponent={multipleDuration}>
                                <NoaContainer style={{textAlign: "center",width: "100%"}}>
                                    <FaultsTable data={topFaults}/>
                                </NoaContainer>
                            </NoaCard>
                            
                        </Grid.Column>
                        <Grid.Column computer={8} tablet={16} mobile={16}>
                            <NoaCard title={"Top Faults"} renderDuration={true} durationComponent={multipleDuration}>
                                <NoaContainer style={{textAlign: "center",width: "100%"}}>
                                    <FaultsTable data={recentFaults}/>
                                </NoaContainer>
                            </NoaCard>
                        </Grid.Column>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const FaultsTable = (props) => {
    const data = props.data;
    const columns = [
		{
			label: "1",
			Header: "Fault ID",
            accessor: "faultId"
		},
		{
			label: "2",
			Header: "Description",
            accessor: "description"
		},
        {
			label: "3",
			Header: "Severity",
			accessor: "severity"
		},
        {
			label: "4",
			Header: "Occurance",
			accessor: "occurance"
        }
    ]
    const selectedRows = [];
    return (
        <Grid stackable>
            <Grid.Row columns={1}>
            <Grid.Column width={16}>
                <Grid columns={3}>
                    <Grid.Column width={1}></Grid.Column>
                    <Grid.Column width={14}>
                        <NoaTable data={data}
                            columns={columns}
                            selectedRows={selectedRows}
                            onlyTable={true}
                            borderless={true}
                            hidePagination={true}
                            selectedPageSize={5}
                        />
                    </Grid.Column>
                    <Grid.Column width={1}></Grid.Column>
                </Grid>
            </Grid.Column>
            </Grid.Row>
        </Grid>
        
    )
}

const multipleDuration = () => {
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>{new Date().toLocaleString()}</p>   
                        </Grid.Column>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
export default FaultsSummary;