import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../widget/NoaTable';

import {
    Grid,
    Segment,
    Checkbox,
    Button,
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, fullHeight,
    titleText, cardLayout, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight,
    applyButton
} from '../../../constants';

import { NoaContainer} from '../../../widget/NoaWidgets';
import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';

const GlobalFault = (props) => {
    const [faults, setFaults] = useState([]);
    
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = faults[sel[i]].faultId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getFaults = (filterObj) => {
        context.setRenderLocation(["global-faults-list"]);
        NoaClient.post(
            "/api/global/fault",
            filterObj,
            (response) => {
                let responseData = response.data;
                let faultsList = [];
                responseData.data.map((item) => {
                    let severity = item.severity;

                    item["severity"] = faultSeverityObj[severity]
                    faultsList.push(item);
                })
                setFaults(faultsList);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/global/fault/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }
    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        
        let filterCriteria = {}
        
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"fault":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getFaults(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                            <GlobalFaultTable faults={faults} getFaults={getFaults}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const faultStatusObj = {
    1 : "-",
    2 : "Cleared",
    3 : "Acknowledged"
}

const faultSeverityObj = {
    1 : "Information",
    2 : "Warning",
    3 : "Minor",
    4 : "Major",
    5 : "Critical"
}

const GlobalFaultTable = (props) => {
    const faults = props.faults;
    const getFaults = props.getFaults;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"fault" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
		{
			label: "2",
			Header: "Fault Code",
            accessor: "faultCode",
            width: 1
		},
        {
			label: "4",
			Header: "Description",
            accessor: "faultContent",
            width: 3
		},
        {
			label: "5",
			Header: "Resource",
            accessor: "resource",
            width: 2
        },
        {
			label: "5",
			Header: "Resource Id",
            accessor: "resourceId",
            width: 2
        },
        {
            label: "9",
            Header: "Severity",
            accessor: "severity",
            width: 2
        },
        {
			label: "7",
			Header: "Occurance",
            accessor: "faultDate",
            width: 3
        },
        {
			label: "8",
			Header: "Count",
            accessor: "count",
            width: 1
        },
        {
            label: "9",
            Header: "Status",
            accessor: "status",
            width: 1
        }
    ]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getFaults(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"fault" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getFaults(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getFaults(filterObj)
    }

    const fetchData = () => {
        fetchFilteredData({"filters":null})
        setClearSelected(true);
    }
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Faults List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    <FaultsToolbar selectedRows={selectedRows} fetchData={fetchData}/>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={faults}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="Faults" 
                        fetchData={fetchData} 
                        location="global-faults-list" 
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const FaultsToolbar = (props) => {
    const selectedRows = props.selectedRows;
    const fetchData = props.fetchData;

    console.log(selectedRows)
    const handleAck = () => {
		NoaClient.post(
			"/api/global/fault/acknowledge",
			selectedRows,
			(response) => {
				fetchData();
			})
    }

    const handleClear = () => {
		NoaClient.post(
			"/api/global/fault/clear",
			selectedRows,
			(response) => {
				fetchData();
			})
    }
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={12} textAlign='right'>
                            <Button style={applyButton} onClick={handleAck} disabled={selectedRows.length > 0 ? false : true}>Ack</Button>
                        </Grid.Column>
                        <Grid.Column width={4} textAlign='left'>
                            <Button style={applyButton} onClick={handleClear} disabled={selectedRows.length > 0 ? false : true}>Clear</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

export default GlobalFault;