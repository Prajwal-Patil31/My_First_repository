import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../widget/NoaTable';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Input,
    Dropdown,
    Checkbox
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, noMarginTB, 
    noMarginLR, titleText, cardLayout, 
    completeHeight, completeWidth, formHeader, 
    formParameter, formTitle, applyButton, 
    cancelButton, tablePadding, tableHeaderHeight, 
    fullHeight, dividerStyle, formSpacingTB, 
    inputBoxStyle, formContentSpacingTB, dropdownStyle
} from '../../../constants';

import NoaClient from '../../../utility/NoaClient';
import NoaFilter from '../../../widget/NoaFilter';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';

import { NoaHeader, NoaContainer} from '../../../widget/NoaWidgets';
import NoaToolbar from '../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../widget/NoaNotification';

const faultSeverityObj = {
    1 : "Information",
    2 : "Warning",
    3 : "Minor",
    4 : "Major",
    5 : "Critical"
}

const FaultPolicyManager = (props) => {
    const [policies, setPolicies] = useState([]);
    
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const router = useRouter();
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = policies[sel[i]].policyId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const getPolicies = (filterObj) => {
        context.setRenderLocation(["fault-policy-list"]);
        NoaClient.post(
            "/api/platform/fault/policy",
            filterObj,
            (response) => {
                let responseData = response.data;
                let policyList = [];
                responseData.data.map((item) => {
                    let severity = item.severity;
                    let toSeverity = item.toSeverity;

                    item["severity"] = faultSeverityObj[severity]
                    item["toSeverity"] = faultSeverityObj[toSeverity]
                    policyList.push(item);
                })
                setPolicies(policyList);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/fault/policy/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
                
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        let filterCriteria = {}
        router.stateService.go('default');

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"fault-processing-policy":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getPolicies(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                            <FaultPolicyTable policies={policies}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            getPolicies={getPolicies}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
    ({ indeterminate, ...rest }, ref) => {
        const defaultRef = React.useRef()
        const resolvedRef = ref || defaultRef

        React.useEffect(() => {
            resolvedRef.current.indeterminate = indeterminate
        }, [resolvedRef, indeterminate])

        return (<Checkbox ref={resolvedRef} {...rest} />)
    }
)

const FaultPolicyTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);

    const policies = props.policies;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const getPolicies = props.getPolicies;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"fault-processing-policy" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
        {
            label: "2",
            Header: "Policy Name",
            accessor: "policyName",
            filterable: true,
            width:2
        },
        {
            label: "3",
            Header: "Policy Type",
            accessor: "policyType",
            filterable: true,
            width:3
        },
        {
            label: "5",
            Header: "Severity",
            accessor: "severity",
            filterable: true,
            width:2
        },
        {
            label: "4",
            Header: "To Severity",
            accessor: "toSeverity",
            filterable: true,
            width:2
        },
        {
            label: "6",
            Header: "Num of Hours Older",
            accessor: "numOfHoursOlder",
            filterable: true,
            width:2

        },
        {
            label: "7",
            Header: "Num of Days Older",
            accessor: "numOfDaysOlder",
            filterable: true,
            width:2
        },
        {
            label: "8",
            Header: "Retain Min Faults",
            accessor: "retainMinFaults",
            filterable: true,
            width:2
        }
    ]

    const handleAddFaultPolicy = () => {
        router.stateService.go("add-fault-policy",{fetchData: fetchData, clearSelection: clearSelection})
    }
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-fault-policy',{id: policies[selId].policyId,fetchData: fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["fault-policy-list"]);
        NoaClient.delete(
            "/api/platform/fault/policy/",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null})
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getPolicies(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"fault-processing-policy" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getPolicies(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getPolicies(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Fault Policies List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddFaultPolicy}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={policies}
                            columns={columns}
                            selectedRows={selections}
                            onSelectedRowsChange={setSelections}
                            clearSelected={clearSelected}
                            selectedPageSize={pageSize}
                            handlePagination={handlePagination}
                            totalPages={totalPages}
                            handlePageSize={handlePageSize}
                            totalEntries={totalEntries}
                            resource="Fault Policies" 
                            fetchData={fetchData} 
                            location="fault-policy-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const AddFaultPolicy = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const setRenderAdd = props.setRenderAdd;
    
    const getPolicies = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const [faultPolicy, setFaultPolicy] = useState({});

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleChange = (value, key) => {
		setFaultPolicy(prevState => ({
            ...prevState,
            [key]: value
        }));
    }
    
    const handleAdd = () => {
        if(faultPolicy != null) {
            NoaClient.put(
                "/api/platform/fault/policy",
                faultPolicy,
                (response) => {
                    //context.setRenderLocation(['fault-policy-list'])
                    getPolicies();
                    noaNotification('success', 'Fault Policy Created Successfully');
                    closeFooter();
            })
        }
    }

    const [escSeverityType,setEscSeverityType] = useState([]);;

    const handleDropdown = (value,key) => {
        handleChange(value, key)
        setEscSeverityType(severityTypes.filter(type => type.value > value));
    }

    const severityTypes = [
        { 'key': "information", 'text': "Information", 'value': 1 },
        { 'key': "warning", 'text': "Warning", 'value': 2 },
        { 'key': "minor", 'text': "Minor", 'value': 3 },
        { 'key': "major", 'text': "Major", 'value': 4 },
        { 'key': "critical", 'text': "Critical", 'value': 5 }
    ]

    const policyTypes = [
        { 'key': "auto-escalate", 'text': "Auto Escalate", 'value': "auto-escalate" },
        { 'key': "auto-acknowledge", 'text': "Auto Acknowledge", 'value': "auto-acknowledge" }
    ]

    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create Fault Policy</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1} style={formContentSpacingTB}>
                    <Grid.Column width={16} textAlign='left' id="add-fault-policy">
                    <Grid columns={3} stackable>
                        <Grid.Column width={3}></Grid.Column>
                        <Grid.Column width={10} style={noPadding}>
                        <Grid>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={2} stackable>
                                    <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Fault Policy Details</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1} style={formSpacingTB}>
                                            <Grid.Column width={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={5} textAlign='left'>
                                                                <p style={formParameter} className="required">Policy Name</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Input value={faultPolicy.policyName} fluid={false} 
                                                                        type='text' name='policyName'
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'policyName')
                                                                        }
                                                                >
                                                                    <input style={inputBoxStyle}></input>
                                                                </Input>
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={5} textAlign='left'>
                                                            <p style={formParameter} className="required">Policy Type</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                        selectOnBlur={false}
                                                                        placeholder="Policy Type"
                                                                        options={policyTypes} 
                                                                        style={dropdownStyle}
                                                                        value={faultPolicy.policyType}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'policyType')
                                                                        }
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={5} textAlign='left'>
                                                            <p style={formParameter}>Num of Days Older</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='numOfDaysOlder' 
                                                                    value={faultPolicy.numOfDaysOlder}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'numOfDaysOlder')
                                                                    }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={5} textAlign='left'>
                                                            <p style={formParameter}>Num of Hours Older</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='numOfHoursOlder' 
                                                                    value={faultPolicy.numOfHoursOlder}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'numOfHoursOlder')
                                                                    }>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={5} textAlign='left'>
                                                            <p style={formParameter}>Retain Min Faults</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='retainMinFaults' 
                                                                    value={faultPolicy.retainMinFaults}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'retainMinFaults')
                                                                    }>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                    <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Severity Details</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1} style={formSpacingTB}>
                                            <Grid.Column width={16}>
                                                <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter} className="required">Severity</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                            selectOnBlur={false}
                                                                            placeholder="Severity"
                                                                            options={severityTypes}
                                                                            style={dropdownStyle}
                                                                            value={faultPolicy.severity}
                                                                            onChange={
                                                                                (e, {value}) => handleDropdown(value,'severity')
                                                                            }
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                {faultPolicy.policyType === "auto-escalate" ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter} className="required">Escalate To Severity</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                            selectOnBlur={false}
                                                                            placeholder="To Severity"
                                                                            options={escSeverityType}
                                                                            style={dropdownStyle}
                                                                            value={faultPolicy.toSeverity}
                                                                            onChange={
                                                                                (e, {value}) => handleChange(value, 'toSeverity')
                                                                            }
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                : ""}
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        </Grid.Column>
                        <Grid.Column width={3}></Grid.Column>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2}>
                            <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    context.setRenderLocation(['add-fault-policy'])
                                    handleAdd();
                                }}>Add</Button>
                            </Grid.Column>
                            <Grid.Column width={8} textAlign='left'>
                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ModifyFaultPolicy = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    const clearSelection = props.clearSelection;
    const getPolicies = props.fetchData;

    const [faultPolicy, setFaultPolicy] = useState({});
    
    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        const policyId = props.id;
        context.setRenderLocation(['modify-fault-policy']);
        if(policyId != null && policyId != undefined) {
            getFaultPolicy(policyId);
        }
    },[]);
    
    const getFaultPolicy = (policyId) => {
        NoaClient.get(
            "/api/platform/fault/policy/" + policyId,
            (response) => {
                let responseData = response.data;
                setFaultPolicy(responseData);
            });
    }

    const handleChange = (value, key) => {
		setFaultPolicy(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleModify = () => {
        if(faultPolicy != null) {
            const policyId = faultPolicy.policyId;
            NoaClient.post(
                "/api/platform/fault/policy/" + policyId,
                faultPolicy,
                (response) => {
                    getPolicies();
                    noaNotification('success', 'Fault Policy Updated Successfully');
                    closeFooter();
                    setFaultPolicy({});
            })
        }
    }
    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Fault Policy Details: {faultPolicy.policyName}</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} textAlign='left' id="modify-fault-policy">
                    <Grid columns={3} stackable>
                        <Grid.Column width={5}></Grid.Column>
                        <Grid.Column width={6}>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Policy Name</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Input type='text' name='policyName' 
                                                    value={faultPolicy.policyName}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'policyName')
                                                    }
                                        >
                                            <input style={inputBoxStyle}></input>
                                        </Input>
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Num of Days Older</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Input type='number' name='numOfDaysOlder' 
                                                    value={faultPolicy.numOfDaysOlder}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'numOfDaysOlder')
                                                    }
                                        >
                                            <input style={inputBoxStyle}></input>
                                        </Input>
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Num of Hours Older</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Input type='number' name='numOfHoursOlder' 
                                                    value={faultPolicy.numOfHoursOlder}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'numOfHoursOlder')
                                                    }
                                        >
                                            <input style={inputBoxStyle}></input>
                                        </Input>
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Retain Min Faults</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Input type='number' name='retainMinFaults' 
                                                    value={faultPolicy.retainMinFaults}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'retainMinFaults')
                                                    }
                                        >
                                            <input style={inputBoxStyle}></input>
                                        </Input>
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid.Column>
                        <Grid.Column width={5}></Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>

            <Grid.Row columns={1}>
                <Grid.Column textAlign='center' width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                handleModify()
                                context.setRenderLocation(['modify-fault-policy']);
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

export default FaultPolicyManager;
export {AddFaultPolicy,ModifyFaultPolicy};