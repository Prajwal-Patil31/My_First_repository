import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../widget/NoaTable';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Dropdown,
    Checkbox,
    Input
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, noMarginTB, 
    noMarginLR, titleText, cardLayout, 
    completeHeight, completeWidth, formHeader, 
    formParameter, formTitle, applyButton, 
    cancelButton, tablePadding, tableHeaderHeight, 
    fullHeight, dividerStyle, inputBoxStyle,
    formContentSpacingTB, formSpacingTB, dropdownStyle
} from '../../../constants';

import NoaClient from '../../../utility/NoaClient';

import NoaFilter from '../../../widget/NoaFilter';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';

import { NoaHeader, NoaContainer} from '../../../widget/NoaWidgets';

import NoaToolbar from '../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../widget/NoaNotification';

const faultSeverityObj = {
    1 : "Information",
    2 : "Warning",
    3 : "Minor",
    4 : "Major",
    5 : "Critical"
}

const FaultConfig = (props) => {
    const [faultConfigurations, setFaultConfigurations] = useState([]);
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = faultConfigurations[sel[i]].configId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const getFaultConfigurations = (filterObj) => {
        context.setRenderLocation(['fault-config-list']);
        NoaClient.post(
            "/api/platform/fault/config",
            filterObj,
            (response) => {
                let responseData = response.data;
                let configList = [];
                responseData.data.map((item) => {
                    let severity = item.severity;

                    item["severity"] = faultSeverityObj[severity]
                    configList.push(item);
                })
                setFaultConfigurations(configList);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/fault/config/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    const router = useRouter();

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        
        let filterCriteria = {}
        
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"fault-config":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getFaultConfigurations(filterCriteria);
    },[]);
    
    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1} style={fullHeight}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                            <FaultConfigurationTable faultConfigurations={faultConfigurations}
                                                    selectedRows={selectedRows}
                                                    setClearSelected={setClearSelected}
                                                    getFaultConfigurations={getFaultConfigurations}
                                                    setSelected={setSelected} 
                                                    clearSelected={clearSelected}
                                                    columns={columns}
                                                    filters={filters}
                                                    pageSize={pageSize}
                                                    totalPages={totalPages}
                                                    setPageSize={setPageSize}
                                                    totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
    ({ indeterminate, ...rest }, ref) => {
        const defaultRef = React.useRef()
        const resolvedRef = ref || defaultRef

        React.useEffect(() => {
            resolvedRef.current.indeterminate = indeterminate
        }, [resolvedRef, indeterminate])

        return (<Checkbox ref={resolvedRef} {...rest} />)
    }
)

const FaultConfigurationTable = (props) => {
    const router = useRouter();

    const context = useContext(GlobalSpinnerContext);

    const faultConfigurations = props.faultConfigurations;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const getFaultConfigurations = props.getFaultConfigurations;
    
    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections, setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"fault-config" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "2",
			Header: "Fault Error Code",
            accessor: "errorCode",
            editable: true,
            width:2
		},
        {
			label: "4",
			Header: "Severity",
            accessor: "severity",
            editable: true,
            width:3
		},
        {
			label: "5",
			Header: "Related Error Code",
            accessor: "relatedErrorCode",
            editable: true,
            width:2
        },
        {
			label: "6",
			Header: "Trap Category",
            accessor: "trapCategory",
            editable: true,
            width:2
        },
        {
			label: "7",
			Header: "Policy Type",
            accessor: "policyType",
            width:3
        },
        {
            Header: "Policy Name",
            accessor: "policyName",
            width:3
        },
    ]

    const handleAddFaultConfig = () => {
        router.stateService.go("add-fault-config",{fetchData: fetchData, clearSelection: clearSelection})
    }

    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-fault-config',{id: faultConfigurations[selId].configId,fetchData: fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["fault-config-list"]);
        NoaClient.delete(
            "/api/platform/fault/config/",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null})
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getFaultConfigurations(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"fault-config" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getFaultConfigurations(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getFaultConfigurations(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Fault Configurations</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddFaultConfig}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={faultConfigurations}
                            columns={columns}
                            selectedRows={selections}
                            onSelectedRowsChange={setSelections}
                            clearSelected={clearSelected}
                            selectedPageSize={pageSize}
                            handlePagination={handlePagination}
                            totalPages={totalPages}
                            handlePageSize={handlePageSize}
                            totalEntries={totalEntries}
                            resource="Fault Configurations" 
                            fetchData={fetchData} 
                            location="fault-config-list"      
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const AddFaultConfiguration = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const getFaultConfigurations = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const [faultConfig, setFaultConfig] = useState({});
    const [faultPolicies, setFaultPolicies] = useState([]);
    const [parsedPolicies, setParsedPolicies] = useState([]);
    const [policyType, setPolicyType] = useState(null);

    useEffect(() => {
        context.setRenderLocation(['add-fault-config']);
        getFaultPolicies();
    },[]);

    const getFaultPolicies = () => {
        NoaClient.get(
        "/api/platform/fault/policy",
        (response) => {
            let responseData = response.data;
            setFaultPolicies(responseData);
        });
    }

    useEffect(() => {
        if(policyType != null) {
            let policiesList = [];
            let filteredPolicies = faultPolicies.filter(policy => policy.policyType === policyType);
            filteredPolicies.map((item,index) => {
                let policyObj = {'key' : item.policyId, 'value' : item.policyName, 'text': item.policyName}
                policiesList[index] = policyObj;
            })
            setParsedPolicies(policiesList);
        }
    },[policyType]);

    const handleChange = (value, key) => {
		setFaultConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        let selPolicy = faultPolicies.find(policy => policy.policyName == faultConfig.policyName);
        let policyId = selPolicy.policyId;
        NoaClient.put(
            "/api/platform/fault/config",
            faultConfig,
            (response) => {
                let responseData = response.data;
                let configId = responseData.configId;
                //context.setRenderLocation(['fault-config-list'])
                noaNotification('success', 'Fault Configuration Created Successfully');
                getFaultConfigurations();
                closeFooter();
                handleAddPolicy(configId,policyId);
        })
    }

    const handleAddPolicy = (configId,policyId) => {
        NoaClient.post(
            "/api/platform/fault/config/" + configId + "/policy/" + policyId,
            null,
            (response) => {
                noaNotification('success', 'Fault Policy Assigned Successfully');
        })
    }

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const policyTypes = [
        { 'key': "auto-escalate", 'text': "Auto Escalate", 'value': "auto-escalate" },
        { 'key': "auto-acknowledge", 'text': "Auto Acknowledge", 'value': "auto-acknowledge" }
    ]

    const severityTypes = [
        { 'key': "information", 'text': "Information", 'value': 1 },
        { 'key': "warning", 'text': "Warning", 'value': 2 },
        { 'key': "minor", 'text': "Minor", 'value': 3 },
        { 'key': "major", 'text': "Major", 'value': 4 },
        { 'key': "critical", 'text': "Critical", 'value': 5 }
    ]

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create Fault Config</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} textAlign='left' id="add-fault-config">
                <Grid columns={3} stackable>
                    <Grid.Column width={3}></Grid.Column>
                    <Grid.Column width={10} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} textAlign='center'>
                                            <p style={formHeader}>Fault Configuration Details</p>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1} style={formSpacingTB}>
                                        <Grid.Column width={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter} className="required">Error Code</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={7} textAlign='left'>
                                                        <Input type='number' name='errorCode' 
                                                            value={faultConfig.errorCode}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'errorCode')
                                                            }
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={2}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter} className="required">Severity</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={7} textAlign='left'>
                                                        <Dropdown clearable selection required selectOnBlur={false}
                                                                    placeholder="Severity Type"
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    options={severityTypes} 
                                                                    value={faultConfig.severity}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value,'severity')
                                                                    }
                                                        />
                                                    </Grid.Column>
                                                    <Grid.Column width={2}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Related Error Code</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={7} textAlign='left'>
                                                        <Input type='number' name='relatedErrorCode' 
                                                                    value={faultConfig.relatedErrorCode}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'relatedErrorCode')
                                                                    }
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={2}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Trap Category</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={7} textAlign='left'>
                                                        <Input type='number' name='trapCategory' 
                                                                    value={faultConfig.trapCategory}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'trapCategory')
                                                                    }
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={2}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} textAlign='center'>
                                            <p style={formHeader}>Fault Processing Policy</p>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1} style={formSpacingTB}>
                                        <Grid.Column width={16}>
                                            <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={2}></Grid.Column>
                                                    <Grid.Column width={5} textAlign='left'>
                                                    <p style={formParameter}>Fault Policy Type</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={7} textAlign='left'>
                                                        <Dropdown clearable selection required
                                                                selectOnBlur={false}
                                                                placeholder="Policy Type"
                                                                options={policyTypes}
                                                                style={dropdownStyle}
                                                                selectOnBlur={false}
                                                                value={faultConfig.policyType}
                                                                onChange={
                                                                    (e, {value}) => {
                                                                        let val = value == "" ? null : value
                                                                        setPolicyType(val)
                                                                        handleChange(val, 'policyType')
                                                                    }
                                                                }
                                                        />
                                                    </Grid.Column>
                                                    <Grid.Column width={2}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={2}></Grid.Column>
                                                    <Grid.Column width={5} textAlign='left'>
                                                        <p style={formParameter} className="required">Fault Policy</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={7} textAlign='left'>
                                                        <Dropdown clearable selection required
                                                                selectOnBlur={false}
                                                                placeholder="Policy Name"
                                                                options={parsedPolicies}
                                                                style={dropdownStyle}
                                                                value={faultConfig.policyName}
                                                                disabled={faultConfig.policyType == null ? true : false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value == "" ? null : value, 'policyName')
                                                                }
                                                        />
                                                    </Grid.Column>
                                                    <Grid.Column width={2}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={3}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                context.setRenderLocation(['add-fault-config'])
                                handleAdd()
                            }}>Add</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const ModifyFaultConfiguration = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    const clearSelection = props.clearSelection;
    const getFaultConfigurations = props.fetchData;

    const [faultConfig, setFaultConfig] = useState({});

    useEffect(() => {
        const configId = props.id;
        context.setRenderLocation(['modify-fault-config']);
        if(configId != null && configId != undefined) {
            getFaultConfiguration(configId);
        }
    },[props.id]);

    const getFaultConfiguration = (configId) => {
        NoaClient.get(
            "/api/platform/fault/config/" + configId,
            (response) => {
                let responseData = response.data;
                setFaultConfig(responseData);
            },
        )
    }

    const handleChange = (e, d) => {
        const target = e.target;
        const value = target.value==='' ? null : target.value;
        const name = target.name;

        setFaultConfig(prevState => ({
            ...prevState,
            [name]:value
        }));
    }

    const handleModify = () => {
        if(faultConfig != null) {
            context.setRenderLocation(['modify-fault-config']);
            const configId = faultConfig.configId;
            NoaClient.post(
                "/api/platform/fault/config/" + configId,
                faultConfig,
                (response) => {
                    //context.setRenderLocation(['fault-config-list'])
                    noaNotification('success', 'Fault Configuration Updated Successfully');
                    getFaultConfigurations();
                    closeFooter()
                    setFaultConfig({});
            })
        }
    }

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Fault Configuration Details: {faultConfig.errorCode}</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} textAlign='left' id="modify-fault-config">
                <Grid columns={3} stackable>
                    <Grid.Column width={5}></Grid.Column>
                    <Grid.Column width={6}>
                        <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={4} stackable>
                                <Grid.Column width={3}></Grid.Column>
                                <Grid.Column width={5} textAlign='left'>
                                    <p style={formParameter}>Error Code</p>
                                </Grid.Column>
                                <Grid.Column width={6} textAlign='left'>
                                    <Input type='number' name='errorCode' 
                                            value={faultConfig.errorCode}
                                            fluid={false}
                                            onChange={
                                                (event, data) => handleChange(event, data)
                                            }>
                                        <input style={inputBoxStyle}></input>
                                    </Input>
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={4} stackable>
                                <Grid.Column width={3}></Grid.Column>
                                <Grid.Column width={5} textAlign='left'>
                                    <p style={formParameter}>Severity</p>
                                </Grid.Column>
                                <Grid.Column width={6} textAlign='left'>
                                    <Input type='number' name='severity' 
                                        value={faultConfig.severity}
                                        fluid={false}
                                        onChange={
                                            (event, data) => handleChange(event, data)
                                        }>
                                        <input style={inputBoxStyle}></input>
                                    </Input>
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={4} stackable>
                                <Grid.Column width={3}></Grid.Column>
                                <Grid.Column width={5} textAlign='left'>
                                    <p style={formParameter}>Related Error Code</p>
                                </Grid.Column>
                                <Grid.Column width={6} textAlign='left'>
                                    <Input type='number' name='relatedErrorCode' 
                                        value={faultConfig.relatedErrorCode}
                                        fluid={false}
                                        onChange={
                                            (event, data) => handleChange(event, data)
                                        }>
                                        <input style={inputBoxStyle}></input>
                                    </Input>
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={4} stackable>
                                <Grid.Column width={3}></Grid.Column>
                                <Grid.Column width={5} textAlign='left'>
                                    <p style={formParameter}>Trap Category</p>
                                </Grid.Column>
                                <Grid.Column width={6} textAlign='left'>
                                    <Input type='number' name='trapCategory' 
                                        value={faultConfig.trapCategory}
                                        fluid={false}
                                        onChange={
                                            (event, data) => handleChange(event, data)
                                        }>
                                        <input style={inputBoxStyle}></input>
                                    </Input>
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                    <Grid.Column width={5}></Grid.Column>
                </Grid> 
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column textAlign='center' width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                handleModify()
                                context.setRenderLocation(['modify-fault-config']);
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

export default FaultConfig;
export {AddFaultConfiguration, ModifyFaultConfiguration}