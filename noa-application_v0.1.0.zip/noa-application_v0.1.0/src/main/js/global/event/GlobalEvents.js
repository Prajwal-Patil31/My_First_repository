import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../widget/NoaTable';

import {
    Grid,
    Segment,
    Checkbox,
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, fullHeight,
    titleText, cardLayout, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight
} from '../../constants';

import { NoaContainer} from '../../widget/NoaWidgets';
import NoaClient from '../../utility/NoaClient';
import NoaFilter from '../../widget/NoaFilter';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';

const GlobalEvents = (props) => {
    const [events, setEvents] = useState([]);
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = events[sel[i]].eventId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getEvents = (filterObj) => {
        context.setRenderLocation(["global-events-list"]);
        NoaClient.post(
            "/api/global/event",
            filterObj,
            (response) => {
                let responseData = response.data;
                setEvents(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }/* ,source */);
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/global/event/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        let filterCriteria = {};
        filterCriteria["filters"] = {"ietf-network":{}};
        filterCriteria["pagination"] = null;
        filterCriteria["sort"] = null;
        getEvents(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                            <GlobalEventsTable events={events} getEvents={getEvents}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const GlobalEventsTable = (props) => {
    const events = props.events;
    const getEvents = props.getEvents;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    const filters = props.filters;
    //const columns = props.columns;

    const [selections, setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"event" : {}});

    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "2",
			Header: "Event Type",
            accessor: "eventType",
            width:2
		},
        {
			label: "4",
			Header: "Resource",
            accessor: "resource",
            width:2
		},
        {
			label: "5",
			Header: "Resource Identifier",
            accessor: "resourceId",
            width:2
        },
        {
			label: "6",
			Header: "Description",
            accessor: "description",
            width:2
        },
        {
			label: "7",
			Header: "Timestamp",
            accessor: "timeStamp",
            width:2
        },
        {
			label: "8",
			Header: "Acknowledged User",
            accessor: "acknowledgedUser",
            width:2
        },
        {
			label: "9",
			Header: "Acknowledged Timestamp",
            accessor: "acknowledgedTimeStamp",
            width:3
        }
    ]

    const clearSelection = () => {
        setClearSelected(true);
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getEvents(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"event" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getEvents(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getEvents(filterObj)
    }

    const fetchData = () => fetchFilteredData({"filters":null})

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Event List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>                              
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={events}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        resource="Events" 
                        fetchData={fetchData} 
                        location="global-events-list"
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}
export default GlobalEvents;