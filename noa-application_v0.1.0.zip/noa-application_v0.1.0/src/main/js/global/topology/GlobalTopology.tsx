// @flow

import React, { useState, useEffect, useContext } from 'react';

import useNext, {
	TopologyConfig,
	TopologyData,
	EventHandlers,
	TopologyNode,
	TopologyLink
} from "../../lib/modules/Next";

import { useHistory } from 'react-router-dom';

import {
	Grid,
	Container,
	Dropdown,
	Checkbox,
	Menu,
	Segment,
	Popup,
	Label
} from 'semantic-ui-react';

import "../../lib/next/css/next.min.css";
import 'semantic-ui-css/semantic.min.css';

import { 
	subMenuItem, completeHeight, subMenuLayout,
	completeWidth, bodyLayoutFlex, topologyChartTitle,
	noPadding, topologyContainer, topologyChartValue, 
	topologyChartDesc, dropdownStyle
} from '../../constants';

import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';

import useOutsideClickAlert from '../../utility/useOutsideClickAlert';
import { createPortal } from 'react-dom';
import {NodeTooltip,LinkTooltip} from '../../widget/TopoTooltip';

import { NoaContainer } from '../../widget/NoaWidgets';
import NoaFilter from '../../widget/NoaFilter';
import { useLocation } from "react-router-dom";
import { MenuContext } from '../../utility/MenuContext';

const nodeSetLocations = [
	{ "x": 202.528, "y": 126.800},
	
	{ "x": 182.528, "y": 106.800},
	{ "x": 129.951026, "y": 195.723076},
	{ "x": 232.951026, "y": 305.723076},
	{ "x": 192.528, "y": 136.800},
	{ "x": 239.951026, "y": 385.723076},
];

const locations = [
	{"latitude": 76.420, "longitude": -19.745},
	{"latitude": 68.825, "longitude": 12.785},
	{"latitude": 77.850, "longitude": 98.177},
	{"latitude": 31.839,"longitude": -40.798},
	{"latitude": 82.843,"longitude": -91.105},
	{"latitude": 57.578,"longitude": -87.143},
	{"latitude": 86.832,"longitude": -68.099},
	{"latitude": 69.203, "longitude": -111.016},
	{"latitude": 78.018, "longitude": -109.743},
	{"latitude": 47.900, "longitude": -92.778},
	{"latitude": 18.591,"longitude": -81.478},
	{"latitude": 8.350, "longitude": -43.811},
	{"latitude": -27.422, "longitude": -44.941},
	{"latitude": 68.688,"longitude": -39.572},
	{"latitude": 69.905, "longitude": 95.933},
	{"latitude": 66.409,"longitude": 48.849},
]

const sampleConfig: TopologyConfig = {
	'adaptive': true,
	'showIcon': true,
	'nodeConfig': {
		'label': 'model.name',
		'iconType': 'router',
		'color': 'model.color',
	},
	'linkConfig': {
		'linkType': 'curve',
		'color' : 'model.color'
	},
	'layoutType' : 'INMap',
	'layoutConfig': {
		'longitude': 'model.longitude',
		'latitude': 'model.latitude'
	},
	'nodeSetConfig': {
		'identityKey': 'name',
		'label': 'model.name',
		'iconType': 'router',
		'color': 'model.color',
	},
	'identityKey': 'name',
	'dataProcessor': 'force',
	'enableSmartLabel': true,
	'enableGradualScaling': true,
	'supportMultipleLink': true
};

const PopupVisibilityContext = React.createContext();

const PopupVisibilityProvider = (props) => {
	const [visibility, setVisibility] = useState(false);
	
    return (
        <PopupVisibilityContext.Provider
            value={{
				visibility: visibility,
				setVisibility: setVisibility
            }}
        >
            {props.children}
        </PopupVisibilityContext.Provider>
    )
}
const GlobalTopologyContext = React.createContext();

const GlobalTopologyProvider = (props) => {

	const [filteredTopology, setFilteredTopology] = useState({});
	const [networks, setNetworks] = useState([]);
	const [services, setServices] = useState([]);

	const [selNetworks, setSelNetworks] = useState([]);
	const [nwType, setNwType] = useState("L3 Network");
	const [servType, setServType] = useState(null);
	const [selServices, setSelServices] = useState([]);

	const getNetworks = () => {
		let filter = {
            "filters" : {
                "ietf-network" : {
                    "network-type" : [nwType]
                }
            }
        }

        NoaClient.post(
            "/api/network",
            filter,
            (response) => {
                let responseData = response.data;
                let networksList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        networksList[index] = nodeObj;
                    })
                }
                setNetworks(networksList);
            }
        )
	}

	const getServices = () => {
		let filter = {
            "filters" : {
                "vpn-service" : {
                    "service-type" : [servType]
                }
            }
        }

        NoaClient.post(
            "/api/service/",
            filter,
            (response) => {
                let responseData = response.data;
                let servicesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.serviceId, 'value' : item.serviceId, 'text': item.serviceName}
                        servicesList[index] = nodeObj;
                    })
                }
                setServices(servicesList);
            }
        )
	}

	useEffect(() => {
		if(nwType != null) {
			getNetworks();
		}
	},[nwType]);

	useEffect(() => {
		if(servType != null) {
			getServices();
		}
	},[servType]);

    return (
        <GlobalTopologyContext.Provider
            value={{
                selNetworks: selNetworks,
				setSelNetworks: setSelNetworks,
				selServices: selServices,
				setSelServices: setSelServices,
				nwType: nwType,
				servType: servType,
				setNwType: setNwType,
				setServType: setServType,
				networks: networks,
				services: services,
				filteredTopology: filteredTopology,
				setFilteredTopology: setFilteredTopology
            }}
        >
            {props.children}
        </GlobalTopologyContext.Provider>
    )
}

const GlobalTopology = () => {	

	return (
	<NoaContainer style={Object.assign({},bodyLayoutFlex, completeHeight,completeWidth)}>
		<GlobalTopologyProvider>
			<PopupVisibilityProvider>
			<Grid>
				<NoaContainer style={completeWidth}>
				<Grid.Row columns={1} style={Object.assign({},noPadding)}>
					<Grid.Column width={16}>
					</Grid.Column>
				</Grid.Row>
				</NoaContainer>
			</Grid>
			<Grid style={completeHeight}>
				<NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
					<Grid.Row columns={1} style={completeHeight}>
						<Grid.Column width={16} style={completeHeight}>
							<GlobalTopologyView />
						</Grid.Column>
					</Grid.Row>
				</NoaContainer>
			</Grid>
			</PopupVisibilityProvider>
		</GlobalTopologyProvider>
	</NoaContainer>		
	)
};

const GlobalTopologyView = (props) => {
	const context = useContext(GlobalSpinnerContext);
	const redirectContext = useContext(RouteRediretContext);
	const topologyContext = useContext(GlobalTopologyContext);
	const visibilityContext = useContext(PopupVisibilityContext);

	let location = useLocation();
	let currentPath = location.pathname;

    const menuContext = useContext(MenuContext);

    useEffect(() => {
		menuContext.setData([]);
        menuContext.setHideMenu(true);
        menuContext.setDisplayText("Global Topology");
	},[currentPath]);
	
	const history = useHistory();

	const [nodeId, setNodeId] = useState(null);
	const [linkId, setLinkId] = useState(null);
	const [linkDetails, setLinkDetails] = useState({});
	const [nodeDetails, setNodeDetails] = useState({});

	const [networkDetails, setNetworkDetails] = useState({});
	const [serviceDetails, setServiceDetails] = useState({});

	const [baseNetworks, setBaseNetworks] = useState([]);
	
	const [networkTopology, setNetworkTopology] = useState({});

	const [redirectionType, setRedirectionType] = useState(null);
	
	const [selectedMenuItem, setSelectedMenuItem] = useState(null);

	const [sampleTopology, setSampleTopology] = useState<TopologyData>({} as TopologyData);

	const [renderNodeTooltip, setRenderNodeTooltip] = useState(false);
	const [renderLinkTooltip, setRenderLinkTooltip] = useState(false);

	const [hierarchyData, setHierarchyData] = useState({});

	const [topology, setTopology] = useState(sampleTopology);
	
	const [topologyView, setTopologyView] = useState("BASIC");
	const [topologyAction, setTopologyAction] = useState(null);

	const [zoomLevel, setZoomLevel] = useState(0);

	const { ref, isClickedOutside } = useOutsideClickAlert(false);

	const [filteredNetworks, setFilteredNetworks] = useState([]);
	const [filteredNodes, setFilteredNodes] = useState([]);
	const [filteredLinks, setFilteredLinks] = useState([]);

	const topologyViews = {
		'ENABLE_MAP_VIEW': 'Enable Map View',
		'SHOW_HIERARCHY': 'Show Hierarchy',
		'SHOW_TRAFFIC': 'Show Traffic',
		'SHOW_END_TO_END_PATHS': 'Show End-to-End Paths'
	}

    const forRedirection = (id) => {
        const selectedNode = id;
		
		if(redirectionType === "L2 VPN Network") {
			const deviceId = selectedNode.split('@')[1];
			history.push({
				pathname: '/network/elements/' + deviceId + "/l2vpn-instances/" + selectedNode,
				state: { nodeId: selectedNode }
			})
		} else if (redirectionType === "L3 VPN Network") {
			const deviceId = selectedNode.split('@')[1];
			history.push({
				pathname: '/network/elements/' + deviceId + "/l3vpn-instances/" + selectedNode,
				state: { nodeId: selectedNode }
			})
		} 
		else if (redirectionType === "Network") {
			history.push({
				pathname: '/network/networks/' + selectedNode,
				state: { nodeId: selectedNode }
			})
		} else {
			history.push({
				pathname: '/network/elements/' + selectedNode,
				state: { networkId: selectedNode }
			})
		}
	}

	useEffect(()=> {
		NoaClient(context, redirectContext);
		context.setRenderLocation(["global-topology"])
		getNetworkTopology(true,topologyContext.nwType);
		//setTopologyData(sampleTopologyData, true, true,'INMap'); */
	},[]);

	useEffect(() => {
		getNetworkTopology(true,topologyContext.nwType);
	},[topologyContext.nwType]);

	const getNetworkTopology = (zoomFit,networkType) => {
		if(networkType != null && networkType !="") {
			NoaClient.get(
				"/api/global/topology/" + networkType,
				(response) => {
					let responseData = response.data;
					setNetworkTopology(responseData);
					delete responseData["nodeSets"]
					setTopologyData(responseData, zoomFit != null ? zoomFit : false, true,'INMap');
				}
			)
		}
	}

	useEffect(() => {
		if(isClickedOutside) {
			nxApp.tooltipManager().closeAll();
			nxApp.stageTooltip().close();
		}
	}, [isClickedOutside])

	useEffect(() => {
		if(topologyContext) {
			if(topologyContext.filteredTopology.nodes != undefined){
				let nodes = topologyContext.filteredTopology.nodes;
				let nodesList = [];
				nodes.map((item) => {
					nodesList.push(item.name);
				})
				setFilteredNodes(nodesList);
			}

			if(topologyContext.filteredTopology.links != undefined){
				let links = topologyContext.filteredTopology.links;
				let linksList = [];
				links.map((item) => {
					linksList.push(item.name);
				})
				setFilteredLinks(linksList);
			}

			if(topologyContext.filteredTopology.nodeSets != undefined){
				let nodeSets = topologyContext.filteredTopology.nodeSets;
				let networksList = [];
				nodeSets.map((item) => {
					networksList.push(item.name);
				})
				setFilteredNetworks(networksList);
			}
		}
	},[topologyContext.filteredTopology]);

	useEffect(() => {
		let topology = networkTopology
		if(filteredNodes.length > 0) {
			let nodes = topology.nodes;
			let parsedNodes =[];
			nodes.map((item) => {
				if(filteredNodes.includes(item.name)) {
					item["color"] = "#0how00";
				} else {
					item["color"] = "#999";
				}
				parsedNodes.push(item);
			});
			topology["nodes"] = parsedNodes;
			
		}

		if(filteredLinks.length > 0) {
			let links = topology.links;
			let parsedLinks =[];
			links.map((item) => {
				if(filteredLinks.includes(item.name)) {
					item["color"] = "#0how00";
				} else {
					item["color"] = "#999";
				}
				parsedLinks.push(item);
			});
			topology["links"] = parsedLinks;
		}
		setNetworkTopology(topology);
		delete topology["nodeSets"]
		setTopologyData(topology, true, true,'INMap');
	},[filteredNodes,filteredLinks]);

	let nodesLayer = []

	const getNetworkDetails = () => {
		let networkIds = topologyContext.selNetworks;
		NoaClient.post(
			"/api/global/topology/network",
			networkIds,
			(response) => {
				let obj = {};
				let responseData = response.data;
				let keys = Object.keys(responseData);
				for(let i = 0 ; i < keys.length ; i++) {
					let key = keys[i];
					let nodes = responseData[key];
					let objKeys = Object.keys(obj);
					nodes.forEach(node => {
						if(objKeys.includes(node)) {
							let arr = obj[node];
							let newArray = [...arr,key];
							obj[node] = newArray
						} else {
							obj[node] = [key];
						}
					})
				}
				setNetworkDetails(obj);
			}
		)
	}

	useEffect(() => {
		let keys = Object.keys(networkDetails);
		if(keys.length > 0) {
			nodesLayer = nxApp.getLayer("nodes");
			let nodes = []
			nodes = nodesLayer.nodes();
			let color = "#F6C565";
			nodes.forEach((node,index) => {
				if(keys.includes(node.id())) {
					window.nx.util.setProperty(node, 'color', color);
				}
			})
		}
	},[networkDetails]);

	useEffect(() => {
		setTopologyData(networkTopology,true, true,'INMap');
		if(topologyContext.selNetworks.length > 0) {
			getNetworkDetails();
		}
		if(topologyContext.selServices.length > 0) {
			getServiceDetails();
		}
	},[topologyContext.selNetworks,topologyContext.selServices]);

	const getServiceDetails = () => {
		let serviceIds = topologyContext.selServices;
		NoaClient.post(
			"/api/global/topology/service",
			serviceIds,
			(response) => {
				let obj = {};
				let responseData = response.data;
				let keys = Object.keys(responseData);
				for(let i = 0 ; i < keys.length ; i++) {
					let key = keys[i];
					let nodes = responseData[key];
					let objKeys = Object.keys(obj);
					nodes.forEach(node => {
						if(objKeys.includes(node)) {
							let arr = obj[node];
							let newArray = [...arr,key];
							obj[node] = newArray
						} else {
							obj[node] = [key];
						}
					})
				}
				setServiceDetails(obj);
			}
		)
	}

	useEffect(() => {
		let keys = Object.keys(serviceDetails);
		if(keys.length > 0) {
			nodesLayer = nxApp.getLayer("nodes");
			let nodes = []
			nodes = nodesLayer.nodes();
			let color = "#F6C565";
			nodes.forEach((node,index) => {
				if(keys.includes(node.id())) {
					window.nx.util.setProperty(node, 'color', color);
				}
			})
		}
	},[serviceDetails]);


	let nodeSetLayer = []
	
	const setTopologyData = (topologyData, zoomFit, localMapView, layoutType) => {
		let networkTopology = Object.assign({}, topologyData);
		let modifiedNodes = [];
		let modifiedLinks = [];
		let modifiedNodeSets = [];
		
		if(networkTopology != null) {
			if(Array.isArray(networkTopology["nodes"]) && Array.isArray(networkTopology["links"])) {
				let nodes = networkTopology["nodes"];
				let links = networkTopology["links"];
				let nodeSets = networkTopology["nodeSets"];
					
				modifiedNodes = nodes.map((node,index) => {
					let nodeObj = node;
					nodeObj["latitude"] = locations[index % locations.length].latitude;
					nodeObj["longitude"] = locations[index % locations.length].longitude;
					return nodeObj;
				})
	
				modifiedLinks = links.map(link=>{
					const linkObj = link;
					if(link.color!== null && link.color!== undefined) {
						linkObj["color"] = link.color;
						return linkObj;
					}
					return linkObj;
				})
	
				if(nodeSets !== undefined && nodeSets && nodeSets.length) {
					modifiedNodeSets = nodeSets.map((nodeSet,index) => {
						nodeSet["x"] = locations[index % locations.length].latitude;
						nodeSet["y"] = locations[index % locations.length].longitude;
						nodeSet["latitude"] = locations[index % locations.length].latitude;
						nodeSet["longitude"] = locations[index % locations.length].longitude;
						return nodeSet;
					});
				}

				let topologyData: TopologyData = {
					"nodes": modifiedNodes,
					"links": modifiedLinks,
					"nodeSet": modifiedNodeSets,
					"zoomFit": true,
					"mapView" : localMapView,
					"layoutType" : 'INMap'
				}				
				setSampleTopology(topologyData);
			}
			
		} 
	}

	useEffect(() => {
		switch (topologyAction) {
			case 'SHOW_HIERARCHY':
				//setMapView(false);
				hierarchicalViewRender()
				break;
			case 'REMOVE_HIERARCHY':
				setTopologyData(networkTopology, true, false,'INMap');
				break;
			case 'SHOW_TRAFFIC':
				nodeSetViewRender('green',topologyView);
				break;
			case 'HIDE_TRAFFIC':
				nodeSetViewRender('0how00',topologyView);
				break;
			case 'ENABLE_MAP_VIEW':
				setTopologyData(networkTopology, true, true,'INMap');
				
				break;
			case 'DISABLE_MAP_VIEW':
				setTopologyData(networkTopology, true, false,'INMap');
				break;
			case 'SHOW_END_TO_END_PATHS':
				hierarchicalViewRender();
				break;
			case 'HIDE_END_TO_END_PATHS':
				nodeSetViewRender(null,topologyView);
				break;
			default:
				nodeSetViewRender(null,topologyView);
				break;
		}
	}, [topologyView, topologyAction]);

	const renderNodeSets = () => {
		let nodeSets = [];
		switch (topologyView) {
			case 'NETWORKS':
				nodeSets = networkTopology[topologyContext.nwType]["networks"];
				break;
			case 'BASE_NETWORK':
				nodeSets = baseNetworks;
				break;
			default:
				break;
		}
		nodeSets.map((nodeSet,index) => {
			nodeSet["x"] = nodeSetLocations[index % nodeSetLocations.length].x;
			nodeSet["y"] = nodeSetLocations[index % nodeSetLocations.length].y;
			nxApp.addNodeSet(nodeSet);
		})
	}

	const nodeSetViewRender = (color,topologyAction) => {
		if(topologyAction == "BASIC") {
			if(typeof topology.getLayer !== 'undefined') {
				let newTopology = {
					'nodes': [],
					'links': [],
					'nodeSet': []
				}
	
				networkTopology[topologyContext.nwType]['nodes'].forEach(node => {
					newTopology['nodes'].push(node);
				})
					
				networkTopology[topologyContext.nwType]['links'].map(link => {
					newTopology['links'].push(link);
				})
	
				setTopologyData(newTopology, false, null,'INMap');
				
			}	
		} else {
			renderNodeSets();
		}
	}

	const [nodeArray, setNodeArray] = useState([]);

	const hierarchicalViewRender = () => {
		setTopologyData(hierarchyData, true, false,null);
	}

	const handleLinkClick = (link) => {
		setRenderLinkTooltip(true);
		setLinkId(link.id());
	}

	const handleNodeClick = (node) => {
		setRenderNodeTooltip(true);
		setNodeId(node.id());
		let nodeId = node.id();
		//getNodeDetails(nodeId)
	}

	useEffect(() => {
		if(nodeId != null) {
			context.setRenderLocation(["tooltip-node"]);
			getNodeDetails(nodeId);
		}
	},[nodeId]);

	const getNodeDetails = (selId) => {
		if(selId != null && selId != undefined) {
			let nodes = networkTopology.nodes;
			let selNode = nodes.find(node => node.name === selId);
			let elementId = selNode.id;
			NoaClient.get(
				"/api/element/" + elementId,
				(response) => {
					let responseData = response.data;
					setNodeDetails(responseData);
				}
			)
		}
	}
	
	const getLinkDetails = () => {
		NoaClient.get(
			"/api/global/topology/" + topologyContext.nwType + "/link/" + linkId,
            (response) => {
				let responseData = response.data;
				setLinkDetails(responseData);
            }
        )
	}
	
	/* useEffect(() => {
		if(nodeId != null) {
			getNodeDetails();
		}
	},[nodeId]); */

	useEffect(() => {
		if(linkId != null) {
			context.setRenderLocation(["tooltip-link"]);
			getLinkDetails();
		}
	},[linkId]);

	const setContext = (nxApp: any) => {
		setTopology(nxApp);

		var nxTopologyView = 'BASIC';
		var nxTopologyAction = null;
		var nodeEnter = false;
		var linkEnter = false;
		var nodeSetSelected = false;

		nx.define('StageTooltip', nx.graphic.Topology.Tooltip, {
			properties: {
				topology: {},
				title: {}
			},
			view: {
				props: {
					'class': 'popover fade',
					style: {
						position: 'absolute',
						outline: "none",
					},
					tabindex: -1
				},
				content: [
					{
						props: {
							'class': 'arrow'
						}
					},
					{
						name: 'header',
						props: {
							'class': 'n-topology-tooltip-header'
						},
						content: [
							{
								tag: 'h',
								props: {
									'class': 'ui teal header'
								},
								name: 'title',
							}
						]
					},
					{
						name: 'content',
						props: {
							'class': 'n-topology-tooltip-content n-list'
						},
						content: [
							{
								name: 'list',
								tag: 'div',
								props: {
									'class': 'ui divided relaxed list',
									template: {
										tag: 'div',
										props: {
											'class': 'item',
											role: 'listitem',
											style: {
												'height' : '30px'
											}
										},
										content: [
											{
												tag: 'label',
												content: '{value}'
											},
										],
										events: {
											'mouseup': '{#_selectMenuItem}',
											'mouseenter': '{#_mouseenter}',
										}
									}
								}
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					let menuItems = Object.assign({}, topologyViews);
					delete menuItems[nxTopologyView];

					if(nxTopologyAction !== null) {
						delete menuItems[nxTopologyAction];
					}

					switch (nxTopologyView) {
						
						case 'BASE_NETWORK':
							switch (nxTopologyAction) {
								case null:
								case 'REMOVE_HIERARCHY':
								/* case 'SHOW_TRAFFIC':
								case 'HIDE_TRAFFIC': */
									menuItems['EXPAND_BASE_NETWORKS'] = 'Expand Base Networks';
									break;
								default:
									break;
							}
							break;
						default:
							break;
					}	
					
					switch (nxTopologyAction) {
						case 'SHOW_HIERARCHY':
							menuItems['REMOVE_HIERARCHY'] = 'Remove Hierarchy';
							break;
						case 'REMOVE_HIERARCHY':
							menuItems['SHOW_HIERARCHY'] = 'Show Hierarchy';
							break;
						case 'SHOW_TRAFFIC':
							menuItems['HIDE_TRAFFIC'] = 'Hide Traffic';
							break;
						case 'HIDE_TRAFFIC':
							menuItems['SHOW_TRAFFIC'] = 'Show Traffic';
							break;
						case 'ENABLE_MAP_VIEW':
							menuItems['DISABLE_MAP_VIEW'] = 'Disable Map View';
							break;
						case 'DISABLE_MAP_VIEW':
							menuItems['ENABLE_MAP_VIEW'] = 'Enable Map View';
							break;
						case 'SHOW_END_TO_END_PATHS':
							menuItems['HIDE_END_TO_END_PATHS'] = 'Hide End-to-End Paths';
							break;
						case 'HIDE_END_TO_END_PATHS':
							menuItems['SHOW_END_TO_END_PATHS'] = 'Show End-to-End Paths';
							break;	
						default:
							break;
					}

					this.view('list').set('items', new nx.data.Dictionary(menuItems));
					this.open(args);
				},
				_selectMenuItem: function(sender, event) {
					if(sender.model().key() === 'BASIC' || 
						sender.model().key() === 'NETWORK_SLICE' || 
						sender.model().key() === 'NETWORKS' || 
						sender.model().key() === 'BASE_NETWORK') {
						nxTopologyView = sender.model().key();
						setTopologyView(sender.model().key());
						nxTopologyAction = null;
						setTopologyAction(null);
					} else {
						nxTopologyAction = sender.model().key();
						setTopologyAction(nxTopologyAction);
					}
				},
				_mouseenter: function (sender, event) {
					
				},
			}
		})

		var stageTooltip = new StageTooltip();

		nxApp.stageTooltip(stageTooltip);

		nxApp.on('rightClickStage', function(sender, event) {
			if(!nodeEnter) {
				nxApp.selectedNodes().clear();
			}
			if(nxApp.selectedNodes().toArray().length === 0  && nodeSetSelected == false) {
				stageTooltip.setView({
					target: {
						x: event.pageX,
						y: event.pageY
					}
				});
			}
		});

		window.nx.define('nodeContextMenu', window.nx.ui.Component, {
			properties: {
				node: {
					set: function (node) {
						this.title(node.label());
						this.selectedNodeId(node.label())
					}
				},
				topology: {},
				title: {},
				selectedNodeId: {},
			},
			view: {
				content: [
					{
						name: 'content',
						content: [
							{
								tag: 'div',								
								props: {
									'id': 'node-tooltip',
									style: {
										height: "400px",
										width: "320px"
									},
								},
								name: 'nodeTooltip',
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					this.open(args);
				},
			}
		});

		window.nx.define('linkContextMenu', window.nx.ui.Component, {
			properties: {
				node: {
					set: function (link) {
						this.title(link.label());
						this.selectedNodeId(link.label())
						let menuItems = {}
						menuItems['View ' + link.label()] = 'View_Configuration';
					}
				},
				topology: {},
				title: {},
				selectedNodeId: {},
			},
			view: {
				content: [
					{
						name: 'content',
						props: {
							'class': 'n-topology-tooltip-content n-list'
						},
						content: [
							{
								tag: 'div',								
								props: {
									'id': 'link-tooltip',
									style: {
										height: "400px",
										width: "320px"
									},
								},
								name: 'linkTooltip',
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					this.open(args);
				},
			}
		});

		nx.define('NodeSetContextMenu', nx.graphic.Topology.Tooltip, {
			properties: {
				topology: {},
				title: {},
				selectedNodeSetId: {}
			},
			view: {
				props: {
					'class': 'popover fade',
					style: {
						position: 'absolute',
						outline: "none"
					},
					tabindex: -1
				},
				content: [
					{
						props: {
							'class': 'arrow'
						}
					},
					{
						name: 'header',
						props: {
							'class': 'n-topology-tooltip-header'
						},
						content: [
							{
								tag: 'span',
								props: {
									'class': 'n-topology-tooltip-header-text'
								},
								name: 'title',
								content: '{#title}'
							}
						]
					},
					{
						name: 'content',
						props: {
							'class': 'n-topology-tooltip-content n-list'
						},
						content: [
							{
								name: 'list',
								tag: 'ul',
								props: {
									'class': 'n-list-wrap',
									template: {
										tag: 'li',
										props: {
											'class': 'n-list-item-i',
											role: 'listitem',
											style: {
												'padding': 1,
												'margin': 1,
												'font-size': 12,
												'border-bottom': 'solid'
											}
										},
										content: [
											{
												tag: 'label',
												content: '{key}',
												props: {
													value: "{value}"
												}
											},
										],
										events: {
											'mouseup': '{#_selectMenuItem}'
										}
									}
								},
								events: {
									'mouseleave': '{#_leaveMenu}'
								},
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					const nodeSet = args.nodeSet;
					this.selectedNodeSetId(nodeSet.label());
					let menuItems = {};
					menuItems['View ' + nodeSet.label() ] = 'View_Configuration';

					this.view('list').set('items', new nx.data.Dictionary(menuItems));
					this.open(args);
				},
				_selectMenuItem: function(sender, event) {
					nxTopologyView = sender.model().value();
					forRedirection(this.selectedNodeSetId());
					setSelectedMenuItem(sender.model().value());
				},
				_leaveMenu: function(sender, event) {
					this.close();
				}
			}
		})

		var nodeSetContextMenu = new NodeSetContextMenu();

		nxApp.on('pressStage', function(sender, event) {
			nodeSetContextMenu.close()
			stageTooltip.close();
		});

		nxApp.on('beforeSetData', function(sender, event) {
			stageTooltip.close();
		});

		nxApp.on('clickNodeSet', function(sender, nodeSet) {
			let clickType = event.button;
			setRedirectionType("Network");
			switch(clickType) {
				case 2:
					nodeSetSelected = true;
					nodeSetContextMenu.setView({
						target: {
							x: event.pageX,
							y: event.pageY
						},
						nodeSet: nodeSet
					});
					break;
				default:
					break;
			}
		});

		window.nx.define("customTooltipPolicy", window.nx.graphic.Topology.TooltipPolicy, {
			properties: {
				topology: {},
				tooltipManager: {},
			},
			methods: {
				init(args: any) {
					// @ts-ignore
					this.sets(args);
					// @ts-ignore
					this._tm = this.tooltipManager();
				},
				clickLink(link: TopologyLink) {
					this._tm.openLinkTooltip(link);
					handleLinkClick(link);
					visibilityContext.setVisibility(true);
					// Overwrite click behavior: Do nothing.
					// This prevents the popup from displaying in the Next container
				},
				leaveNode() {
					nodeEnter = false;
					//this._tm.closeAll();
				},
				doubleClickNode(node: TopologyNode) {
					this._tm.closeAll();
				},
				rightClickNode(node: TopologyNode) {
					setRedirectionType("Element")
					//this._tm.openNodeTooltip(node);
				},
				enterNode(node: TopologyNode) {
					nodeEnter = true;
					//this._tm.openNodeTooltip(node);
					//handleNodeClick(node);
				},
				clickNode(node: TopologyNode) {
					this._tm.openNodeTooltip(node);
					handleNodeClick(node);
					visibilityContext.setVisibility(true);
					//this._tm.openNodeTooltip(node);
				},
				enterLink(link: TopologyLink) {
					linkEnter = true;
				},
				leaveLink() {
					linkEnter = false
				},
				enterNodeSet() {
					nodeEnter = true;
					nodeSetSelected = true;
				},
				leaveNodeSet() {
					nodeEnter = false;
					nodeSetSelected = false;
				},
				clickStage(){
					if(!nodeEnter) {
						if(!linkEnter) {
							visibilityContext.setVisibility(false);
						}
					}
				}
			},
		});
		
		window.nx.define('CustomNodeToolTip', nx.graphic.Topology.Tooltip, {
			properties: {
				items: {},
				serviceItems: {},
				heading: {},
				topology: {},
				title: {},
				label: {}
			},
			view: {
				props: {
					'class': 'popover fade',
					style: {
						position: 'absolute',
						outline: "none",
					},
					tabindex: -1
				},
				content: [
					{
						props: {
							'class': 'arrow'
						}
					},
					{
						name: 'header',
						props: {
							'class': 'n-topology-tooltip-header'
						},
						content: [
							{
								tag: 'h',
								props: {
									'class': 'n-topology-tooltip-header-text'
								},
								name: 'label',
								content: '{#label}'
							}
						]
					},
					{
						name: 'content',
						props: {
							'class': 'n-topology-tooltip-content n-list'
						},
						content: [
							{
								tag: 'span',
								props: {
									'class': 'n-topology-tooltip-header-text'
								},
								name: 'title',
								content: '{#title}'
							},
							{
								name: 'list',
								tag: 'div',
								props: {
									'class': 'ui divided relaxed list',
									template: {
										tag: 'div',
										props: {
											'class': 'item',
											role: 'listitem',
											style: {
												'height' : '30px'
											}
										},
										content: [
											{
												tag: 'label',
												content: '{value}'
											},
										]
									}
								}
							},
							// service related render
							{
								tag: 'span',
								props: {
									'class': 'n-topology-tooltip-header-text'
								},
								name: 'heading',
								content: '{#heading}'
							},
							{
								name: 'serviceList',
								tag: 'div',
								props: {
									'class': 'ui divided relaxed list',
									template: {
										tag: 'div',
										props: {
											'class': 'item',
											role: 'listitem',
											style: {
												'height' : '30px'
											}
										},
										content: [
											{
												tag: 'label',
												content: '{value}'
											},
										]
									}
								}
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					const node = args.node;
					const title = args.title;
					const heading = args.heading;
					this.title(title);
					this.heading(heading);
					this.label(args.label);
					
					let networkArr = args.items;
					let serviceArr = args.serviceItems;

					let tooltipItems = {};
					if(networkArr != undefined) {
						networkArr.forEach(item => {
							tooltipItems[item] = item;
						})
					}
					
					let serviceItems = {};
					if(serviceArr != undefined) {
						serviceArr.forEach(item => {
							serviceItems[item] = item
						})
					}
					this.view('list').set('items', new nx.data.Dictionary(tooltipItems));
					this.view('serviceList').set('items', new nx.data.Dictionary(serviceItems));
					this.open(args);
				},
			}
		})
		nxApp.tooltipManager().tooltipPolicyClass("customTooltipPolicy");
		nxApp.tooltipManager().registerTooltip("StageTooltip", nx.graphic.Topology.Tooltip);
		nxApp.tooltipManager().nodeTooltipContentClass("nodeContextMenu");
		nxApp.tooltipManager().linkTooltipContentClass("linkContextMenu");

		window.nx.define('ExtendedScene', window.nx.graphic.Topology.Scene, {
			methods: {
				activate: function () {
				},
				deactivate: function () {
					//setAddFlow(true);
					/* var pathLayer = drawPath(nxApp);
					pathLayer.clear(); */
				},
				clickNode: function (sender, node) {
					if (nodeArray.includes(String(node.id()))) {
					} else {
						setNodeArray(prev => [...prev, node.id()]);
					}
				}
			}
		});
	}

	const handleZooming = (nxApp) => {
		const zoom = nxApp.stage().zoomLevel();
		console.log(zoom)
		if(zoom < 1.25) {
			if(zoomLevel !== 0) {
				setZoomLevel(0);
				nxApp.collapseAll();
			}
		} else if(zoom >= 1.25) {
			if(zoomLevel !== 1) {
				setZoomLevel(1);
				nxApp.expandAll();
			}
		}
	}

	let customNodeToolTip = null;

	const sampleEvtHandlers: EventHandlers = {
		topologyGenerated: (nxApp: any) => {
			if(topologyAction !== "SHOW_HIERARCHY") {
				if(zoomLevel === 0) {
					nxApp.collapseAll()
				} else if(zoomLevel === 1) {
					nxApp.expandAll();
				}
			}			
			if(topologyAction === "SHOW_HIERARCHY") {
				vertical(nxApp);
			}
		},
		zooming:(nxApp: any) => {
			if(topologyAction !== "SHOW_HIERARCHY") {
				handleZooming(nxApp);
			}
		},
		clickNode: (sender, node) => {
			
		},
		doubleClickNode: (sender, node) => {
			const nodeId = node.id();
			//forRedirection(nodeId);
		},
		enterNode: (sender,node) => {
			if(Object.keys(networkDetails).includes(node.id()) || Object.keys(serviceDetails).includes(node.id())) {
				customNodeToolTip = new CustomNodeToolTip();
				nxApp.customToolTip(customNodeToolTip);
				customNodeToolTip.setView({
					target: {
						x: event.pageX,
						y: event.pageY
					},
					title: Object.keys(networkDetails).length > 0 ? "Networks:" : null,
					heading: Object.keys(serviceDetails).length > 0 ? "Services:" : null,
					node: node,
					items: networkDetails[node.id()],
					serviceItems: serviceDetails[node.id()],
					label: node.id()
				});
			}
		},
		leaveNode: (sender,node) => {
			if(customNodeToolTip != null) {
				customNodeToolTip.close();
			}
		}
	};

	const { NextUI, nxApp } = useNext({
		topologyData: sampleTopology,
		topologyConfig: sampleConfig,
		eventHandlers: sampleEvtHandlers,
		style: { width: "100%", height: "85vh" },
		callback: setContext,
		headerComponent: HeaderComponent,
		footerComponent: FooterComponent
	});

	function getLinksBetweenNodes(topo, src, dest) {
		var sid = src.id();
		var did = dest.id();

		var linkSet = topo.getLinkSet(sid, did);
		if (linkSet !== null) {
			return window.nx.util.values(linkSet.links());
		}
		return false;
	}

	function getLinkList(topo, nodesDict, pathHops) {

		var linkList = [];

		for (var i = 0; i < pathHops.length - 1; i++) {

			var srcNode = nodesDict.getItem(pathHops[i]);
			var destNode = nodesDict.getItem(pathHops[i + 1]);

			var links = getLinksBetweenNodes(topo, srcNode, destNode);
			if (links != false) {
				linkList.push(links[0]);
			}
		}

		return linkList;
	}

	var pathLayer = [];
	var nodesDict = [];

	function drawPath(nxApp, pathHops) {
		/* TODO: Explore topology.on() for post-render callback */

		pathLayer = nxApp.getLayer("paths");
		nodesDict = nxApp.getLayer("nodes").nodeDictionary();
		var linkList = getLinkList(nxApp, nodesDict, pathHops);
		var pathInst;

		if(linkList.length>1) {
			pathInst = new window.nx.graphic.Topology.Path({
				"pathWidth": 3,
				"links": linkList,
				"arrow": "cap",
				"sourceNode": nodesDict.toArray()[0],
				"pathStyle": {
					"fill": "#f00"
				}
			});
			pathLayer.addPath(pathInst);
			//return pathLayer;
		} else {
			setNodeArray([]);
			alert('No Links b/w Selected Nodes');
		}
	}

	function makeGroup() {
		var groupLayer = nxApp.getLayer("groups");
		var nodesDict = nxApp.getLayer("nodes").nodeDictionary();

		var nodesList = [nodesDict.getItem("atl"), nodesDict.getItem("mia"), nodesDict.getItem("kcy")];

		var group = groupLayer.addGroup({
			nodes: nodesList,
			label: 'Group 1',
			color: 'red',
			group: 'group'
		});

		groupLayer.addGroup(group);
	}

	const horizontal = function (nxApp) {
		var layout = topology.getLayout('hierarchicalLayout');
		layout.direction('horizontal');
		layout.sortOrder(['L3 Network', 'L2 Network', 'L1 Network']);
		layout.levelBy(function (node, model) {
			return model.get('role');
		});
		topology.activateLayout('hierarchicalLayout');
	}

	const vertical = function (nxApp) {
		var layout = nxApp.getLayout('hierarchicalLayout');
		layout.direction('vertical');
		layout.sortOrder(['L3 Network', 'L2 Network', 'L1 Network']);
		layout.levelBy(function (node, model) {
			return model.get('role');
		});
		nxApp.activateLayout('hierarchicalLayout');
	}

	return(
		<div ref={ref}>
			<NoaContainer style={topologyContainer}>
			<Grid>
				<Grid.Row columns={1}>
					<Grid.Column width={16} id="global-topology">
						{NextUI}
					</Grid.Column>
				</Grid.Row>
				{renderNodeTooltip ? <RenderNodeDetails nodeDetails={nodeDetails}/> : ""}
				{renderLinkTooltip ? <RenderLinkDetails linkDetails={linkDetails}/> : ""}
			</Grid>
			</NoaContainer>
		</div>
	)
}

const RenderNodeDetails = (props) => {
	const nodeDetails = props.nodeDetails;
	const tooltipLocation = document.getElementById('node-tooltip');
	return tooltipLocation != null ? createPortal(<NodeTooltip data={nodeDetails}/>, tooltipLocation) : null
}

const RenderLinkDetails = (props) => {
	const linkDetails = props.linkDetails;
	const tooltipLocation = document.getElementById('link-tooltip');	
	return tooltipLocation != null ? createPortal(<LinkTooltip data={linkDetails}/>, tooltipLocation) : null
}

const HeaderComponent = () => {
	const { ref, isClickedOutside } = useOutsideClickAlert(false);

	const [viewOpen, setViewOpen] = useState(false);
	const [filterOpen, setFilterOpen] = useState(false);

	return(
		<Container style={{position: "absolute", top: "0", right: "18px",textAlign:"right"}} ref={ref}>
		<Menu pointing secondary compact style={subMenuLayout}>
			<Menu.Menu position='right'>
			<Popup 
				on="click"
				basic
				position='bottom right'
				trigger={
				<Menu.Item position='right' active={viewOpen} onClick={() =>{
					setViewOpen(true)
					setFilterOpen(false)
				}}>
					<p style={subMenuItem}>View</p>
				</Menu.Item>} 
			>
				<Grid>
					<Grid.Row columns={1}>
						<Grid.Column width={16}>
							<ViewComponent />	
						</Grid.Column>
					</Grid.Row>
				</Grid>
			</Popup>

			<Popup 
				on="click"
				basic
				position='bottom right'			
				trigger={
				<Menu.Item position='right' active={filterOpen} onClick={() =>{
					setFilterOpen(true)
					setViewOpen(false)
				}}>
					<p style={subMenuItem}>Filter</p>
				</Menu.Item>} 
			>	
				<Grid>
					<Grid.Row columns={1}>
						<Grid.Column width={16}>
							<FilterComponent />
						</Grid.Column>
					</Grid.Row>
				</Grid>
				</Popup>
			</Menu.Menu>
		</Menu>
		</Container>
	)
}

const ViewComponent = () => {
	const topologyContext = useContext(GlobalTopologyContext);
	const context = useContext(GlobalSpinnerContext);

	const [networks, setNetworks] = useState([]);
	const [services, setServices] = useState([]);

	useEffect(() => {
		setNetworks(topologyContext.networks);
	},[topologyContext.networks]);

	useEffect(() => {
		setServices(topologyContext.services);
	},[topologyContext.services]);

	return(
		<Container style={{width: "600px",height: "auto"}}>
		<Grid style={Object.assign({})}>
			<Grid.Row columns={1}>
				<Grid.Column width={16} id="topology-view">
					<Grid columns={3} stackable>
						<Grid.Column width='equal'>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Grid columns={2} stackable>
											<Grid.Column width={11} style={{fontFamily: "Montserrat",fontSize: "1.1em",fontWeight:600}}>
												View Networks
											</Grid.Column>
											<Grid.Column width={5} style={{paddingLeft:"0px"}}>
												<Checkbox toggle/>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection
												placeholder="Network Type"
												value={topologyContext.nwType}
												selectOnBlur={false}
												style={dropdownStyle}
												options={networkTypes} 
												onChange={(e,{value}) => {
													topologyContext.setNwType(value)
													context.setRenderLocation(["topology-view","global-topology"]);
												}}
										/>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection multiple
											placeholder="Network List"
											value={topologyContext.selNetworks}
											selectOnBlur={false}
											style={dropdownStyle}
											options={networks} 
											onChange={(e,{value}) => {
												context.setRenderLocation(["topology-view","global-topology"]);
												topologyContext.setSelNetworks(value)
											}}
										/>
									</Grid.Column>
								</Grid.Row>

							</Grid>
						</Grid.Column>
						<Grid.Column width='equal'>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Grid columns={2} stackable>
											<Grid.Column width={11} style={{fontFamily: "Montserrat",fontSize: "1.1em",fontWeight:600}}>
												View Services
											</Grid.Column>
											<Grid.Column width={5} style={{paddingLeft:"0px"}}>
												<Checkbox toggle/>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection
												placeholder="Service Type"
												value={topologyContext.servType}
												selectOnBlur={false}
												options={serviceTypes} 
												style={dropdownStyle}
												onChange={(e,{value}) => topologyContext.setServType(value)}
										/>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection multiple
											placeholder="Service List"
											style={dropdownStyle}
											value={topologyContext.selServices}
											selectOnBlur={false}
											options={services} 
											onChange={(e,{value}) => topologyContext.setSelServices(value)}
										/>
									</Grid.Column>
								</Grid.Row>

							</Grid>
						</Grid.Column>
						<Grid.Column width='equal'>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Grid columns={2} stackable>
											<Grid.Column width={11} style={{fontFamily: "Montserrat",fontSize: "1.1em",fontWeight:600}}>
												View Sites
											</Grid.Column>
											<Grid.Column width={5} style={{paddingLeft:"0px"}}>
												<Checkbox toggle/>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection
												placeholder="Site List"
												options={[]} 
												style={dropdownStyle}
												selectOnBlur={false}
										/>
									</Grid.Column>
								</Grid.Row>
							</Grid>
						</Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</Container>
	)
}

const FilterComponent = () => {
	const topologyContext = useContext(GlobalTopologyContext);
	const context = useContext(GlobalSpinnerContext);

	const [filters, setFilters] = useState({});

	const getFilterCriteria = () => {
        NoaClient.get(
            "/api/global/topology/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.filters !== null) {
					setFilters(responseData.filters);
					
					let filterNames = Object.keys(responseData.filters);
					
					let filterCriteria = {}
					
					filterCriteria["pagination"] = null;
					filterCriteria["sort"] = null;
					
					let filterBody = {};
					filterNames.map((filterName) => {
						filterBody[filterName] = {};
						filterCriteria["filters"] = filterBody;
					})
					
                }
            }
        )
	}

	const getNetworkTopology = (filters) => {
		filters["filters"]["topology:ietf-network"]["network-type"] = [topologyContext.nwType];
		NoaClient.post(
			"/api/global/topology/",
			filters,
			(response) => {
				let responseData = response.data;
				topologyContext.setFilteredTopology(responseData);
								
			}
		)
	}

	useEffect(() => {
		getFilterCriteria();
		context.setRenderLocation(["topology-filter"]);
	},[]);

	return(
		<Container style={{width: "600px",height: "auto"}}>
		<Grid style={Object.assign({})}>
			<Grid.Row columns={1}>
				<Grid.Column width={16} id="topology-filter">
					<NoaFilter filters={filters} getData={getNetworkTopology}/>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</Container>
	)
}

const FooterComponent = () => {
	return(
		<Container style={{position: "absolute", bottom: "0",right: "0"}}>
		<Grid>
			<Grid.Row columns={2}>
				<Grid.Column width={9}></Grid.Column>
				<Grid.Column width={7}>
				<Grid columns={2} stackable>
					<Grid.Column width={8} style={{maxWidth:"240px"}}>
					<Segment style={{border:"1px solid rgb(213,223,233,.5)"}}>
					<Grid>
						<Grid.Row columns={1} style={{paddingBottom:"0px"}}>
							<Grid.Column width={16} textAlign='center'>
								<p style={topologyChartTitle}>Networks</p>
							</Grid.Column>
						</Grid.Row>
						<Grid.Row columns={1}>
							<Grid.Column width={16} textAlign='center'>
								<Grid columns={3}>
									<Grid.Column width='equal' verticalAlign='middle'>
									<Label circular style={Object.assign({background:"#394867"},topologyChartValue)}>
											4
									</Label>
									<p style={topologyChartDesc}>L1</p>
									</Grid.Column>
									<Grid.Column width='equal' verticalAlign='middle'>
									<Label circular style={Object.assign({background:"#90A1B1"},topologyChartValue)}>
											18
									</Label>
									<p style={topologyChartDesc}>L2</p>
									</Grid.Column>
									<Grid.Column width='equal' verticalAlign='middle'>
									<Label circular style={Object.assign({background:"#6B637B"},topologyChartValue)}>
										35
									</Label>
									<p style={topologyChartDesc}>L3</p>
									</Grid.Column>
								</Grid>
							</Grid.Column>
						</Grid.Row>
						
					</Grid>
					</Segment>
					</Grid.Column>
					<Grid.Column width={8} style={{maxWidth:"240px"}}>
						<Segment style={{border:"1px solid rgb(213,223,233,.5)"}}>
							<Grid>
								<Grid.Row columns={1} style={{paddingBottom:"0px"}}>
									<Grid.Column width={16} textAlign='center'>
										<p style={topologyChartTitle}>Services</p>
									</Grid.Column>
								</Grid.Row>
								<Grid.Row columns={1}>
									<Grid.Column width={16} textAlign='center'>
										<Grid columns={3}>
											<Grid.Column width='equal'>
											<Label size='massive' circular style={Object.assign({background:"#394867"},topologyChartValue)}>
												48
											</Label>
											<p style={topologyChartDesc}>VPLS</p>
											</Grid.Column>
											<Grid.Column width='equal'>
											<Label size='massive' circular style={Object.assign({background:"#90A1B1"},topologyChartValue)}>
												33
											</Label>
											<p style={topologyChartDesc}>VPWS</p>
											</Grid.Column>
											<Grid.Column width='equal'>
											<Label size='massive' circular style={Object.assign({background:"#6B637B"},topologyChartValue)}>
												59
											</Label>
											<p style={topologyChartDesc}>VRF</p>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>
							</Grid>
						</Segment>
					</Grid.Column>
				</Grid>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</Container>
	)
}

const networkTypes = [
	{ 'key': "L1 Network", 'text': "L1 Network", 'value': "L1 Network" },
	{ 'key': "L2 Network", 'text': "L2 Network", 'value': "L2 Network" },
	{ 'key': "L2.5 Network", 'text': "L2.5 Network", 'value': "L2.5 Network" },
	{ 'key': "L3 Network", 'text': "L3 Network", 'value': "L3 Network" }
]

const serviceTypes = [
	{ 'key': "L3 VPN", 'text': "L3 VPN", 'value': "L3 VPN" },
	{ 'key': "L2 VPN", 'text': "L2 VPN", 'value': "L2 VPN" }
]

export default GlobalTopology;