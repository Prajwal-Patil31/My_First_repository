import React, { useContext, useEffect, useState } from 'react';

import {Grid } from 'semantic-ui-react';
import { useLocation } from "react-router-dom";

import { noPadding, cardDurationItem, completeWidth, cardKeyItem, cardValueItem, lineChartTitle } from './constants';

import {NoaContainer} from './widget/NoaWidgets';
import NoaRadialBarChart from './widget/NoaRadialBarChart';
import NoaCard from './widget/NoaCard';
import NoaLineChart from './widget/NoaLineChart';
import NoaAreaChart from './widget/NoaAreaChart';
import NoaProgressBar from './widget/NoaProgressBar';
import { MenuContext } from './utility/MenuContext';
import NoaPieChart from './widget/NoaPieChart';
import "./index.css";
import { GlobalSpinnerContext } from './utility/GlobalSpinner';
import { RouteRediretContext } from './utility/RouteRedirect';
import NoaClient from './utility/NoaClient';

const Dashboard = (props) => {
    let location = useLocation();
	let currentPath = location.pathname;

    const menuContext = useContext(MenuContext);
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const [networkOverview, setNetworkOverview] = useState([]);
    const [inventoryOverview, setInventoryOverview] = useState({});
    const [networkStatus, setNetworkStatus] = useState({});
    const [alarmSummary, setAlarmSummary] = useState({});
    const [alarmDistribution, setAlarmDistribution] = useState({});
    const [topPerformances, setTopPerformances] = useState({});

    const getNetworkOverview = () => {
        NoaClient.get(
            "/api/global/dashboard/network-overview",
            (response) => {
                let responseData = response.data;
                setNetworkOverview(responseData);
            });
    }
    
    const getInventoryOverview = () => {
        NoaClient.get(
            "/api/global/dashboard/inventory-overview",
            (response) => {
                let responseData = response.data;
                setInventoryOverview(responseData);
            });
    }

    const getNetworkStatus = () => {
        NoaClient.get(
            "/api/global/dashboard/network-status",
            (response) => {
                let responseData = response.data;
                setNetworkStatus(responseData);
            });
    }

    const getAlarmSummary = () => {
        NoaClient.get(
            "/api/global/dashboard/alarm-summary",
            (response) => {
                let responseData = response.data;
                setAlarmSummary(responseData);
            });
    }

    const getAlarmDistribution = () => {
        NoaClient.get(
            "/api/global/dashboard/alarm-distribution",
            (response) => {
                let responseData = response.data;
                setAlarmDistribution(responseData);
            });
    }

    const getTopPerformances = () => {
        NoaClient.get(
            "/api/global/dashboard/top-performance",
            (response) => {
                let responseData = response.data;
                setTopPerformances(responseData);
            });
    }
    useEffect(() => {
		menuContext.setData([]);
        menuContext.setHideMenu(true);
        menuContext.setDisplayText("Global Dashboard");
    },[currentPath]);
    
    useEffect(() => {
        NoaClient(context,redirectContext);
        getNetworkOverview();
        getInventoryOverview();
        getNetworkStatus();
        getAlarmSummary();
        getAlarmDistribution();
        getTopPerformances();
    },[]);

	return(
		<NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <NoaCard title={"Network Overview"} renderDuration={false}>
                            <NoaContainer style={Object.assign({paddingLeft: "5em", paddingRight: "4em"},completeWidth)}>
                            <Grid stackable verticalAlign='middle' columns={1}>
                                <Grid.Column width={16}>
                                    <Grid columns={4} stackable>
                                        {networkOverview.map((overviewData,index) => (
                                            <Grid.Column computer={4} tablet={8} mobile={16}>
                                                <NoaRadialBarChart data={overviewData} colors={pieChartColors[index]}/>
                                            </Grid.Column>
                                        ))}
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>

				<Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                    <Grid columns={2} stretched stackable relaxed='very'>
                        <Grid.Column computer={8} tablet={16} mobile={16}>
                            <NoaCard title={"Inventory Overview"} renderDuration={false}>
                                <NoaContainer style={Object.assign({paddingLeft: "1.5em", paddingRight: "1.5em"})}>
                                    {Object.keys(inventoryOverview).length > 0 ? 
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <NoaPieChart data={inventoryOverview["detailed"]} colors={eventColors} labelValue={"428 Elements"} renderDetails={true}/>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid>
                                                    <Grid.Row columns={Object.keys(inventoryOverview["summary"]).length}>
                                                        {Object.keys(inventoryOverview["summary"]).map((keyValue,index) => (
                                                            <Grid.Column width='equal'>
                                                                <Grid columns={2} stackable>
                                                                    <Grid.Column width={10} style={noPadding}>
                                                                        <p style={cardKeyItem}>{keyValue}</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} style={noPadding}>
                                                                        <p style={cardValueItem}>{inventoryData[keyValue]}</p>
                                                                    </Grid.Column>
                                                                </Grid>
                                                            </Grid.Column>
                                                        ))}
                                                    </Grid.Row> 
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    :""}
                                </NoaContainer>
                            </NoaCard>
                        </Grid.Column>
                        <Grid.Column computer={8} tablet={16} mobile={16} >
                            <NoaCard title={"Network Status"} renderDuration={false}>
                                <NoaContainer style={Object.assign({paddingLeft: "3em", paddingRight: "3em",paddingBottom:"2em",paddingTop:"2em"})}>
                                    {Object.keys(networkStatus).length > 0 ? 
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                {networkStatus["resources"].map((item) => (
                                                    <NoaProgressBar data={item} title={null}/>
                                                ))}
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1} style={{paddingTop:"2.5em"}}>
                                            <Grid.Column width={16}>
                                                {networkStatus["links"].map((item) => (
                                                    <NoaProgressBar data={item} title={null}/>
                                                ))}
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    :""}
                                </NoaContainer>
                            </NoaCard>
                        </Grid.Column>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
                
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Alarm/Event Summary"} renderDuration={true}>
                            <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
                            {Object.keys(alarmSummary).length > 0 ? 
                            <Grid columns={2} stackable>
                                <Grid.Column width={8}>
                                    <NoaContainer style={{textAlign: "center"}}>
                                        <FaultOverviewChart data={alarmSummary["alarms-summary"]} listData={alarmSummary["alarms-summary"]} colors={alarmColors} label={"225 Alarms"}/>
                                    </NoaContainer>
                                </Grid.Column>

                                <Grid.Column width={8}>
                                    <NoaContainer style={{textAlign: "center"}}>
                                        <FaultOverviewChart data={alarmSummary["events-summary"]} listData={alarmSummary["events-summary"]} colors={eventColors} label={"225 Events"}/>
                                    </NoaContainer>
                                </Grid.Column>
                            </Grid>
                            :""}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>

                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Alarm/Event Distribution"}>
                            <NoaContainer style={Object.assign({paddingRight:"2.5em",paddingLeft:"2.5em",paddingBottom:"2em",paddingTop:"1.5em"},completeWidth)}>
                            {Object.keys(alarmDistribution).length > 0 ? 
                                <Grid columns={3} stackable>
                                    {Object.keys(alarmDistribution).map((item,index) => (
                                        <Grid.Column computer={index == 1 ? 6 : 5} tablet={8} mobile={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                                                        <p style={cardKeyItem}>Top {item} by Active Alarms</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1} style={{paddingTop:"1em"}}>
                                                    <Grid.Column width={16}>
                                                        <NoaContainer style={{textAlign: "center"}}>
                                                            {alarmDistribution[item].map((faultValues) => (
                                                                <NoaProgressBar data={faultValues} title={null} customTooltip={CustomTooltip}/>
                                                            ))}
                                                        </NoaContainer>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                    ))}
                                </Grid>
                                
                            
                            :""}
                            {/* <Grid >
                                {mockResourceFaults.map((resourceFault,index) => (
                                    <Grid.Column computer={index == 1 ? 6 : 5} tablet={8} mobile={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                                                    <p style={cardKeyItem}>{faultsCategory[index]}</p>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1} style={{paddingTop:"1em"}}>
                                                <Grid.Column width={16}>
                                                    <NoaContainer style={{textAlign: "center"}}>
                                                        {resourceFault.map((item) => (
                                                            <NoaProgressBar data={item} title={null} customTooltip={CustomTooltip}/>
                                                        ))}
                                                    </NoaContainer>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                    </Grid.Column>
                                ))}
                            </Grid> */}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>

                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"TopN Performance"}>
                            <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
                            {Object.keys(topPerformances).length > 0 ? 
                            <Grid stackable style={{padding: "1.5em"}}>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <DeviceResourceUtilization utilization={topPerformances["device"]}/>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <ServiceThroughput utilization={topPerformances["services"]}/>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <LinkUtilization utilization={topPerformances["links"]}/>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            :""}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
	)
}

const FaultOverviewChart = (props) => {
    const [data, setData] = useState([]);
    const [colors, setColors] = useState([]);
    const [label, setLabel] = useState(null);
    const [listData, setListData] = useState({});

    useEffect(() => {
        setData(props.data)
    },[props.data]);

    useEffect(() => {
        setColors(props.colors)
    },[props.colors]);

    useEffect(() => {
        setLabel(props.label)
    },[props.label]);

    useEffect(() => {
        setListData(props.listData)
    },[props.listData]);

    return(
        <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
            <Grid columns={2} stackable>
                <Grid.Column tablet={12} computer={8} mobile={16} verticalAlign='middle' style={{paddingRight:"0px",minWidth:"250px"}}>
                    <NoaPieChart data={data} colors={colors} labelValue={label}/>
                </Grid.Column>
                <Grid.Column tablet={10} computer={8} mobile={16} verticalAlign='top' style={{paddingLeft:"0px"}}>
                    <Grid>
                        {Object.keys(listData).map((keyValue,index) => (
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                    <Grid columns={3}>
                                        <Grid.Column textAlign='left' width={7}>
                                            <p style={cardKeyItem}>{keyValue}</p>
                                        </Grid.Column>
                                        <Grid.Column textAlign='left' width={3}>
                                            <p style={cardValueItem}>{listData[keyValue]}</p>
                                        </Grid.Column>
                                        <Grid.Column width={6}></Grid.Column>
                                    </Grid>
                                </Grid.Column>
                            </Grid.Row> 
                        ))}
                    </Grid>
                </Grid.Column>
            </Grid>
        </NoaContainer>
    )
}
const CustomTooltip = (props) => {
    return (
        <foreignObject x="0" y={props.y} style={{overflow: "visible"}}>
        <div xmlns="http://www.w3.org/1999/xhtml">
            <p style={{color: "red"}}>{props.payload.value}</p>
        </div>
        </foreignObject>
    );
}

const DeviceResourceUtilization = (props) => {
    return(
        <Grid stackable>
            <Grid.Row columns={1} style={{paddingBottom: "0px"}}>
                <Grid.Column width={16} verticalAlign='bottom' textAlign='left'>
                    <p style={lineChartTitle}>Device Resource Utilization</p>
                </Grid.Column>
            </Grid.Row>
            
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16}>
                    <NoaLineChart data={mockDeviceUtilization} lineType={"stepAfter"} colors={deviceUtilizationColors}/>
                </Grid.Column>
            </Grid.Row>

            <Grid.Row columns={1} style={{paddingTop:"0px"}}>
                <Grid.Column width={16} verticalAlign='top'>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>1Hour</p>   
                        </Grid.Column>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>  
    )
}

const ServiceThroughput = (props) => {
    return(
        <Grid stackable>
            <Grid.Row columns={1} style={{paddingBottom: "0px"}}>
                <Grid.Column width={16} verticalAlign='bottom' textAlign='left'>
                    <p style={lineChartTitle}>Service Throughput</p>
                </Grid.Column>
            </Grid.Row>
            
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16}>
                    <NoaAreaChart data={mockDeviceUtilization} colors={deviceUtilizationColors}/>
                </Grid.Column>
            </Grid.Row>

            <Grid.Row columns={1} style={{paddingTop: "0px"}}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} verticalAlign='top'>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>6Hour</p>   
                        </Grid.Column>
                        <Grid.Column width={8} verticalAlign='top'>
                            <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const LinkUtilization = (props) => {
    return(
        <Grid stackable>
            <Grid.Row columns={1} style={{paddingBottom: "0px"}}>
                <Grid.Column width={16} textAlign='left'>
                    <p style={lineChartTitle}>Link Utilization</p>
                </Grid.Column>
            </Grid.Row>
            
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16}>
                    <NoaLineChart data={mockDeviceUtilization} lineType={"linear"} colors={deviceUtilizationColors}/>
                </Grid.Column>
            </Grid.Row>

            <Grid.Row columns={1} style={{paddingTop: "0px"}}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>12Hour</p>   
                        </Grid.Column>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const pieChartColors = ["#903749", "#543864","#750550","#21325E"];
const alarmColors = ['#FB4E4E','#F6A609','#667EFF','#FFDB1F','#66B2FF'];
const eventColors = ['#1A374D','#6998AB','#B1D0E0','#406882'];

const mockNetworkOverview = [
        { name: "sites", value: 0, maxValue: 100 },
    
    
        { name: "networks", value: 0, maxValue: 100 },
    
    
        { name: "services", value: 0, maxValue: 100 },
    
    
        { name: "elements", value: 0, maxValue: 500 },
];
const mockPathStatus = [
    [
        { name: "LSPs", count: [0,134], total: "134/208",maxValue:208,color:"#394867"}
    ],
    [
        { name: "ROUTES", count: [0,228], total: "228/256",maxValue:256,color:"#394867"}
    ],
    [
        { name: "PATHS", count: [0,103], total: "103/137",maxValue:137,color:"#394867"}
    ]
]
const mockNetworkStatus = [
    [
        { name: "ELEMENTS", count: [0,134], total: "134/428",maxValue:428,color:"#394867"}
    ],
    [
        { name: "NETWORKS", count: [0,62], total: "62/92",maxValue:92,color:"#394867"}
    ],
    [
        { name: "SERVICES", count: [0,39], total: "39/53",maxValue:53,color:"#394867"}
    ]
]

const inventoryMockData = {
    "pe-router" : 134,
    "ce-router" : 226,
    "p-router" : 56
}

const inventoryData = {
    "managed" : 408,
    "unmanaged" : 20
}

const mockAlarmData = {
    "critical" : 23,
    "major" : 43,
    "minor" : 165,
    "warning" : 53,
    "information" : 239
}

const mockEventsData = {
    "device" : 59,
    "link/route" : 25,
    "network" : 14,
    "service" : 9
}

const deviceUtilizationColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}
const mockDeviceUtilization = [
    {
        "DEL-PE-480": 2400,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 600,
        "BOM-CE-001": 1600,
        "VJA-P-980": 900,
    },
    {
        "DEL-PE-480": 1800,
        "BOM-CE-165": 1600,
        "DEL-PE-560": 200,
        "BOM-CE-001": 6800,
        "VJA-P-980": 2500,
    },
    {
        "DEL-PE-480": 5600,
        "BOM-CE-165": 5400,
        "DEL-PE-560": 200,
        "BOM-CE-001": 200,
        "VJA-P-980": 2400,
    },
    {
        "DEL-PE-480": 1526,
        "BOM-CE-165": 1426,
        "DEL-PE-560": 100,
        "BOM-CE-001": 3200,
        "VJA-P-980": 3000,
    },
    {
        "DEL-PE-480": 3600,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 1800,
        "BOM-CE-001": 400,
        "VJA-P-980": 500,
    },
    {
        "DEL-PE-480": 3200,
        "BOM-CE-165": 1000,
        "DEL-PE-560": 1200,
        "BOM-CE-001": 800,
        "VJA-P-980": 1700,
    },
    {
        "DEL-PE-480": 3300,
        "BOM-CE-165": 2600,
        "DEL-PE-560": 700,
        "BOM-CE-001": 750,
        "VJA-P-980": 1800,
    },
]

const mockTopDeviceByFaults = [
    [
        { name: "BLR-CE-126", count: [0,48], total: "48/50",maxValue:50,color:"#394867"}
    ],
    [
        { name: "MAA-PE-201", count: [0,36], total: "36/50",maxValue:50,color:"#394867"}
    ],
    [
        { name: "DEL-CE-088", count: [0,30], total: "30/50",maxValue:50,color:"#394867"}
    ],
    [
        { name: "BOM-PE-174", count: [0,18], total: "18/50",maxValue:50,color:"#394867"}
    ],
    [
        { name: "HYD-PE-036", count: [0,10], total: "10/50",maxValue:50,color:"#394867"}
    ]
]

const mockTopLinksByFaults = [
    [
        { name: "BLR-CE-126", count: [0,39], total: "39/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "MAA-PE-201", count: [0,22], total: "22/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "DEL-CE-088", count: [0,21], total: "21/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "BOM-PE-174", count: [0,15], total: "15/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "HYD-PE-036", count: [0,10], total: "10/40",maxValue:40,color:"#394867"}
    ]
]

const mockTopServicesByFaults = [
    [
        { name: "BLR-CE-126", count: [0,28], total: "28/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "MAA-PE-201", count: [0,25], total: "25/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "DEL-CE-088", count: [0,20], total: "20/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "BOM-PE-174", count: [0,10], total: "10/40",maxValue:40,color:"#394867"}
    ],
    [
        { name: "HYD-PE-036", count: [0,9], total: "9/40",maxValue:40,color:"#394867"}
    ]
]

const mockResourceFaults = [mockTopDeviceByFaults,mockTopLinksByFaults,mockTopServicesByFaults];
const faultsCategory = ["Top Device By Active Alarms", "Top Links by Active Alarms", "Top Services by Active Alarms"]
export {FaultOverviewChart};
export default Dashboard;