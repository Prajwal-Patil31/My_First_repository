import axios from 'axios';
import noaNotification from '../widget/NoaNotification';

const NoaClient = (spinnerContext, redirectContext) => {
    const service = axios.create();
    const context = spinnerContext;
    let notificationCount = 0;
    let count = 0;

    NoaClient.spinnerType = context.spinnerType;

    //service.interceptors.response.use(handleSuccess(response), handleError(error));

    const handleSuccess = (response) => {
        return response;
    }

    const handleError = (error) => {
        switch (error.response.status) {
            case 401:
                console.log("Unauthorised")
                break;
            case 403:
                console.log("Forbidden")
                break;
            case 404:
                console.log("NOT FOUND")
                break;
            default:
                console.log(error)
                break;
        }
        return Promise.reject(error)
    }

    if(count === 0) {
        notificationCount = 0;
    }

    const handleNotification = (error, message) => {
        count--;
        context.setRequestCount(count);
        if(error.response.status === 401) {
            if(redirectContext) {
                redirectContext.setRouteRedirect(true);
            }
            notificationCount++;
            if(notificationCount === 1) {
                noaNotification('error', "Unauthorised");
            }
        } else if(error.response.status === 403) {
            if(redirectContext) {
                redirectContext.setRouteRedirect(true);
            }
            notificationCount++;
            if(notificationCount === 1) {
                noaNotification('error', "Forbidden");
            }
        } else if(typeof error.response.data === 'string' && error.response.data !== '') {
            noaNotification('error', error.response.data);
        } else {
            noaNotification('error', message);
        }
    }

    NoaClient.get = (path, callback,source,headers) => {
        if(headers === null || typeof headers === 'undefined') {
            headers = { 'X-Requested-With': 'XMLHttpRequest' }
        } else {
            headers['X-Requested-With'] = 'XMLHttpRequest';
        }
        count++;
        context.setRequestCount(count);
        return service.request ({
            method: 'GET',
            url: path,
            headers: headers,
            cancelToken: source != undefined ? source.token : null
        }).then((response) => {
            callback(response);
            count--;
            context.setRequestCount(count);
        }, (error) => {
            handleNotification(error, 'Unable to Fetch');
        });
    }

    NoaClient.delete = (path, payload, callback) => {
        count++;
        context.setRequestCount(count);
        return service.request ({
            method: 'DELETE',
            url: path,
            data: payload,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then((response) => {
            callback(response);
            count--;
            context.setRequestCount(count);
        }, (error) => {
            handleNotification(error, 'Unable to Delete');
        });
    }

    NoaClient.patch = (path, payload, callback) => {
        count++;
        context.setRequestCount(count);
        return service.request ({
            method: 'PATCH',
            url: path,
            data: payload,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then((response) => {
            callback(response);
            count--;
            context.setRequestCount(count);
        }, (error) => {
            handleNotification(error, 'Unable to Update');
        });
    }

    NoaClient.post = (path, payload, callback) => {
        count++;
        context.setRequestCount(count);
        return service.request ({
            method: 'POST',
            url: path,
            data: payload,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then((response) => {
            callback(response);
            count--;
            context.setRequestCount(count);
        }, (error) => {
            handleNotification(error, 'Unable to Modify');
        });
    }

    NoaClient.put = (path, payload, callback) => {
        count++;
        context.setRequestCount(count);
        return service.request ({
            method: 'put',
            url: path,
            data: payload,
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        }).then((response) => {
            callback(response);
            count--;
            context.setRequestCount(count);
        }, (error) => {
            handleNotification(error, 'Unable to Add');
        });
    }
}

export default NoaClient;