import React, { useState } from 'react';

const GlobalThemeContext = React.createContext();

const GlobalThemeProvider = (props) => {
    const [theme, setTheme] = useState(THEMES.LIGHT);

    const changeTheme = () => {
		theme === THEMES.LIGHT ? setTheme(THEMES.DARK) : setTheme(THEMES.LIGHT);
	}
    return (
        <GlobalThemeContext.Provider
            value={{
                theme: theme,
                changeTheme: changeTheme
            }}
        >
            {props.children}
        </GlobalThemeContext.Provider>
    )
}
const GlobalThemeConsumer = GlobalThemeContext.Consumer;


const THEMES = {
	LIGHT : "light",
	DARK : "dark"
}

export { GlobalThemeContext, GlobalThemeProvider, GlobalThemeConsumer }