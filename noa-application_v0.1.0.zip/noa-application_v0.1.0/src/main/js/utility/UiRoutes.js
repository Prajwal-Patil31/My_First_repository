import React from 'react'
import { AddRole, ModifyRole } from '../security/rbac/RoleManager';
import { AddPasswordPolicy, ModifyPasswordPolicy } from "../security/account/user/password/PasswordPolicyManager";
import { AddUserGroup, ModifyUserGroup } from '../security/account/group/UserGroupManager';
import { AddUser, ModifyUser } from '../security/account/user/UserManager';
import { AddBridgeInstance, BridgeManagement } from '../element/config/bridge/BridgeInstanceManager';
import { AddLdpEntity, ModifyLdpEntity } from '../element/config/mpls/ldp/LdpEntitiesManager';
import { AddTunnel, ModifyTunnel } from '../element/config/mpls/tunnel/TunnelManager';
import { InterfaceManagement } from '../element/config/resource/port/PhysicalInterfaceConfig';
import { AddBgpInstance, BgpInstanceManagement } from '../element/config/route/bgp/BgpConfig';
import { AddOspfInstance, OspfInstanceManagement } from '../element/config/route/ospf/OspfConfig';
import { AddDevice } from "../element/inventory/ElementInventory"; 
import { AddFaultConfiguration, ModifyFaultConfiguration } from '../global/event/fault/FaultConfig';
import { AddFaultPolicy, ModifyFaultPolicy } from '../global/event/fault/FaultPolicyManager';
import { AddLink, ModifyLink } from '../network/l1/NetworkLinkManager';
import { AddNetwork } from '../network/NetworkManager';
import { AddService } from '../service/ServiceManager';
import { AddPathhop } from '../service/PathhopManager';
import { AddEndpoint } from '../service/ServiceEndpointManager';
import { AddPath, ModifyPath } from '../service/ServicePathManager';
import { AddLsp } from '../network/l2/NetworkLspManager';
import { AddRoute } from '../network/l3/NetworkRouteManager';
import { AddVlan, ModifyVlan } from '../element/config/vlan/VlanConfig';

const uiRoutes = [
    {
        name: 'default',
        component: () => (<DefaultComponent />)
    },


    //Fault Configuration:
    {
        name: 'add-fault-config',
        component: AddFaultConfiguration,
        params: { 
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-fault-config',
        component: ModifyFaultConfiguration,
        params: { 
            id: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    
    //Fault Policy:
    {
        name: 'add-fault-policy',
        component: AddFaultPolicy,
        params: { 
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-fault-policy',
        component: ModifyFaultPolicy,
        params: {
            id: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    //Element:
    {
        name: 'add-device',
        component: AddDevice,
        params: {
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    //Physical Interface:
    {
        name: 'view-physical-interface',
        component: InterfaceManagement,
        params: {
            id: {
                type: "string",
                array: false
            },
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    //Bridge Instance:
    {
        name: 'add-bridge-instance',
        component: AddBridgeInstance,
        params: {
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'view-bridge-instance',
        component: BridgeManagement,
        params: {
            id: {
                type: "string",
                array: false
            },
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    {
        name: 'view-bridge-instance.addvlan',
        views: {
            "addvlan" : AddVlan
        },
        params: {
            bridgeId: {
                array: false
            },
            deviceId: {
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'bridgeId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const bridgeId = trans.params().bridgeId
                    return bridgeId
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    //BGP Instance
    {
        name: 'add-bgp-instance',
        component: AddBgpInstance,
        params: {
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'view-bgp-instance',
        component: BgpInstanceManagement,
        params: {
            id: {
                type: "string",
                array: false
            },
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //OSPF Instance
    {
        name: 'add-ospf-instance',
        component: AddOspfInstance,
        params: {
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'view-ospf-instance',
        component: OspfInstanceManagement,
        params: {
            id: {
                type: "string",
                array: false
            },
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //LDP Entity:
    {
        name: 'add-ldp-entity',
        component: AddLdpEntity,
        params: {
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-ldp-entity',
        component: ModifyLdpEntity,
        params: {
            id: {
                type: "string",
                array: false
            },
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //MPLS Tunnel:
    {
        name: 'add-tunnel',
        component: AddTunnel,
        params: {
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-tunnel',
        component: ModifyTunnel,
        params: {
            id: {
                type: "string",
                array: false
            },
            deviceId: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'deviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const deviceId = trans.params().deviceId
                    return deviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //Network:
    {
        name: 'add-network',
        component: AddNetwork,
        params: {
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'add-link',
        component: AddLink,
        params: {
            networkId:{
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'networkId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const networkId = trans.params().networkId
                    return networkId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    {
        name: 'add-lsp',
        component: AddLsp,
        params: {
            networkId:{
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'networkId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const networkId = trans.params().networkId
                    return networkId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    {
        name: 'add-route',
        component: AddRoute,
        params: {
            networkId:{
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'networkId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const networkId = trans.params().networkId
                    return networkId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    //VPN Service:
    {
        name: 'add-service',
        component: AddService,
        params: {
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },

    {
        name: 'add-path',
        component: AddPath,
        params: {
            serviceId: {
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'serviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const serviceId = trans.params().serviceId
                    return serviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'view-path',
        component: ModifyPath,
        params: {
            id: {
                array: false
            },
            serviceId: {
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'serviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const serviceId = trans.params().serviceId
                    return serviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'view-path.addpathhop',
        views: {
            "addpathhop" : AddPathhop
        },
        params: {
            pathId: {
                array: false
            },
            serviceId: {
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'pathId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const pathId = trans.params().pathId
                    return pathId
                }
            },
            {
                token: 'serviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const serviceId = trans.params().serviceId
                    return serviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    /* {
        name: 'view-path.pathdefault',
        views: {
            "pathdefault" : DefaultComponent
        },
    }, */
    {
        name: 'add-endpoint',
        component: AddEndpoint,
        params: {
            serviceId: {
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'serviceId',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const serviceId = trans.params().serviceId
                    return serviceId
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //Password Policy:
    {
        name: 'add-password-policy',
        component: AddPasswordPolicy,
        params: { 
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-password-policy',
        component: ModifyPasswordPolicy,
        params: {
            id: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //User Account:
    {
        name: 'add-user',
        component: AddUser,
        params: { 
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-user',
        component: ModifyUser,
        params: {
            id: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //Role:
    {
        name: 'add-role',
        component: AddRole,
        params: { 
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-role',
        component: ModifyRole,
        params: {
            id: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },


    //User Group:
    {
        name: 'add-user-group',
        component: AddUserGroup,
        params: { 
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
    {
        name: 'modify-user-group',
        component: ModifyUserGroup,
        params: {
            id: {
                type: "string",
                array: false
            },
            fetchData: {
                array: false
            },
            clearSelection: {
                array: false
            }
        },
        resolve: [
            {
                token: 'id',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const id = trans.params().id
                    return id
                }
            },
            {
                token: 'fetchData',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const fetchData = trans.params().fetchData
                    return fetchData
                }
            },
            {
                token: 'clearSelection',
                deps: ['$transition$'],
                resolveFn: (trans) => {
                    const clearSelection = trans.params().clearSelection
                    return clearSelection
                }
            }
        ]
    },
]

const DefaultComponent = () => {
	return(
		<div></div>
	)
}

const BridgeDefaultComponent = () => {
	return(
		<div></div>
	)
}
export default uiRoutes;