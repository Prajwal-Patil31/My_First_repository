import { useState, useEffect, useRef } from 'react';

export default function useOutsideClickAlert (initialValue) {
    const [isClickedOutside, setIsClickedOutside] = useState(initialValue);
    const ref = useRef(null);

    const handleClickOutside = (event) => {
        if (ref.current && !ref.current.contains(event.target)) {
            setIsClickedOutside(true);
        } else {
            setIsClickedOutside(false);
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside, true);
        document.addEventListener('contextmenu', handleClickOutside, true);
        return () => {
            document.removeEventListener('click', handleClickOutside, true);
            document.removeEventListener('contextmenu', handleClickOutside, true);
        };
    }, []);

    return { ref, isClickedOutside };
}
  