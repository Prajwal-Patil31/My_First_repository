import React, { useContext, useEffect, useState } from 'react'
import {Redirect} from "react-router-dom";

const RouteRediretContext = React.createContext();

const RouteRediret = () => {
    const context = useContext(RouteRediretContext);

    return (
        context.routeRedirect === true ? <Redirect to="/logout" /> : ''
    )
}

const RouteRediretProvider = (props) => {
    const [routeRedirect, setRouteRedirect] = useState(false);

    useEffect(() => {
        if(routeRedirect) {
            setRouteRedirect(false);
        }
    }, [routeRedirect])

    return (
        <RouteRediretContext.Provider
            value={{
                routeRedirect: routeRedirect,
                setRouteRedirect: redirect => setRouteRedirect(redirect)
            }}
        >
            {props.children}
        </RouteRediretContext.Provider>
    )
}

const RouteRedirectConsumer = RouteRediretContext.Consumer;

export {RouteRediret, RouteRediretProvider, RouteRedirectConsumer, RouteRediretContext}
