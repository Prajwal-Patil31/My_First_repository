import React, { useState } from 'react'
//import noaNotification from './NoaNotification';
import update from 'react-addons-update';

const NotificationContext = React.createContext();


const NotificationProvider = (props) => {
    const [notificationObjects, setNotificationObjects] = useState([]);
    const [faultObject, setFaultObject] = useState(null);
    const [eventObject, setEventObject] = useState(null);

    const renderNotification = (notification) => {
        console.log(notification)
        //noaNotification('error', notification["description"]);
    }

    return (
        <NotificationContext.Provider
            value={{
                notificationObjects: notificationObjects,
                renderNotification: (notification ) => renderNotification(notification),
                setNotificationObjects: (notification) => {
                    const index = notificationObjects.findIndex(oldObject => oldObject.eventId === notification.eventId);
                    
                    if(index >= 0) {
                        setNotificationObjects(
                            update(notificationObjects, {
                                [index]: {$set: notification}
                            })
                        );
                    } else {
                        if(notification["eventType"] === 'Fault') {
                            renderNotification(notification);
                        }                        
                        setNotificationObjects(oldArray => [...oldArray, notification]);
                    }
                },
                eventObject: eventObject,
                setEventObject: (eventObject) => setEventObject(eventObject),
                faultObject: faultObject,
                setFaultObject: (faultObject) => setFaultObject(faultObject)
            }}
        >
            {props.children}
        </NotificationContext.Provider>
    )
}

export {NotificationProvider, NotificationContext}
