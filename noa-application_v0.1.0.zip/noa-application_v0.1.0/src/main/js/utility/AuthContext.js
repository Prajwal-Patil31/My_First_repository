/**@module AuthContext */

import React from 'react';
import NoaClient from '../utility/NoaClient';
import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import axios from 'axios';

/**
 *Initializing a new React Context. 
*/
const AuthContext = React.createContext();
export const USER_SESSION_KEY = 'USER_SESSION_KEY';

/**
 * Component to implement Login and Logout functionality.
 * 
 * @class 
 * @augments React.Component
*/
class AuthProvider extends React.Component {
	state = { 
		isAuth: false,
		userDetails: {}
	}

	constructor() {
		super()
		this.login = this.login.bind(this);
		this.logout = this.logout.bind(this);
	}

	componentDidMount() {
		NoaClient(this.context);
		let session = JSON.parse(sessionStorage.getItem(USER_SESSION_KEY));
		if (session !== null) {
			this.setState({userDetails: session});
			this.setState({isAuth: true});
		}
	}

	/**
	 * Makes a REST request to authenticate the User and Creates a new Session.
	 * @param {*} user Details of the User.
	 * @param {*} redirect Redirect to the page.
	 */
	login(user, redirect) {
		const CancelToken = axios.CancelToken;
        const source = CancelToken.source();
		NoaClient.get(
            "/login",
            (response) => {
                this.setState({ isAuth: true });
				this.setState({userDetails: response.data});
				sessionStorage.setItem(USER_SESSION_KEY, JSON.stringify(this.state.userDetails));
			},
			source,
			{ 
				authorization: 'Basic ' + window.btoa(user.username + ":" + user.password),
				contenttype: 'application/json',
				accept: 'application/json' 
			}
		)

		redirect();
	}

	/**
	 * Makes a REST request to logout the logged in User and Removes the 
	 * respective Session.
	 * @param {*} redirect Redirect to Home Page
	 *  
	 */
	logout(redirect) {
		NoaClient.get(
			'/logout',
			(response) => {
				this.setState({ isAuth: false });
				sessionStorage.removeItem(USER_SESSION_KEY);
				sessionStorage.clear();
				redirect();
			}
		)
	}

	render() {
		const userDetails = this.state.userDetails
    return (
      	<AuthContext.Provider
			value={{
				isAuth: this.state.isAuth,
				firstName: userDetails.FirstName,
				lastName: userDetails.LastName,
				accountId: userDetails.accountId,
				login: this.login,
				logout: this.logout
			}}
      	>
        {this.props.children}
      </AuthContext.Provider>
    )
  }
}
AuthProvider.contextType = GlobalSpinnerContext;
const AuthConsumer = AuthContext.Consumer;

export { AuthProvider, AuthConsumer, AuthContext };