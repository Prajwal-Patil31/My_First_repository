import React, { useEffect, useState } from 'react';

const MenuContext = React.createContext();

const MenuContextProvider = (props) => {
    const [data, setData] = useState([]);
    const [displayText, setDisplayText] = useState(null);
    const [layout, setLayout] = useState(null);
    const [hideMenu, setHideMenu] = useState(false);
    const [activeItem, setActiveItem] = useState(0);

    useEffect(() => {
        sessionStorage.setItem("hideMenu",hideMenu);
    },[hideMenu]);

    return (
        <MenuContext.Provider
            value={{
                data: data,
                displayText: displayText,
                setData: (value) => setData(value),
                setDisplayText: setDisplayText,
                hideMenu: hideMenu,
                setHideMenu: setHideMenu,
                activeItem: activeItem,
                setActiveItem: setActiveItem,
                layout:layout,
                setLayout:setLayout
            }}
        >
            {props.children}
        </MenuContext.Provider>
    )
}
const MenuContextConsumer = MenuContext.Consumer;

export { MenuContext, MenuContextProvider, MenuContextConsumer }