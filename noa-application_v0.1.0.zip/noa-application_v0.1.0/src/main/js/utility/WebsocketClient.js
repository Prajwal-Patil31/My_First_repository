import { Component } from 'react'

import SockJS from 'sockjs-client';
import Stomp from 'stomp-websocket';

const currentURL = window.location.host

class WebsocketClient extends Component {

    constructor(props) {
        super(props)
        this.noaSubscribe = null;
    }
    

    connectWs = (topic, callback) => {
        /* TODO: Enforcing WS Transport for SockJS doesn't Change the Endpoint to 'ws:' */
        /* const socket = new SockJS('/sws', "", {debug: true, transports: "websockets"}); */
        
        /* TODO: SockJS Tries all Transports, Possible Failures due to Tomcat Config or WebSecurityConfig 
        or WebSocketConfig or WebSocketSecurityConfig; Requirement: WS if Available Other Transports Otherwise */
        /* const socket = new SockJS('/sws'); */
        
        /* TODO:Stomp.overWS Results in Runtime Library Failure */
        /* const stompClient = Stomp.overWS(socket); */
        const stompClient = Stomp.client('ws://'+currentURL+'/sws');
        stompClient.connect({}, function(frame) {
            this.noaSubscribe = stompClient.subscribe('/topic/'+topic, function(alert) {
                callback(alert.body);
            });
        });
    }
    
    disConnectWs = () => {
        console.log("Disconnected");
        if(this.noaSubscribe !== null) {
            this.noaSubscribe.unsubscribe();
        }
    }
    
    /* render() {
        return (
            <div>
                
            </div>
        )
    } */
}

export default new WebsocketClient;