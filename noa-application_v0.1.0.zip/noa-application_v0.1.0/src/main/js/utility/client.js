'use strict';

const rest = require('rest');
const defaultRequest = require('rest/interceptor/defaultRequest');
const mime = require('rest/interceptor/mime');
const uriTemplateInterceptor = require('../api/uriTemplateInterceptor');
const errorCode = require('rest/interceptor/errorCode');
const location = require('rest/interceptor/location');
const baseRegistry = require('rest/mime/registry');

const registry = baseRegistry.child();

registry.register('text/uri-list', require('../api/uriListConverter'));
registry.register('application/hal+json', require('rest/mime/type/application/hal'));

module.exports = rest
	.wrap(mime, { registry: registry })
	.wrap(uriTemplateInterceptor)
	.wrap(errorCode)
	.wrap(location)
	.wrap(defaultRequest, { headers: { 'Accept': 'application/hal+json' ,'X-Requested-With': 'XMLHttpRequest'}});
