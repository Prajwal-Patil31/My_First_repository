import React, { useContext, useEffect, useState } from 'react'
import { Dimmer, Loader } from 'semantic-ui-react';
import { createPortal } from 'react-dom';

const GlobalSpinnerContext = React.createContext();

const GlobalSpinner = () => {
    const context = useContext(GlobalSpinnerContext);

    return (
        <>
        {
        context.renderLocation.length > 0 ? 
        context.renderLocation.map((item) => {
            return(
                document.getElementById(item)  != null ?
                createPortal(<Dimmer active inverted id={item + "-spinner"}>
                    <Loader inverted>Loading</Loader>
                </Dimmer>, document.getElementById(item))  : ""
            )
        })
        :""}        
        </>
    )
}

const GlobalSpinnerProvider = (props) => {
    const [requestCount, setRequestCount] = useState(0);
    const [renderLocation, setRenderLocation] = useState([]);
    
    useEffect(() => {
        if(requestCount == 0) {
            setRenderLocation([]);
        }
    },[requestCount]);

    return (
        <GlobalSpinnerContext.Provider
            value={{
                spinnerType: 'global',
                requestCount: requestCount,
                setRequestCount: count => setRequestCount(count),
                renderLocation: renderLocation,
                setRenderLocation: setRenderLocation,
            }}
        >
            {props.children}
        </GlobalSpinnerContext.Provider>
    )
}

export {GlobalSpinner, GlobalSpinnerProvider, GlobalSpinnerContext}
