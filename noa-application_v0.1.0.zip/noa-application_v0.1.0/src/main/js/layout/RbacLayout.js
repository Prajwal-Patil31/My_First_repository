'use strict';
import React, { useContext, useEffect } from 'react';
import ProtectedRoute from '../utility/ProtectedRoute';
import { useLocation } from "react-router-dom";

import { Switch, withRouter,Redirect} from "react-router-dom";

import { MenuContext } from '../utility/MenuContext';
import { completeHeight, completeWidth, fullHeight, noBoxShadow } from '../constants';
import { NoaContainer } from '../widget/NoaWidgets';
import { Grid } from 'semantic-ui-react';

import UserManager from '../security/account/user/UserManager';
import RoleManager from '../security/rbac/RoleManager';
import UserGroupManager from '../security/account/group/UserGroupManager';
import { GroupIcon, ProfileIcon, RoleIcon, SecurityIcon, UsersIcon } from '../widget/NoaIcons';

const RbacLayout = (props) => {
    let location = useLocation();
    let { path, url } = props.match;

    let currentPath = location.pathname;

    const menuContext = useContext(MenuContext);
    
    useEffect(() => {
		menuContext.setActiveItem(0);
    },[]);
    
	useEffect(() => {
        const itemsData = [
            { key: 'users', name: 'Users', url: "/Platform/RBAC/User", text: "RBAC: Users", children: [],icon: ProfileIcon,activeIndex:0},
            { key: 'roles', name: 'Roles', url: "/Platform/RBAC/Role",text: "RBAC: Roles", children: [],icon: RoleIcon,activeIndex:1},
            { key: 'groups', name: 'User Group', url: "/Platform/RBAC/Group",text: "RBAC: User Groups", children: [],icon: GroupIcon,activeIndex:2},
        ]
        menuContext.setData(itemsData);
        menuContext.setLayout("Rbac");
        let allOptions = [];

        itemsData.forEach((item) => {
            if(item.children.length > 0){
                let childOptions = item.children;
                childOptions.forEach((childItem) => {
                    allOptions.push(childItem)
                })
            }
            allOptions.push(item);
        })
        let currentUrl = allOptions.find(item => item.url == location.pathname);
        if(currentUrl == undefined) {				
            menuContext.setHideMenu(true);
        } else {
            menuContext.setDisplayText(currentUrl.text)
            menuContext.setHideMenu(false);
            menuContext.setActiveItem(currentUrl.activeIndex)
        }	
    },[currentPath]);
    
    return (
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight,noBoxShadow)} columns={1}>
                <Grid.Column width={16} style={fullHeight} verticalAlign='top' textAlign='center'>
                    <Switch location={location}>
                        <ProtectedRoute exact path={`${path}/User`} component={UserManager} />
                        <ProtectedRoute exact path={`${path}/Role`} component={RoleManager} />
                        <ProtectedRoute exact path={`${path}/Group`} component={UserGroupManager} />
                        <Redirect to="/" />
                    </Switch>
                </Grid.Column>
            </Grid>
            {props.children}
        </NoaContainer>
    )
}

export default withRouter(RbacLayout);