/**@module AppLayout */

'use strict';
import React, { createRef, useContext, useEffect } from 'react';

import NoaHeader from '../widget/NoaHeader';
import Footer from '../widget/Footer';
import UserLayout from './UserLayout';
import ProtectedRoute from '../utility/ProtectedRoute';
import Login from '../security/authentication/Login';
import Logout from '../security/authentication/Logout';
import FaultsLayout from './FaultsLayout';
import ElementsLayout from './ElementsLayout';
import NetworksLayout from './NetworksLayout';
import ServiceLayout from './ServiceLayout';

import { Route, Switch, Redirect, withRouter } from "react-router-dom";

import { Grid } from 'semantic-ui-react';

import { noPadding,completeHeight,completeWidth} from '../constants';

import 'semantic-ui-css/semantic.min.css';
import 'rsuite/dist/styles/rsuite-default.css';

import { RouteRediret } from '../utility/RouteRedirect';
import WebsocketClient from '../utility/WebsocketClient';
import { NotificationContext } from '../utility/NotificationContext';

import { NoaContainer} from '../widget/NoaWidgets';
import BreadCrumb from '../widget/Breadcrumb';
import RbacLayout from './RbacLayout';
import SecurityLayout from './SecurityLayout';
import RollbackLayout from './RollbackLayout';
import GlobalTopology from '../global/topology/GlobalTopology';
import { UIRouter, memoryLocationPlugin } from '@uirouter/react';

import uiRoutes from '../utility/UiRoutes';
import NoaSubMenu from '../widget/NoaSubMenu';
import '../index.css';
import TaskScheduling from '../platform/TaskScheduling';
import SystemStatus from '../platform/SystemStatus';
import GlobalLayout from './GlobalLayout';

/**
 * Component to Render different layouts for different URI paths.
 * 
 * @class
 * @augments React.Component
 */
const AppLayout = (props) => {
	const notificationContext = useContext(NotificationContext);
	
	useEffect(() => {
		WebsocketClient.connectWs(
            'notification',
            (notificationString) => {
				const notifObject = JSON.parse(notificationString);
				if(notifObject.notification !== null) {
					notificationContext.setNotificationObjects(notifObject.notification);
				}
				if(notifObject.fault !== null) {
					notificationContext.setFaultObject(notifObject.fault);
				}
				if(notifObject.eventObject !== null) {
					notificationContext.setEventObject(notifObject.eventObject);
				}
			}
		);
		return () => {
			WebsocketClient.disConnectWs();
		}
	}, []);
	let { path, url } = props.match;

	const plugins = [memoryLocationPlugin];
	let contextRef = createRef();

	return (
		<UIRouter plugins={plugins} states={uiRoutes}>
		<NoaContainer ref={contextRef} style={Object.assign({},completeHeight,completeWidth)}>
			<Grid columns={1}>
				<Grid.Column width={16}>
				<NoaContainer style={{width:"80%",marginTop:"3.25em"}}>
				<Grid>
					<Grid.Row columns={1} style={noPadding}>
						<Grid.Column width={16} style={{padding: 0,zIndex: 2,minHeight:"4em"}}>
							<NoaHeader />
						</Grid.Column>
					</Grid.Row>
					
					<Grid.Row columns={1}>
						<Grid.Column width={16} style={{padding: 0,zIndex: 1}}>
							<BreadCrumb />
						</Grid.Column>
					</Grid.Row>

					<Grid.Row columns={1} style={noPadding}>
						<Grid.Column width={16} style={{padding: 0}}>
							<NoaSubMenu>
							<RouteRediret />
							<Switch>
								<Route exact path="/" component={GlobalLayout} />
								<ProtectedRoute path="/Topology" component={GlobalTopology}/>
								<ProtectedRoute path="/Elements" component={ElementsLayout}/>
								<ProtectedRoute path="/Networks" component={NetworksLayout}/>
								<ProtectedRoute path="/Services" component={ServiceLayout}/>
								<ProtectedRoute path="/Platform/RBAC" component={RbacLayout} />
								<ProtectedRoute path="/Platform/Security" component={SecurityLayout} />
								<ProtectedRoute path="/Platform/Configuration" component={RollbackLayout} />
								<ProtectedRoute path="/Platform/Task/Scheduling" component={TaskScheduling} />
								<ProtectedRoute path="/Platform/System/Status" component={SystemStatus} />
								<ProtectedRoute path="/Faults" component={FaultsLayout}/>
								<ProtectedRoute path="/User" component={UserLayout}/>
								<Route path="/login" component={Login}/>
								<Route path="/logout" component={Logout}/>
								<Redirect to="/" />
							</Switch>
							</NoaSubMenu>
							{props.children}
						</Grid.Column>
					</Grid.Row>
					<Grid.Row columns={1}>
						<Grid.Column width={16}>
							<Footer/>
						</Grid.Column>
					</Grid.Row>
				</Grid>
				</NoaContainer>		
				</Grid.Column>
			</Grid>
		</NoaContainer>
		</UIRouter>
	)
}

export default withRouter(AppLayout);