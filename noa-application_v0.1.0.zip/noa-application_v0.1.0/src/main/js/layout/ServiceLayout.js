/**@module ServiceLayout */

'use strict';
import React,{ useContext, useEffect } from 'react';

import ProtectedRoute from '../utility/ProtectedRoute';
import { useLocation } from "react-router-dom";
import {
  Switch,
  withRouter, Redirect
} from "react-router-dom";

import { Grid } from 'semantic-ui-react';

import { CSSTransition, TransitionGroup } from "react-transition-group";

import { MenuContext } from '../utility/MenuContext';
import { completeHeight, completeWidth, fullHeight, noBoxShadow } from '../constants';

import ServiceSummary from '../service/stat/ServiceSummary';
import ServiceFaults from '../service/event/ServiceFaults';
import { NoaContainer } from '../widget/NoaWidgets';
import ServiceCatalog from '../service/catalog/ServiceCatalog';
import ServiceConnectivity from '../service/ServiceConnectivity';
import ServiceTopology from '../service/topology/ServiceTopology';
import { ConnectivityIcon, FaultsIcon, StatIcon, SummaryIcon, TopologyIcon } from '../widget/NoaIcons';
import ServiceManager from '../service/ServiceManager';
import ServiceStatistics from '../service/stat/ServiceStatistics';

const styles = {
	marginBottom: 50
};

const ServiceLayout = (props) => {

	let location = useLocation();
	let { path, url } = props.match;

	let currentPath = location.pathname;
	var results = currentPath.split('/');
	const serviceName = results[2]

	const menuContext = useContext(MenuContext);
	
	useEffect(() => {
		menuContext.setActiveItem(0);
	},[]);

	useEffect(() => {
		if(serviceName !== undefined && serviceName !== "" && serviceName !== null) {
			const itemsData = [
				{ key: 'summary', name: 'Summary', url: "/Services/" + serviceName, text: serviceName, children: [],icon: SummaryIcon,activeIndex:0},
				{ key: 'resources', name: 'Topology', url: "/Services/" + serviceName + "/Topology", text: serviceName,children: [],icon: TopologyIcon,activeIndex:1},
				{ key: 'faults', name: 'Faults', url: "/Services/" + serviceName + "/Fault",text: serviceName, children: [],icon: FaultsIcon,activeIndex:2},
				{ key: 'connectivity', name: 'Connectivity', url: "/Services/" + serviceName + "/Connectivity/Path", text: serviceName, children: [], icon: ConnectivityIcon,activeIndex:3},
				{ key: 'statistics', name: 'Statistics', url: "/Services/" + serviceName + "/Statistics", text: serviceName,children: [],icon: StatIcon,activeIndex:4},
			]
			menuContext.setData(itemsData);
			menuContext.setLayout("Service");
			let allOptions = [];

			itemsData.forEach((item) => {
				if(item.children.length > 0){
					let childOptions = item.children;
					allOptions.push(childOptions);
				}
				allOptions.push(item);
			})
			let currentUrl = allOptions.find(item => item.url == location.pathname);
			if(currentUrl != undefined) {			
				menuContext.setDisplayText(currentUrl.text)
				menuContext.setHideMenu(false);
				menuContext.setActiveItem(currentUrl.activeIndex)
			}
		}
	},[currentPath]);

	return (
		<NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
			<Grid style={Object.assign({},fullHeight,noBoxShadow)} columns={1}>
				<Grid.Column width={16} verticalAlign='top' style={fullHeight} textAlign='center'>
				<Switch location={location}>
					<ProtectedRoute exact path={`${path}`} component={ServiceManager} />
					<ProtectedRoute exact path={`${path}/Catalog`} component={ServiceCatalog} />					
					<ProtectedRoute exact path={`${path}/:serviceName`} component={ServiceSummary} />
					<ProtectedRoute exact path={`${path}/:serviceName/Topology`} component={ServiceTopology} />
					<ProtectedRoute exact path={`${path}/:serviceName/Fault`} component={ServiceFaults} />
					<ProtectedRoute exact path={`${path}/:serviceName/Connectivity/Path`} component={ServiceConnectivity} />
					<ProtectedRoute exact path={`${path}/:serviceName/Statistics`} component={ServiceStatistics} />
					<Redirect to="/" />
				</Switch>
				</Grid.Column>
			</Grid>
			{props.children}
		</NoaContainer>
	)
}

export default withRouter(ServiceLayout);