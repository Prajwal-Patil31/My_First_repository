/**@module FaultsLayout */

'use strict';
import React, { useContext, useEffect } from 'react';
import GlobalFault from '../global/event/fault/GlobalFault';
import GlobalEvents from '../global/event/GlobalEvents';
import FaultConfig from '../global/event/fault/FaultConfig';
import FaultsSummary from '../global/event/fault/FaultsSummary';
import FaultPolicyManager from '../global/event/fault/FaultPolicyManager';

import ProtectedRoute from '../utility/ProtectedRoute';
import { useLocation } from "react-router-dom";

import { Switch, withRouter,Redirect } from "react-router-dom";

import { Grid } from 'semantic-ui-react';

import 'semantic-ui-css/semantic.min.css';

import { completeWidth, fullHeight, noBoxShadow} from '../constants'
import { MenuContext } from '../utility/MenuContext';
import { NoaContainer } from '../widget/NoaWidgets';
import { EventsIcon, FaultsIcon, FPolicyIcon, SettingsIcon, SummaryIcon } from '../widget/NoaIcons';

const FaultsLayout = (props) => {

	let location = useLocation();
	let { path, url } = props.match;

	let currentPath = location.pathname;

	const menuContext = useContext(MenuContext);

	useEffect(() => {
		const itemsData = [
			{ key: 'summary', name: 'Summary', url: "/Faults", text: "Faults Summary", children: [],icon: SummaryIcon,activeIndex:0},
			{ key: 'faults', name: 'Faults', url: "/Faults/List", text: "Global Faults",children: [],icon: FaultsIcon,activeIndex:1},
			{ key: 'events', name: 'Events', url: "/Faults/Event", text: "Global Events",children: [],icon: EventsIcon,activeIndex:2},
			{ key: 'fault-configuration', name: 'Configuration', url: "/Faults/Configuration", text: "Fault Configuration",children: [],icon: SettingsIcon,activeIndex:3},
			{ key: 'policy', name: 'Policy', url: "/Faults/Policy", text: "Fault Policies",children: [],icon: FPolicyIcon,activeIndex:4},
		]
		menuContext.setData(itemsData);
		menuContext.setLayout("Faults");
		let allOptions = [];

		itemsData.forEach((item) => {
			if(item.children.length > 0){
				let childOptions = item.children;
				allOptions.push(childOptions);
			}
			allOptions.push(item);
		})
		let currentUrl = allOptions.find(item => item.url == location.pathname);
		console.log(currentUrl)
		if(currentUrl == undefined) {				
			menuContext.setHideMenu(true);
		} else {
			menuContext.setDisplayText(currentUrl.text)
			menuContext.setHideMenu(false);
			menuContext.setActiveItem(currentUrl.activeIndex)
		}
	},[currentPath]);

	return (
		<NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
			<Grid style={Object.assign({},fullHeight, noBoxShadow)} columns={1}>
				<Grid.Column width={16} style={fullHeight} verticalAlign='top' textAlign='center'>
				<Switch location={location}>
					<ProtectedRoute exact path={`${path}/List`} component={GlobalFault} />
					<ProtectedRoute exact path={`${path}/Event`} component={GlobalEvents} />
					<ProtectedRoute exact path={`${path}/Configuration`} component={FaultConfig} />
					<ProtectedRoute exact path={`${path}`} component={FaultsSummary} />
					<ProtectedRoute exact path={`${path}/Policy`} component={FaultPolicyManager} />
					<Redirect to="/" />
				</Switch>
				</Grid.Column>
			</Grid>
			{props.children}
		</NoaContainer>
	)
}
export default withRouter(FaultsLayout);