'use strict';
import React, { useContext,useEffect } from 'react';

import ProtectedRoute from '../utility/ProtectedRoute';
import { useLocation } from "react-router-dom";

import { Switch,withRouter,Redirect } from "react-router-dom";

import { MenuContext } from '../utility/MenuContext';
import { completeHeight, completeWidth, fullHeight, noBoxShadow } from '../constants';
import { NoaContainer } from '../widget/NoaWidgets';
import { Grid } from 'semantic-ui-react';

import PasswordPolicyManager from '../security/account/user/password/PasswordPolicyManager';
import AuditLogManagement from '../security/audit/AuditLogManagement';
import SessionManager from '../security/session/SessionManager';
import { AuditLogIcon, PPolicyIcon, SessionIcon } from '../widget/NoaIcons';

const SecurityLayout = (props) => {

    let location = useLocation();
    let { path, url } = props.match;

    let currentPath = location.pathname;

    const menuContext = useContext(MenuContext);
    
    useEffect(() => {
		menuContext.setActiveItem(0);
    },[]);
    
	useEffect(() => {
        const itemsData = [
            { key: 'password-policy', name: 'Password Policy', url: "/Platform/Security/Policy/Password", text: "Password Policy",
                children: [],icon: PPolicyIcon,activeIndex:0},
            { key: 'audit-log', name: 'Audit Log', url: "/Platform/Security/Audit",text: "Audit Log",
            children: [],icon: AuditLogIcon,activeIndex:1},
            { key: 'sessions', name: 'Sessions', url: "/Platform/Security/Session",text: "Active User Sessions",
            children: [],icon: SessionIcon,activeIndex:2},
        ]
        menuContext.setData(itemsData);
        menuContext.setLayout("Security");
        let allOptions = [];

        itemsData.forEach((item) => {
            if(item.children.length > 0){
                let childOptions = item.children;
                childOptions.forEach((childItem) => {
                    allOptions.push(childItem)
                })
            }
            allOptions.push(item);
        })
        let currentUrl = allOptions.find(item => item.url == location.pathname);
        if(currentUrl == undefined) {				
            menuContext.setHideMenu(true);
        } else {
            menuContext.setDisplayText(currentUrl.text)
            menuContext.setHideMenu(false);
            menuContext.setActiveItem(currentUrl.activeIndex)
        }
    },[currentPath]);

    return (
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight,noBoxShadow)} columns={1}>
                <Grid.Column width={16} style={fullHeight} verticalAlign='top' textAlign='center'>
                    <Switch location={location}>
                        <ProtectedRoute exact path={`${path}/Policy/Password`} component={PasswordPolicyManager} />
                        <ProtectedRoute exact path={`${path}/Audit`} component={AuditLogManagement} />
                        <ProtectedRoute exact path={`${path}/Session`} component={SessionManager} />
                        <Redirect to="/" />
                    </Switch>
                </Grid.Column>
            </Grid>
            {props.children}
        </NoaContainer>
    )
}

export default withRouter(SecurityLayout);