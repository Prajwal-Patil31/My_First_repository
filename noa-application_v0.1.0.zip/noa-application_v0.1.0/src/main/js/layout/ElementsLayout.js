/**@module ElementsLayout */

'use strict';
import React, { useContext, useEffect } from 'react';

import ProtectedRoute from '../utility/ProtectedRoute';
import { useLocation } from "react-router-dom";

import { Switch, withRouter,Redirect } from "react-router-dom";

import { Grid } from 'semantic-ui-react';

import { MenuContext } from '../utility/MenuContext';
import { NoaContainer } from '../widget/NoaWidgets';
import { noBoxShadow, completeWidth, fullHeight } from '../constants'

import ElementInventory from '../element/inventory/ElementInventory';
import ElementSummary from '../element/stat/ElementSummary';
import ElementDiscovery from '../element/discovery/ElementDiscovery';
import ElementGeneralConfig from '../element/config/ElementGeneralConfig';
import ElementFaults from '../element/event/ElementFaults';
import ElementConnectivity from '../element/ElementConnectivity';
import BridgeConfig from '../element/config/bridge/BridgeConfig';
import MplsConfig from '../element/config/mpls/MplsConfig';
import ElementRoutingConfig from '../element/config/route/ElementRoutingConfig';
import ElementResources from '../element/config/resource/ElementResources';
import ElementStatistics from '../element/stat/ElementStatistics';
import PortConfig from '../element/config/resource/port/PortConfig';

import { 
	BridgeIcon, ConnectivityIcon, FaultsIcon, 
	GeneralIcon, InterfaceIcon, MplsIcon, 
	ResourcesIcon, RoutingIcon, SettingsIcon, 
	StatIcon, SummaryIcon 
} from '../widget/NoaIcons';

/**
 * Component to Redirect the User to pages related to Elements
 * in a protected way.
 * 
 * @class
 * @augments React.Component
*/

const ElementsLayout = (props) => {
	let location = useLocation();
	let { path, url } = props.match;

	let currentPath = location.pathname;
	var result = [];
	var results = currentPath.split('/');
	const deviceName = results[2]

	const menuContext = useContext(MenuContext);
	
	useEffect(() => {
		menuContext.setActiveItem(0);
	},[]);

	useEffect(() => {
		if(deviceName !== undefined && deviceName !== "" && deviceName !== null) {
			const itemsData = [
				{ key: 'summary', name: 'Summary',url:"/Elements/" + deviceName,text: deviceName,children:[],icon: SummaryIcon,activeIndex:0},
				{ key: 'resources', name: 'Resources',url:"/Elements/" + deviceName + "/Resource",text: deviceName,children:[],icon: ResourcesIcon,activeIndex:1},
				{ key: 'faults', name: 'Faults',url:"/Elements/" + deviceName + "/Fault",text: deviceName,children:[],icon: FaultsIcon,activeIndex:2},
				{ 
					key: 'configuration', 
					name: 'Configuration',
					url:"/Elements/" + deviceName + "/Configuration",
					text: deviceName,
					icon: SettingsIcon,
					activeIndex:3,
					children:[
						{
							key: "general", name: "General",url:"/Elements/" + deviceName + "/Configuration/General",children:[],
							activeIndex:3,text: deviceName,icon:GeneralIcon
						},
						{
							key: "interface", name: "Interface",url:"/Elements/" + deviceName + "/Configuration/Interface",children:[],
							activeIndex:3,text: deviceName,icon:InterfaceIcon
						},
						{
							key: "bridge", name: "Bridge",url:"/Elements/" + deviceName + "/Configuration/Bridge",children:[],
							activeIndex:3,text: deviceName,icon:BridgeIcon
						},
						{
							key: "routing", name: "Routing",url:"/Elements/" + deviceName + "/Configuration/Routing",children:[],
							activeIndex:3,text: deviceName,icon:RoutingIcon
						},
						{
							key: "mpls", name: "MPLS",url:"/Elements/" + deviceName + "/Configuration/MPLS",children:[],
							activeIndex:3,text: deviceName,icon:MplsIcon
						}
					]
				},
				{ key: 'connectivity', name: 'Connectivity',url:"/Elements/" + deviceName + "/Connectivity",text: deviceName,children:[],icon: ConnectivityIcon,activeIndex:4},
				{ key: 'statistics', name: 'Statistics',url:"/Elements/" + deviceName + "/Statistics",text: deviceName,children:[],icon: StatIcon,activeIndex:5},
			]
			menuContext.setData(itemsData);
			menuContext.setLayout("Elements");
			let allOptions = [];

			itemsData.forEach((item) => {
				if(item.children.length > 0){
					let childOptions = item.children;
					childOptions.forEach((childItem) => {
						allOptions.push(childItem)
					})
				}
				allOptions.push(item);
			})
			let currentUrl = allOptions.find(item => item.url == location.pathname);
			
			if(currentUrl != undefined) {
				menuContext.setDisplayText(currentUrl.text)
				menuContext.setHideMenu(false);
				menuContext.setActiveItem(currentUrl.activeIndex);
			}
		}
	},[currentPath]);

	return (
		<NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
		<Grid style={Object.assign({},fullHeight,noBoxShadow)} columns={1}>
			<Grid.Column width={16} verticalAlign='top' style={fullHeight} textAlign='center'>
			<Switch location={location}>
				<ProtectedRoute exact path={`${path}`} component={ElementInventory} />
				<ProtectedRoute exact path={`${path}/Discovery`} component={ElementDiscovery} />
				<ProtectedRoute exact path={`${path}/:deviceName`} component={ElementSummary} />
				<ProtectedRoute exact path={`${path}/:deviceName/Resource`} component={ElementResources} />
				<ProtectedRoute exact path={`${path}/:deviceName/Statistics`} component={ElementStatistics} />
				<ProtectedRoute exact path={`${path}/:deviceName/Fault`} component={ElementFaults} />
				<ProtectedRoute exact path={`${path}/:deviceName/Connectivity`} component={ElementConnectivity} />
				<ProtectedRoute exact path={`${path}/:deviceName/Configuration/Interface`} component={PortConfig} />
				<ProtectedRoute exact path={`${path}/:deviceName/Configuration/General`} component={ElementGeneralConfig} />
				<ProtectedRoute exact path={`${path}/:deviceName/Configuration/Bridge`} component={BridgeConfig} />
				<ProtectedRoute exact path={`${path}/:deviceName/Configuration/MPLS`} component={MplsConfig} />
				<ProtectedRoute exact path={`${path}/:deviceName/Configuration/Routing`} component={ElementRoutingConfig} />
				<Redirect to="/" />
			</Switch>
			</Grid.Column>
		</Grid>
		{props.children}
		</NoaContainer>
	)
}

export default withRouter(ElementsLayout);