import React from 'react';
import { Grid } from 'semantic-ui-react';
import { completeWidth, fullHeight, noBoxShadow } from '../constants';
import Dashboard from '../Dashboard';
import { NoaContainer } from '../widget/NoaWidgets';

const GlobalLayout = () => {
	return(
		<NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
		<Grid style={Object.assign({},fullHeight,noBoxShadow)} columns={1}>
			<Grid.Column width={16} verticalAlign='top' style={fullHeight} textAlign='center'>
				<Dashboard />
			</Grid.Column>
		</Grid>
		</NoaContainer>
	)
}
export default GlobalLayout;