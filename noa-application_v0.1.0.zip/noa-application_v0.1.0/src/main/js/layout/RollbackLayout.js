'use strict';
import React, { useContext,useEffect } from 'react';
import ProtectedRoute from '../utility/ProtectedRoute';

import { useLocation } from "react-router-dom";
import { Switch,withRouter,Redirect } from "react-router-dom";

import { completeHeight, completeWidth, fullHeight, noBoxShadow } from '../constants';
import { NoaContainer } from '../widget/NoaWidgets';
import { Grid } from 'semantic-ui-react';
import ConfigurationRecord from '../platform/config/ConfigurationRecord';
import { MenuContext } from '../utility/MenuContext';

const RollbackLayout = (props) => {
    let location = useLocation();
    let { path, url } = props.match;
    let currentPath = location.pathname;
    
    const menuContext = useContext(MenuContext);
    
    useEffect(() => {
        menuContext.setData([]);
		menuContext.setDisplayText("Configuration Records");
        menuContext.setHideMenu(true);
        menuContext.setLayout("Rollback");
    },[currentPath]);
    
    return (
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Column width={16} style={completeHeight} verticalAlign='top' textAlign='center'>
                    <Switch location={location}>
                        <ProtectedRoute exact path={`${path}/Rollback`} component={ConfigurationRecord} />
                        <Redirect to="/" />
                    </Switch>
                </Grid.Column>
            </Grid>
            {props.children}
        </NoaContainer>
    )
}

export default withRouter(RollbackLayout);