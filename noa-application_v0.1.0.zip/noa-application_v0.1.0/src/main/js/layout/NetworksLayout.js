/**@module ElementsLayout */

'use strict';
import React, { useContext, useEffect, useState } from 'react';
import ProtectedRoute from '../utility/ProtectedRoute';
import { useLocation } from "react-router-dom";

import {
	Switch,
	withRouter,Redirect
} from "react-router-dom";

import { Grid } from 'semantic-ui-react';
//import LeafletMaps from '../Elements/LeafletMaps';

import { MenuContext } from '../utility/MenuContext';
import {NoaContainer} from '../widget/NoaWidgets';

import NetworkManager from '../network/NetworkManager';
import NetworkSummary from '../network/stat/NetworkSummary';
import NetworkFaults from '../network/event/NetworkFaults';
import NetworkStatistics from '../network//stat/NetworkStatistics';
import NetworkLinkManager from '../network/l1/NetworkLinkManager';
import NetworkTopology from '../network/topology/NetworkTopology';

import { completeWidth, fullHeight, noBoxShadow } from '../constants';
import { ConnectivityIcon, FaultsIcon, StatIcon, SummaryIcon, TopologyIcon } from '../widget/NoaIcons';
import NetworkRouteManager from '../network/l3/NetworkRouteManager';
import NetworkLspManager from '../network/l2/NetworkLspManager';

/**
 * Component to Redirect the User to pages related to Elements
 * in a protected way.
 * 
 * @class
 * @augments React.Component
*/

const NetworksLayout = (props) => {

	let location = useLocation();
	let { path, url } = props.match;

	let currentPath = location.pathname;
	var results = currentPath.split('/');
	const networkName = results[2]
	
	let networkType = sessionStorage.getItem("networkType");
	let linkType = "";
	switch(networkType) {
		case "L1 Network":
			linkType = "link"
			break;
		case "L2 Network":
			linkType = "link"
			break;
		case "L2.5 Network":
			linkType = "lsp"
			break;
		case "L3 Network":
			linkType = "route"
			break;
	}
	const menuContext = useContext(MenuContext);
	
	useEffect(() => {
		menuContext.setActiveItem(0);
	},[]);

	useEffect(() => {
		if(networkName !== undefined && networkName !== "" && networkName !== null) {
			const itemsData = [
				{ key: 'summary', name: 'Summary', url: "/Networks/" + networkName, text: networkName, children: [],icon: SummaryIcon,activeIndex:0},
				{ key: 'resources', name: 'Topology', url: "/Networks/" + networkName + "/Topology",text: networkName, children:[],icon: TopologyIcon,activeIndex:1},
				{ key: 'faults', name: 'Faults', url: "/Networks/" + networkName + "/Fault",text: networkName, children: [],icon: FaultsIcon,activeIndex:2},
				{ key: 'connectivity', name: 'Connectivity', url: "/Networks/" + networkName + "/Connectivity/" + linkType,text: networkName, children: [],icon: ConnectivityIcon,activeIndex:3},
				{ key: 'statistics', name: 'Statistics', url: "/Networks/" + networkName + "/Statistics", text: networkName,children: [],icon: StatIcon,activeIndex:4},
			]
			menuContext.setData(itemsData);
			menuContext.setLayout("Networks");
			let allOptions = [];

			itemsData.forEach((item) => {
				if(item.children.length > 0){
					let childOptions = item.children;
					allOptions.push(childOptions);
				}
				allOptions.push(item);
			})
			let currentUrl = allOptions.find(item => item.url == location.pathname);
			if(currentUrl != undefined) {
				menuContext.setDisplayText(currentUrl.text)
				menuContext.setHideMenu(false);
				menuContext.setActiveItem(currentUrl.activeIndex)
			}
		}
	},[currentPath]);

	return (
		<NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
			<Grid style={Object.assign({},fullHeight,noBoxShadow)} columns={1}>
				<Grid.Column width={16} verticalAlign='top' textAlign='center' style={fullHeight}>
				<Switch location={location}>
					<ProtectedRoute exact path={`${path}`} component={NetworkManager} />
					<ProtectedRoute exact path={`${path}/:networkName`} component={NetworkSummary} />
					<ProtectedRoute exact path={`${path}/:networkName/Topology`} component={NetworkTopology} />
					<ProtectedRoute exact path={`${path}/:networkName/Fault`} component={NetworkFaults} />
					<ProtectedRoute exact path={`${path}/:networkName/Connectivity/Link`} component={NetworkLinkManager} />
					<ProtectedRoute exact path={`${path}/:networkName/Connectivity/Lsp`} component={NetworkLspManager} />
					<ProtectedRoute exact path={`${path}/:networkName/Connectivity/Route`} component={NetworkRouteManager} />
					<ProtectedRoute exact path={`${path}/:networkName/Statistics`} component={NetworkStatistics} />
					<Redirect to="/" />
				</Switch>
				</Grid.Column>
			</Grid>
			{props.children}
		</NoaContainer>
		
	)
}
export default withRouter(NetworksLayout);