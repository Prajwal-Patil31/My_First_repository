/**@module LoginLayout */

import React from 'react';

import { Grid, Image, Divider } from 'semantic-ui-react';
 
import Login from '../security/authentication/Login';

import 'semantic-ui-css/semantic.min.css';
import { dividerStyle } from '../constants';

/**
 * Component to provide Layout for the Login page.
 * 
 * @class
 * @augments React.Component
 */
class LoginLayout extends React.Component {
    constructor(props) {
        super(props);
    }

    /**
     * Renders a view of Login Page .
    */
    render() {
        return (
            <div>
            <Grid>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2}
                            verticalAlign='middle' 
                            style={{backgroundColor: '#FFFFFF', height: '100vh'}}>
                            <Grid.Column>
                                <Grid centered style={{backgroundColor: '#F5F5F5', height: '100vh'}}>
                                    <Grid.Column verticalAlign='middle'>
                                        <Image centered size="medium" src="/images/unoa-l.png"/>
                                        <p textAlign='center' style={{fontFamily: 'OpenSansLight',fontSize:"1.8em",paddingTop:"1em"}}>
                                            Network Orchestration & Automation Platform
                                        </p>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                            <Grid.Column>
                                <Grid columns={3} centered style={{width: '100vh'}}>
                                    <Grid.Column width={1}></Grid.Column>
                                    <Grid.Column width={6} verticalAlign='middle' id="login">
                                        <p textAlign='center' style={{fontFamily: 'OpenSansLight',fontSize:"1.8em"}}>
                                            NOA Administration Console
                                        </p>
                                        <Divider style={dividerStyle}/>
                                        <Login/>
                                    </Grid.Column>
                                    <Grid.Column width={1}></Grid.Column>
                                </Grid>
                            </Grid.Column> 
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
            </div>
        )
    }
}

export default LoginLayout;