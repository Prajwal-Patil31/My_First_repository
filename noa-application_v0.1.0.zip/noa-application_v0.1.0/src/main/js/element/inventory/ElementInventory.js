import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../widget/NoaTable';
import { withRouter,Link } from 'react-router-dom';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Checkbox,
    Dropdown,
    Icon,
    Input
} from 'semantic-ui-react';

import { 
    noBoxShadow,overviewStyle,fullHeight,
    noPadding, noMarginTB, noMarginLR, 
    titleText, cardLayout, applyButton, 
    cancelButton, formParameter, tablePadding, 
    formTitle, completeHeight, completeWidth,
    tableHeaderHeight, dividerStyle, formContentSpacingTB, 
    inputBoxStyle, dropdownStyle, pieValueItem, 
    pieKeyItem
} from '../../constants';

import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';
import NoaFilter from '../../widget/NoaFilter';
import { NoaHeader, NoaContainer} from '../../widget/NoaWidgets';
import NoaRadialBarChart from '../../widget/NoaRadialBarChart';
import NoaCard from '../../widget/NoaCard';
import NoaToolbar from '../../widget/NoaToolbar';
import { MenuContext } from '../../utility/MenuContext';
import { UIView, useRouter } from '@uirouter/react';
import NoaPieChart from '../../widget/NoaPieChart';
import noaNotification from '../../widget/NoaNotification';

const pieChartColors = ["#903749", "#543864","#750550","#21325E"];

const ElementInventory = (props) => {
    const [elementOverview, setElementOverview] = useState({});
    const [elementsStatus, setElementsStatus] = useState([]);

    const [devices, setDevices] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const menuContext = useContext(MenuContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = devices[sel[i]].deviceId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getDevices = (paginationObj) => {
        context.setRenderLocation(["element-list"]);
        setDevices([]);
        NoaClient.post(
            "/api/element",
            paginationObj,
			(response) => {
                let responseData = response.data;
                setDevices(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
		});
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    const getElementsOverview = () => {
        NoaClient.get(
            "/api/element/overview",
            (response) => {
                let responseData = response.data;
                setElementOverview(responseData);
            });
    }

    const getElementsStatus = () => {
        NoaClient.get(
            "/api/element/status",
            (response) => {
                let responseData = response.data;
                setElementsStatus(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        getElementsOverview();
        getElementsStatus();
        let filterCriteria = {}

        router.stateService.go('default');

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getDevices(filterCriteria);
        menuContext.setHideMenu(true);
		menuContext.setDisplayText("Element Inventory");
    },[]);

    const eventColors = ['#1A374D','#6998AB','#406882','#B1D0E0'];
    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={{maxHeight: "100vh"}}>
                <Grid.Column width={16} verticalAlign='top'>
                    <ElementOverview summaryObj={elementOverview} 
                                    eventColors={eventColors} 
                                    devices={totalEntries} 
                                    deviceStateData={elementsStatus}
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16} verticalAlign='top'>
                    <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                        <DevicesTable 
                            devices={devices}
                            setSelected={setSelected}
                            clearSelected={clearSelected}
                            setClearSelected={setClearSelected}
                            getDevices={getDevices}
                            selectedRows={selectedRows}
                            columns={columns}
                            filters={filters}
                            pageSize={pageSize}
                            totalPages={totalPages}
                            setPageSize={setPageSize}
                            totalEntries={totalEntries}
                        />
                    </Segment>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const ElementOverview = (props) => {
    const summaryObj = props.summaryObj;
    const eventColors = props.eventColors;
    const devices = props.devices;
    const deviceStateData = props.deviceStateData;
    return(
        <NoaContainer style={Object.assign({},overviewStyle,completeWidth)}>
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2} stretched stackable relaxed='very'>
                    <Grid.Column width={6} id="element-overview">
                        <NoaCard title={"Element Overview"} renderDuration={false}>
                            <NoaContainer style={Object.assign({paddingLeft: "1.5em", paddingRight: "1.5em"})}>
                                {Object.keys(summaryObj).length > 0 ? 
                                <Grid columns={2} stackable>
                                    <Grid.Column textAlign='left' computer={9} tablet={16} mobile={16} style={{minWidth:"200px"}}>
                                        <NoaPieChart data={summaryObj} colors={eventColors} labelValue={"286 Elements"} renderDetails={false}/>
                                    </Grid.Column>
                                    <Grid.Column computer={7} tablet={16} mobile={16} verticalAlign='middle'>
                                        <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid>
                                                {Object.keys(summaryObj).map((keyValue,index) => (
                                                    <Grid.Row columns={1} verticalAlign='middle'>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={2} stackable verticalAlign='bottom'>
                                                                <Grid.Column tablet={12} computer={9} mobile={16} textAlign='left' style={pieKeyItem}>
                                                                    {keyValue}
                                                                </Grid.Column>
                                                                <Grid.Column tablet={12} computer={7} mobile={16} textAlign='left' 
                                                                    style={Object.assign({color:eventColors[index]},pieValueItem)}>
                                                                    {summaryObj[keyValue]}
                                                                </Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row> 
                                                ))}
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        </Grid>
                                    </Grid.Column>
                                </Grid>
                                :""}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                    <Grid.Column width={10}>
                        <NoaCard title={"Element Status"} renderDuration={false}>
                            <NoaContainer style={Object.assign({paddingLeft: "1.5em", paddingRight: "1.5em"})}>
                            {deviceStateData.length > 0 ? 
                            <Grid stackable verticalAlign='middle'>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={3} stackable>
                                            {deviceStateData.map((deviceData,index) => (
                                                <Grid.Column computer={index == 1 ? 6 : 5} tablet={8} mobile={16}>
                                                    <NoaRadialBarChart data={deviceData} colors={pieChartColors[index]}/>
                                                </Grid.Column>
                                            ))}
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>   
                            :""}
                            </NoaContainer>                 
                        </NoaCard>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const DevicesTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const setClearSelected = props.setClearSelected;
    const getDevices = props.getDevices;
    //const columns = props.columns;
    const filters = props.filters;
    const selectedRows = props.selectedRows;

    const [devicesData, setDevicesData] = useState([]);
    const [selections, setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {}});
    
    useEffect(() => {
        if(props.devices) {
            let devicesList = props.devices;
            setDevicesData(props.devices)
        }
    },[props.devices]);
    
	useEffect(() => {
		setSelected(selections);
	}, [selections]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
        {
            label: "2",
            Header: "Element Name",
            Cell: ({row}) => {
                let deviceId = row.original.deviceId;
                let deviceName = row.original.deviceName;
                
                const toElementInstance = { 
                    pathname: `/Elements/${deviceName}`,
                }
                return <Link to={toElementInstance} onClick={() => {
                    sessionStorage.setItem("elementId",deviceId);
                    sessionStorage.setItem("elementName",deviceName);
                }}>{deviceName}</Link>
            },
            width:2
        },
        {
            label: "3",
            Header: "Element Type",
            accessor: "deviceType",
            width:2
        },
        {
            label: "4",
            Header: "Host",
            accessor: "host",
            width:2          
        },
        {
            label: "5",
            Header: "Port",
            accessor: "port",
            width:2
        },
        {
            label: "6",
            Header: "Hardware Version",
            accessor: "hardwareVersion",
            filterable: true,
            width:3

        },
        {
            label: "7",
            Header: "Software Version",
            accessor: "softwareVersion",
            filterable: true,
            width:2
        },
        {
            label: "8",
            Header: "Element Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:2
        }
    ]

    const handleAddDevice = () => {
        router.stateService.go("add-device",{fetchData: fetchData, clearSelection: clearSelection})
    }

    /* useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-fault-config',{id: faultConfigurations[selId].configId,fetchData: getFaultConfigurations,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]); */
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["element-list"]);

        NoaClient.delete(
            "/api/element",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null})
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getDevices(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getDevices(body)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})

    if (!devicesData && !devicesData.length)
		return null;

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Element List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddDevice}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle' style={noPadding}>
                    <NoaTable data={devicesData}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={setPageSize}
                        totalEntries={totalEntries}
                        resource="Element" 
                        fetchData={fetchData} 
                        location="element-list"   
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>   
        
    );
}

const renderBoolean = (row) => {
    const enabledState = row.original.elementStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddDevice = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const getDevices = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();
    
    const [device, setDevice] = useState({});

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleAdd = () => {
        NoaClient.put(
			"/api/element",
			device,
			(response) => {
                noaNotification('success','Device Attached Successfully.');
				getDevices();
				closeFooter();
        });
    }

    const handleChange = (value, key) => {
		setDevice(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Attach Device</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-element">
                <Grid columns={3} stackable>
                    <Grid.Column width={3}></Grid.Column>
                    <Grid.Column width={10} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='top'>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Device Name</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='deviceName' 
                                                                        value={device.deviceName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'deviceName')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter}>Host Address</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='host' 
                                                                        value={device.host}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'host')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter}>Host Port</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='port' 
                                                                        value={device.port}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'port')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='top'>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Device Type</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection fluid required
                                                                    placeholder="Select Device Type"
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    options={deviceTypes_dd}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value==='' ? null : value, 'deviceType')
                                                                    }
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Username</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='userName' 
                                                                        value={device.userName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'userName')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Password</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='password' name='password' 
                                                                        value={device.password}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'password')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={3}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                handleAdd();
                                context.setRenderLocation(["add-element"]); 
                            }}>Attach</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>           
        </Grid>
        </NoaContainer>
    )
}

const deviceTypes_dd = [
    {
        key: 'pe-router',
        text: 'PE Router',
        value: 'pe-router',
    },
    {
        key: 'p-router',
        text: 'P Router',
        value: 'p-router',
    },
    {
        key: 'ce-router',
        text: 'CE Router',
        value: 'ce-router',
    }
]

export default withRouter(ElementInventory);
export {AddDevice}