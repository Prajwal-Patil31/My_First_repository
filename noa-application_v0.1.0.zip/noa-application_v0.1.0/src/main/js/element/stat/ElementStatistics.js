import React from 'react';

const ElementStatistics = (props) => {
    return(
        <div></div>
    )
}
export default ElementStatistics;