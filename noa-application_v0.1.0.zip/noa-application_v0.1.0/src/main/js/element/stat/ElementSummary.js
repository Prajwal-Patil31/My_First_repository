import React, { useEffect, useState, useContext} from 'react';

import { Grid, Container } from 'semantic-ui-react';

import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';

import NoaTable from '../../widget/NoaTable';

import { 
    cardDurationItem, cardKeyItem, cardValueItem, 
    completeWidth, noPadding
} from '../../constants';

import NoaRadialBarChart from '../../widget/NoaRadialBarChart.js';
import NoaLineChart from '../../widget/NoaLineChart';
import NoaCard from '../../widget/NoaCard';
import { NoaContainer } from '../../widget/NoaWidgets';
import NoaProgressBar from '../../widget/NoaProgressBar';
import { MenuContext } from '../../utility/MenuContext';
import NoaRadialBar from '../../widget/NoaRadialBar';

const ElementSummary = (props) => {
    
    const deviceId = sessionStorage.getItem("elementId"); 

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const menuContext = useContext(MenuContext);

    const [deviceDetails, setDeviceDetails] = useState({});
    const [deviceState, setDeviceState] = useState([]);
    const [deviceResources, setDeviceResources] = useState({});
    const [portUtilizationIn, setPortUtilizationIn] = useState([]);
    const [portUtilizationOut, setPortUtilizationOut] = useState([]);
    const [serviceThroughput, setServiceThroughput] = useState([]);
    const [linkLatency, setLinkLatency] = useState([]);

    const getDeviceDetails = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/overview",
            (response) => {
                let responseData = response.data;
                setDeviceDetails(responseData);
            });
    }

    const getDeviceState = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/state",
            (response) => {
                let responseData = response.data;
                setDeviceState(responseData);
            });
    }

    const getDeviceResources = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/resource/overview",
            (response) => {
                let responseData = response.data;
                setDeviceResources(responseData);
            });
    }

    const getInUtilization = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/interface/in",
            (response) => {
                let responseData = response.data;
                setPortUtilizationIn(responseData);
            });
    }

    const getOutUtilization = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/interface/out",
            (response) => {
                let responseData = response.data;
                setPortUtilizationOut(responseData);
            });
    }

    const getServiceThroughput = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/service/throughput",
            (response) => {
                let responseData = response.data;
                setServiceThroughput(responseData);
            });
    }

    const getLinkLatency = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/link/latency",
            (response) => {
                let responseData = response.data;
                setLinkLatency(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        menuContext.setHideMenu(false);
        menuContext.setActiveItem(0);
        getDeviceDetails();
        getDeviceState();
        getDeviceResources();
        getInUtilization();
        getOutUtilization();
        getServiceThroughput();
        getLinkLatency();
    }, []);

    return(
        <Container style={completeWidth}>
            <Grid>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid stackable stretched columns={2} relaxed='very'>
                            <Grid.Column computer={5} tablet={16} mobile={16}>
                                <NoaCard title={"Device Details"} renderDuration={true} durationComponent={timeInHours}>
                                    {Object.keys(deviceDetails).length > 0 ? 
                                        <DeviceDetailCard data={deviceDetails["summary"]} color={"#007EFF"} listData={deviceDetails["detailed"]}/>
                                    :""}
                                </NoaCard>
                            </Grid.Column>
                            <Grid.Column computer={11} tablet={16} mobile={16}>
                                <NoaCard title={"Device State"} renderDuration={true}>
                                    <NoaContainer style={Object.assign({paddingLeft: "1.5em", paddingRight: "1.5em"})}>
                                    {deviceState.length > 0 ? 
                                        <Grid stackable verticalAlign='middle' columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    {deviceState.map((deviceData,index) => (
                                                        <Grid.Column computer={4} tablet={8} mobile={16} style={{minWidth:"180px"}}>
                                                            <NoaRadialBarChart data={deviceData} colors={pieChartColors[index]} />
                                                        </Grid.Column>
                                                    ))}
                                                </Grid>
                                            </Grid.Column>
                                        </Grid>
                                    :""}
                                    </NoaContainer>
                                </NoaCard>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Device Resources"} renderDuration={true}>
                            <NoaContainer style={{width:"100%",paddingLeft: "1.5em", paddingRight: "1.5em",paddingTop:"2em",paddingBottom:"2em"}}>
                            <Grid columns={3} stackable>
                                {Object.keys(deviceResources).length > 0 ? 
                                    (
                                    Object.keys(deviceResources).map((value,index) => (
                                        <Grid.Column computer={index == 1 ? 6 : 5} tablet={8} mobile={16}>
                                            <NoaContainer style={{textAlign: "center"}}>
                                                {deviceResources[value].map((item) => (
                                                    <NoaProgressBar data={item} title={null}/>
                                                ))}
                                            </NoaContainer>
                                        </Grid.Column>
                                    )))
                                :""}                                
                            </Grid>
                            </NoaContainer>                           
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                    <Grid columns={2} stackable doubling verticalAlign="middle" relaxed='very'>
                        <Grid.Column computer={8} tablet={16} mobile={16} textAlign='center'>
                            <NoaCard title={"Interface Utilization In"} renderDuration={true} durationComponent={multipleDuration}>
                                <InterfaceUtilizationIn data={portUtilizationIn}/>
                            </NoaCard>
                            
                        </Grid.Column>
                        <Grid.Column computer={8} tablet={16} mobile={16} textAlign='center'>
                            <NoaCard title={"Interface Utilization Out"} renderDuration={true} durationComponent={multipleDuration}>
                                <InterfaceUtilizationIn data={portUtilizationOut}/>
                            </NoaCard>
                        </Grid.Column>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Service Throughput"} renderDuration={true} durationComponent={periodicalDuration}>
                            {serviceThroughput.length > 0 ? 
                                <NoaLineChart data={serviceThroughput} lineType={"linear"} colors={serviceThroughputColors}/>
                            :""}
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Link Latency Deviation"} renderDuration={true} durationComponent={periodicalDuration}>
                            {linkLatency.length > 0 ? 
                                <NoaLineChart data={linkLatency} lineType={"linear"} colors={serviceThroughputColors}/>
                            :""}
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
      </Container>
    )
}

const DeviceDetailCard = (props) => {
    const [data, setData] = useState([]);
    const [color, setColor] = useState(null);
    const [listData, setListData] = useState({});

    useEffect(() => {
        setData(props.data)
    },[props.data]);

    useEffect(() => {
        setColor(props.color)
    },[props.color]);

    useEffect(() => {
        setListData(props.listData)
    },[props.listData]);
    
    return(
        <NoaContainer style={{width: "100%",textAlign: "center"}}>
            <Grid columns={2} relaxed='very' stackable>
                <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='middle' textAlign='left' style={{minWidth:"200px"}}>
                    <NoaRadialBar data={data} color={color}/>
                </Grid.Column>
                <Grid.Column computer={8} tablet={16} mobile={16}>
                    <Grid stackable textAlign='center'>
                        {Object.keys(listData).map((keyValue,index) => (
                            <Grid.Row columns={1} style={{paddingBottom:"0px"}}>
                                <Grid.Column width={16} style={noPadding} textAlign='left'>
                                    <span style={cardKeyItem}>{keyValue}</span><br/>
                                    <span style={cardValueItem}>{listData[keyValue]}</span>
                                </Grid.Column>
                            </Grid.Row>
                        ))}
                    </Grid>
                </Grid.Column>
            </Grid>
        </NoaContainer>
    )
}
const InterfaceUtilizationIn = (props) => {
    const data = props.data;

    const columns = [
		{
			label: "1",
			Header: "Interface ID",
            accessor: "interfaceId"
		},
		{
			label: "2",
			Header: "Interface Type",
            accessor: "interfaceType"
		},
        {
			label: "4",
			Header: "Utilization",
			accessor: "utilization"
		},
        {
			label: "5",
			Header: "Port",
			accessor: "port"
        }
    ]
    const selectedRows = [];

    return (
        <Grid stackable>
            <Grid.Row columns={1}>
            <Grid.Column width={16}>
                <Grid columns={3}>
                    <Grid.Column width={1}></Grid.Column>
                    <Grid.Column width={14}>
                        <NoaTable data={data}
                            columns={columns}
                            selectedRows={selectedRows}
                            onlyTable={true}
                            borderless={true}
                            hidePagination={true}
                        />
                    </Grid.Column>
                    <Grid.Column width={1}></Grid.Column>
                </Grid>
            </Grid.Column>
            </Grid.Row>
        </Grid>
        
    )
}

const multipleDuration = () => {
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>{new Date().toLocaleString()}</p>   
                        </Grid.Column>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const timeInHours = () => {
    
    return(
        <Grid>
            <Grid.Row columns={1} verticalAlign='bottom'>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>5Hour</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const periodicalDuration = () => {
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={10}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>
                                {new Date(Date.now() - ( 3600 *1000 * 1 )).toLocaleString()}-{new Date().toLocaleString()}
                            </p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
const pieChartColors = ["#903749", "#543864","#750550","#21325E"];
const chartColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const serviceThroughputColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}
export default ElementSummary;