import React, { useContext } from 'react';
import { noBorder, noBoxShadow } from '../../constants';
import { MenuContext } from '../../utility/MenuContext';

const ElementDiscovery = () => {
    const menuContext = useContext(MenuContext);
    
    menuContext.setDisplayText("Element Discovery");
    menuContext.setHideMenu(true);

    return(
        <div style={noBorder,noBoxShadow}></div>
    )
}
export default ElementDiscovery