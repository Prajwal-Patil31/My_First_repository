import React, { useEffect, useState,useContext } from 'react';
import NoaTable from '../widget/NoaTable';
import { Link } from "react-router-dom";

import {
    Grid,
    Checkbox,
    Icon,
    Tab,
    Accordion,
    Menu,
    Segment
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, accordionTitle, 
    completeHeight, completeWidth,tablePadding,
    fullHeight, cardLayout, nMenuItem,
    pieValueItem, pieKeyItem
} from '../constants';

import { NoaContainer} from '../widget/NoaWidgets';
import NoaCard from '../widget/NoaCard';
import NoaClient from '../utility/NoaClient';
import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { RouteRediretContext } from '../utility/RouteRedirect';
import { DropdownIcon } from '../widget/NoaIcons';
import NoaPieChart from '../widget/NoaPieChart';

const networkColors = ['#1A374D','#6998AB','#6B637B'];
const serviceColors = ['#543864','#B8AEBE','#903749']
const connectionColors = ['#1A374D','#6998AB','#406882']

const ElementConnectivity = (props) => {
    const [networkOverview, setNetworkOverview] = useState({});
    const [serviceOverview, setServiceOverview] = useState({});
    const [connectionOverview, setConnectionOverview] = useState({});

    const deviceId = sessionStorage.getItem("elementId");
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const mockNetworkStats = {
        "L1 Networks" : 8,
        "L2 Networks" : 67,
        "L3 Networks" : 142
    }

    const mockServiceStats = {
        "VPLS Service" : 94,
        "VPWS Service" : 56,
        "L3VPN Service" : 102
    }
    
    const mockConnections = {
        "Links" : 94,
        "LSPs" : 153,
        "Routes" : 289
    }

    const getNetworksOverview = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/network/overview",
            (response) => {
                let responseData = response.data;
                setNetworkOverview(responseData);
            });
    }
    const getServicesOverview = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/service/overview",
            (response) => {
                let responseData = response.data;
                setServiceOverview(responseData);
            });
    }
    const getConnectionsOverview = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/connection/overview",
            (response) => {
                let responseData = response.data;
                setConnectionOverview(responseData);
            });
    }
    useEffect(() => {
        NoaClient(context, redirectContext);
        getNetworksOverview();
        getServicesOverview();
        getConnectionsOverview();
    },[]);

    const panes = [
        {
            menuItem: <Menu.Item key='networks' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Networks</Menu.Item>,
            render: () => <ElementNetworks deviceId={deviceId}/>
        },
        {
            menuItem: <Menu.Item key='services' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Services</Menu.Item>,
            render: () => <ElementServices deviceId={deviceId}/>
        },
        {
            menuItem: <Menu.Item key='connections' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Connections</Menu.Item>,
            render: () => <ElementConnections deviceId={deviceId}/>
        }
    ]

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={{maxHeight: "100vh"}}>
                <Grid.Column width={16} verticalAlign='top'>
                    <ElementConnectivityOverview mockNetworkStats={networkOverview} mockConnections={connectionOverview} mockServiceStats={serviceOverview}/>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1} style={fullHeight} className="card-spacing">
                <Grid.Column width={16} verticalAlign='top'>
                <Segment style={Object.assign({minHeight:"100vh",maxHeight:"75em",overflowY:"auto"},cardLayout)}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                                <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} />
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Segment>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const ElementConnectivityOverview = (props) => {
    const mockServiceStats = props.mockServiceStats;
    const mockNetworkStats = props.mockNetworkStats;
    const mockConnections = props.mockConnections;

    return(
        <NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1} stretched>
                <Grid.Column width={16}>
                    <Grid columns={3} stackable stretched relaxed='very'>
                        <Grid.Column width='equal'>
                            <NoaCard renderDuration={false}>
                                <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
                                    <SummaryDetailCard data={mockNetworkStats} listData={mockNetworkStats} colors={networkColors} label={"217 Networks"}/>
                                </NoaContainer>
                            </NoaCard>
                        </Grid.Column>
                        <Grid.Column width='equal'>
                            <NoaCard renderDuration={false}>
                                <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
                                    <SummaryDetailCard data={mockServiceStats} listData={mockServiceStats} colors={serviceColors} label={"152 Services"}/>
                                </NoaContainer>
                            </NoaCard>
                        </Grid.Column>
                        <Grid.Column width='equal'>
                            <NoaCard renderDuration={false}>
                                <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
                                    <SummaryDetailCard data={mockConnections} listData={mockConnections} colors={connectionColors} label={"536 Connections"}/>
                                </NoaContainer>
                            </NoaCard>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>            
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const SummaryDetailCard = (props) => {
    const [data, setData] = useState([]);
    const [colors, setColors] = useState([]);
    const [label, setLabel] = useState(null);
    const [listData, setListData] = useState({});

    useEffect(() => {
        setData(props.data)
    },[props.data]);

    useEffect(() => {
        setColors(props.colors)
    },[props.colors]);

    useEffect(() => {
        setLabel(props.label)
    },[props.label]);

    useEffect(() => {
        setListData(props.listData)
    },[props.listData]);

    let pieChartStyle = {
        "innerRadius":50,
        "outerRadius":70
    }
    return(
        <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
            <Grid columns={2} stackable>
                <Grid.Column tablet={12} computer={9} mobile={16} style={{minWidth:"160px"}}>
                    <NoaPieChart data={data} colors={colors} labelValue={label} styles={pieChartStyle}/>
                </Grid.Column>
                
                <Grid.Column tablet={10} computer={7} mobile={16} verticalAlign='top'>
                    <NoaContainer style={{textAlign: "center"}}>
                    <Grid stackable>
                        {Object.keys(listData).map((keyValue,index) => (
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                    <Grid columns={2} stackable verticalAlign='bottom'>
                                        <Grid.Column tablet={16} computer={9} mobile={16} textAlign='left' style={pieKeyItem}>
                                            {keyValue}
                                        </Grid.Column>
                                        <Grid.Column tablet={16} computer={7} mobile={16} textAlign='left' style={Object.assign({color:colors[index]},pieValueItem)}>
                                            {listData[keyValue]}
                                        </Grid.Column>
                                    </Grid>
                                </Grid.Column>
                            </Grid.Row> 
                        ))}
                    </Grid>
                    </NoaContainer>
                </Grid.Column>
            </Grid>
        </NoaContainer>
    )
}

const ElementNetworks = (props) => { 
    const context = useContext(GlobalSpinnerContext);

    const [deviceId, setDeviceId] = useState(null);
    const [networks, setNetworks] = useState([]);
	const [selectedRows, setSelectedRows] = useState({});
    
    useEffect(() => {
        setDeviceId(props.deviceId);
    },[props.deviceId]);
    
    const getNetworks = () => {
        context.setRenderLocation(["element-network-list"]);
        NoaClient.get(
            "/api/element/" + deviceId + "/network",
            (response) => {
                let responseData = response.data;
                setNetworks(responseData);
            }
        )
    }

    useEffect(() => {
        if(deviceId != null) {
            getNetworks();
        }
    },[deviceId]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
            label: "8",
            Header: "Network Name",
            Cell: ({row}) => {
                let networkId = row.original.networkId;
                let networkName = row.original.networkName;
                let networkType = row.original.networkType;

                const toNetworkInstance = { 
                    pathname: `/Networks/${networkName}`,
                }
                return <Link to={toNetworkInstance} onClick={() => {
                    sessionStorage.setItem("networkId",networkId);
                    sessionStorage.setItem("networkName",networkName);
                    sessionStorage.setItem("networkType",networkType);
                }}>{networkName}</Link>
            },
            width:2
        },
		{
			label: "2",
			Header: "Network Type",
            accessor: "networkType",
            width:2
		},
        {
			label: "4",
			Header: "Protocol",
            accessor: "protocol",
            width:2
		},
        {
			label: "5",
			Header: "IP Range",
            accessor: "ipRange",
            width:2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"networkStatus")
            ),
            width:2
        }
    ]

	if (!networks && !networks.length)
		return null;

    return (
        <NoaContainer style={{width: "100%",paddingLeft: "2em", paddingRight: "2em",paddingTop: "1em",paddingBottom: "1em"}}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle' id="element-networks">
                    <NoaTable data={networks}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelectedRows}
                        resource="Networks" 
                        fetchData={getNetworks} 
                        location="element-network-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    );
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const ElementServices = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const [deviceId, setDeviceId] = useState(null);
    const [services, setServices] = useState([]);
	const [selectedRows, setSelectedRows] = useState({});
    
    useEffect(() => {
        setDeviceId(props.deviceId);
    },[props.deviceId]);
    
    const getServices = () => {
        context.setRenderLocation(["element-service-list"]);
        NoaClient.get(
            "/api/element/" + deviceId + "/service",
            (response) => {
                let responseData = response.data;
                setServices(responseData);
            }
        )
    }

    useEffect(() => {
        if(deviceId != null) {
            getServices();
        }
    },[deviceId]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
        {
            label: "8",
            Header: "Service Name",
            Cell: ({row}) => {
                let serviceId = row.original.serviceId;
                let serviceName = row.original.serviceName;
                let serviceType = row.original.serviceType;
                
                const toServiceInstance = { 
                    pathname: `/Services/${serviceName}`,
                }
                return <Link to={toServiceInstance} onClick={() => {
                    sessionStorage.setItem("serviceId",serviceId);
                    sessionStorage.setItem("serviceName",serviceName);
                    sessionStorage.setItem("serviceType",serviceType);
                }}>{serviceName}</Link>
            },
            width:2
        },
        {
            label: "2",
            Header: "Service Type",
            accessor: "serviceType",
            width:2
        },
        {
            label: "4",
            Header: "Subscriber Name",
            accessor: "subscriberName",
            width:2
        },
        {
            label: "5",
            Header: "Service Rate",
            accessor: "serviceRate",
            width:2
        },
        {
            label: "6",
            Header: "End Points",
            accessor: "endPoints",
            width:2
        },
        {
            label: "7",
            Header: "Paths",
            accessor: "paths",
            width:2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"serviceStatus")
            ),
            width:2
        }
    ]  
    return(
        <NoaContainer style={{width: "100%",paddingLeft: "2em", paddingRight: "2em",paddingTop: "1em",paddingBottom: "1em"}}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle'>                    
                    <NoaTable data={services}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelectedRows}
                        resource="Services" 
                        fetchData={getServices} 
                        location="element-service-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const ElementConnections = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const [deviceId, setDeviceId] = useState(null);
    const [links, setLinks] = useState([]);
    const [lsps, setLsps] = useState([]);
    const [routes, setRoutes] = useState([]);

    useEffect(() => {
        setDeviceId(props.deviceId);
    },[props.deviceId]);

    const getRelatedLinks = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/link",
            (response) => {
                let responseData = response.data;
                setLinks(responseData);
            }
        )
    }

    const getRelatedLsps = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/lsp",
            (response) => {
                let responseData = response.data;
                setLsps(responseData);
            }
        )
    }

    const getRelatedRoutes = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/route",
            (response) => {
                let responseData = response.data;
                setRoutes(responseData);
            }
        )
    }

    useEffect(() => {
        if(deviceId != null) {
            context.setRenderLocation(["element-links-list","element-lsps-list","element-routes-list"]);
            getRelatedLinks();
            getRelatedLsps();
            getRelatedRoutes();
        }
    },[deviceId]);

    const [indexesState, setIndexesState] = useState({ activeIndexes: [0] });

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;  
    return(
        <NoaContainer style={{ width: "100%", height: "100%" }}>
            <Grid style={{maxHeight:"56em",overflowY:"auto"}} className="content">
                <Grid.Row columns={1}>
                    <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                        <Accordion>
                            <Accordion.Title
                                active={activeIndex.includes(0)}
                                index={0}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                Links
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(0)}>
                                <LinksTable links={links} getRelatedLinks={getRelatedLinks}/>
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(1)}
                                index={1}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                LSPs
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(1)}>
                                <LspsTable lsps={lsps} getRelatedLsps={getRelatedLsps}/>
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(2)}
                                index={2}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                Routes
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(2)}>
                                <RoutesTable routes={routes} getRelatedRoutes={getRelatedRoutes}/>
                            </Accordion.Content>
                        </Accordion>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const LinksTable = (props) => {
    const links = props.links;
    const getRelatedLinks = props.getRelatedLinks;

    const columns = [
		{
			label: "1",
			Header: "Name",
            accessor: "linkName",
            width:3
		},
		{
			label: "2",
			Header: "Source Element",
            accessor: "sourceNode",
            width:2
		},
        {
			label: "4",
			Header: "Source Interface",
            accessor: "sourceEndpoint",
            width:2
		},
        {
			label: "5",
			Header: "Destination Element",
            accessor: "destinationNode",
            width:2
        },
        {
			label: "6",
			Header: "Destination Interface",
            accessor: "destinationEndpoint",
            width:2
        },
        {
			label: "7",
			Header: "Link Rate",
            accessor: "linkRate",
            width:3
        },
        {
            label: "8",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"linkStatus")
            ),
            width:2
        }
    ]

    const [selectedRows,setSelectedRows] = useState([]);

    return(
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle'>
                    <NoaTable data={links}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelectedRows}
                        resource="Links" 
                        fetchData={getRelatedLinks} 
                        location="element-links-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const LspsTable = (props) => {
    const lsps = props.lsps;
    const getRelatedLsps = props.getRelatedLsps;
    const columns = [
		{
			label: "1",
			Header: "Name",
            accessor: "lspName",
            width:3
		},
		{
			label: "2",
			Header: "Source Element",
            accessor: "sourceElement",
            width:2
		},
        {
			label: "5",
			Header: "Destination Element",
            accessor: "destinationElement",
            width:2
        },
        {
			label: "6",
			Header: "Destination Interface",
            accessor: "destinationInterface",
            width:2
        },
        {
			label: "7",
			Header: "Local Interface",
            accessor: "sourceInterface",
            width:2
        },
        {
			label: "7",
			Header: "Tunnel ID",
            accessor: "tunnelId",
            width:2
        },
        {
            label: "8",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"lspStatus")
            ),
            width:3
        }
    ]

    const [selectedRows,setSelectedRows] = useState([]);

    return(
        <NoaContainer style={{width: "100%",paddingLeft: "2em", paddingRight: "2em",paddingTop: "1em",paddingBottom: "1em"}}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle'>
                    <NoaTable data={lsps}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelectedRows}
                        resource="LSPs" 
                        fetchData={getRelatedLsps} 
                        location="element-lsps-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const RoutesTable = (props) => {
    const routes = props.routes;
    const getRelatedRoutes = props.getRelatedRoutes;
    const columns = [
		{
			label: "1",
			Header: "Name",
            accessor: "routeName",
            width:3
		},
		{
			label: "2",
			Header: "Source Element",
            accessor: "sourceElement",
            width:2
		},
        {
			label: "5",
			Header: "Destination Element",
            accessor: "destinationElement",
            width:2
        },
        {
			label: "5",
			Header: "Local Address",
            accessor: "localAddress",
            width:2
        },
        {
			label: "6",
			Header: "Next Hop Address",
            accessor: "nexthopAddress",
            width:2
        },
        {
			label: "7",
			Header: "Protocol",
            accessor: "protocol",
            width:2
        },
        {
            label: "8",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"routeStatus")
            ),
            width:3
        }
    ]

    const [selectedRows,setSelectedRows] = useState([]);

    return(
        <NoaContainer style={{width: "100%",paddingLeft: "2em", paddingRight: "2em",paddingTop: "1em",paddingBottom: "1em"}}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle' id="element-routes">
                    <NoaTable data={routes}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelectedRows}
                        resource="Routes"
                        fetchData={getRelatedRoutes} 
                        location="element-routes-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

export default ElementConnectivity;