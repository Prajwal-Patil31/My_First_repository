/**@module ElementGeneralConfig */

import React, { useContext, useState,useEffect } from 'react';

import {
    Grid,
    Segment,
    Accordion
} from 'semantic-ui-react';

import { accordionTitle, cardLayout, completeWidth } from '../../constants';
import 'semantic-ui-css/semantic.min.css';

import { NoaContainer } from '../../widget/NoaWidgets';

import LoggingConfig from './system/log/LoggingConfig';
import SecurityConfig from './system/security/SecurityConfig';
import PerformanceConfig from './system/PerformanceConfig';
import ServicesConfig from './system/ServicesConfig';
import SystemConfig from './system/SystemConfig';
import { DropdownIcon } from '../../widget/NoaIcons';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';

const ElementGeneralConfig = (props) => {
    const deviceId = sessionStorage.getItem("elementId"); 
    const context = useContext(GlobalSpinnerContext);

    const [indexesState, setIndexesState] = useState({ activeIndexes: [0] });

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;

    useEffect(() => {
        context.setRenderLocation(["security-config","system-config","logging-config"])
    }, [])
    return (
        <NoaContainer style={Object.assign({minHeight:"100vh"},completeWidth)}>
        <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
            <Grid>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                        <Grid style={{maxHeight:"70em",overflowY:"auto"}} className="content">
                        <Accordion>
                            <Accordion.Title
                                active={activeIndex.includes(0)}
                                index={0}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                System
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(0)}>
                                <SystemConfig deviceId={deviceId}/>
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(1)}
                                index={1}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                Security
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(1)}>
                                <SecurityConfig deviceId={deviceId}/>
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(2)}
                                index={2}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                Services
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(2)}>
                                <ServicesConfig />
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(3)}
                                index={3}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon/>
                                Limits
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(3)}>
                                <PerformanceConfig />
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(4)}
                                index={4}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                Logging
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(4)}>
                                <LoggingConfig deviceId={deviceId}/>
                            </Accordion.Content>
                        </Accordion>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </Segment>
        </NoaContainer>
    )
}

export default ElementGeneralConfig;