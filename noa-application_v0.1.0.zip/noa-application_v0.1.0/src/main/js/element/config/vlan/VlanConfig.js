import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../widget/NoaTable';
import { Link } from 'react-router-dom';

import {
    Grid,
    Button,
    Divider,
    Checkbox,
    Dropdown,
    Step,
    Icon,
    Input,
    Accordion
} from 'semantic-ui-react';

import {
    noMarginTB, noMarginLR, formTitle, 
    noBoxShadow, formParameter,applyButton, 
    cancelButton, completeHeight, completeWidth, 
    tablePadding, tableHeaderHeight,noPadding,
    accordionTitle, dividerStyle, dropdownStyle, 
    inputBoxStyle
} from '../../../constants';

import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';
import NoaFilter from '../../../widget/NoaFilter';
import { NoaHeader, NoaContainer} from '../../../widget/NoaWidgets';
import NoaToolbar from '../../../widget/NoaToolbar';
import { DropdownIcon, PreviousIcon } from '../../../widget/NoaIcons';
import { UIView, useRouter } from '@uirouter/react';
import NoaCard from '../../../widget/NoaCard';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const VlanConfig = (props) => {   
    const deviceId = props.deviceId;
    const bridgeId = props.bridgeId; 
    const closeFooter = props.closeFooter;
    
    const [vlans, setVlans] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const [renderSubComponent, setRenderSubComponent] = useState(false);
    const [subComponentData, setSubComponentData] = useState({});
    
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = vlans[sel[i]].vlanId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const getVlans = () => {
        if(bridgeId != null && bridgeId != undefined) {
            NoaClient.get(
                "/api/element/" + deviceId + "/bridge/" + bridgeId + "/vlan",
                (response) => {
                    let responseData = response.data;
                    setVlans(responseData);
            });
        }
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        context.setRenderLocation(["vlan-list"])
        getVlans();
    },[props.bridgeId]);

    return (
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
        <Grid style={Object.assign({},completeHeight, noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    {renderSubComponent ? 
                        <ModifyVlan data={subComponentData} renderSubComponent={renderSubComponent} 
                                    setRenderSubComponent={setRenderSubComponent} bridgeId={bridgeId} deviceId={deviceId}/> 
                        : 
                        <VlanTable vlans={vlans} getVlans={getVlans}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected}
                                    clearSelected={clearSelected}
                                    setRenderSubComponent={setRenderSubComponent}
                                    setSubComponentData={setSubComponentData}
                                    deviceId={deviceId}
                                    bridgeId={bridgeId}
                        />
                    }
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2} stackable>
                        <Grid.Column width={8} textAlign='right'>

                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const VlanTable = (props) => {
    const router = useRouter();
    const vlans = props.vlans;
    const getVlans = props.getVlans;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const deviceId = props.deviceId;
    const bridgeId = props.bridgeId;

    const setRenderSubComponent = props.setRenderSubComponent;
    const setSubComponentData = props.setSubComponentData;

    const [selections,setSelections] = useState([]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
        {
            label: "1",
            Header: "VLAN Name",
            Cell: ({row}) => {
                let vlanName = row.original.vlanName
                return <Link onClick={() => {
                    setSubComponentData(row.original);
                    setRenderSubComponent(true)
                }}>{vlanName}</Link>
            },
            width:2
        },
		{
			label: "2",
			Header: "VLAN Type",
            accessor: "vlanType",
            width:3
		},
        {
			label: "4",
			Header: "Num of ACs",
            accessor: "acCount",
            width:2
		},
        {
			label: "5",
			Header: "Hybrid Ports",
            accessor: "hybridPorts",
            width:2
        },
        {
			label: "6",
			Header: "Tagged Ports",
            accessor: "taggedPorts",
            width:2
        },
        {
			label: "7",
			Header: "Untagged Ports",
            accessor: "untaggedPorts",
            width:2
        },
        {
            label: "8",
            Header: "Vlan Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:2
        }
    ]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    const handleAddVlan = () => {
        router.stateService.go(".addvlan",{fetchData: getVlans,bridgeId:bridgeId,deviceId:deviceId,clearSelection: clearSelection})
    }

    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        NoaClient.delete(
			"/api/element/" + deviceId + "/bridge/" + bridgeId + "/vlan",
			selectedItems,
			(response) => {
                getVlans();
                setClearSelected(true);
        });
    }
        
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                invokeAdd={handleAddVlan}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={vlans}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        resource="VLANs" 
                        fetchData={getVlans} 
                        location="vlan-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView name="addvlan"/>
                </Grid.Column>
            </Grid.Row>          
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.vlanStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddVlan = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const fetchData = props.fetchData;
    const clearSelection = props.clearSelection;
    const deviceId = props.deviceId;
    const bridgeId = props.bridgeId;

    const [step, setStep] = React.useState(0);
    const [vlan, setVlan] = useState({});
    const [interfaces, setInterfaces] = useState([]);
    const [selectedInterfaces, setSelectedInterfaces] = useState({"tagged": [],"untagged" :[],"hybrid" :[]});

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 2 ? 2 : nextStep);
    };

    const closeFooter = () => {
        router.stateService.go('view-bridge-instance',{id: bridgeId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
    }

    useEffect(() => {
        switch (step) {
            case 0:
                setVlan({});
                break;
            case 1:
                context.setRenderLocation(["get-interfaces"]);
                getInterfaces();
                break;
            case 2:
                context.setRenderLocation(["add-vlan"]);
                handleAdd();
                break;
            default:
                break;
        }
    }, [step]);

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);
    
    const getInterfaces = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceId, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setInterfaces(interfacesList);
            }
        )
    }

    const handleAdd = () => {
        NoaClient.put(
			"/api/element/" + deviceId + "/bridge/" + bridgeId + "/vlan",
			vlan,
			(response) => {
                let responseData = response.data;
                addVlanInterfaces(responseData.vlanId,selectedInterfaces);
                fetchData();
                closeFooter()
                
        });
    }

    const addVlanInterfaces = (vlanId,interfaceIds) => {
        NoaClient.post(
			"/api/element/" + deviceId + "/bridge/" + bridgeId + "/vlan/" + vlanId + "/interface",
			interfaceIds,
			(response) => {
                
        });
    }

    const handleInput = (value, key) => {
		setVlan(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const vlanTypes = [
        { 'key': "l3ipvlan", 'text': "L3 Ip Vlan", 'value': "l3ipvlan" }
    ]

    const handlePortSelection = (portType, value) => {
        let interfaceObj = selectedInterfaces;
        interfaceObj[portType] = value;
        setSelectedInterfaces(interfaceObj)
    }

    useEffect(() => {
        context.setRenderLocation(["add-vlan"]);
    },[]);

    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create VLAN</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}}>
                        <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Step.Group style={{border: "0px"}} fluid>
                                    <Step style={{border: "0px"}} active={step == 0 ? true : false} completed={step > 0 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>VLAN Details</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 1 ? true : false} completed={step > 1 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>VLAN Interfaces</Step.Title>
                                        </Step.Content>
                                    </Step>
                                </Step.Group>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1} style={{paddingTop: "2.5em"}} verticalAlign='middle'>
                            <Grid.Column width={16} style={{paddingLeft: "2em", paddingRight: "2em"}} verticalAlign='middle' id="add-vlan">
                                <Grid columns={3} stackable>
                                <Grid.Column width={2}></Grid.Column>
                                <Grid.Column width={12}>
                                    {step === 0 ? (
                                    <NoaContainer style={{minHeight: "34.375em"}}>
                                        <Grid columns={3} stackable verticalAlign='middle'>
                                        <Grid.Column computer={7} tablet={16} mobile={16} verticalAlign='middle'>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={2} stackable>
                                                            <Grid.Column width={8}>
                                                                <p style={formParameter}>VLAN Name</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={8} >
                                                                <Input type='text' name='vlanName' 
                                                                    value={vlan.vlanName}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleInput(value==='' ? null : value, 'vlanName')
                                                                    }>
                                                                        <input style={inputBoxStyle}></input>
                                                                </Input>
                                                            </Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={2} stackable>
                                                            <Grid.Column width={8}>
                                                                <p style={formParameter}>VLAN Type</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={8} >
                                                                <Dropdown clearable selection fluid required
                                                                        placeholder="VLAN Type"
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        value={vlan.vlanType ? vlan.vlanType : ''}
                                                                        options={vlanTypes}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'vlanType')
                                                                        }
                                                                />
                                                            </Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={2} stackable>
                                                            <Grid.Column width={8}>
                                                                <p style={formParameter}>VLAN Status</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={8} >
                                                                <Checkbox
                                                                    toggle={true}
                                                                    value={vlan.vlanStatus}
                                                                    onChange={
                                                                        (e,data)=>handleInput(data.checked, 'vlanStatus')
                                                                    }
                                                                />
                                                            </Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                        <Grid.Column computer={2} tablet={16} mobile={16} verticalAlign='middle'></Grid.Column>
                                        <Grid.Column computer={7} tablet={16} mobile={16} verticalAlign='middle'>
                                            <Grid>
                                                
                                            </Grid>
                                        </Grid.Column>
                                    </Grid>
                                    </NoaContainer>
                                    ) : 
                                    step === 1 ? (
                                    <NoaContainer style={{minHeight: "34.375em"}}>
                                    <Grid verticalAlign='middle'>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={3} stackable>
                                                    <Grid.Column width={1}></Grid.Column>
                                                    <Grid.Column width={14}>
                                                        <Grid columns={3} stackable>
                                                            <Grid.Column computer={7} tablet={16} mobile={16}>
                                                                <Grid>
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                        <Grid columns={2} stackable>
                                                                            <Grid.Column width={8} textAlign='left'>
                                                                                <p style={formParameter}>Tagged Ports</p>
                                                                            </Grid.Column>
                                                                            <Grid.Column width={8} textAlign='left'>
                                                                                <Dropdown clearable selection required multiple
                                                                                        placeholder="Select Ports"
                                                                                        selectOnBlur={false}
                                                                                        options={interfaces}
                                                                                        style={dropdownStyle}
                                                                                        onChange={
                                                                                            (e, {value}) => handlePortSelection("tagged",value)
                                                                                        }
                                                                                />
                                                                            </Grid.Column>
                                                                        </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>

                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                        <Grid columns={2} stackable>
                                                                            <Grid.Column width={8} textAlign='left'>
                                                                                <p style={formParameter}>Untagged Ports</p>
                                                                            </Grid.Column>
                                                                            <Grid.Column width={8} textAlign='left'>
                                                                                <Dropdown clearable selection required multiple
                                                                                        placeholder="Select Ports"
                                                                                        selectOnBlur={false}
                                                                                        options={interfaces}
                                                                                        style={dropdownStyle}
                                                                                        onChange={
                                                                                            (e, {value}) => handlePortSelection("untagged",value)
                                                                                        }
                                                                                />
                                                                            </Grid.Column>
                                                                        </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>

                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                        <Grid columns={2} stackable>
                                                                            <Grid.Column width={8} textAlign='left'>
                                                                                <p style={formParameter}>Hybrid Ports</p>
                                                                            </Grid.Column>
                                                                            <Grid.Column width={8} textAlign='left'>
                                                                                <Dropdown clearable selection required multiple
                                                                                        placeholder="Select Ports"
                                                                                        selectOnBlur={false}
                                                                                        style={dropdownStyle}
                                                                                        options={interfaces}
                                                                                        onChange={
                                                                                            (e, {value}) => handlePortSelection("hybrid",value)
                                                                                        }
                                                                                />
                                                                            </Grid.Column>
                                                                        </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                </Grid>
                                                            </Grid.Column>
                                                            <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                                            <Grid.Column computer={7} tablet={16} mobile={16}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                    <Grid.Column width={1}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </NoaContainer>
                                    ) 
                                    : ""}
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={4}></Grid.Column>
                                    <Grid.Column width={4} textAlign='right'>
                                        <Button style={cancelButton} onClick={onPrevious} disabled={step === 0}>
                                            Previous
                                        </Button>
                                    </Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <Button style={applyButton} onClick={onNext} >
                                            {step === 1 ? 'Save' : 'Next'}
                                        </Button>
                                        <Button style={cancelButton} onClick={closeFooter} >
                                            Cancel
                                        </Button>
                                    </Grid.Column>
                                    <Grid.Column width={4}></Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
const ModifyVlan = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const setRenderSubComponent = props.setRenderSubComponent;
    const renderSubComponent = props.renderSubComponent;
    const data = props.data;
    const bridgeId = props.bridgeId;
    const deviceId = props.deviceId;

    const handlePrevious = (e) => {
        setRenderSubComponent(!renderSubComponent)
        e.stopPropagation();
    }
    useEffect(() => {
        context.setRenderLocation(["modify-vlan"]);
    },[]);

    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                    <Grid.Column width={5}textAlign='left'>
                        <PreviousIcon invokeMethod={handlePrevious}/>                        
                    </Grid.Column>
                    <Grid.Column width={12} textAlign='right'>
                       
                    </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} id="modify-vlan">
                    <UpdateVlan data={data} bridgeId={bridgeId} deviceId={deviceId}/>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const UpdateVlan = (props) => {
    const data = props.data;
    const bridgeId = props.bridgeId;
    const vlanId = data.vlanId;
    const deviceId = props.deviceId;

    const [indexesState, setIndexesState] = useState({ activeIndexes: [0] });

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;

    return(
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
            <Accordion>
                <Accordion.Title
                    active={activeIndex.includes(0)}
                    index={0}
                    onClick={handleClick}
                    style={Object.assign({textAlign:'left'},accordionTitle)}
                >
                    <DropdownIcon />
                    VLAN Parameters
                </Accordion.Title>
                <Accordion.Content active={activeIndex.includes(0)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                        <Grid columns={3} stackable>
                            <Grid.Column width={1}></Grid.Column>
                            <Grid.Column width={14}>
                                <Grid columns={3} stackable>

                                    <Grid.Column computer={7} mobile={16} tablet={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>VLAN Name</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input value={data.vlanName} name='vlanName'>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>VLAN Type</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input value={data.vlanType} name='vlanType'>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>VLAN Status</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Checkbox toggle checked={data.vlanStatus}/>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                    </Grid.Column>

                                    <Grid.Column computer={2} mobile={16} tablet={16}></Grid.Column>
                                    <Grid.Column computer={7} mobile={16} tablet={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Hybrid Ports</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input value={data.hybridPorts} name='hybridPorts'>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Tagged Ports</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input value={data.taggedPorts} name='taggedPorts'>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Untagged Ports</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input value={data.untaggedPorts} name='untaggedPorts'>
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                    </Grid.Column>

                                </Grid>
                            </Grid.Column>
                            <Grid.Column width={1}></Grid.Column>
                        </Grid>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Accordion.Content>
                <Accordion.Title
                    active={activeIndex.includes(1)}
                    index={1}
                    onClick={handleClick}
                    style={Object.assign({textAlign:'left'},accordionTitle)}
                >
                    <DropdownIcon />
                    Ports List
                </Accordion.Title>
                <Accordion.Content active={activeIndex.includes(1)}>
                    <VlanInterfaces vlanId={vlanId} bridgeId={bridgeId} deviceId={deviceId}/>
                </Accordion.Content>
                
            </Accordion>
        </NoaContainer>
    )
}

const VlanInterfaces = (props) => {
    const vlanId = props.vlanId;
    const bridgeId = props.bridgeId;
    const deviceId = props.deviceId;

    const [vlanInterfaces, setVlanInterfaces] = useState({});

    const getVlanInterfaces = () => {
        NoaClient.get(
        "/api/element/" + deviceId + "/bridge/" + bridgeId + "/vlan/" + vlanId + "/interface",
        (response) => {
            let responseData = response.data;
            setVlanInterfaces(responseData);
        });
    }

    useEffect(() => {
        getVlanInterfaces();
    },[]);

    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={3} stackable>
                        {Object.keys(vlanInterfaces).map((item,index) => (
                            <Grid.Column width='equal'>
                                <NoaCard title={item} renderDuration={false}>
                                <Grid style={{paddingLeft:"2em",paddingRight:"2em"}}>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={3} stackable>
                                            {vlanInterfaces[item].map((vlanInterface) => (
                                                <Grid.Column width='equal' textAlign='left'>
                                                    <li style={formParameter}>
                                                    {vlanInterface.interfaceName}
                                                    </li>
                                                </Grid.Column>
                                            ))}
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </NoaCard>
                            </Grid.Column>
                        ))}
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
export default VlanConfig;
export {AddVlan,ModifyVlan}