import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Button,
    Checkbox,
    Icon,
    Input,
    Tab,
    Menu,
    Label
} from 'semantic-ui-react';

import { 
    tableHeaderHeight, noMarginTB, noMarginLR,
    formParameter, applyButton, cancelButton, 
    completeHeight, completeWidth, tablePadding,
    fullHeight, noPadding, nMenuItem, 
    inputBoxStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';

import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import { NoaContainer} from '../../../../widget/NoaWidgets';
import NoaLineChart from '../../../../widget/NoaLineChart';
import NoaFilter from '../../../../widget/NoaFilter';
import { UIView, useRouter } from '@uirouter/react';

const PhysicalInterfaceConfig = (props) => {
    const deviceId = props.deviceId; 

    const [ietfInterfaces, setIetfInterfaces] = useState([]);
    
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});
    
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = ietfInterfaces[sel[i]].interfaceId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getInterfaces = (filterObj) => {
        context.setRenderLocation(['physical-interface-list'])
        NoaClient.post(
            "/api/element/" + deviceId + "/interface",
            filterObj,
            (response) => {
                let responseData = response.data;
                setIetfInterfaces(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/interface/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                

                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                    
                }
                
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device": {"device-id":[deviceId],"ietf-interface":{}}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getInterfaces(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <InterfaceTable ietfInterfaces={ietfInterfaces} getInterfaces={getInterfaces}
                                        selectedRows={selectedRows}
                                        setClearSelected={setClearSelected}
                                        setSelected={setSelected} 
                                        clearSelected={clearSelected}
                                        deviceId={deviceId}
                                        columns={columns}
                                        filters={filters}
                                        pageSize={pageSize}
                                        totalPages={totalPages}
                                        setPageSize={setPageSize}
                                        totalEntries={totalEntries}
                        />
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const InterfaceTable = (props) => {
    const router = useRouter();

    const ietfInterfaces = props.ietfInterfaces;
    const getInterfaces = props.getInterfaces;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const setClearSelected = props.setClearSelected
    const deviceId = props.deviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"ietf-interface" :{}}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Interface Name",
            accessor: "interfaceName",
            width:2
		},
        {
			label: "4",
			Header: "Interface Type",
            accessor: "interfaceType",
            width:3
		},
        {
			label: "5",
			Header: "Layer",
            accessor: "layer",
            width:2
        },
        {
			label: "6",
			Header: "Address",
            accessor: "ipAddress",
            width:3
        },
        {
			label: "7",
			Header: "Speed",
            accessor: "speed",
            width:2
        },
        {
            label: "8",
            Header: "Admin Status",
            Cell: ({row}) => (
                renderBoolean(row,"adminStatus",false)
            ),
            width:2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"enabled",true)
            ),
            width:2
        }
    ]
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('view-physical-interface',{id: ietfInterfaces[selId].interfaceId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getInterfaces(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"ietf-interface" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getInterfaces(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getInterfaces(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                                               
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={ietfInterfaces}
                                columns={columns}
                                selectedRows={selections}
                                onSelectedRowsChange={setSelections}
                                clearSelected={clearSelected}
                                setClearSelected={setClearSelected}
                                selectedPageSize={pageSize}
                                handlePagination={handlePagination}
                                totalPages={totalPages}
                                handlePageSize={handlePageSize}
                                totalEntries={totalEntries}
                                resource="Physical Interfaces" 
                                fetchData={fetchData} 
                                location="physical-interface-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row,key,operational) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            operational ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' /> : 
            <Label basic color={'green'}>
                Enabled
            </Label>
            : 
            operational ?
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' /> :
            <Label basic color={'red'}>
                Disabled
            </Label>
        }
       </>
    )
}

const InterfaceManagement = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const clearSelection = props.clearSelection;
    const getInterfaces = props.fetchData;

    const [ietfInterface, setIetfInterface] = useState({});
    const [deviceId, setDeviceId] = useState(null);

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        const interfaceId = props.id;
        setDeviceId(props.deviceId);
        context.setRenderLocation(['view-physical-interface']);
        if(interfaceId != null && interfaceId != undefined && props.deviceId != null) {
            getInterface(props.deviceId,interfaceId);
        }
    },[props.id]);

    const getInterface = (deviceId,interfaceId) => {
        NoaClient.get(
            "/api/element/" + deviceId + "/interface/" + interfaceId,
            (response) => {
                let responseData = response.data;
                setIetfInterface(responseData);
            }
        )
    }

    const panes = [
        {
            menuItem:   <Menu.Item key='interfaceconfig' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Advance Config
                        </Menu.Item>,
            render: () => <InterfaceConfiguration data={ietfInterface} closeFooter={closeFooter} getInterfaces={getInterfaces} deviceId={deviceId}/>
        },
        {
            menuItem:   <Menu.Item key='interfacestats' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Statistics
                        </Menu.Item>,
            render: () => <InterfaceStatistics closeFooter={closeFooter}/>
        }
    ]
    return(
        <NoaContainer style={completeWidth}>
            <Tab panes={panes} menu={{secondary: true, pointing: true,stackable: true}}/>
        </NoaContainer>
    )
}

const InterfaceStatistics = (props) => {
    const closeFooter = props.closeFooter;
    return(
        <NoaContainer style={Object.assign({minHeight:"60vh"},completeWidth)}>
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <NoaLineChart data={serviceThroughputValues} lineType={"linear"} colors={serviceThroughputColors}/>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const InterfaceConfiguration = (props) => {
    const closeFooter = props.closeFooter;
    const getInterfaces = props.getInterfaces;
    const deviceId = props.deviceId;

    const [ietfInterface, setIetfInterface] = useState({});

    useEffect(() => {
        setIetfInterface(props.data);
    },[props.data]);

    const handleModify = () => {
        const id = ietfInterface.interfaceId;
        NoaClient.post(
			"/api/element/" + deviceId + "/interface/" + id,
			ietfInterface,
			(response) => {
                getInterfaces();
                closeFooter();
			})
    }

    const handleChange = (e, d) => {
        const target = e.target;
        const value = target.value==='' ? null : target.value;
        const name = target.name;

        setIetfInterface(prevState => ({
            ...prevState,
            [name]:value
        }));
    }
    return(
        <NoaContainer style={Object.assign({minHeight:"60vh"},completeWidth)}>
        <Grid>
            <Grid.Row columns={1} style={Object.assign({marginTop:"4em",marginBottom:"3em"})}>
                <Grid.Column width={16} id="view-physical-interface">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Interface Id</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='interfaceId' 
                                                            value={ietfInterface.interfaceId}
                                                            fluid={false}
                                                            onChange={
                                                                (event, data) => handleChange(event, data)
                                                            }>
                                                                <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Interface Name</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='interfaceName' 
                                                            value={ietfInterface.interfaceName}
                                                            fluid={false}
                                                            onChange={
                                                                (event, data) => handleChange(event, data)
                                                            }>
                                                                <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Interface Type</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='interfaceType' 
                                                            value={ietfInterface.interfaceType}
                                                            fluid={false}
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>IP Address</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='ipAddress' 
                                                            value={ietfInterface.ipAddress}
                                                            fluid={false}>
                                                                <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Layer</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='layer' 
                                                            value={ietfInterface.layer}
                                                            fluid={false}
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Speed</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='speed' 
                                                            value={ietfInterface.speed}
                                                            fluid={false}>
                                                                <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Interface Status</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        {ietfInterface.enabled == true ? 
                                                        <Icon color={"green"} size='big' name='arrow alternate circle up outline' />
                                                        : 
                                                        <Icon color={"red"} size='big' name='arrow alternate circle down outline' />
                                                        }
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Admin State</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        {ietfInterface.adminStatus == "up" ? 
                                                        <Icon color={"green"} size='big' name='arrow alternate circle up outline' />
                                                        : 
                                                        <Icon color={"red"} size='big' name='arrow alternate circle down outline' />
                                                        }
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={handleModify}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const serviceThroughputColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}

const serviceThroughputValues = [
    {
        "DEL-PE-480": 2400,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 600,
        "BOM-CE-001": 1600,
        "VJA-P-980": 900,
    },
    {
        "DEL-PE-480": 1800,
        "BOM-CE-165": 1600,
        "DEL-PE-560": 200,
        "BOM-CE-001": 6800,
        "VJA-P-980": 2500,
    },
    {
        "DEL-PE-480": 5600,
        "BOM-CE-165": 5400,
        "DEL-PE-560": 200,
        "BOM-CE-001": 200,
        "VJA-P-980": 2400,
    },
    {
        "DEL-PE-480": 1526,
        "BOM-CE-165": 1426,
        "DEL-PE-560": 100,
        "BOM-CE-001": 3200,
        "VJA-P-980": 3000,
    },
    {
        "DEL-PE-480": 3600,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 1800,
        "BOM-CE-001": 400,
        "VJA-P-980": 500,
    },
    {
        "DEL-PE-480": 3200,
        "BOM-CE-165": 1000,
        "DEL-PE-560": 1200,
        "BOM-CE-001": 800,
        "VJA-P-980": 1700,
    },
    {
        "DEL-PE-480": 3300,
        "BOM-CE-165": 2600,
        "DEL-PE-560": 700,
        "BOM-CE-001": 750,
        "VJA-P-980": 1800,
    },
]

export default PhysicalInterfaceConfig;
export {InterfaceManagement}