import React from 'react';
import {
    Grid,
    Segment,
    Tab,
    Menu
} from 'semantic-ui-react';
import { cardLayout, completeWidth, fullHeight, nMenuItem } from '../../../../constants';
import { NoaContainer } from '../../../../widget/NoaWidgets';

import LogicalInterfaceConfig from './LogicalInterfaceConfig';
import PhysicalInterfaceConfig from './PhysicalInterfaceConfig';

const PortConfig = (props) => {
    const deviceId = sessionStorage.getItem("elementId"); 

    const panes = [
        {
            menuItem:   <Menu.Item key='physical-interface' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Physical Ports
                        </Menu.Item>,
            render: () => <PhysicalInterfaceConfig deviceId={deviceId}/>
        },
        {
            menuItem:   <Menu.Item key='logical-interface' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Logical Interfaces
                        </Menu.Item>,
            render: () => <LogicalInterfaceConfig deviceId={deviceId}/>
        },
    ]

    return(
        <NoaContainer style={Object.assign({display: "flex",flexDirection: "column"},fullHeight,completeWidth)}>
            <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                            <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} />
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Segment>
        </NoaContainer>
    )
}
export default PortConfig;