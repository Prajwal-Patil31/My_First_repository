import React from 'react';

const LogicalInterfaceConfig = (props) => {
    return(
        <div>

        </div>
    )
}
export default LogicalInterfaceConfig;