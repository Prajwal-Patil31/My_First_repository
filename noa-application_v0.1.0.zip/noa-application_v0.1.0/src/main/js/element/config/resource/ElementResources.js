import React from 'react';

const ElementResources = (props) => {
    return(
        <div></div>
    )
}
export default ElementResources;