import React from 'react';

const RootBridgeConfig = (props) => {
    return(
        <div>

        </div>
    )
}
export default RootBridgeConfig;