import React from 'react';

import {
    Grid,
    Segment,
    Tab,
    Menu
} from 'semantic-ui-react';

import { cardLayout, completeWidth, fullHeight, nMenuItem } from '../../../constants';

import RootBridgeConfig from './RootBridgeConfig';
import BridgeInstanceManager from './BridgeInstanceManager';
import { NoaContainer } from '../../../widget/NoaWidgets';

const BridgeConfig = (props) => {
    const deviceId = sessionStorage.getItem("elementId"); 

    const panes = [
        {
            menuItem: <Menu.Item key='bridge-instance' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Bridge Instances</Menu.Item>,
            render: () => <BridgeInstanceManager deviceId={deviceId}/>
        },
        {
            menuItem: <Menu.Item key='root-bridge' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Root Bridge</Menu.Item>,
            render: () => <RootBridgeConfig deviceId={deviceId}/>
        },
    ]

    return(
        <NoaContainer style={Object.assign({display: "flex",flexDirection: "column"},fullHeight,completeWidth)}>
            <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                            <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} />
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Segment>
        </NoaContainer>
    )
}

export default BridgeConfig;