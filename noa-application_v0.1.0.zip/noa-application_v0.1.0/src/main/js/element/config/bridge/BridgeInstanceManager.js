import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../widget/NoaTable';

import {
    Grid,
    Button,
    Checkbox,
    Input,
    Tab,
    Menu,
    Icon,
    Step,
    Divider,
    Dropdown,
    Label
} from 'semantic-ui-react';

import { 
    noBoxShadow,noPadding, noMarginTB, 
    noMarginLR, formParameter, applyButton, 
    cancelButton, completeHeight, completeWidth,
    tableHeaderHeight, formTitle, tablePadding,
    fullHeight, dividerStyle, formContentSpacingTB,
    formSpacingTB, inputBoxStyle, nMenuItem,
    dropdownStyle
} from '../../../constants';

import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';
import NoaFilter from '../../../widget/NoaFilter';
import { NoaContainer, NoaHeader} from '../../../widget/NoaWidgets';

import NoaLineChart from '../../../widget/NoaLineChart';
import VlanConfig from '../vlan/VlanConfig';
import NoaToolbar from '../../../widget/NoaToolbar';

import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../widget/NoaNotification';

const BridgeInstanceManager = (props) => {
    const deviceId = props.deviceId; 

    const [bridges, setBridges] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = bridges[sel[i]].bridgeId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getBridges = (filterObj) => {
        context.setRenderLocation(["bridge-instances-list"]);
        if(deviceId != null && deviceId != undefined) {
            NoaClient.post(
                "/api/element/" + deviceId + "/bridge",
                filterObj,
                (response) => {
                    let responseData = response.data;
                    setBridges(responseData.data);
                    setTotalPages(responseData.page.maxPages);
                    setTotalEntries(responseData.page.totalEntries);
                }
            )
        }
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/bridge/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device" : {"device-id":[deviceId],"bridge-instance" :{}}}
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getBridges(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <BridgeInstanceTable bridges={bridges} getBridges={getBridges}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected} 
                                    clearSelected={clearSelected}
                                    deviceId={deviceId}
                                    columns={columns}
                                    filters={filters}
                                    pageSize={pageSize}
                                    totalPages={totalPages}
                                    setPageSize={setPageSize}
                                    totalEntries={totalEntries}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const BridgeInstanceTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);

    const bridges = props.bridges;
    const getBridges = props.getBridges;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const deviceId = props.deviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"bridge-instance" :{}}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Name",
            accessor: "bridgeName",
            width:2
		},
        {
            label: "2",
            Header: "GVRP Status",
            Cell: ({row}) => (
                renderBoolean(row,"gvrpStatus",false)
            ),
            width:2
        },
        {
            label: "3",
            Header: "GMRP Status",
            Cell: ({row}) => (
                renderBoolean(row,"gmrpStatus",false)
            ),
            width:2
        },
        {
			label: "5",
			Header: "Traffic Class",
            accessor: "trafficClass",
            width:2
        },
        
        {
			label: "7",
			Header: "Max VLANs",
            accessor: "maxSupportedVlans",
            width:2
        },
        {
			label: "8",
			Header: "VLAN Count",
            accessor: "numOfVlans",
            width:2
        },
        {
			label: "9",
			Header: "Active VLANs",
            accessor: "activeVlans",
            width:2
        },
        {
            label: "3",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"bridgeState",true)
            ),
            width:1
        },
    ]

    const handleAddBridge = () => {
        router.stateService.go("add-bridge-instance",{deviceId:deviceId,fetchData:fetchData, clearSelection: clearSelection})
    }
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('view-bridge-instance',{id: bridges[selId].bridgeId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["bridge-instances-list"]);
        NoaClient.delete(
            "/api/element/" + deviceId + "/bridge",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null})
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getBridges(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"bridge-instance" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getBridges(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getBridges(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddBridge}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={bridges}
                            columns={columns}
                            selectedRows={selections}
                            onSelectedRowsChange={setSelections}
                            clearSelected={clearSelected}
                            setClearSelected={setClearSelected}
                            selectedPageSize={pageSize}
                            handlePagination={handlePagination}
                            totalPages={totalPages}
                            handlePageSize={handlePageSize}
                            totalEntries={totalEntries}
                            resource="Bridge Instances" 
                            fetchData={fetchData} 
                            location="bridge-instances-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row,key,operational) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            operational ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' /> : 
            <Label basic color={'green'}>
                Enabled
            </Label>
            : 
            operational ?
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' /> :
            <Label basic color={'red'}>
                Disabled
            </Label>
        }
       </>
    )
}

const AddBridgeInstance = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    
    const getBridges = props.fetchData;
    const clearSelection = props.clearSelection;
        
    const [step, setStep] = React.useState(0);
    const [deviceId, setDeviceId] = useState(null);
    const [bridge, setBridge] = useState({});
    const [interfaces, setInterfaces] = useState([]);
    const [selectedInterfaces, setSelectedInterfaces] = useState([]);

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 2 ? 2 : nextStep);
    };

    useEffect(() =>{
        setDeviceId(props.deviceId);
    },[props.deviceId]);

    const closeFooter = () => {
        router.stateService.go('default');
    }

    useEffect(() => {
        switch (step) {
            case 0:
                setBridge({});
                break;
            case 1:
                context.setRenderLocation(["get-interfaces"])
                getInterfaces();
                break;
            case 2:
                context.setRenderLocation(["add-bridge"])
                handleAdd();
                break;
            default:
                break;
        }
    }, [step]);

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);
    
    const getInterfaces = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceId, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setInterfaces(interfacesList);
            }
        )
    }

    const handleAdd = () => {
        NoaClient.put(
			"/api/element/" + deviceId + "/bridge",
			bridge,
			(response) => {
                let responseData = response.data;
                if(selectedInterfaces.length > 0) {
                    addBridgePorts(responseData.bridgeId,selectedInterfaces);
                }                
                noaNotification('success','Bridge Instance Created Successfully.');
                getBridges();
                closeFooter();
                
        });
    }

    const addBridgePorts = (bridgeId,bridgePorts) => {
        NoaClient.post(
			"/api/element/" + deviceId + "/bridge/" + bridgeId + "/port",
			bridgePorts,
			(response) => {
                noaNotification('success','Ports added to Bridge Instance Successfully.');
        });
    }

    const handleInput = (value, key) => {
		setBridge(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const trafficClassTypes = [
        {"key" : "forward-all", "text" : "Forward All","value" : "forward-all"},
        {"key" : "forward-tagged-only", "text" : "Forward Tagged Only","value" : "forward-tagged-only"},
        {"key" : "forward-untagged-only", "text" : "Forward UnTagged Only","value" : "forward-untagged-only"},
    ]

    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create Bridge</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Step.Group style={{border: "0px"}} fluid>
                                    <Step style={{border: "0px"}} active={step == 0 ? true : false} completed={step > 0 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Bridge Details</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 1 ? true : false} completed={step > 1 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Bridge Ports</Step.Title>
                                        </Step.Content>
                                    </Step>
                                </Step.Group>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1} style={Object.assign({minHeight:"300px"},formContentSpacingTB)}>
                            <Grid.Column width={16} id="add-bridge">
                                <Grid columns={3} stackable>
                                <Grid.Column width={2}></Grid.Column>
                                <Grid.Column width={12} style={noPadding}>
                                <Grid>
                                    <Grid.Row columns={1} style={formSpacingTB}>
                                        <Grid.Column width={16}>
                                        {step === 0 ? (
                                        <NoaContainer style={completeWidth}>
                                            <Grid columns={2} stackable stretched>
                                            <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='top'>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter} className="required">Bridge Identifier</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Input type='text' name='bridgeName' 
                                                                        value={bridge.bridgeName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'bridgeName')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>GVRP Status</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Checkbox
                                                                        toggle={true}
                                                                        value={bridge.gvrpStatus}
                                                                        onChange={
                                                                            (e,data)=>handleInput(data.checked, 'gvrpStatus')
                                                                        }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>GMRP Status</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Checkbox
                                                                        toggle={true}
                                                                        value={bridge.gmrpStatus}
                                                                        onChange={
                                                                            (e,data)=>handleInput(data.checked, 'gmrpStatus')
                                                                        }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>Traffic Class</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Dropdown clearable selection
                                                                                selectOnBlur={false}
                                                                                style={dropdownStyle}
                                                                                placeholder="Traffic Class Type"
                                                                                options={trafficClassTypes}
                                                                                value={bridge.trafficClass}
                                                                                onChange={
                                                                                    (e, {value}) => handleInput(value==='' ? null : value, 'trafficClass')
                                                                                }
                                                                        />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                            </Grid.Column>
                                            <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='top'>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>Max VLAN Id</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Input type='number' name='maxVlanId' 
                                                                        value={bridge.maxVlanId}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'maxVlanId')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>Max VLANs</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Input type='text' name='maxSupportedVlans' 
                                                                        value={bridge.maxSupportedVlans}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'maxSupportedVlans')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>Bridge State</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Checkbox
                                                                        toggle={true}
                                                                        value={bridge.bridgeState}
                                                                        onChange={
                                                                            (e,data)=>handleInput(data.checked, 'bridgeState')
                                                                        }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid>
                                        </NoaContainer>
                                        ) : 
                                        step === 1 ? (
                                        <NoaContainer style={completeWidth}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16} id="get-interfaces">
                                                <Grid columns={3} stackable>
                                                    <Grid.Column width={6}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                            <Grid>
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid columns={2} stackable>
                                                                        <Grid.Column width={8}>
                                                                            <p style={formParameter}>Bridge Ports</p>
                                                                        </Grid.Column>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <Dropdown clearable selection required multiple
                                                                                    selectOnBlur={false}
                                                                                    placeholder="Select Ports"
                                                                                    options={interfaces}
                                                                                    value={selectedInterfaces}
                                                                                    style={dropdownStyle}
                                                                                    onChange={
                                                                                        (e, {value}) => setSelectedInterfaces(value)
                                                                                    }
                                                                            />
                                                                        </Grid.Column>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                            </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                    </Grid>
                                                    </Grid.Column>
                                                    <Grid.Column width={5}>
                                                    </Grid.Column>
                                                    <Grid.Column width={5}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </NoaContainer>
                                        ) 
                                        : ""}
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={3}>
                                    <Grid.Column width={5}></Grid.Column>
                                    <Grid.Column width={6}>
                                        <Grid columns={3}>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={onPrevious} disabled={step === 0}>
                                                    Previous
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={applyButton} onClick={onNext} >
                                                    {step === 1 ? 'Add' : 'Next'}
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                            </Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                    <Grid.Column width={5}>
                                   
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const BridgeManagement = (props) => {
    const router = useRouter();

    const clearSelection = props.clearSelection;
    const getBridges = props.fetchData;

    const [deviceId, setDeviceId] = useState(null);
    const [bridgeId, setBridgeId] = useState(null);

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        const bridgeId = props.id;
        if(bridgeId != null && bridgeId != undefined && props.deviceId != null) {
            setDeviceId(props.deviceId);
            setBridgeId(bridgeId);
        }
    },[props.id]);

    const panes = [
        {
            menuItem:   <Menu.Item key='vlans' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            VLANs
                        </Menu.Item>,
            render: () => <VlanConfig deviceId={deviceId} bridgeId={bridgeId} closeFooter={closeFooter}/>
        },
        {
            menuItem:   <Menu.Item key='bridgeports' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Bridge Ports
                        </Menu.Item>,
            render: () => <BridgePortsList deviceId={deviceId} bridgeId={bridgeId} closeFooter={closeFooter}/>
        },
        {
            menuItem:   <Menu.Item key='stp' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            STP/RSTP
                        </Menu.Item>,
            render: () => <StpConfiguration deviceId={deviceId} bridgeId={bridgeId} closeFooter={closeFooter}/>
        },
        {
            menuItem:   <Menu.Item key='portstatistics' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Port Statistics
                        </Menu.Item>,
            render: () => <PortStatistics closeFooter={closeFooter}/>
        }
    ]
    return(
        <NoaContainer style={completeWidth}>
            <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} renderActiveOnly={true}/>
        </NoaContainer>
    )
}

const BridgePortsList = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const deviceId = props.deviceId;
    const bridgeId = props.bridgeId;
    const closeFooter = props.closeFooter;

    const [bridgePorts, setBridgePorts] = useState([]);
    
    const getBridgePorts = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/bridge/" + bridgeId + "/port",
            (response) => {
                let responseData = response.data;
                setBridgePorts(responseData);
            }
        )
    }
    useEffect(() => {
        context.setRenderLocation(["bridge-ports-list"]);
        getBridgePorts();
    },[props.bridgeId]);

    const columns = [
		{
			label: "1",
			Header: "Interface Name",
            accessor: "interfaceName",
            width:2
		},
        {
			label: "4",
			Header: "Interface Type",
            accessor: "interfaceType",
            width:3
		},
        {
			label: "5",
			Header: "Layer",
            accessor: "layer",
            width:2
        },
        {
			label: "6",
			Header: "Address",
            accessor: "ipAddress",
            width:2
        },
        {
			label: "7",
			Header: "Speed",
            accessor: "speed",
            width:2
        },
        {
            label: "8",
            Header: "Admin Status",
            Cell: ({row}) => (
                renderBoolean(row,"adminStatus",false)
            ),
            width:2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"enabled",true)
            ),
            width:2
        }
    ]
    const [selectedRows,setSelectedRows] = useState([]);

    return (
        <NoaContainer style={{width: "100%",height: "100%", paddingLeft: "2em", paddingRight: "2em",paddingTop: "1em",paddingBottom: "1em"}}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} id="bridge-ports">
                    <NoaTable data={bridgePorts}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelectedRows}
                        resource="Bridge Ports" 
                        fetchData={getBridgePorts} 
                        location="bridge-ports-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2} stackable>
                        <Grid.Column width={8} textAlign='right'>

                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const PortStatistics = (props) => {
    const closeFooter = props.closeFooter;
    return(
        <Grid style={completeHeight}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='middle'>
                    <NoaLineChart data={serviceThroughputValues} lineType={"linear"} colors={serviceThroughputColors}/>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2} stackable>
                        <Grid.Column width={8} textAlign='right'>

                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const StpConfiguration = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const deviceId = props.deviceId;
    const bridgeId = props.bridgeId;
    const closeFooter = props.closeFooter;

    const [stpConfig, setStpConfig] = useState({});

    const getStpConfig = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/bridge/" + bridgeId + "/stp",
            (response) => {
                let responseData = response.data;
                setStpConfig(responseData);
            }
        )
    }

    const updateStpConfig = () => {
        NoaClient.post(
            "/api/element/" + deviceId + "/bridge/" + bridgeId + "/stp",
            stpConfig,
            (response) => {
            }
        )
    }
    
    useEffect(() => {
        context.setRenderLocation(["stp-config"]);
        getStpConfig()
    },[props.bridgeId]);

    const handleChange = (value, key) => {
		setStpConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16} id="stp-config">
                <Grid>
                    <Grid.Row columns={1} style={formContentSpacingTB}>
                        <Grid.Column width={16}>
                        <Grid columns={3} stackable>
                            <Grid.Column width={4}></Grid.Column>
                            <Grid.Column width={8}>
                                <Grid>
                                <Grid.Row columns={1} verticalAlign='top'>
                                    <Grid.Column width={16}>
                                        <Grid columns={2} stackable>
                                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                                <Grid columns={3} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={5} textAlign='left'>
                                                        <p style={formParameter}>STP Status</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Checkbox toggle/>
                                                    </Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                                <Grid columns={3} stackable>
                                                    <Grid.Column width={5} textAlign='left'>
                                                        <p style={formParameter}>RSTP Status</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Checkbox toggle checked={true}
                                                        />
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                </Grid>
                            </Grid.Column>
                            <Grid.Column width={4}></Grid.Column>
                        </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1} style={formContentSpacingTB}>
                        <Grid.Column width={16}>
                        <Grid columns={3} style={completeHeight} stackable>
                            <Grid.Column width={2}></Grid.Column>
                            <Grid.Column width={12} style={noPadding}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                    <Grid columns={2} stackable>
                                        <Grid.Column computer={8} tablet={16} mobile={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Designated Root Bridge</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='deviceId' 
                                                                        value={deviceId}
                                                                        fluid={false}
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Bridge Root Cost</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='designatedRootBridge' 
                                                                        value={stpConfig.designatedRootBridge}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'designatedRootBridge')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Bridge Transmit Hold Count</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='transmitHoldCount' 
                                                                        value={stpConfig.transmitHoldCount}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'transmitHoldCount')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Max Age</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='maxAge' 
                                                                        value={stpConfig.maxAge}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'maxAge')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </Grid.Column>
                                        <Grid.Column computer={8} tablet={16} mobile={16}>
                                        <Grid stackable>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Hello Time</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='helloTime' 
                                                                        value={stpConfig.helloTime}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'helloTime')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Forward Delay</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='forwardDelay' 
                                                                        value={stpConfig.forwardDelay}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'forwardDelay')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>    
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Topology Changes</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='number' name='topologyChanges' 
                                                                        value={stpConfig.topologyChanges}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleChange(value, 'topologyChanges')
                                                                        }
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Last Topology Change</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='lastTopologyChange' 
                                                                        value={stpConfig.lastTopologyChange}
                                                                        fluid={false}
                                                            >
                                                                <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column width={2}></Grid.Column>
                        </Grid>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                updateStpConfig()
                                context.setRenderLocation(["stp-config"]);
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const serviceThroughputColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}

const serviceThroughputValues = [
    {
        "DEL-PE-480": 2400,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 600,
        "BOM-CE-001": 1600,
        "VJA-P-980": 900,
    },
    {
        "DEL-PE-480": 1800,
        "BOM-CE-165": 1600,
        "DEL-PE-560": 200,
        "BOM-CE-001": 6800,
        "VJA-P-980": 2500,
    },
    {
        "DEL-PE-480": 5600,
        "BOM-CE-165": 5400,
        "DEL-PE-560": 200,
        "BOM-CE-001": 200,
        "VJA-P-980": 2400,
    },
    {
        "DEL-PE-480": 1526,
        "BOM-CE-165": 1426,
        "DEL-PE-560": 100,
        "BOM-CE-001": 3200,
        "VJA-P-980": 3000,
    },
    {
        "DEL-PE-480": 3600,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 1800,
        "BOM-CE-001": 400,
        "VJA-P-980": 500,
    },
    {
        "DEL-PE-480": 3200,
        "BOM-CE-165": 1000,
        "DEL-PE-560": 1200,
        "BOM-CE-001": 800,
        "VJA-P-980": 1700,
    },
    {
        "DEL-PE-480": 3300,
        "BOM-CE-165": 2600,
        "DEL-PE-560": 700,
        "BOM-CE-001": 750,
        "VJA-P-980": 1800,
    },
]

export default BridgeInstanceManager;
export {AddBridgeInstance, BridgeManagement};