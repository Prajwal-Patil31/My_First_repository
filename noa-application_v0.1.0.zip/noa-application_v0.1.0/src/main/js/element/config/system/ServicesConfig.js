import React from 'react';

const ServicesConfig = () => {
    return(
        <div></div>
    )
}
export default ServicesConfig;