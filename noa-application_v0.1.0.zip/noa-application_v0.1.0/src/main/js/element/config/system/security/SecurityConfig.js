import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Button,
    Input,
    Dropdown
} from 'semantic-ui-react';

import { 
    formParameter, applyButton, cancelButton, 
    completeWidth, formContentSpacingTB, noPadding, 
    inputBoxStyle, dropdownStyle 
} from '../../../../constants';

import 'semantic-ui-css/semantic.min.css';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import { NoaContainer } from '../../../../widget/NoaWidgets';
import noaNotification from '../../../../widget/NoaNotification';

const SecurityConfig = (props) => {
    const deviceId = props.deviceId;

    const [securityConfig, setSecurityConfig] = useState({});

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    useEffect(() => {
        NoaClient(context, redirectContext);
        getSecurityConfig();
    },[]);

    const authenticationOptions = [
        {key: 'local', text: 'Local', value: 'local'},
        {key: 'remoteRadius', text: 'Remote Radius', value: 'remoteRadius'},
        {key: 'remoteTacacs', text: 'Remote Tacacs', value: 'remoteTacacs'},
        {key: 'radiusFallbackToLocal', text: 'Radius Fallback To Local', value: 'radiusFallbackToLocal'},
        {key: 'tacacsFallbackToLocal', text: 'Tacacs Fallback To Local', value: 'tacacsFallbackToLocal'},
        {key: 'ldap', text: 'LDAP', value: 'ldap'},
    ];

    const getSecurityConfig = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/system/security",
            (response) => {
                setSecurityConfig(response.data);
            })
    }

    const handleModify = () => {
        context.setRenderLocation(["security-config"])
        NoaClient.post(
			"/api/element/" + deviceId + "/system/security",
			securityConfig,
			(response) => {
                noaNotification('success','Security Config Updated Successfully.')
                getSecurityConfig();
		    })
    }

    const handleInputChange = (value, key) => {
		setSecurityConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }
    return(
        <NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column window={16} id="security-config">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Login Authentication</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                            placeholder="Auth Option"
                                                            style={dropdownStyle}
                                                            selectOnBlur={false}
                                                            options={authenticationOptions}
                                                            value={securityConfig.loginAuthentication ? securityConfig.loginAuthentication : ''}
                                                            onChange={
                                                                (e, {value}) => handleInputChange(value, 'loginAuthentication')
                                                            }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Max Login Attempts</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='maxLoginAttempts' 
                                                            value={securityConfig.maxLoginAttempts}
                                                            onChange={
                                                                (e, {value}) => handleInputChange(value, 'maxLoginAttempts')
                                                            }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Login Lock Time</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='loginLockTime' 
                                                            value={securityConfig.loginLockTime}
                                                            onChange={
                                                                (e, {value}) => handleInputChange(value, 'loginLockTime')
                                                            }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Web Session Time Out</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='webSessionTimeOut'
                                                            value={securityConfig.webSessionTimeOut}
                                                            onChange={
                                                                (e, {value}) => handleInputChange(value, 'webSessionTimeOut')
                                                            }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Web Session Max Users</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='webSessionMaxUsers' 
                                                        value={securityConfig.webSessionMaxUsers}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'webSessionMaxUsers')
                                                        }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            handleModify();
                            context.setRenderLocation(["security-config"])
                        }}>Update</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const addressTypes = [
    { 'key': "ipv4", 'text': "IPV4", 'value': "ipv4" },
    { 'key': "ipv6", 'text': "IPV6", 'value': "ipv6" }
]
export default SecurityConfig;