import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Button,
    Input,
    Dropdown
} from 'semantic-ui-react';

import { 
    formParameter, applyButton, cancelButton, 
    completeWidth, formContentSpacingTB, noPadding, 
    inputBoxStyle, dropdownStyle 
} from '../../../constants';

import 'semantic-ui-css/semantic.min.css';

import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';
import { NoaContainer } from '../../../widget/NoaWidgets';
import noaNotification from '../../../widget/NoaNotification';

const SystemConfig = (props) => {
    const deviceId = props.deviceId;

    const [deviceConfig, setDeviceConfig] = useState({});

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    useEffect(() => {
        NoaClient(context, redirectContext);
        getDeviceConfig();        
    },[]);

    const getDeviceConfig = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/config",
            (response) => {
                setDeviceConfig(response.data);
            })
    }

    const handleModify = () => {
        context.setRenderLocation(["system-config"])
        NoaClient.post(
			"/api/element/" + deviceId + "/config",
			deviceConfig,
			(response) => {
                noaNotification('success','System Config Updated Successfully.')
                getDeviceConfig();
		    })
    }
    const addressTypes = [
        { 'key': "ipv4", 'text': "IPV4", 'value': "ipv4" },
        { 'key': "ipv6", 'text': "IPV6", 'value': "ipv6" }
    ]

    const dateTimeTypes = [
        { 'key': "dns-servers", 'text': "DNS Servers", 'value': "dns-servers" },
        { 'key': "ntp-servers", 'text': "NTP Server", 'value': "ntp-servers" }
    ]

    const handleInputChange = (value, key) => {
		setDeviceConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }
    return(
        <NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="system-config">
                    <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Host Name</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='hostName' 
                                                                value={deviceConfig.hostName}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleInputChange(value, 'hostName')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Management Interface</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='managementInterface' 
                                                                value={deviceConfig.managementInterface}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleInputChange(value, 'managementInterface')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Host Address Mode</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                            placeholder="Address Mode"
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            value={deviceConfig.hostAddressMode}
                                                            options={addressTypes} 
                                                            onChange={
                                                                (e, {value}) => handleInputChange(value, 'hostAddressMode')
                                                            }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Management IP</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='managementIp' 
                                                        value={deviceConfig.managementIp}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'managementIp')
                                                        }>
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Subnet Mask</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='subnetMask' 
                                                        value={deviceConfig.subnetMask}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'subnetMask')
                                                        }>
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid stackable columns={4}>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Default Gateway</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='defaultGateway' 
                                                        value={deviceConfig.defaultGateway}
                                                        fluid={false}                                                        
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'defaultGateway')
                                                        }>
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Element Mode</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='elementMode' 
                                                        value={deviceConfig.elementMode}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'elementMode')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>                                                
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Domain Name</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='domainName' 
                                                        value={deviceConfig.domainName}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'domainName')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid stackable columns={4}>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>DNS Servers</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='dnsServers' 
                                                        value={deviceConfig.dnsServers}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'dnsServers')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Date/Time mode</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                            placeholder="Date/Time Mode"
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            value={deviceConfig.dateTimeMode}
                                                            options={dateTimeTypes} 
                                                            onChange={
                                                                (e, {value}) => handleInputChange(value, 'dateTimeMode')
                                                            }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>NTP Servers</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='ntpServers' 
                                                        value={deviceConfig.ntpServers}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'ntpServers')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                handleModify();
                                context.setRenderLocation(["system-config"])
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}
export default SystemConfig;