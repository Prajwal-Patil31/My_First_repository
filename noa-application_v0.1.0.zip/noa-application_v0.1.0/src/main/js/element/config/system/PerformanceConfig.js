import React from 'react';

const PerformanceConfig = () => {
    return(
        <div></div>
    )
}
export default PerformanceConfig;