import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Button,
    Input,
    Dropdown
} from 'semantic-ui-react';

import { 
    formParameter, applyButton, cancelButton, 
    completeWidth, formContentSpacingTB, noPadding, 
    inputBoxStyle, dropdownStyle 
} from '../../../../constants';

import 'semantic-ui-css/semantic.min.css';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import { NoaContainer } from '../../../../widget/NoaWidgets';
import noaNotification from '../../../../widget/NoaNotification';

const LoggingConfig = (props) => {
    const deviceId = props.deviceId;

    const [loggingConfig, setLoggingConfig] = useState({});

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    useEffect(() => {
        NoaClient(context, redirectContext);
        getLoggingConfig();
    },[]);

    const peerLoggingOptions = [
        {key: 'console', text: 'Console', value: 'console'},
        {key: 'file', text: 'File', value: 'file'},
        {key: 'flash', text: 'Flash', value: 'flash'},
    ];

    const logTransferModes = [
        {key: 'tftp', text: 'TFTP', value: 'tftp'},
        {key: 'sftp', text: 'SFTP', value: 'sftp'},
    ];

    const getLoggingConfig = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/config/log",
            (response) => {
                setLoggingConfig(response.data);
            })
    }

    const handleModify = () => {
        context.setRenderLocation(["logging-config"])
        NoaClient.post(
			"/api/element/" + deviceId + "/config/log",
			loggingConfig,
			(response) => {
                noaNotification('success','Logging Config Updated Successfully.')
                getLoggingConfig();
		    })
    }

    const handleInputChange = (value, key) => {
		setLoggingConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }
    return(
        <NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="logging-config">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                        <Grid columns={2} stackable>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Peer Logging Option</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection required
                                                        placeholder="Log Option"
                                                        selectOnBlur={false}
                                                        options={peerLoggingOptions}
                                                        style={dropdownStyle}
                                                        value={loggingConfig.peerLoggingOption ? loggingConfig.peerLoggingOption : ''}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'peerLoggingOption')
                                                            }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                {loggingConfig.peerLoggingOption === 'file' ? 
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Log File Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='logFileName' 
                                                        value={loggingConfig.logFileName}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'logFileName')
                                                        }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row> : "" }
                                {loggingConfig.peerLoggingOption === 'file' ? 
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Max Log File Size</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='logFileSize' 
                                                        value={loggingConfig.logFileSize}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'logFileSize')
                                                        }>
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row> : "" }
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Log Size Threshold</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='logSizeThreshold' 
                                                        value={loggingConfig.logSizeThreshold}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'logSizeThreshold')
                                                        }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Upload Log Transfer Mode</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection required
                                                        placeholder="Log Transfer Mode"
                                                        selectOnBlur={false}
                                                        options={logTransferModes}
                                                        style={dropdownStyle}
                                                        value={loggingConfig.uploadLogTransferMode ? loggingConfig.uploadLogTransferMode : ''}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'uploadLogTransferMode')
                                                        }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                {loggingConfig.uploadLogTransferMode === 'sftp' ?
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid stackable columns={4}>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Upload Log User Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='uploadLogUserName' 
                                                        value={loggingConfig.uploadLogUserName}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'uploadLogUserName')
                                                        }>
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row> : ""}

                                {loggingConfig.uploadLogTransferMode === 'sftp' ? 
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid stackable columns={4}>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Upload Log Password</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='password' fluid
                                                        name='uploadLogPassword'                                                         
                                                        value={loggingConfig.uploadLogPassword}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'uploadLogPassword')
                                                        }>
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                : ""}
                            </Grid>
                            </Grid.Column>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Upload IP Address Type</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection required
                                                        placeholder="IP Addr Type"
                                                        selectOnBlur={false}
                                                        style={dropdownStyle}
                                                        options={addressTypes}
                                                        value={loggingConfig.uploadLogFileToIpAddressType ? loggingConfig.uploadLogFileToIpAddressType : ''}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'uploadLogFileToIpAddressType')
                                                        }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Upload IP Address</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='uploadLogFileToIpvx' 
                                                    value={loggingConfig.uploadLogFileToIpvx}
                                                    onChange={
                                                        (e, {value}) => handleInputChange(value, 'uploadLogFileToIpvx')
                                                    }>
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid stackable columns={4}>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Upload Log File Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='ulRemoteLogFileName' 
                                                        value={loggingConfig.ulRemoteLogFileName}
                                                        onChange={
                                                            (e, {value}) => handleInputChange(value, 'ulRemoteLogFileName')
                                                        }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            handleModify()
                            context.setRenderLocation(["logging-config"])
                        }}>Update</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const addressTypes = [
    { 'key': "ipv4", 'text': "IPV4", 'value': "ipv4" },
    { 'key': "ipv6", 'text': "IPV6", 'value': "ipv6" }
]
export default LoggingConfig;