import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Button,
    Checkbox,
    Input,
    Divider
} from 'semantic-ui-react';

import { 
    formParameter, applyButton, completeWidth, 
    noMarginLR, noMarginTB, tablePadding, 
    completeHeight, dividerStyle, formContentSpacingTB, 
    inputBoxStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { NoaContainer } from '../../../../widget/NoaWidgets';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import noaNotification from '../../../../widget/NoaNotification';

const MplsL2vpnConfig = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const deviceId = props.deviceId;
    const [l2vpnInstances, setL2vpnInstances] = useState([]);

    const [l2vpnConfig, setL2vpnConfig] = useState({});

    const getMplsL2VpnConfig = () => {
        NoaClient.get(
			"/api/element/" + deviceId + "/mpls/service/l2vpn/config",
			(response) => {
				setL2vpnConfig(response.data);
        });
    }

    const updateMplsL2VpnConfig = () => {
        NoaClient.post(
			"/api/element/" + deviceId + "/mpls/service/l2vpn/config",
			l2vpnConfig,
			(response) => {
                noaNotification('success','L2VPN Configuration Updated Successfully');
        });
    }

    const handleInput = (value, key) => {
		setL2vpnConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const getL2vpnInstances = () => {
        context.setRenderLocation(['l2vpn-instances-list'])
        NoaClient.get(
			"/api/element/" + deviceId + "/mpls/service/l2vpn",
			(response) => {
				setL2vpnInstances(response.data);
        });
    }
    useEffect(() => {
        NoaClient(context,redirectContext)
        getMplsL2VpnConfig();
        getL2vpnInstances();
    },[]);

    return(
        <Grid>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="l2vpn-config">
                    <Grid columns={3} stackable>
                        <Grid.Column width={3}></Grid.Column>
                        <Grid.Column width={10} textAlign='center' verticalAlign='middle'>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Enable L2VPN Features</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    value={l2vpnConfig.enableL2Vpn}
                                                    onChange={
                                                        (e,data)=>handleInput(data.checked, 'enableL2Vpn')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Invalid Label Cleanup Interval</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='l2VpnCleanupInterval' 
                                                    value={l2vpnConfig.l2VpnCleanupInterval}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleInput(value==='' ? null : value, 'l2VpnCleanupInterval')
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Admin Status</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    value={l2vpnConfig.l2VpnAdminStatus}
                                                    onChange={
                                                        (e,data)=>handleInput(data.checked, 'l2VpnAdminStatus')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>                    
                        </Grid.Column>
                        <Grid.Column width={3}></Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            context.setRenderLocation(['l2vpn-config']);
                            updateMplsL2VpnConfig()
                        }}>UPDATE</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={{paddingTop: "3em"}}>
                <Grid.Column>
                <Grid stackable>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                            <L2VpnInstanceTable l2vpnInstances={l2vpnInstances} getL2vpnInstances={getL2vpnInstances}/>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const L2VpnInstanceTable = (props) => {
    const l2vpnInstances = props.l2vpnInstances;
    const getL2vpnInstances = props.getL2vpnInstances;

    const columns = [
		{
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Instance Name",
            accessor: "vpnId",
            width:2
		},
		{
			label: "2",
			Header: "Bridge Instance Id",
            accessor: "bridgeInstanceId",
            width:2
		},
        {
			label: "3",
			Header: "VPN Service Name",
            accessor: "vplsName",
            width:2
		},
        {
			label: "5",
			Header: "Signaling Type",
            accessor: "signalingType",
            width:2
        },
        {
			label: "6",
			Header: "MTU",
            accessor: "mtu",
            width:2
        },
        {
			label: "7",
			Header: "Send Control Word",
            accessor: "sendControlWord",
            width:2
        },
        {
			label: "8",
			Header: "Operational Status",
            accessor: "operationalStatus",
            width:3
		},
	]

    const [selectedRows, setSelectedRows] = useState({});

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginLR,noMarginTB)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={l2vpnInstances}
                                columns={columns}
                                selectedRows={selectedRows}
                                onSelectedRowsChange={setSelectedRows}
                                resource="L2 VPN Instances" 
                                fetchData={getL2vpnInstances} 
                                location="l2vpn-instances-list"
                    />
                </Grid.Column>
            </Grid.Row>
            
        </Grid>    
        </NoaContainer>
    )
}

export default MplsL2vpnConfig;