import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Button,
    Checkbox,
    Input,
    Divider,
} from 'semantic-ui-react';

import { 
    formParameter, applyButton, dividerStyle, 
    tablePadding, completeWidth, completeHeight, 
    noMarginLR, noMarginTB, formContentSpacingTB, 
    inputBoxStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import noaNotification from '../../../../widget/NoaNotification';
import { NoaContainer } from '../../../../widget/NoaWidgets';

const MplsL3vpnConfig = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const deviceId = props.deviceId;
    const [l3vpnInstances, setL3vpnInstances] = useState([]);

    const [l3vpnConfig, setL3vpnConfig] = useState({});
    
    const getMplsL3VpnConfig = () => {
        NoaClient.get(
			"/api/element/" + deviceId + "/mpls/service/l3vpn/config",
			(response) => {
				setL3vpnConfig(response.data);
        });
    }

    const updateMplsL3VpnConfig = () => {
        NoaClient.post(
			"/api/element/" + deviceId + "/mpls/service/l3vpn/config",
			l3vpnConfig,
			(response) => {
                noaNotification('success','L3VPN Configuration Updated Successfully.');
        });
    }

    const handleInput = (value, key) => {
		setL3vpnConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const getMplsL3VpnInstances = () => {
        NoaClient.get(
			"/api/element/" + deviceId + "/mpls/service/l3vpn",
			(response) => {
				setL3vpnInstances(response.data);
        });
    }

    useEffect(() => {
        getMplsL3VpnConfig();
        getMplsL3VpnInstances();    
    },[]);
    return(
        <Grid>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="l3vpn-config">
                    <Grid columns={3} stackable>
                        <Grid.Column width={3}></Grid.Column>
                        <Grid.Column width={10} textAlign='center' verticalAlign='middle'>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Enable L3VPN</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    value={l3vpnConfig.enableL3Vpn}
                                                    onChange={
                                                        (e,data)=>handleInput(data.checked, 'enableL3Vpn')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>


                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Invalid Label Receive Threshold</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='illegalLabelsReceiveThreshold' 
                                                    value={l3vpnConfig.illegalLabelsReceiveThreshold}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleInput(value==='' ? null : value, 'illegalLabelsReceiveThreshold')
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Max Possible Routes</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxPossibleRoutes' 
                                                    value={l3vpnConfig.maxPossibleRoutes}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleInput(value==='' ? null : value, 'maxPossibleRoutes')
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Max Route Threshold Time</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxRouteThresholdTime' 
                                                    value={l3vpnConfig.maxRouteThresholdTime}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleInput(value==='' ? null : value, 'maxRouteThresholdTime')
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                        </Grid.Column>
                        <Grid.Column width={3}></Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            context.setRenderLocation(['l3vpn-config'])
                            updateMplsL3VpnConfig()
                        }}>Update</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={{paddingTop: "3em"}}>
                <Grid.Column>
                <Grid stackable>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                            <L3VpnInstanceTable l3vpnInstances={l3vpnInstances} getMplsL3VpnInstances={getMplsL3VpnInstances}/>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const L3VpnInstanceTable = (props) => {
    const l3vpnInstances = props.l3vpnInstances;
    const getMplsL3VpnInstances = props.getMplsL3VpnInstances;
    const columns = [
		{
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Instance Name",
            accessor: "instanceName",
            width:2
		},
		{
			label: "2",
			Header: "Bridge Instance Id",
            accessor: "bridgeInstanceId",
            width:2
		},
        {
			label: "3",
			Header: "VRF Name",
            accessor: "vpnServiceName",
            width:2
		},
        {
			label: "5",
			Header: "Max Routes",
            accessor: "maxRoutes",
            width:2
        },
        {
			label: "6",
			Header: "Mid Route Threshold",
            accessor: "midRouteThreshold",
            width:2
        },
        {
			label: "7",
			Header: "High Route Threshold",
            accessor: "highRouteThreshold",
            width:2
        },
        {
			label: "8",
			Header: "Operational Status",
            accessor: "operationalStatus",
            width:3
		},
	]

    const [selectedRows, setSelectedRows] = useState({});

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginLR,noMarginTB)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={l3vpnInstances}
                            columns={columns}
                            selectedRows={selectedRows}
                            onSelectedRowsChange={setSelectedRows}
                            resource="L3 VPN Instances" 
                            fetchData={getMplsL3VpnInstances} 
                            location="l3vpn-instances-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
        
    )
}

export default MplsL3vpnConfig;