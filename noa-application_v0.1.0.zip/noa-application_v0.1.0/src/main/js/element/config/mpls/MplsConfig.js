import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Tab,
    Menu,
    Accordion,
    Segment
} from 'semantic-ui-react';

import { 
    accordionTitle, completeWidth, fullHeight, 
    cardLayout, nMenuItem
} from '../../../constants';
import { NoaContainer} from '../../../widget/NoaWidgets';
import TunnelManager from './tunnel/TunnelManager';
import LdpConfig from './ldp/LdpConfig';
import MplsGeneralConfig from './MplsGeneralConfig';
import MplsL2vpnConfig from './l2vpn/MplsL2vpnConfig';
import MplsL3vpnConfig from './l3vpn/MplsL3vpnConfig';
import { DropdownIcon } from '../../../widget/NoaIcons';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';

const MplsConfig = (props) => {
    const deviceId = sessionStorage.getItem("elementId"); 
    
    const panes = [
        {
            menuItem: <Menu.Item key='general' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>General</Menu.Item>,
            render: () => <MplsGeneralConfig deviceId={deviceId}/>
        },
        {
            menuItem: <Menu.Item key='ldp' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>LDP</Menu.Item>,
            render: () => <LdpConfig deviceId={deviceId}/>
        },
        {
            menuItem: <Menu.Item key='mplsTunnels' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>MPLS Tunnels</Menu.Item>,
            render: () => <TunnelManager tunnels={mockTunnels} deviceId={deviceId}/>
        },
        {
            menuItem: <Menu.Item key='serviceInstances' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Service Instances</Menu.Item>,
            render: () => <ServiceInstancesManagement deviceId={deviceId}/>
        }
    ]

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                            <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} />
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Segment>
        </NoaContainer>
    )
}

const ServiceInstancesManagement = (props) => {
    const deviceId = props.deviceId;
    const context = useContext(GlobalSpinnerContext);

    const [indexesState, setIndexesState] = useState({ activeIndexes: [0] });

    useEffect(() => {
        context.setRenderLocation(['l2vpn-instances','l3vpn-instances']);
    },[]);

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;

    return(
        <NoaContainer style={Object.assign({marginTop:"3em",marginBottom:"3em"},fullHeight,completeWidth)} >
            <Grid style={{maxHeight:"66em",overflowY:"auto"}} className="content">
                <Grid.Row columns={1}>
                    <Grid.Column width={16} textAlign='center' verticalAlign='top'>
                        <Accordion>
                            <Accordion.Title
                                active={activeIndex.includes(0)}
                                index={0}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                L2VPN Service
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(0)}>
                                <MplsL2vpnConfig deviceId={deviceId}/>
                            </Accordion.Content>
                            <Accordion.Title
                                active={activeIndex.includes(1)}
                                index={1}
                                onClick={handleClick}
                                style={Object.assign({textAlign:'left'},accordionTitle)}
                            >
                                <DropdownIcon />
                                L3VPN Service
                            </Accordion.Title>
                            <Accordion.Content active={activeIndex.includes(1)}>
                                <MplsL3vpnConfig deviceId={deviceId} />
                            </Accordion.Content>
                        </Accordion>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const mockTunnels =[]
export default MplsConfig;