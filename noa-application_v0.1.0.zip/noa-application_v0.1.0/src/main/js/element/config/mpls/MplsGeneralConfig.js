import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Button,
    Checkbox,
    Dropdown
} from 'semantic-ui-react';

import { formParameter, applyButton, cancelButton, noPadding, dropdownStyle} from '../../../constants';
import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';
import noaNotification from '../../../widget/NoaNotification';

const MplsGeneralConfig = (props) => {
    const deviceId = props.deviceId;
    const [mplsConfig, setMplsConfig] = useState({});

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const updateMplsConfig = () => {
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls",
            mplsConfig,
			(response) => {
                noaNotification('success','MPLS Configuration Updated Successfully.');
                getMplsConfig();
            })
    }

    const getMplsConfig = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/mpls",
            (response) => {
                setMplsConfig(response.data);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getMplsConfig();
        context.setRenderLocation(['mpls-general-config']);
    },[]);

    const handleChange = (value, key) => {
		setMplsConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const qosPolicies = [
        { 'key': "stdip", 'text': "STDIP", 'value': "stdip" },
        { 'key': "rfc1349", 'text': "RFC1349", 'value': "rfc1349" },
        { 'key': "diffserv", 'text': "Diff-Serv", 'value': "diffserv" }
    ]

    const labelDistributionModes = [
        { 'key': "LDP", 'text': "LDP", 'value': "LDP" },
        { 'key': "CR-LDP", 'text': "CR-LDP", 'value': "CR-LDP" },
        { 'key': "RSVP-TE", 'text': "RSVP-TE", 'value': "RSVP-TE" }
    ]

    const labelAllocationModes = [
        { 'key': "ordered", 'text': "Ordered", 'value': "ordered" },
        { 'key': "independent", 'text': "Independent", 'value': "independent" }
    ]
    
    return(
        <Grid>
            <Grid.Row columns={1} style={Object.assign({marginTop:"4em",marginBottom:"3em"})}>
                <Grid.Column width={16} id="mpls-general-config">
                    <Grid columns={3} stackable>
                        <Grid.Column width={4}></Grid.Column>
                        <Grid.Column width={8} style={noPadding}>
                        <Grid>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Enable MPLS</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Checkbox
                                            toggle={true}
                                            checked={mplsConfig.enableMpls ? mplsConfig.enableMpls : false}
                                            onChange={
                                                (e,data)=>handleChange(data.checked,'enableMpls')
                                            }
                                        />
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>QOS Policy</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Dropdown clearable selection required
                                            selectOnBlur={false}
                                            style={dropdownStyle}
                                            placeholder="QOS Policy Type"
                                            value={mplsConfig.qosPolicy ? mplsConfig.qosPolicy : ''}
                                            options={qosPolicies} 
                                            onChange={
                                                (e, {value}) => handleChange(value==='' ? null : value, 'qosPolicy')
                                            }
                                        />
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Label Distribution Mode</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Dropdown clearable selection required
                                            placeholder="Label Dist Mode"
                                            selectOnBlur={false}
                                            style={dropdownStyle}
                                            value={mplsConfig.labelDistributionMode ? mplsConfig.labelDistributionMode : ''}
                                            options={labelDistributionModes} 
                                            onChange={
                                                (e, {value}) => handleChange(value==='' ? null : value, 'labelDistributionMode')
                                            }
                                        />
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Label Allocation Mode</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Dropdown clearable selection required
                                            placeholder="Label Alloc Mode"
                                            selectOnBlur={false}
                                            style={dropdownStyle}
                                            value={mplsConfig.labelAllocationMode ? mplsConfig.labelAllocationMode : ''}
                                            options={labelAllocationModes} 
                                            onChange={
                                                (e, {value}) => handleChange(value==='' ? null : value, 'labelAllocationMode')
                                            }
                                        />
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>

                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={4} stackable>
                                    <Grid.Column width={3}></Grid.Column>
                                    <Grid.Column width={4} textAlign='left'>
                                        <p style={formParameter}>Loop Detection</p>
                                    </Grid.Column>
                                    <Grid.Column width={6} textAlign='left'>
                                        <Checkbox
                                            toggle={true}
                                            checked={mplsConfig.loopDetection ? mplsConfig.loopDetection : false}
                                            onChange={
                                                (e,data)=>handleChange(data.checked,'loopDetection')
                                            }
                                        />
                                    </Grid.Column>
                                    <Grid.Column width={3}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        </Grid.Column>
                        <Grid.Column width={4}></Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2} stackable>
                        <Grid.Column textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                context.setRenderLocation(['mpls-general-config']);
                                updateMplsConfig();
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column textAlign='left'>
                            <Button style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
export default MplsGeneralConfig;