import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Button,
    Divider,
    Checkbox,
    Dropdown,
    Icon,
    Input,
} from 'semantic-ui-react';

import { 
    noBoxShadow,noPadding, noMarginTB, 
    noMarginLR, formTitle, formParameter, 
    applyButton, cancelButton, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight, 
    dividerStyle, inputBoxStyle, formContentSpacingTB, 
    dropdownStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';
import { NoaHeader, NoaContainer} from '../../../../widget/NoaWidgets';
import NoaToolbar from '../../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../../widget/NoaNotification';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const TunnelManager = (props) => {
    const deviceId = props.deviceId;

    const [tunnels, setTunnels] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});
    
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = tunnels[sel[i]].tunnelId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getTunnels = (filterObj) => {
        context.setRenderLocation(['mpls-tunnels-list']);
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls/tunnel",
            filterObj,
            (response) => {
                let responseData = response.data;
                setTunnels(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        context.setRenderLocation(['mpls-tunnels-list']);
        NoaClient.get(
            "/api/element/" + deviceId + "/mpls/tunnel/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device" : {"device-id":[deviceId],"mpls-tunnel" :{}}}
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getTunnels(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
        <Grid style={Object.assign({},completeHeight, noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <TunnelsTable tunnels={tunnels} getTunnels={getTunnels}
                                selectedRows={selectedRows}
                                setClearSelected={setClearSelected}
                                setSelected={setSelected} 
                                clearSelected={clearSelected}
                                deviceId={deviceId}
                                columns={columns}
                                filters={filters}
                                pageSize={pageSize}
                                totalPages={totalPages}
                                setPageSize={setPageSize}
                                totalEntries={totalEntries}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const TunnelsTable = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const tunnels = props.tunnels;
    const getTunnels = props.getTunnels;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const deviceId = props.deviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"mpls-tunnel" :{}}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Tunnel Name",
            accessor: "tunnelName",
            width:2
		},
		{
			label: "2",
			Header: "Ingress LSR Id",
            accessor: "ingressLsrId",
            width:2
		},
        {
			label: "4",
			Header: "Egress LSR Id",
            accessor: "egressLsrId",
            width:2
		},
        {
			label: "5",
			Header: "Tunnel Role",
            accessor: "tunnelRole",
            width:2
        },
        {
			label: "6",
			Header: "Signalling Protocol",
            accessor: "signalingProtocol",
            width:2
        },
        {
			label: "7",
			Header: "Instance Id",
            accessor: "tunnelInstance",
            width:3
        },
        {
            label: "7",
            Header: "Operational Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:2
        }
    ]

    const router = useRouter();

    const handleAddTunnel = () => {
        router.stateService.go("add-tunnel",{deviceId:deviceId,fetchData: fetchData, clearSelection: clearSelection})
    }
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-tunnel',{id: tunnels[selId].tunnelId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["mpls-tunnels-list"]);
        NoaClient.delete(
			"/api/element/" + deviceId + "/mpls/tunnel",
			selectedItems,
			(response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        });
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getTunnels(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"mpls-tunnel" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getTunnels(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getTunnels(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    
    return(
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddTunnel}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={tunnels}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="MPLS Tunnels" 
                        fetchData={fetchData} 
                        location="mpls-tunnels-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.adminStatus == "false" ? false : true;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddTunnel = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    
    const getTunnels = props.fetchData;
    const clearSelection = props.clearSelection;
    const deviceId = props.deviceId;

    const [tunnel, setTunnel] = useState({});

    const [ingressDeviceName, setIngressDeviceName] = useState(null);
    const [egressElements, setEgressElements] = useState([]);

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleChange = (value, key) => {
		setTunnel(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        tunnel["ingressLsrId"] = ingressDeviceName
        NoaClient.put(
            "/api/element/" + deviceId + "/mpls/tunnel",
            tunnel,
            (response) => {
                noaNotification('success','MPLS Tunnel Created Successfully.')
                getTunnels();
                closeFooter();
        })
    }

    const getElements = () => {
        NoaClient.get(
            "/api/element",
			(response) => {
                let responseData = response.data;
                let elementsList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        if(item.deviceId != deviceId) {
                            let deviceObj = {'key' : item.deviceId, 'value' : item.deviceName, 'text': item.deviceName}
                            elementsList.push(deviceObj);
                        } else {
                            setIngressDeviceName(item.deviceName);
                        }
                    })
                }
                setEgressElements(elementsList);
		});
    }

    useEffect(() => {
        context.setRenderLocation(['add-mpls-tunnel']);
        getElements();
    },[]);

    const signalingTypes = [
        {
            key: 'bgp',
            text: 'BGP',
            value: 'bgp',
        },
        {
            key: 'ldp',
            text: 'LDP',
            value: 'ldp',
        }
    ];

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create MPLS Tunnel</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-mpls-tunnel">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                        <Grid columns={2} stackable>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Tunnel Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='tunnelName' 
                                                            value={tunnel.tunnelName}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'tunnelName')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Tunnel Role</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='tunnelRole' 
                                                            value={tunnel.tunnelRole}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'tunnelRole')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Tunnel Index</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='tunnelIndex' 
                                                            value={tunnel.tunnelIndex}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'tunnelIndex')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Signaling Protocol</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection
                                                        placeholder="Select Signaling protocol"
                                                        selectOnBlur={false}
                                                        style={dropdownStyle}
                                                        options={signalingTypes}
                                                        value={tunnel.signalingProtocol}
                                                        onChange={
                                                            (e, {value}) => handleChange(value, "signalingProtocol")
                                                        }
                                                    />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Egress LSR Id</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection
                                                            placeholder="Select Egress LSR"
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            options={egressElements}
                                                            value={tunnel.egressLsrId}
                                                            onChange={
                                                                (e, {value}) => {
                                                                    handleChange(value, "egressLsrId")
                                                                }
                                                            }
                                                    />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Admin Status</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={tunnel.adminStatus ? tunnel.adminStatus : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'adminStatus')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Setup Priority</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='setUpPriority' 
                                                            value={tunnel.setUpPriority}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'setUpPriority')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Holding up Priority</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='holdingPriority' 
                                                            value={tunnel.holdingPriority}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'holdingPriority')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Instance Priority</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='instancePriority' 
                                                            value={tunnel.instancePriority}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'instancePriority')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                context.setRenderLocation(["add-mpls-tunnel"]);
                                handleAdd()
                            }}>Add</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const ModifyTunnel = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    const clearSelection = props.clearSelection;
    const getTunnels = props.fetchData;

    const [deviceId, setDeviceId] = useState(null);
    const [tunnelId, setTunnelId] = useState(null);
    const [tunnel, setTunnel] = useState({});

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        context.setRenderLocation(["modify-tunnel"]);
        const id = props.id;
        if(id != null && id != undefined && props.deviceId != null) {
            setDeviceId(props.deviceId);
            setTunnelId(id);
        }
    },[props.id]);

    useEffect(() => {
        if(tunnelId != null) {
            getTunnel();
        }
    },[tunnelId]);

    const getTunnel = () => {
        NoaClient.get(
			"/api/element/" + deviceId + "/mpls/tunnel/" + tunnelId,
			(response) => {
                setTunnel(response.data);
        });
    }

    const handleModify = () => {
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls/tunnel/" + tunnelId,
            tunnel,
			(response) => {
                getTunnels();
                closeFooter();
        });
    }


    const handleChange = (value, key) => {
		setTunnel(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} style={noPadding} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Tunnel Details: {tunnel.tunnelName}</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="modify-tunnel">
                        <Grid columns={3}>
                            <Grid.Column width={3}></Grid.Column>
                            <Grid.Column width={12}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={window.innerWidth > 1330 ? 8 : 12} tablet={16} mobile={16}>
                                    <Grid>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Setup Priority</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Input type='text' name='setupPriority' 
                                                        value={tunnel.setUpPriority}
                                                        fluid={false}
                                                        /* onChange={
                                                            (e, {value}) => handleChange(value, 'setUpPriority')
                                                        } */
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Holding Priority</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Input type='text' name='holdingPriority' 
                                                        value={tunnel.holdingPriority}
                                                        fluid={false}
                                                        /* onChange={
                                                            (e, {value}) => handleChange(value, 'holdingPriority')
                                                        } */
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Total Up Time</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Input type='text' name='port' 
                                                        value={tunnel.sessionAttributes}
                                                        fluid={false}
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                    </Grid.Row>
                                    </Grid>
                                </Grid.Column>

                                <Grid.Column computer={window.innerWidth > 1330 ? 8 : 12} tablet={16} mobile={16} textAlign='left'>
                                    <Grid>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Primary Instance</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Input type='number' name='primaryInstance' 
                                                        value={tunnel.primaryInstance}
                                                        fluid={false}
                                                        /* onChange={
                                                            (e, {value}) => handleChange(value, 'primaryInstance')
                                                        } */
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Instance Priority</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Input type='number' name='instancePriority' 
                                                        value={tunnel.instancePriority}
                                                        fluid={false}
                                                        /* onChange={
                                                            (e, {value}) => handleChange(value, 'instancePriority')
                                                        } */
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Admin Status</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Checkbox  name='adminStatus' 
                                                        checked={tunnel.adminStatus}
                                                        toggle
                                                        /* onChange={
                                                            (e, data) => handleChange(data.checked, 'adminStatus')
                                                        } */
                                            />
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={2}>
                                        <Grid.Column width={8} textAlign='left'>
                                            <p style={formParameter}>Path In Use</p>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Input type='text' name='pathInUse' 
                                                        value={tunnel.pathInUse}
                                                        fluid={false}
                                                        /* onChange={
                                                            (e, {value}) => handleChange(value, 'pathInUse')
                                                        } */
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                    </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column width={3}></Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2} stackable>
                            {/* <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    handleModify()
                                    context.setRenderLocation(['modify-tunnel'])
                                }}>Update</Button>
                            </Grid.Column> */}
                            <Grid.Column width={8} textAlign='left'>
                                <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
export default TunnelManager;
export {AddTunnel,ModifyTunnel}