import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Button,
    Checkbox,
    Input,
    Accordion
} from 'semantic-ui-react';

import { 
    formParameter, applyButton, cancelButton, 
    accordionTitle, noPadding, inputBoxStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';

import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import LdpEntitiesManager from './LdpEntitiesManager';
import LdpPeers from './LdpPeers';
import { DropdownIcon } from '../../../../widget/NoaIcons';
import noaNotification from '../../../../widget/NoaNotification';

const LdpConfig = (props) => {
    const deviceId = props.deviceId;

    const [ldpConfig, setLdpConfig] = useState({});
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const updateLdpConfig = () => {
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls/ldp",
            ldpConfig,
			(response) => {
                noaNotification('success','LDP Configuration Updated Successfully');
                getLdpConfig();
            })
    }

    const getLdpConfig = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/mpls/ldp",
            (response) => {
                setLdpConfig(response.data);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        context.setRenderLocation(['ldp-config']);
        getLdpConfig();
    },[]);

    const [indexesState, setIndexesState] = useState({ activeIndexes: [0] });

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;

    const handleChange = (value, key) => {
		setLdpConfig(prevState => ({
            ...prevState,
            [key]: value
        }));
    }
    return(
        <Grid style={{maxHeight:"56em",overflowY:"auto"}} className="content">
            <Grid.Row columns={1} style={Object.assign({marginTop:"4em",marginBottom:"3em"})}>
                <Grid.Column width={16} id="ldp-config">
                <Grid columns={3} stackable>
                    <Grid.Column width={4}></Grid.Column>
                    <Grid.Column width={8} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Re-Trigger LDP Sessions</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={ldpConfig.reTriggerLdpSessions ? ldpConfig.reTriggerLdpSessions : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'reTriggerLdpSessions')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>


                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Enable LSP Notifications</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={ldpConfig.enableLspNotifications ? ldpConfig.enableLspNotifications : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'enableLspNotifications')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>


                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Send Configuration Sequence</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={ldpConfig.sendConfigurationSequence ? ldpConfig.sendConfigurationSequence : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'sendConfigurationSequence')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>


                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>LSR LDP Id</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input value={deviceId}>
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={4}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                context.setRenderLocation(['ldp-config']);
                                updateLdpConfig()}
                            }>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column>
                <Grid stackable>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                            <Accordion>
                                <Accordion.Title
                                    active={activeIndex.includes(0)}
                                    index={0}
                                    onClick={handleClick}
                                    style={Object.assign({textAlign:'left'},accordionTitle)}
                                >
                                    <DropdownIcon />
                                    LDP Entities
                                </Accordion.Title>
                                <Accordion.Content active={activeIndex.includes(0)}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <LdpEntitiesManager deviceId={deviceId} />
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Accordion.Content>
                                <Accordion.Title
                                    active={activeIndex.includes(1)}
                                    index={1}
                                    onClick={handleClick}
                                    style={Object.assign({textAlign:'left'},accordionTitle)}
                                >
                                    <DropdownIcon />
                                    LDP Peers
                                </Accordion.Title>
                                <Accordion.Content active={activeIndex.includes(1)}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <LdpPeers deviceId={deviceId} />
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Accordion.Content>
                            </Accordion>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
export default LdpConfig;