import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';
import {
    Grid,
    Button,
    Checkbox,
    Dropdown,
    Icon,
    Divider,
    Input
} from 'semantic-ui-react';

import { 
    dividerStyle, noPadding, noMarginTB, 
    noMarginLR,formTitle, noBoxShadow,
    formParameter, applyButton, cancelButton, 
    completeHeight, completeWidth, tablePadding,
    tableHeaderHeight,
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import noaNotification from '../../../../widget/NoaNotification';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';
import { NoaContainer, NoaHeader} from '../../../../widget/NoaWidgets';
import NoaToolbar from '../../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const LdpEntitiesManager = (props) => {   
    const deviceId = props.deviceId;

    const [ldpEntities, setLdpEntities] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = ldpEntities[sel[i]].entityId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const getLdpEntities = (filterObj) => {
        context.setRenderLocation(['ldp-entity-list']);
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls/ldp/entity",
            filterObj,
            (response) => {
                let responseData = response.data;
                setLdpEntities(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/mpls/ldp/entity/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }
    

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device":{"device-id":[deviceId],"ldp-entity":{}}}
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getLdpEntities(filterCriteria);
    },[]);

    return (
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
        <Grid style={Object.assign({},completeHeight, noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <LdpEntitiesTable ldpEntities={ldpEntities} getLdpEntities={getLdpEntities}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected}
                                    clearSelected={clearSelected}
                                    deviceId={deviceId}
                                    columns={columns}
                                    filters={filters}
                                    pageSize={pageSize}
                                    totalPages={totalPages}
                                    setPageSize={setPageSize}
                                    totalEntries={totalEntries}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const LdpEntitiesTable = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const ldpEntities = props.ldpEntities;
    const getLdpEntities = props.getLdpEntities;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const deviceId = props.deviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"ldp-entity" :{}}});

    const columns = [
		{
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Entity Index",
            accessor: "entityIndex",
            width:1
		},
		{
			label: "2",
			Header: "Label Distribution Method",
            accessor: "labelDistMethod",
            width:2
		},
        {
			label: "3",
			Header: "Label Retention Mode",
            accessor: "labelRetentionMode",
            width:2
		},
        {
			label: "5",
			Header: "TCP Port",
            accessor: "tcpPort",
            width:2
        },
        {
			label: "6",
			Header: "UDP Discovery Port",
            accessor: "udpDescPort",
            width:3
        },
        {
			label: "7",
			Header: "Max PDU Length",
            accessor: "maxPduLength",
            width:2
        },
        {
            label: "7",
            Header: "Operational Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:3
        }
	]

    const router = useRouter();

    const handleAddLdpEntity = () => {
        router.stateService.go("add-ldp-entity",{deviceId:deviceId,fetchData: fetchData, clearSelection: clearSelection})
    }
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-ldp-entity',{id: ldpEntities[selId].entityId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["ldp-entity-list"]);
        NoaClient.delete(
            "/api/element/" + deviceId + "/mpls/ldp/entity",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null})
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getLdpEntities(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"ldp-entity" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getLdpEntities(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getLdpEntities(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    
    if (!ldpEntities && !ldpEntities.length)
        return null;
        
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    {/* <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddLdpEntity}
                                    />   */}                              
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={ldpEntities}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="LDP Entities" 
                        fetchData={fetchData} 
                        location="ldp-entity-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.operStatus == "false" ? false : true;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddLdpEntity = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    
    const getLdpEntities = props.fetchData;
    const clearSelection = props.clearSelection;
    const deviceId = props.deviceId;

    const [ldpEntity, setLdpEntity] = useState({});

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleChange = (value, key) => {
		setLdpEntity(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/element/" + deviceId + "/mpls/ldp/entity",
            ldpEntity,
            (response) => {
                getLdpEntities();
                closeFooter();
        })
    }
    return (
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create LDP Entity</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="add-ldp-entity">
                        <Grid columns={3} stackable>
                            <Grid.Column width={1}></Grid.Column>
                            <Grid.Column width={14}>
                            <Grid columns={3} stackable>
                                <Grid.Column computer={7} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter}>Entity Index</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='entityIndex' 
                                                                value={ldpEntity.entityIndex}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'entityIndex')
                                                                }
                                                    >
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter} className="required">Label Distribution Method</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                        placeholder="Select Label Distribution Mode"
                                                        selectOnBlur={false}
                                                        value={ldpEntity.labelDistMethod ? ldpEntity.labelDistMethod : ''}
                                                        options={labelDistTypes} 
                                                        onChange={
                                                            (e, {value}) => handleChange(value==='' ? null : value, 'labelDistMethod')
                                                        }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter} className="required">Label Retention Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                        selectOnBlur={false}
                                                        placeholder="Select Label Retention Type"
                                                        value={ldpEntity.labelRetentionMode ? ldpEntity.labelRetentionMode : ''}
                                                        options={labelRetentionTypes} 
                                                        onChange={
                                                            (e, {value}) => handleChange(value==='' ? null : value, 'labelRetentionMode')
                                                        }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter}>Target Peer Address Types</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                        placeholder="Select Peer Address Type"
                                                        selectOnBlur={false}
                                                        value={ldpEntity.targetPeerAddrType ? ldpEntity.targetPeerAddrType : ''}
                                                        options={peerAddrTypes} 
                                                        onChange={
                                                            (e, {value}) => handleChange(value==='' ? null : value, 'targetPeerAddrType')
                                                        }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter} className="required">Target Peer Address</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='targetPeer' 
                                                                value={ldpEntity.targetPeer}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'targetPeer')
                                                                }
                                                    >
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                <Grid.Column computer={7} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter} className="required">TCP Port</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='tcpPort' 
                                                                value={ldpEntity.tcpPort}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'tcpPort')
                                                                }
                                                    >
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter}>UDP Port</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='udpDescPort' 
                                                                value={ldpEntity.udpDescPort}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'udpDescPort')
                                                                }
                                                    >
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter}>Keep Alive Hold Timer</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='keepAliveHoldTimer' 
                                                                value={ldpEntity.keepAliveHoldTimer}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'keepAliveHoldTimer')
                                                                }
                                                    >
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter}>Max PDU Length</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='maxPduLength' 
                                                                value={ldpEntity.maxPduLength}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'maxPduLength')
                                                                }
                                                    >
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={2}></Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <p style={formParameter}>Operational Status</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Checkbox
                                                        toggle={true}
                                                        checked={ldpEntity.operStatus ? ldpEntity.operStatus : false}
                                                        onChange={
                                                            (e,data)=>handleChange(data.checked,'operStatus')
                                                        }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={2}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column width={1}></Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row style={{paddingTop: "2em"}} columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2}>
                            <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    context.setRenderLocation(["add-ldp-entity"]);
                                    handleAdd()
                                }}>Add</Button>
                            </Grid.Column>
                            <Grid.Column width={8} textAlign='left'>
                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ModifyLdpEntity = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    const clearSelection = props.clearSelection;
    const getLdpEntities = props.fetchData;

    const [deviceId, setDeviceId] = useState(null);
    const [entityId, setEntityId] = useState(null);

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        context.setRenderLocation(["modify-ldp-entity"])
        const id = props.id;
        if(id != null && id != undefined && props.deviceId != null) {
            setDeviceId(props.deviceId);
            setEntityId(id);
        }
    },[props.id]);

    const [ldpEntity, setLdpEntity] = useState({});

    const handleChange = (value, key) => {
		setLdpEntity(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleModify = () => {
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls/ldp/entity/" + ldpEntity.entityId,
            ldpEntity,
            (response) => {
                getLdpEntities();
                closeFooter(false);
                setLdpEntity({});
        })
    }

    useEffect(() => {
        if(entityId != null) {
            NoaClient.get(
                "/api/element/" + deviceId + "/mpls/ldp/entity/" + entityId,
                (response) => {
                    setLdpEntity(response.data);
            })
        }
    },[entityId]);

    return (
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} style={noPadding} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Modify LDP Entity</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="modify-ldp-entity">
                        <Grid columns={2} stackable>
                            <Grid.Column computer={window.innerWidth > 1330 ? 8 : 12} tablet={16} mobile={16}>
                                <Grid>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Target Peer Address Types</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Dropdown clearable selection required
                                            placeholder="Select Peer Address Type"
                                            selectOnBlur={false}
                                            value={ldpEntity.targetPeerAddrType ? ldpEntity.targetPeerAddrType : ''}
                                            options={peerAddrTypes} 
                                            onChange={
                                                (e, {value}) => handleChange(value==='' ? null : value, 'targetPeerAddrType')
                                            }
                                        />
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Target Peer Address</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='text' name='targetPeer' 
                                                    value={ldpEntity.targetPeer}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'targetPeer')
                                                    }
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Operational Status</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Checkbox
                                            toggle={true}
                                            checked={ldpEntity.operStatus ? ldpEntity.operStatus : false}
                                            onChange={
                                                (e,data)=>handleChange(data.checked,'operStatus')
                                            }
                                        />
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Init Session Threshold</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='number' name='initSessionThreshold' 
                                                    value={ldpEntity.initSessionThreshold}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'initSessionThreshold')
                                                    }
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                </Grid>
                            </Grid.Column>

                            <Grid.Column computer={window.innerWidth > 1330 ? 8 : 12} tablet={16} mobile={16}>
                                <Grid>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Path Vector Limit</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='number' name='pathVectorLimit' 
                                                    value={ldpEntity.pathVectorLimit}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'pathVectorLimit')
                                                    }
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Hop Count Limit</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='number' name='hopCountLimit' 
                                                    value={ldpEntity.hopCountLimit}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'hopCountLimit')
                                                    }
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Keep Alive Hold Timer</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='number' name='keepAliveHoldTimer' 
                                                    value={ldpEntity.keepAliveHoldTimer}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'keepAliveHoldTimer')
                                                    }
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <p style={formParameter}>Hello Hold Timer</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='number' name='helloHoldTimer' 
                                                    value={ldpEntity.helloHoldTimer}
                                                    fluid={false}
                                                    onChange={
                                                        (e, {value}) => handleChange(value, 'helloHoldTimer')
                                                    }
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                </Grid>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>

                <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2} stackable>
                            <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    handleModify()
                                    context.setRenderLocation(['modify-ldp-entity'])
                                }}>Update</Button>
                            </Grid.Column>
                            <Grid.Column width={8} textAlign='left'>
                                <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const labelDistTypes = [
    {
        key: 'downstreamOnDemand',
        text: 'Down Stream On Demand',
        value: 'downstreamOnDemand',
    },
    {
        key: 'downstreamUnsolicited',
        text: 'Down Stream Unsolicited',
        value: 'downstreamUnsolicited',
    }
];

const labelRetentionTypes = [
    {
        key: 'conservative',
        text: 'Conservative',
        value: 'conservative',
    },
    {
        key: 'liberal',
        text: 'Liberal',
        value: 'liberal',
    }
];

const peerAddrTypes = [
    {
        key: 'ipv4',
        text: 'IP V4',
        value: 'ipv4',
    },
    {
        key: 'ipv6',
        text: 'IP V6',
        value: 'ipv6',
    }
];

const labelTypes = [
    {
        key: 'generic',
        text: 'Generic',
        value: 'generic',
    },
    {
        key: 'atm',
        text: 'ATM',
        value: 'atm',
    },
    {
        key: 'frameRelay',
        text: 'Frame Relay',
        value: 'frameRelay',
    }
];
export default LdpEntitiesManager;
export {AddLdpEntity,ModifyLdpEntity};