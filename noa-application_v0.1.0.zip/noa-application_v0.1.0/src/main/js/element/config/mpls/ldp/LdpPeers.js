import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Checkbox,
    Icon
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';
import { NoaContainer} from '../../../../widget/NoaWidgets';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const LdpPeers = (props) => {   
    const deviceId = props.deviceId;

    const [ldpPeers, setLdpPeers] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = ldpPeers[sel[i]].peerId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const getLdpPeers = (filterObj) => {
        context.setRenderLocation(['ldp-peer-list']);
        NoaClient.post(
            "/api/element/" + deviceId + "/mpls/ldp/peer",
            filterObj,
            (response) => {
                let responseData = response.data;
                setLdpPeers(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/mpls/ldp/peer/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device" : {"device-id":[deviceId],"ldp-peer" :{}}}
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getLdpPeers(filterCriteria);
    },[]);

    return (
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
        <Grid style={Object.assign({},completeHeight, noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <LdpPeersTable ldpPeers={ldpPeers} getLdpPeers={getLdpPeers}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected}
                                    clearSelected={clearSelected}
                                    columns={columns}
                                    filters={filters}
                                    pageSize={pageSize}
                                    totalPages={totalPages}
                                    setPageSize={setPageSize}
                                    totalEntries={totalEntries}
                                    deviceId={deviceId}              
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const LdpPeersTable = (props) => {
    const deviceId = props.deviceId;
    const ldpPeers = props.ldpPeers;
    const getLdpPeers = props.getLdpPeers;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"ldp-peer" :{}}});

    const columns = [
		{
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
            label: "1",
            Header: "Peer Name",
            accessor: "peerName",
            width:2
        },
        /* {
            label: "2",
            Header: "Peer LDP Id",
            accessor: "peerLdpId",
            filterable: true
        }, */
        {
            label: "3",
            Header: "Peer Label Distribution Method",
            accessor: "peerLabelDistMethod",
            width:3
        },
        {
            label: "4",
            Header: "Peer Path Vector Limit",
            accessor: "peerPathVectorLimit",
            filterable: true,
            width:3
        },
        {
            label: "5",
            Header: "Address Type",
            accessor: "peerTransportAddrType",
            filterable: true,
            width:3
        },
        {
            label: "6",
            Header: "Peer Transport Address",
            accessor: "peerTransportAddr",
            width:2
        },
        {
            label: "7",
            Header: "Peer Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:2
        }
	]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);
    
    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getLdpPeers(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"ldp-peer" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getLdpPeers(body)
    }
    
    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getLdpPeers(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    
    if (!ldpPeers && !ldpPeers.length)
        return null;
        
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>                              
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={ldpPeers}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="LDP Peers" 
                        fetchData={fetchData} 
                        location="ldp-peer-list"
                    />
                </Grid.Column>
            </Grid.Row>            
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.peerStatus == undefined ? false : row.original.peerStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}
export default LdpPeers;