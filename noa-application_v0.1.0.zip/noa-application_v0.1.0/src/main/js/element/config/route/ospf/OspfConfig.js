import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Checkbox,
    Tab,
    Menu,
    Icon,
    Input,
    Button,
    Divider
} from 'semantic-ui-react';

import {
    noMarginTB, noMarginLR, titleText, 
    subMenuItem, completeHeight, completeWidth, 
    tableHeaderHeight, noPadding, noBoxShadow, 
    applyButton, cancelButton, formParameter, 
    formTitle, tablePadding, autoHeight, 
    fullHeight, dividerStyle, formContentSpacingTB, 
    inputBoxStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import { NoaContainer, NoaHeader} from '../../../../widget/NoaWidgets';
import NoaLineChart from '../../../../widget/NoaLineChart';
import NoaFilter from '../../../../widget/NoaFilter';
import OspfNeighbours from './OspfNeighbours';
import OspfRouteRedistribution from './OspfRouteRedistribution';
import NoaToolbar from '../../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../../widget/NoaNotification';

const OspfConfig = (props) => {
    const deviceId = props.deviceId;
    
    const [ospfInstances, setOspfInstances] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = ospfInstances[sel[i]].ospfId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getOspfInstances = (filterObj) => {
        context.setRenderLocation(["ospf-instance-list"])
        NoaClient.post(
            "/api/element/" + deviceId + "/router/ospf",
            filterObj,
            (response) => {
                let responseData = response.data;
                setOspfInstances(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/router/ospf/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }

                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device" : {"device-id":[deviceId],"ospf-instance" :{}}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getOspfInstances(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <OspfInstanceTable ospfInstances={ospfInstances} getOspfInstances={getOspfInstances}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            deviceId={deviceId}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                        />
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const OspfInstanceTable = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const ospfInstances = props.ospfInstances;
    const getOspfInstances = props.getOspfInstances;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const deviceId = props.deviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;
    
    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"ospf-instance" :{}}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Identifier Name",
            accessor: "ospfInstanceName",
            width:2
		},
		{
			label: "2",
			Header: "Global Trace Level",
            accessor: "globalTraceLevel",
            width:2
		},
        {
			label: "4",
			Header: "SPF Compute Interval",
            accessor: "spfComputeInterval",
            width:2
		},
        {
			label: "5",
			Header: "Staggering Status",
            accessor: "staggeringStatus",
            width:2
        },
        {
			label: "6",
			Header: "Internal State",
            accessor: "internalState",
            width:2
        },
        {
			label: "7",
			Header: "TOS Support",
            accessor: "tosSupport",
            width:2
        },
        {
            label: "8",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:3
        }
    ]

    const router = useRouter();

    const handleAddOspfInstance = () => {
        router.stateService.go("add-ospf-instance",{deviceId:deviceId,fetchData: fetchData, clearSelection: clearSelection})
    }
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('view-ospf-instance',{id: ospfInstances[selId].ospfId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["ospf-instance-list"]);
        
        NoaClient.delete(
            "/api/element/" + deviceId + "/router/ospf/",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getOspfInstances(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"ospf-instance" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getOspfInstances(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getOspfInstances(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>OSPF Instances</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddOspfInstance}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={ospfInstances}
                                columns={columns}
                                selectedRows={selections}
                                onSelectedRowsChange={setSelections}   
                                clearSelected={clearSelected}
                                setClearSelected={setClearSelected}
                                selectedPageSize={pageSize}
                                handlePagination={handlePagination}
                                totalPages={totalPages}
                                handlePageSize={handlePageSize}
                                totalEntries={totalEntries}
                                resource="OSPF Instances" 
                                fetchData={fetchData} 
                                location="ospf-instance-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>   
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.instanceStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddOspfInstance = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    
    const getOspfInstances = props.fetchData;
    const clearSelection = props.clearSelection;
    const deviceId = props.deviceId;
    
    const [ospfInstance, setOspfInstance] = useState({});

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleChange = (value, key) => {
		setOspfInstance(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/element/" + deviceId + "/router/ospf/",
            ospfInstance,
            (response) => {
                noaNotification('success','OSPF Instance Created Successfully.')
                getOspfInstances()
                closeFooter();
        })
    }
    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create OSPF Instance</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-ospf-instance">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Identifier</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='ospfInstanceName' 
                                                                value={ospfInstance.ospfInstanceName}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'ospfInstanceName')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Global Trace Level</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='globalTraceLevel' 
                                                                value={ospfInstance.globalTraceLevel}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'globalTraceLevel')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>SPF Compute Interval</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='spfComputeInterval' 
                                                                value={ospfInstance.spfComputeInterval}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'spfComputeInterval')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Staggering Status</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='staggeringStatus' 
                                                                value={ospfInstance.staggeringStatus}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'staggeringStatus')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Internal State</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='internalState' 
                                                                    value={ospfInstance.internalState}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'internalState')
                                                                    }
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>TOS Support</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='tosSupport' 
                                                                    value={ospfInstance.tosSupport}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleChange(value, 'tosSupport')
                                                                    }
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter}>Operational Status</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Checkbox
                                                            toggle={true}
                                                            checked={ospfInstance.instanceStatus ? ospfInstance.instanceStatus : false}
                                                            onChange={
                                                                (e,data)=>handleChange(data.checked,'instanceStatus')
                                                            }
                                                        />
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            handleAdd()
                            context.setRenderLocation(["add-ospf-instance"]);
                        }}>Add</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}
const OspfInstanceManagement = (props) => {
    const router = useRouter();

    const clearSelection = props.clearSelection;
    const getOspfInstances = props.fetchData;

    const [deviceId, setDeviceId] = useState(null);
    const [ospfId, setOspfId] = useState(null);

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        const id = props.id;
        if(id != null && id != undefined && props.deviceId != null) {
            setDeviceId(props.deviceId);
            setOspfId(id);
        }
    },[props.id]);

    const panes = [
        {
            menuItem: <Menu.Item key='ospfNeighbours'><p style={subMenuItem}>OSPF Neighbours</p></Menu.Item>,
            render: () => 
                <Tab.Pane style={autoHeight}>
                <Grid style={completeHeight}>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <OspfNeighbours deviceId={deviceId} ospfId={ospfId} closeFooter={closeFooter}/>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Tab.Pane>
        },
        /* {
            menuItem: <Menu.Item key='stp'><p style={subMenuItem}>Route Redistribution</p></Menu.Item>,
            render: () => 
                <Tab.Pane style={autoHeight}>
                <Grid style={completeHeight}>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <OspfRouteRedistribution deviceId={deviceId} ospfId={ospfId} closeFooter={closeFooter}/>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Tab.Pane>
        }, */
        {
            menuItem: <Menu.Item key='statistics'><p style={subMenuItem}>Statistics</p></Menu.Item>,
            render: () => 
                <Tab.Pane style={autoHeight}>
                <Grid style={completeHeight}>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <OspfInstanceStatistics closeFooter={closeFooter}/>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Tab.Pane>
        },
    ]
    return(
        <NoaContainer style={completeWidth}>
            <Tab panes={panes} menu={{secondary: true, pointing: true,stackable: true}}/>
        </NoaContainer>
    )
}

const OspfInstanceStatistics = (props) => {
    const closeFooter = props.closeFooter;
    return(
        <Grid style={completeHeight}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaLineChart data={serviceThroughputValues} lineType={"linear"} colors={serviceThroughputColors}/>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const serviceThroughputColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}

const serviceThroughputValues = [
    {
        "DEL-PE-480": 2400,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 600,
        "BOM-CE-001": 1600,
        "VJA-P-980": 900,
    },
    {
        "DEL-PE-480": 1800,
        "BOM-CE-165": 1600,
        "DEL-PE-560": 200,
        "BOM-CE-001": 6800,
        "VJA-P-980": 2500,
    },
    {
        "DEL-PE-480": 5600,
        "BOM-CE-165": 5400,
        "DEL-PE-560": 200,
        "BOM-CE-001": 200,
        "VJA-P-980": 2400,
    },
    {
        "DEL-PE-480": 1526,
        "BOM-CE-165": 1426,
        "DEL-PE-560": 100,
        "BOM-CE-001": 3200,
        "VJA-P-980": 3000,
    },
    {
        "DEL-PE-480": 3600,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 1800,
        "BOM-CE-001": 400,
        "VJA-P-980": 500,
    },
    {
        "DEL-PE-480": 3200,
        "BOM-CE-165": 1000,
        "DEL-PE-560": 1200,
        "BOM-CE-001": 800,
        "VJA-P-980": 1700,
    },
    {
        "DEL-PE-480": 3300,
        "BOM-CE-165": 2600,
        "DEL-PE-560": 700,
        "BOM-CE-001": 750,
        "VJA-P-980": 1800,
    },
]
export default OspfConfig;
export {AddOspfInstance,OspfInstanceManagement}