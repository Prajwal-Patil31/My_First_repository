import React from 'react';

const StaticRoutes = () => {
    return(
        <div></div>
    )
}
export default StaticRoutes