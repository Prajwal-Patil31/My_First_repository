import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';
import { 
    Grid, Button, Checkbox, 
    Dropdown, Tab, Menu, 
    Icon, Divider, Input 
} from 'semantic-ui-react';

import { 
    noBoxShadow,noPadding, noMarginTB, 
    noMarginLR, titleText, formHeader, 
    formParameter, applyButton, cancelButton, 
    subMenuItem, completeHeight, completeWidth, 
    tablePadding, tableHeaderHeight,formTitle, 
    fullHeight, dividerStyle, inputBoxStyle, 
    formContentSpacingTB
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';

import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';

import {NoaContainer, NoaHeader} from '../../../../widget/NoaWidgets';
import BgpPeers from './BgpPeers';
import NoaToolbar from '../../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../../widget/NoaNotification';

const BgpConfig = (props) => {
    const deviceId = props.deviceId;
    
    const [bgpInstances, setBgpInstances] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});
    
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = bgpInstances[sel[i]].bgpId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getBgpInstances = (filterObj) => {
        context.setRenderLocation(["bgp-instance-list"]);
        NoaClient.post(
            "/api/element/" + deviceId + "/router/bgp",
            filterObj,
            (response) => {
                let responseData = response.data;
                setBgpInstances(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/router/bgp/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"network-device":{"device-id":[deviceId],"bgp-instance":{}}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getBgpInstances(filterCriteria);
                
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <BgpInstanceTable bgpInstances={bgpInstances} getBgpInstances={getBgpInstances}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            deviceId={deviceId}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                        />
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const BgpInstanceTable = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const bgpInstances = props.bgpInstances;
    const getBgpInstances = props.getBgpInstances;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const deviceId = props.deviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"network-device" : {"device-id":[deviceId],"bgp-instance" :{}}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Name",
            accessor: "bgpInstanceName",
            width:2
		},
		{
			label: "2",
			Header: "AS Number",
            accessor: "localAsNumber",
            width:1
		},
        {
			label: "4",
			Header: "Max Peers",
            accessor: "maxPeers",
            width:1
		},
        {
			label: "5",
			Header: "Current Peers",
            accessor: "currentPeers",
            width:2
        },
        {
			label: "6",
			Header: "Max Routes",
            accessor: "maxRoutes",
            width:2
        },
        {
			label: "7",
			Header: "Max IGBP Paths",
            accessor: "maxIbgpPaths",
            width:2
        },
        {
			label: "8",
			Header: "Max EBGP Paths",
            accessor: "maxEbgpPaths",
            width:2
        },
        {
			label: "9",
			Header: "Max EIBGP Paths",
            accessor: "maxEibgpPaths",
            width:2
        },
        {
            label: "8",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:1
        }
    ]

    const router = useRouter();

    const handleAddBgpInstance = () => {
        router.stateService.go("add-bgp-instance",{deviceId:deviceId,fetchData: fetchData, clearSelection: clearSelection})
    }
    
    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('view-bgp-instance',{id: bgpInstances[selId].bgpId,deviceId:deviceId,fetchData:fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["bgp-instance-list"]);
        
        NoaClient.delete(
			"/api/element/" + deviceId + "/router/bgp",
			selectedItems,
			(response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        });
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getBgpInstances(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"network-device" : {"device-id":[deviceId],"bgp-instance" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["network-device"] = [deviceId]
            setAppliedFilters(body)
        }
        getBgpInstances(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getBgpInstances(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left' style={titleText}>
                            BGP Instances
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddBgpInstance}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={bgpInstances}
                                columns={columns}
                                selectedRows={selections}
                                onSelectedRowsChange={setSelections}
                                clearSelected={clearSelected}
                                setClearSelected={setClearSelected}
                                selectedPageSize={pageSize}
                                handlePagination={handlePagination}
                                totalPages={totalPages}
                                handlePageSize={handlePageSize}
                                totalEntries={totalEntries}
                                resource="BGP Instances" 
                                fetchData={fetchData} 
                                location="bgp-instance-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.instanceStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddBgpInstance = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    
    const getBgpInstances = props.fetchData;
    const clearSelection = props.clearSelection;
    const deviceId = props.deviceId;
    
    const [bgpInstance, setBgpInstance] = useState({});

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleChange = (value, key) => {
		setBgpInstance(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/element/" + deviceId + "/router/bgp/",
            bgpInstance,
            (response) => {
                noaNotification('success','BGP Instance Created Successfully');
                getBgpInstances();
                closeFooter();
        })
    }
    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create BGP Instance</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-bgp-instance">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid columns={2} stackable>
                        <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                        <Grid.Column width={3}></Grid.Column>
                                        <Grid.Column width={4} textAlign='left'>
                                            <p style={formParameter} className="required">Identifier</p>
                                        </Grid.Column>
                                        <Grid.Column width={6} textAlign='left'>
                                            <Input type='text' name='bgpInstanceName' 
                                                        value={bgpInstance.bgpInstanceName}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleChange(value, 'bgpInstanceName')
                                                        }
                                            >
                                                <input style={inputBoxStyle}></input>
                                            </Input>
                                        </Grid.Column>
                                        <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Local AS Number</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='localAsNumber' 
                                                            value={bgpInstance.localAsNumber}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'localAsNumber')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Advt Non BGP Routes</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={bgpInstance.advtNonBgpRt ? bgpInstance.advtNonBgpRt : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'advtNonBgpRt')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>SNMP Notifications</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={bgpInstance.enableSnmpNotifications ? bgpInstance.enableSnmpNotifications : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'enableSnmpNotifications')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>  
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Max Routes</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxRoutes' 
                                                            value={bgpInstance.maxRoutes}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'maxRoutes')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                        </Grid.Column>
                        <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Max Peers</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxPeers' 
                                                            value={bgpInstance.maxPeers}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'maxPeers')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Max IBGP Paths</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxIbgpPaths' 
                                                            value={bgpInstance.maxIbgpPaths}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'maxIbgpPaths')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                        <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Max EBGP Paths</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxEbgpPaths' 
                                                            value={bgpInstance.maxEbgpPaths}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'maxEbgpPaths')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Max EIBGP Paths</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxEibgpPaths' 
                                                            value={bgpInstance.maxEibgpPaths}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'maxEibgpPaths')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Operational Status</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={bgpInstance.instanceStatus ? bgpInstance.instanceStatus : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'instanceStatus')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            context.setRenderLocation(['add-bgp-instance'])
                            handleAdd()
                        }}>Add</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const BgpInstanceManagement = (props) => {
    const router = useRouter();

    const clearSelection = props.clearSelection;
    const getBgpInstances = props.fetchData;

    const [deviceId, setDeviceId] = useState(null);
    const [bgpId, setBgpId] = useState(null);

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        const id = props.id;
        if(id != null && id != undefined && props.deviceId != null) {
            setDeviceId(props.deviceId);
            setBgpId(id);
        }
    },[props.id]);

    const panes = [
        {
            menuItem: <Menu.Item key='bgpPeers'><p style={subMenuItem}>BGP Peers</p></Menu.Item>,
            render: () => 
                <Tab.Pane style={{height: "auto"}}>
                    <Grid style={completeHeight}>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <BgpPeers bgpId={bgpId} deviceId={deviceId} closeFooter={closeFooter}/>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Tab.Pane>
        },
        {
            menuItem: <Menu.Item key='advanced'><p style={subMenuItem}>Advanced Configuration</p></Menu.Item>,
            render: () => 
                <Tab.Pane style={{height: "auto"}}>
                    <Grid style={completeHeight}>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <BgpAdvanceConfig bgpId={bgpId} deviceId={deviceId} closeFooter={closeFooter}/>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Tab.Pane>
        },
        /* {
            menuItem: <Menu.Item key='stp'><p style={subMenuItem}>Route Redistribution</p></Menu.Item>,
            render: () => 
                <Tab.Pane style={{height: "auto"}}>
                    <Grid style={completeHeight}>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16} textAlign='right'>
                                <Grid columns={3} stackable>
                                    <Grid.Column width={7}></Grid.Column>
                                    <Grid.Column width={8}></Grid.Column>
                                    <Grid.Column width={1}>
                                        
                                    </Grid.Column>
							    </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <BgpRouteRedistribution bgpId={bgpId} deviceId={deviceId}/>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Tab.Pane>
        } */
    ]
    return(
        <NoaContainer style={completeWidth}>
            <Tab panes={panes} menu={{secondary: true, pointing: true,stackable: true}}/>
        </NoaContainer>
    )
}

const BgpAdvanceConfig = (props) => {
    const bgpId = props.bgpId;
    const deviceId = props.deviceId;
    const closeFooter = props.closeFooter;

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const [bgpInstance, setBgpInstance] = useState({});

    const handleChange = (value, key) => {
		setBgpInstance(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const getBgpInstance = () => {
        NoaClient.get(
            "/api/element/" + deviceId + "/router/bgp/" + bgpId,
            (response) => {
                let responseData = response.data;
                setBgpInstance(responseData);
            }
        )
    }

    const handleModify = () => {
        NoaClient.post(
            "/api/element/" + deviceId + "/router/bgp/" + bgpId,
            bgpInstance,
            (response) => {
                noaNotification('success','BGP Configuration Updated Successfully');
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        context.setRenderLocation(["bgp-configuration"])
        getBgpInstance();
    },[props.bgpId]);
    
    return(
        <Grid columns={3} style={completeHeight}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} id="bgp-configuration">
                <Grid columns={3} stackable>
                    <Grid.Column width={3}></Grid.Column>
                    <Grid.Column width={12}>
                        <Grid columns={3} stackable>
                            <Grid.Column computer={7} tablet={16} mobile={16}>
                                <Grid textAlign='left'>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} textAlign='center'>
                                            <p style={formHeader}>Advanced Functions</p>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={2} stackable>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <p style={formParameter}>Synchronization with AS</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <Checkbox
                                                                toggle={true}
                                                                checked={bgpInstance.syncWithAs ? bgpInstance.syncWithAs : false}
                                                                onChange={
                                                                    (e,data)=>handleChange(data.checked,'syncWithAs')
                                                                }
                                                            />
                                                        </Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>


                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={2} stackable>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <p style={formParameter}>Advertise Non-BGP Routes</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <Checkbox
                                                                toggle={true}
                                                                checked={bgpInstance.advtNonBgpRoutes ? bgpInstance.advtNonBgpRoutes : false}
                                                                onChange={
                                                                    (e,data)=>handleChange(data.checked,'advtNonBgpRoutes')
                                                                }
                                                            />
                                                        </Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>


                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={2} stackable>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <p style={formParameter}>Enable SNMP Notifications</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <Checkbox
                                                                toggle={true}
                                                                checked={bgpInstance.enableSnmpNotifications ? bgpInstance.enableSnmpNotifications : false}
                                                                onChange={
                                                                    (e,data)=>handleChange(data.checked,'enableSnmpNotifications')
                                                                }
                                                            />
                                                        </Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={2} stackable>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <p style={formParameter}>Peer IPv4 Unicast Capability</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <Checkbox
                                                                toggle={true}
                                                                checked={bgpInstance.unicastCapability ? bgpInstance.unicastCapability : false}
                                                                onChange={
                                                                    (e,data)=>handleChange(data.checked,'unicastCapability')
                                                                }
                                                            />
                                                        </Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>


                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={2} stackable>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <p style={formParameter}>VPN Route Leaking</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={8} textAlign='left'>
                                                            <Checkbox
                                                                toggle={true}
                                                                checked={bgpInstance.vpnRouteLeaking ? bgpInstance.vpnRouteLeaking : false}
                                                                onChange={
                                                                    (e,data)=>handleChange(data.checked,'vpnRouteLeaking')
                                                                }
                                                            />
                                                        </Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                            </Grid.Column>

                            <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                            <Grid.Column computer={7} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} textAlign='center'>
                                            <p style={formHeader}>Graceful Restart</p>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={2} stackable>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Enable Graceful Restart</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Checkbox
                                                            toggle={true}
                                                            checked={bgpInstance.enableGracefulRestart ? bgpInstance.enableGracefulRestart : false}
                                                            onChange={
                                                                (e,data)=>handleChange(data.checked,'enableGracefulRestart')
                                                            }
                                                        />
                                                    </Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={2} stackable>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Graceful Restart Status</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Input type='text' name='grStatus' 
                                                                    value={bgpInstance.grStatus}
                                                                    fluid={false}
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={2} stackable>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Graceful Restart Outcome</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Input type='text' name='grOutcome' 
                                                                    value={bgpInstance.grOutcome}
                                                                    fluid={false}
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={2} stackable>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Graceful Restart Reason</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Input type='text' name='grReason' 
                                                                    value={bgpInstance.grReason}
                                                                    fluid={false}
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={2} stackable>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Graceful Restart Support</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Input type='text' name='grSupport' 
                                                                    value={bgpInstance.grSupport}
                                                                    fluid={false}
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={2} stackable>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Forwarding Plane Reservation</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <Checkbox
                                                            toggle={true}
                                                            checked={bgpInstance.fwPlanePreservation ? bgpInstance.fwPlanePreservation : false}
                                                            onChange={
                                                                (e,data)=>handleChange(data.checked,'fwPlanePreservation')
                                                            }
                                                        />
                                                    </Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                    <Grid.Column width={3}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "2em"}} columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            handleModify()
                            context.setRenderLocation(["bgp-configuration"]);
                        }}>Update</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const grStatus = [
    {
        key: 'downstreamOnDemand',
        text: 'Down Stream On Demand',
        value: 'plannedRestart',
    },
    {
        key: 'downstreamUnsolicited',
        text: 'Down Stream Unsolicited',
        value: 'unplannedRestart',
    }
];

const grExitReason = [
    {
        key: 'downstreamOnDemand',
        text: 'Down Stream On Demand',
        value: 'inProgress',
    },
    {
        key: 'downstreamUnsolicited',
        text: 'Down Stream Unsolicited',
        value: 'failure',
    },
    {
        key: 'downstreamUnsolicited',
        text: 'Down Stream Unsolicited',
        value: 'complete',
    },
];

const grReason = [
    {
        key: 'downstreamOnDemand',
        text: 'Down Stream On Demand',
        value: 'unknown',
    },
    {
        key: 'downstreamUnsolicited',
        text: 'Down Stream Unsolicited',
        value: 'softwareRestart',
    },
    {
        key: 'downstreamUnsolicited',
        text: 'Down Stream Unsolicited',
        value: 'swReloadUpgrade',
    },
];
export default BgpConfig;
export {AddBgpInstance, BgpInstanceManagement}