import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Checkbox,
    Button,
    Icon,
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight, 
    cancelButton
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';
import { NoaContainer} from '../../../../widget/NoaWidgets';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const OspfNeighbours = (props) => {   
    const deviceId = props.deviceId;
    const ospfId = props.ospfId;
    const closeFooter = props.closeFooter;

    const [neighbours, setNeighbours] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = neighbours[sel[i]].neighbourId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const getOspfNeighbours = () => {
        context.setRenderLocation(["ospf-neighbour-list"])
        NoaClient.get(
            "/api/element/" + deviceId + "/router/ospf/" + ospfId + "/neighbour",
            (response) => {
                let responseData = response.data;
                setNeighbours(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getOspfNeighbours();
    },[props.ospfId]);

    return (
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
        <Grid style={Object.assign({},completeHeight, noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <OspfNeighboursTable neighbours={neighbours} getOspfNeighbours={getOspfNeighbours}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected}
                                    clearSelected={clearSelected}
                                    closeFooter={closeFooter}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const OspfNeighboursTable = (props) => {
    const closeFooter = props.closeFooter;
    const neighbours = props.neighbours;
    const getOspfNeighbours = props.getOspfNeighbours;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const [selections,setSelections] = useState([]);

    const columns = [
		{
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Neighbour Name",
            accessor: "neighbourName",
            width:2
		},
        {
			label: "4",
			Header: "IP Address",
            accessor: "ipAddress",
            width:2
		},
        {
			label: "5",
			Header: "Address Less Index",
            accessor: "addressLessIndex",
            width:2
        },
  
        {
            label: "6",
            Header: "BFD State",
            Cell: ({row}) => (
                renderBoolean(row,"bfdState")
            ),
            width:2
        },
        {
			label: "7",
			Header: "Graceful Restart Status",
            accessor: "gracefulRestartStatus",
            width:2
        },
        {
			label: "8",
			Header: "Graceful Restart Status",
            accessor: "gracefulRestartReason",
            width:3
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"neighbourState")
            ),
            width:2
        }
	]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);
    
    
    if (!neighbours && !neighbours.length)
        return null;
        
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                                                  
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={neighbours}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        resource="OSPF Instances" 
                        fetchData={getOspfNeighbours} 
                        location="ospf-neighbour-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2} stackable>
                        <Grid.Column width={8} textAlign='right'>

                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>               
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

export default OspfNeighbours;