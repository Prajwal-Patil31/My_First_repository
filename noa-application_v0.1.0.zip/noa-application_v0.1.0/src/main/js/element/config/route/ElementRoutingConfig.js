import React from 'react';

import {
    Tab,
    Menu,
    Segment,
    Grid
} from 'semantic-ui-react';

import { completeWidth, fullHeight, cardLayout, nMenuItem} from '../../../constants';

import { NoaContainer} from '../../../widget/NoaWidgets';
import BgpConfiguration from './bgp/BgpConfig';
import OspfConfig from './ospf/OspfConfig';
import StaticRoutes from './StaticRoutes';

const ElementRoutingConfig = (props) => {
    const deviceId = sessionStorage.getItem("elementId"); 

    const panes = [
        {
            menuItem:   <Menu.Item key='bgp' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            BGP
                        </Menu.Item>,
            render: () => <BgpConfiguration deviceId={deviceId}/>
        },
        {
            menuItem:   <Menu.Item key='ospf' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            OSPF
                        </Menu.Item>,
            render: () => <OspfConfig deviceId={deviceId}/>
        },
        {
            menuItem:   <Menu.Item key='static-routes' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>
                            Static Routes
                        </Menu.Item>,
            render: () => <StaticRoutes deviceId={deviceId}/>
        }
    ]

    return(
        <NoaContainer style={Object.assign({display: "flex",flexDirection: "column"},fullHeight,completeWidth)}>
            <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                            <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} />
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Segment>
        </NoaContainer>
    )
}

export default ElementRoutingConfig;