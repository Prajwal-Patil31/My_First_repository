import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';
import {
    Grid,
    Checkbox,
    Button,
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight, cancelButton
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';
import { NoaContainer} from '../../../../widget/NoaWidgets';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const OspfRouteRedistribution = (props) => {   
    const deviceId = props.deviceId;
    const ospfId = props.ospfId;
    const closeFooter = props.closeFooter;

    const [rrdInstances, setRrdInstances] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
		let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
			const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = rrdInstances[sel[i]].configId;
				selections.push(id);
			}
            setSelectedRows(selections);
		}
    }

    const getRrdInstances = () => {
        context.setRenderLocation(['ospf-rrd-list'])
        NoaClient.get(
            "/api/element/" + deviceId + "/router/ospf/" + ospfId + "/redist",
            (response) => {
                let responseData = response.data;
                setRrdInstances(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getRrdInstances();
    },[props.ospfId]);

    return (
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
        <Grid style={Object.assign({},completeHeight, noMarginTB,noMarginLR)}>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <OspfRrdTable rrdInstances={rrdInstances} getRrdInstances={getRrdInstances}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected}
                                    clearSelected={clearSelected}
                                    closeFooter={closeFooter}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const OspfRrdTable = (props) => {
    const closeFooter = props.closeFooter;
    const rrdInstances = props.rrdInstances;
    const getRrdInstances = props.getRrdInstances;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const [selections,setSelections] = useState([]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Destination Address",
            accessor: "destinationAddress",
            width:3
		},
        {
			label: "4",
			Header: "Destination Mask",
            accessor: "destinationMask",
            width:2
		},
        {
			label: "5",
			Header: "Route Metric Type",
            accessor: "routeMetricType",
            width:3
        },
        {
			label: "6",
			Header: "Route Metric",
            accessor: "routeMetric",
            width:3
        },
        {
			label: "7",
			Header: "Route Tag Type",
            accessor: "routeTagType",
            width:2
        },
        {
			label: "8",
			Header: "Route Tag",
            accessor: "routeTag",
            width:2
        }
    ]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);
    
    
    if (!rrdInstances && !rrdInstances.length)
        return null;
        
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                                                  
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>                    
                    <NoaTable data={rrdInstances}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        resource="OSPF RRD Instances" 
                        fetchData={getRrdInstances} 
                        location="ospf-rrd-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2} stackable>
                        <Grid.Column width={8} textAlign='right'>

                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button onClick={closeFooter} style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>              
        </Grid>    
        </NoaContainer>
    )
}

export default OspfRouteRedistribution;