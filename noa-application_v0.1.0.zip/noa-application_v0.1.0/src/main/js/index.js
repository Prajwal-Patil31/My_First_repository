import React from 'react';
import ReactDOM from 'react-dom';
import '../resources/static/fonts/CiscoSansTTLight.woff';
import '../resources/static/fonts/OpenSansLight.ttf';
import '../resources/static/fonts/OpenSansRegular.ttf';
import '../resources/static/fonts/OpenSansSemiBold.ttf';
import '../resources/static/fonts/MontserratRegular.ttf';
import '../resources/static/fonts/MontserratLight.ttf';
import '../resources/static/fonts/MontserratSemiBold.ttf';
import './index.css';
import './App.css';

import "leaflet/dist/leaflet.css";
import App from './App';

ReactDOM.render(<App />, document.getElementById('react'));