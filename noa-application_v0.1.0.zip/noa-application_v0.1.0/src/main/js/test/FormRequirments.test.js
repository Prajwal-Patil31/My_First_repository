//Form Testing 1
jest.mock('../../api/uriTemplateInterceptor', () => {
    'use strict';

    const interceptor = require('rest/interceptor');

    return interceptor({
        request: function (request) {
            if (request.path.indexOf('{') === -1) {
                return request;
            } else {
                request.path = request.path.split('{')[0];
                return request;
            }
        }
    });
});

jest.mock('../../api/uriListConverter', () => {
    'use strict';

    return {
        read: function (str) {
            return str.split('\n');
        },
        write: function (obj) {
            if (obj instanceof Array) {
                return obj.map(resource => resource._links.self.href).join('\n');
            } else {
                return obj._links.self.href;
            }
        }
    };
});

jest.mock('react-router-dom', () => {
    const originalModule = jest.requireActual('react-router-dom');

    return {
        __esModule: true,
        ...originalModule,
        useNavigate: jest.fn(),
        useLocation: jest.fn().mockReturnValue({ pathname: 'Home/security/roles' }),
    };
});

import React from "react";
import { unmountComponentAtNode } from "react-dom";
import { CreatePasswordPolicy } from "./PasswordPolicy";

import { mount, configure } from 'enzyme';

import Adapter from 'enzyme-adapter-react-16';
import { render, screen, fireEvent, waitFor } from "@testing-library/react";

let container = null;
beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

const getPolicies = jest.fn();

describe('Validating Form-Field requirments based on UserInputs', () => {
    it('Checking Effectiveness of Form Requirments based on User Inputs', async () => {
        const { getByTestId, queryByText } = render(<CreatePasswordPolicy getPolicies={getPolicies} />);
        fireEvent.click(screen.getByTestId('button'));
        // expect(screen.getByTestId('drawerBodyCreate')).toHaveTextContent('Policy Name');
        const element = getByTestId('input');
        const elementInput = element.children[0];
        fireEvent.change(elementInput, { target: { name: 'policyName', value: 'po' } });
        fireEvent.click(screen.getByText('Submit'));
        //expect(screen.queryByTestId('drawerBodyCreate')).not.toBeNull();
        await waitFor(screen.queryByText('Too Short'),() => {
        expect(screen.queryByText('Too Short')).not.toBeNull();
        });

    });
});