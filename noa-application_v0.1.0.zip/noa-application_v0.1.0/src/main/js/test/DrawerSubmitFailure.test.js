//Drawer 6 test
jest.mock('../../api/uriTemplateInterceptor', () => {
    'use strict';

    const interceptor = require('rest/interceptor');

    return interceptor({
        request: function (request) {
            if (request.path.indexOf('{') === -1) {
                return request;
            } else {
                request.path = request.path.split('{')[0];
                return request;
            }
        }
    });
});

jest.mock('../../api/uriListConverter', () => {
    'use strict';

    return {
        read: function (str) {
            return str.split('\n');
        },
        write: function (obj) {
            if (obj instanceof Array) {
                return obj.map(resource => resource._links.self.href).join('\n');
            } else {
                return obj._links.self.href;
            }
        }
    };
});

jest.mock('react-router-dom', () => {
    const originalModule = jest.requireActual('react-router-dom');

    return {
        __esModule: true,
        ...originalModule,
        useNavigate: jest.fn(),
        useLocation: jest.fn().mockReturnValue({ pathname: 'Home/security/roles' }),
    };
});

import React, { createFactory } from "react";
import { CreatePasswordPolicy } from "./PasswordPolicy";
import { render, screen, fireEvent, waitForElementToBeRemoved, } from "@testing-library/react";
import { unmountComponentAtNode } from "react-dom";
import userEvent from '@testing-library/user-event';
import { mount, configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

let container = null;
beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

const getPolicies = jest.fn();
const getSelected = jest.fn();

describe('Drawer Clears the Data after Submit/Cancel', () => {
    it('Testing input Fields of drawer to be clear', () => {
        const wrapper = mount(<CreatePasswordPolicy getPolicies={getPolicies} getSelected={getSelected} />);

        wrapper.find('button').simulate('click');
        wrapper.find('input[name="policyName"]').simulate('change', { target: { name: 'policyName', value: 'policy13' } });
        wrapper.find('button[data-testid="submitButton"]').simulate('click');
        expect(wrapper.find('drawer[data-testid="drawerBodyCreate"]')).not.toBeNull();

    });
});
