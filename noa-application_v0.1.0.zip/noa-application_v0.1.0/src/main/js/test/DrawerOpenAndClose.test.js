//Drawer1&2 tests
jest.mock('../../api/uriTemplateInterceptor', () => {
    'use strict';

    const interceptor = require('rest/interceptor');

    return interceptor({
        request: function (request) {
            if (request.path.indexOf('{') === -1) {
                return request;
            } else {
                request.path = request.path.split('{')[0];
                return request;
            }
        }
    });
});

jest.mock('../../api/uriListConverter', () => {
    'use strict';

    return {
        read: function (str) {
            return str.split('\n');
        },
        write: function (obj) {
            if (obj instanceof Array) {
                return obj.map(resource => resource._links.self.href).join('\n');
            } else {
                return obj._links.self.href;
            }
        }
    };
});

jest.mock('react-router-dom', () => {
    const originalModule = jest.requireActual('react-router-dom');

    return {
        __esModule: true,
        ...originalModule,
        useNavigate: jest.fn(),
        useLocation: jest.fn().mockReturnValue({ pathname: 'Home/security/roles' }),
    };
});

import React from "react";
import { CreateRole  } from "./Role";
import { render, screen, fireEvent, waitForElementToBeRemoved } from "@testing-library/react";
import { unmountComponentAtNode } from "react-dom";


let container = null;
beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

const getRoles= jest.fn();
const features_dd = {};


describe("Testing on Create and Cancel Buttons", () => {
    it("Testing Button with Toggle", async () => {
        
       const {getByTestId, queryByTestId}= render(<CreateRole getRoles={getRoles} features_dd={features_dd} />);
       
        fireEvent.click(screen.getByTestId('createButton'));
        expect(screen.getByTestId('drawerBody')).toHaveTextContent('Role Name');
    
        fireEvent.click(screen.getByTestId('cancelButton'));
        await waitForElementToBeRemoved(screen.getByTestId('drawerBody'), () => {
            expect(screen.queryByTestId('drawerBody')).toBeNull();
        });
    });
});
