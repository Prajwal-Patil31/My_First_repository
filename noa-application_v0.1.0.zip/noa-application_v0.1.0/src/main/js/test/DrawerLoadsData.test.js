//Drawer 3&4 test
jest.mock('../../api/uriTemplateInterceptor', () => {
    'use strict';

    const interceptor = require('rest/interceptor');

    return interceptor({
        request: function (request) {
            if (request.path.indexOf('{') === -1) {
                return request;
            } else {
                request.path = request.path.split('{')[0];
                return request;
            }
        }
    });
});

jest.mock('../../api/uriListConverter', () => {
    'use strict';

    return {
        read: function (str) {
            return str.split('\n');
        },
        write: function (obj) {
            if (obj instanceof Array) {
                return obj.map(resource => resource._links.self.href).join('\n');
            } else {
                return obj._links.self.href;
            }
        }
    };
});

jest.mock('react-router-dom', () => {
    const originalModule = jest.requireActual('react-router-dom');

    return {
        __esModule: true,
        ...originalModule,
        useNavigate: jest.fn(),
        useLocation: jest.fn().mockReturnValue({ pathname: 'Home/security/polcies-password' }),
    };
});

import React from "react";
import { unmountComponentAtNode } from "react-dom";
import { ModifyPasswordPolicy } from "./PasswordPolicy";

import { mount, configure } from 'enzyme';

import Adapter from 'enzyme-adapter-react-16';

configure({ adapter: new Adapter() });

let container = null;
beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
});

afterEach(() => {
    unmountComponentAtNode(container);
    container.remove();
    container = null;
});

const initialState = {
    "policyId": "",
    "policyName": "",
    "maxFailAttempts": "",
    "passExpDays": "",
    "minLength": "",
    "minDigits": "",
    "minSplChar": "",
    "minUpperChar": "",
    "minLowerChar": "",
    "numMultLogin": "",
    "minReuseDays": ""
}

const passwordPolicy = {
    "policyId": 3,
    "policyName": "policy13",
    "maxFailAttempts": 3,
    "passExpDays": 4,
    "minLength": 5,
    "minDigits": 6,
    "minSplChar": 7,
    "minUpperChar": 8,
    "minLowerChar": 9,
    "numMultLogin": 10,
    "numOldPass": 11,
    "minReuseDays": 12,
};

const getSelected = jest.fn().mockImplementation(() => {
    return 3;
});

const getPolicies = jest.fn();

describe('Verifying Drawer loads Selected Data in Drawer Input Fields', () => {
    it('Testing the Data whether reflecting or not in Drawer',async () => {

        const wrapper = mount(
            <ModifyPasswordPolicy getSelected={getSelected} getPolicies={getPolicies} />);

        const modifyButton = wrapper.find('button');
        modifyButton.simulate('click');
        wrapper.setState({ passwordpolicy: passwordPolicy });
        expect(wrapper.state('passwordpolicy')).toEqual(passwordPolicy);
        const cancel = wrapper.find('button[data-testid="cancelButton"]');
        cancel.simulate('click');
        const state = await wrapper.state('passwordpolicy');
        expect(state).toEqual(initialState);
    });
});