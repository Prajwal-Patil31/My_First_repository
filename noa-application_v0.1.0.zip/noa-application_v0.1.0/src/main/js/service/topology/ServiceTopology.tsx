// @flow

import React, { useState, useEffect, useContext } from 'react';

import useNext, {
	TopologyConfig,
	TopologyData,
	EventHandlers,
	TopologyNode,
	TopologyLink
} from "../../lib/modules/Next";

import {useLocation } from 'react-router-dom';

import {
	Grid,
	Container,
	Dropdown,
	Checkbox,
	Segment,
	Menu,
	Popup,
	Label
} from 'semantic-ui-react';

import "../../lib/next/css/next.min.css";
import 'semantic-ui-css/semantic.min.css';

import { 
	subMenuItem, bodyLayoutFlex, completeHeight, 
	completeWidth, topologyContainer, subMenuLayout, 
	topologyChartValue, topologyChartDesc, topologyChartTitle, 
	noPadding, dropdownStyle
} from '../../constants';

import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';
import useOutsideClickAlert from '../../utility/useOutsideClickAlert';
import {NodeTooltip,LinkTooltip} from '../../widget/TopoTooltip';
import { NoaContainer } from '../../widget/NoaWidgets';
import { createPortal } from 'react-dom';

const sampleConfig: TopologyConfig = {
	'adaptive': true,
	'showIcon': true,
	'nodeConfig': {
		'label': 'model.name',
		'iconType': 'router',
		'color': 'model.color',
	},
	'linkConfig': {
		'linkType': 'curve',
		'color' : 'model.color'
	},
	'layoutType' : 'INMap',
	'layoutConfig': {
		'longitude': 'model.longitude',
		'latitude': 'model.latitude'
	},
	'nodeSetConfig': {
		'identityKey': 'name',
		'label': 'model.name',
		'iconType': 'router',
		'color': 'model.color',
	},
	'identityKey': 'name',
	'dataProcessor': 'force',
	'enableSmartLabel': true,
	'enableGradualScaling': true,
	'supportMultipleLink': true
};

const locations = [
	{"latitude": 76.420, "longitude": -19.745},
	{"latitude": 68.825, "longitude": 12.785},
	{"latitude": 77.850, "longitude": 98.177},
	{"latitude": 31.839,"longitude": -40.798},
	{"latitude": 82.843,"longitude": -91.105},
	{"latitude": 57.578,"longitude": -87.143},
	{"latitude": 86.832,"longitude": -68.099},
	{"latitude": 69.203, "longitude": -111.016},
	{"latitude": 78.018, "longitude": -109.743},
	{"latitude": 47.900, "longitude": -92.778},
	{"latitude": 18.591,"longitude": -81.478},
	{"latitude": 8.350, "longitude": -43.811},
	{"latitude": -27.422, "longitude": -44.941},
	{"latitude": 68.688,"longitude": -39.572},
	{"latitude": 69.905, "longitude": 95.933},
	{"latitude": 66.409,"longitude": 48.849},
]

const nodeSetLocations = [
	{ "x": 597.621281446664, "y": 250.78890844737532 },
	{ "x": 650.621281446664, "y": 300.78890844737532 }
];

const ServiceTopologyContext = React.createContext();

const ServiceTopologyProvider = (props) => {
	const serviceId = sessionStorage.getItem("serviceId");

	const [networks, setNetworks] = useState([]);
	const [selNetworks, setSelNetworks] = useState([]);
	const [serviceFilter, setServiceFilter] = useState(null);

	const [paths, setPaths] = useState([]);
	const [selPaths, setSelPaths] = useState([]);

	const getProvisionedNetworks = () => {
        NoaClient.get(
            "/api/service/" + serviceId + "/network",
            (response) => {
                let responseData = response.data;
                let networksList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        networksList[index] = nodeObj;
                    })
                }
                setNetworks(networksList);
            }
        )
	}

	const getServicePaths = () => {
        NoaClient.get(
            "/api/service/" + serviceId + "/path",
            (response) => {
                let responseData = response.data;
                let pathsList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let pathObj = {'key' : item.pathId, 'value' : item.pathId, 'text': item.pathName}
                        pathsList[index] = pathObj;
                    })
                }
                setPaths(pathsList);
            }
        )
	}

	useEffect(() => {
		getProvisionedNetworks();
		getServicePaths();
	},[]);

    return (
        <ServiceTopologyContext.Provider
            value={{
                selNetworks: selNetworks,
				setSelNetworks: setSelNetworks,
				networks: networks,
				serviceFilter: serviceFilter,
				setServiceFilter: setServiceFilter,
				paths: paths,
				setSelPaths: setSelPaths,
				selPaths: selPaths
            }}
        >
            {props.children}
        </ServiceTopologyContext.Provider>
    )
}
const ServiceTopologyConsumer = ServiceTopologyContext.Consumer;

const ServiceTopology = (props) => {
	const serviceId = sessionStorage.getItem("serviceId");
	const serviceName = sessionStorage.getItem("serviceName");
	return (
		<NoaContainer style={Object.assign({},bodyLayoutFlex, completeHeight,completeWidth)}>
			<ServiceTopologyProvider>
			<Grid style={completeHeight}>
				<NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
					<Grid.Row columns={1} style={completeHeight}>
						<Grid.Column width={16} style={completeHeight}>
							<ServiceTopologyView serviceId={serviceId} serviceName={serviceName}/>
						</Grid.Column>
					</Grid.Row>
				</NoaContainer>
			</Grid>
			</ServiceTopologyProvider>
		</NoaContainer>		
		)
};

const ServiceTopologyView = (props) => {
	const location = useLocation();
	const serviceId = props.serviceId;
    const serviceName = props.serviceName;

	const context = useContext(GlobalSpinnerContext);
	const redirectContext = useContext(RouteRediretContext);
	const topologyContext = useContext(ServiceTopologyContext);

	const [networkTopology, setNetworkTopology] = useState({});
	const [sampleTopology, setSampleTopology] = useState<TopologyData>({} as TopologyData);
	const [topology, setTopology] = useState(sampleTopology);
    
	const [nodeId, setNodeId] = useState(null);
	const [nodeDetails, setNodeDetails] = useState({});
	const [linkId, setLinkId] = useState(null);
	const [linkDetails, setLinkDetails] = useState({});

	const [networkDetails, setNetworkDetails] = useState({});
	const [servicePaths, setServicePaths] = useState([]);

	const [renderNodeTooltip, setRenderNodeTooltip] = useState(false);
	const [renderLinkTooltip, setRenderLinkTooltip] = useState(false);

	const { ref, isClickedOutside } = useOutsideClickAlert(false);

	const topologyViews = {
		'BASIC': 'Basic View',
		'NETWORK_SLICE': 'Slices View',
		'BASE_NETWORK': 'Base Networks View',
		'SHOW_HIERARCHY': 'Show Hierarchy',
		'SHOW_TRAFFIC': 'Show Traffic'
	}

	const getNetworkTopology = () => {
		NoaClient.get(
			"/api/service/" + serviceId + "/topology",
            (response) => {
				let responseData = response.data;
				setNetworkTopology(responseData);			
            }
		)
	}
	
	const handleLinkClick = (link) => {
		setRenderLinkTooltip(true);
		setLinkId(link.id());
	}

	const handleNodeClick = (node) => {
		setRenderNodeTooltip(true);
		setNodeId(node.id());
	}

	const getNodeDetails = () => {
		let nodes = networkTopology.nodes;
		let selNode = nodes.find(node => node.name === nodeId);
		let elementId = selNode.id;
		NoaClient.get(
			"/api/element/" + elementId,
            (response) => {
				let responseData = response.data;
				setNodeDetails(responseData);
            }
        )
	}
	
	const getLinkDetails = () => {
		NoaClient.get(
			"/api/service/"+ serviceId + "/pathhop/"+ linkId,
            (response) => {
				let responseData = response.data;
				setLinkDetails(responseData);
            }
        )
	}
	
	useEffect(() => {
		if(nodeId != null) {
			context.setRenderLocation(["tooltip-node"]);
			getNodeDetails();
		}
	},[nodeId]);

	useEffect(() => {
		if(linkId != null) {
			context.setRenderLocation(["tooltip-link"]);
			getLinkDetails();
		}
	},[linkId]);

	useEffect(() => {
		NoaClient(context, redirectContext);
		context.setRenderLocation(["service-specific-topology"]);
        getNetworkTopology();
	},[]);

	useEffect(() => {
        if(networkTopology != null) {
            setTopologyData(networkTopology);
        }
    },[networkTopology]);

	function getLinksBetweenNodes(topo, src, dest) {
		var sid = src.id();
		var did = dest.id();

		var linkSet = topo.getLinkSet(sid, did);		

		if (linkSet !== null) {
			return window.nx.util.values(linkSet.links());
		}
		return false;
	}

	function getLinkList(topo, nodesDict, pathHops) {

		var linkList = [];

		for (var i = 0; i < pathHops.length - 1; i++) {

			var srcNode = nodesDict.getItem(pathHops[i]);
			var destNode = nodesDict.getItem(pathHops[i + 1]);

			var links = getLinksBetweenNodes(topo, srcNode, destNode);
			if (links != false) {
				linkList.push(links[0]);
			}
		}

		return linkList;
	}

	var pathLayer = [];
	var nodesDict = [];
	var nodesLayer = [];
	var nodeSetLayer = [];

	useEffect(() => {
		if(isClickedOutside) {
			nxApp.tooltipManager().closeAll();
		}
	}, [isClickedOutside])

    function drawPath(nxApp, pathHops,color) {
		/* TODO: Explore topology.on() for post-render callback */
		pathLayer = nxApp.getLayer("paths");
		nodesDict = nxApp.getLayer("nodes").nodeDictionary();
		var linkList = getLinkList(nxApp, nodesDict, pathHops);
		var pathInst;
		if(linkList.length>1) {
			pathInst = new window.nx.graphic.Topology.Path({
				"pathWidth": 3,
				"links": linkList,
				"arrow": "cap",
				"sourceNode": nodesDict.toArray()[0],
				"pathStyle": {
					"fill": color
				}
			});
			pathLayer.addPath(pathInst);
		}
    }
    
    
	let modifiedNodes = [];
	let modifiedLinks = [];
	let links = [];

	const setTopologyData = (networkTopology) => {
		if(Array.isArray(networkTopology["nodes"]) && Array.isArray(networkTopology["links"])) {
			let nodes = networkTopology["nodes"];
			let links = networkTopology["links"];
			let nodeSets = networkTopology["nodeSet"];
			
			if (nodes.length) {
				
				modifiedNodes = nodes.map((node,index) => {

					let nodeObj = {};
					let nodeId = node["name"];

					nodeObj["id"] = nodeId;
					nodeObj["name"] = nodeId;
					nodeObj["latitude"] = locations[index % locations.length].latitude;
					nodeObj["longitude"] = locations[index % locations.length].longitude;
					nodeObj["color"] = node["color"];
					nodeObj["role"] = node["role"];
					nodeObj["iconType"] = node["iconType"];
					nodeObj["type"] = "network-device";
					return nodeObj;
				})
			}

			if(links!==undefined && links && links.length) {
				modifiedLinks = links.map(link=>{

					let linkObj = link;
					if(link.color!== null && link.color!== undefined) {
						linkObj["color"] = link.color;
					}
					
					return linkObj;
				})
			}

			if(nodeSets !== undefined && nodeSets && nodeSets.length) {
				nodeSets.map((nodeSet,index) => {
					nodeSet["type"] = "network-slice";
					nodeSet["x"] = nodeSetLocations[index].x;
					nodeSet["y"] = nodeSetLocations[index].y;
				});
			}
			
			let topologyData: TopologyData = {
				"nodes": modifiedNodes,
				"links": modifiedLinks,
				"mapView" : true,
				"zoomFit": true,
				"layoutType" : 'INMap'
			}

			setSampleTopology(topologyData);
        }
	}
	let customNodeToolTip = null;
	const sampleEvtHandlers: EventHandlers = {
		clickNode: (sender, node) => {
			const nodeId = node.id();
		},
		doubleClickNode: (sender, node) => {
			
			//forRedirection(nodeId);
		},
		enterNode: (sender,node) => {
			if(Object.keys(networkDetails).includes(node.id())) {
				customNodeToolTip = new CustomNodeToolTip();
				nxApp.customToolTip(customNodeToolTip);
				customNodeToolTip.setView({
					target: {
						x: event.pageX,
						y: event.pageY
					},
					title: null,
					node: node,
					items: networkDetails[node.id()],
					label: node.id()
				});
			}
		},
		leaveNode: (sender,node) => {
			if(customNodeToolTip != null) {
				customNodeToolTip.close();
			}
		}
	};

	const setContext = (nxApp: any) => {
		setTopology(nxApp);

		window.nx.define('nodeContextMenu', window.nx.ui.Component, {
			properties: {
				node: {
					set: function (node) {
						this.title(node.label());
						this.selectedNodeId(node.label())
					}
				},
				topology: {},
				title: {},
				selectedNodeId: {},
			},
			view: {
				content: [
					{
						name: 'content',
						content: [
							{
								tag: 'div',								
								props: {
									'id': 'node-tooltip',
									style: {
										height: "400px",
										width: "320px"
									},
								},
								name: 'nodeTooltip',
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					this.open(args);
				},
			}
		});
		

		window.nx.define('linkContextMenu', window.nx.ui.Component, {
			properties: {
				node: {
					set: function (link) {
						this.title(link.label());
						this.selectedNodeId(link.label())
						let menuItems = {}
						menuItems['View ' + link.label()] = 'View_Configuration';
					}
				},
				topology: {},
				title: {},
				selectedNodeId: {},
			},
			view: {
				content: [
					{
						name: 'content',
						props: {
							'class': 'n-topology-tooltip-content n-list'
						},
						content: [
							{
								tag: 'div',								
								props: {
									'id': 'link-tooltip',
									style: {
										height: "400px",
										width: "320px"
									},
								},
								name: 'linkTooltip',
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					this.open(args);
				},
			}
		});

		window.nx.define("customTooltipPolicy", window.nx.graphic.Topology.TooltipPolicy, {
			properties: {
				topology: {},
				tooltipManager: {},
			},
			methods: {
				init(args: any) {
					// @ts-ignore
					this.sets(args);
					// @ts-ignore
					this._tm = this.tooltipManager();
				},
				clickLink(link: TopologyLink) {
					this._tm.openLinkTooltip(link);
					handleLinkClick(link);
				},
				clickNode(node: TopologyNode) {
					this._tm.openNodeTooltip(node);
					handleNodeClick(node);
				},
				enterNode(node: TopologyNode) {
					
				},
			},
		});
		
		nx.define('CustomNodeToolTip', nx.graphic.Topology.Tooltip, {
			properties: {
				items: {},
				topology: {},
				title: {},
				label: {}
			},
			view: {
				props: {
					'class': 'popover fade',
					style: {
						position: 'absolute',
						outline: "none",
					},
					tabindex: -1
				},
				content: [
					{
						props: {
							'class': 'arrow'
						}
					},
					{
						name: 'header',
						props: {
							'class': 'n-topology-tooltip-header'
						},
						content: [
							{
								tag: 'h',
								props: {
									'class': 'n-topology-tooltip-header-text'
								},
								name: 'label',
								content: '{#label}'
							}
						]
					},
					{
						name: 'content',
						props: {
							'class': 'n-topology-tooltip-content n-list'
						},
						content: [
							{
								tag: 'span',
								props: {
									'class': 'n-topology-tooltip-header-text'
								},
								name: 'title',
								content: '{#title}'
							},
							{
								name: 'list',
								tag: 'div',
								props: {
									'class': 'ui divided relaxed list',
									template: {
										tag: 'div',
										props: {
											'class': 'item',
											role: 'listitem',
											style: {
												'height' : '30px'
											}
										},
										content: [
											{
												tag: 'label',
												content: '{value}'
											},
										]
									}
								}
							}
						]
					}
				]
			},
			methods: {
				setView: function(args) {
					const node = args.node;
					const title = args.title;
					this.title(title);
					this.label(args.label);
					let arr = args.items;
					let tooltipItems = {};
					arr.forEach(item => {
						tooltipItems[item] = item;
					})
					this.view('list').set('items', new nx.data.Dictionary(tooltipItems));
					this.open(args);
				},
			}
		})

		nxApp.tooltipManager().tooltipPolicyClass("customTooltipPolicy");
		nxApp.tooltipManager().nodeTooltipContentClass("nodeContextMenu");
		nxApp.tooltipManager().linkTooltipContentClass("linkContextMenu");
	}

	const { NextUI, nxApp } = useNext({
		topologyData: sampleTopology,
		topologyConfig: sampleConfig,
		eventHandlers: sampleEvtHandlers,
		style: { width: "100%", height: "85vh" },
		callback: setContext,
		headerComponent: HeaderComponent,
		footerComponent: FooterComponent
	});

	const getNetworkDetails = () => {
		let networkIds = topologyContext.selNetworks;
		NoaClient.post(
			"/api/service/" + serviceId + "/network/",
			networkIds,
			(response) => {
				let obj = {};
				let responseData = response.data;
				let keys = Object.keys(responseData);
				for(let i = 0 ; i < keys.length ; i++) {
					let key = keys[i];
					let nodes = responseData[key];
					let objKeys = Object.keys(obj);
					nodes.forEach(node => {
						if(objKeys.includes(node)) {
							let arr = obj[node];
							let newArray = [...arr,key];
							obj[node] = newArray
						} else {
							obj[node] = [key];
						}
					})
				}
				setNetworkDetails(obj);
			}
		)
	}

	useEffect(() => {
		let keys = Object.keys(networkDetails);
		if(keys.length > 0) {
			nodesLayer = nxApp.getLayer("nodes");
			let nodes = []
			nodes = nodesLayer.nodes();
			let color = "#F6C565";
			nodes.forEach((node,index) => {
				if(keys.includes(node.id())) {
					window.nx.util.setProperty(node, 'color', color);
				}
			})
		}
	},[networkDetails]);

	useEffect(() => {
		setTopologyData(networkTopology)
		if(topologyContext.selNetworks.length > 0) {
			context.setRenderLocation(["topology-view"]);
			getNetworkDetails();
		}
	},[topologyContext.selNetworks]);

	const getPathDetails = () => {
		let pathIds = topologyContext.selPaths;
		for(let i = 0; i < pathIds.length; i++) {
			let pathId = pathIds[i];
			getPathhop(pathId,i);
		}
	}

	const getPathhop = (pathId,index) => {
		NoaClient.get(
			"/api/service/" + serviceId + "/path/" + pathId + "/pathhop",
			(response) => {
				let responseData = response.data;
				if(Array.isArray(responseData)) {
					let hops = [];
					responseData.forEach((item,index) => {
						let srcNode = item.sourceElement;
						let destNode = item.destinationElement;
						if(!hops.includes(srcNode)) {
							hops.push(srcNode);
						}

						if(!hops.includes(destNode)) {
							hops.push(destNode);
						}
					})
					let obj = {};
					let color = "#" + Math.random().toString(16).substr(-6);
					
					drawPath(topology,hops,color);
				}
			}
		)
	}

	useEffect(() => {
		if(topologyContext.selPaths.length > 0) {
			pathLayer = nxApp.getLayer("paths");
			pathLayer.clear();
			context.setRenderLocation(["topology-view"])
			getPathDetails();
		} else {
			if(nxApp != undefined) {
				pathLayer = nxApp.getLayer("paths");
				pathLayer.clear();
			}
		}
	},[topologyContext.selPaths]);

	return (
		<div ref={ref}>
			<NoaContainer style={topologyContainer}>
			<Grid>
				<Grid.Row columns={1}>
					<Grid.Column width={16} id="service-specific-topology">
						{NextUI}
					</Grid.Column>
				</Grid.Row>
				{renderNodeTooltip ? <RenderNodeDetails nodeDetails={nodeDetails}/> : ""}
				{renderLinkTooltip ? <RenderLinkDetails linkDetails={linkDetails}/> : ""}
			</Grid>
			</NoaContainer>
		</div>
	)
}

const RenderNodeDetails = (props) => {
	const nodeDetails = props.nodeDetails;
	const tooltipLocation = document.getElementById('node-tooltip');
	return tooltipLocation != null ? createPortal(<NodeTooltip data={nodeDetails}/>, tooltipLocation) : null
}

const RenderLinkDetails = (props) => {
	const linkDetails = props.linkDetails;
	const tooltipLocation = document.getElementById('link-tooltip');	
	return tooltipLocation != null ? createPortal(<LinkTooltip data={linkDetails}/>, tooltipLocation) : null
}

const HeaderComponent = () => {

	const [viewOpen, setViewOpen] = useState(false);
	const [filterOpen, setFilterOpen] = useState(false);

	return(
		<Container style={{position: "absolute", top: "0", right: "18px",textAlign:"right"}}>
		<Menu pointing secondary compact style={subMenuLayout}>
			<Menu.Menu position='right'>
			<Popup 
				on="click"
				basic
				position='bottom right'
				trigger={
					<Menu.Item position='right' active={viewOpen} onClick={() =>{
						setViewOpen(true)
						setFilterOpen(false)
					}}>
						<p style={subMenuItem}>View</p>
					</Menu.Item>}
			>
				
				<Grid>
					<Grid.Row columns={1}>
						<Grid.Column width={16}>
							<ViewComponent />	
						</Grid.Column>
					</Grid.Row>
				</Grid>
				
			</Popup>
			<Popup 
				on="click"
				basic
				position='bottom right'				
				trigger={
					<Menu.Item position='right' active={filterOpen} onClick={() =>{
						setFilterOpen(true)
						setViewOpen(false)
					}}>
						<p style={subMenuItem}>Filter</p>
					</Menu.Item>} 
				
			>
				<Grid>
					<Grid.Row columns={1}>
						<Grid.Column width={16}>
							<FilterComponent />
						</Grid.Column>
					</Grid.Row>
				</Grid>
			</Popup>
			</Menu.Menu>
		</Menu>
		</Container>
	)
}

const ViewComponent = () => {
	const topologyContext = useContext(ServiceTopologyContext);

	const [paths, setPaths] = useState([]);
	const [networks, setNetworks] = useState([]);

	useEffect(() => {
		setPaths(topologyContext.paths);
	},[topologyContext.paths]);

	useEffect(() => {
		setNetworks(topologyContext.networks);
	},[topologyContext.networks]);

	return(
		<Container style={{width: "600px",height: "auto"}}>
		<Grid style={Object.assign({})}>
			<Grid.Row columns={1}>
				<Grid.Column width={16} id="topology-view">
					<Grid columns={2} stackable>
						<Grid.Column width={8}>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Grid columns={2} stackable>
											<Grid.Column width={11} style={{fontFamily: "Montserrat",fontSize: "1.1em",fontWeight:600}}>
												Service Paths
											</Grid.Column>
											<Grid.Column width={5} style={{paddingLeft:"0px"}}>
												<Checkbox toggle/>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection multiple
											placeholder="Paths List"
											selectOnBlur={false}
											style={dropdownStyle}
											value={topologyContext.selPaths}
											options={paths} 
											onChange={(e,{value}) => topologyContext.setSelPaths(value)}
										/>
									</Grid.Column>
								</Grid.Row>

							</Grid>
						</Grid.Column>
						<Grid.Column width={8}>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Grid columns={2} stackable>
											<Grid.Column width={11} style={{fontFamily: "Montserrat",fontSize: "1.1em",fontWeight:600}}>
												By Networks
											</Grid.Column>
											<Grid.Column width={5} style={{paddingLeft:"0px"}}>
												<Checkbox toggle/>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>

								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection multiple
											placeholder="Networks List"
											selectOnBlur={false}
											style={dropdownStyle}
											value={topologyContext.selNetworks}
											options={networks} 
											onChange={(e,{value}) => topologyContext.setSelNetworks(value)}
										/>
									</Grid.Column>
								</Grid.Row>
							</Grid>
						</Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</Container>
	)
}

const FilterComponent = () => {
	const topologyContext = useContext(ServiceTopologyContext);

	return(
		<Container style={{width: "600px",height: "auto"}}>
		<Grid style={Object.assign({})}>
			<Grid.Row columns={1}>
				<Grid.Column width={16}>
					<Grid columns={3} stackable>
						<Grid.Column width={5}></Grid.Column>
						<Grid.Column width={5}>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection
												placeholder="Network Type"
												value={topologyContext.networkFilter}
												style={dropdownStyle}
												selectOnBlur={false}
												options={networkTypes} 
												onChange={(e,{value}) => topologyContext.setNetworkFilter(value)}
										/>
									</Grid.Column>
								</Grid.Row>
							</Grid>
						</Grid.Column>
						<Grid.Column width={6}>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
										<Dropdown clearable selection
												placeholder="Service Type"
												value={topologyContext.serviceFilter}
												options={serviceTypes}
												selectOnBlur={false}
												style={dropdownStyle}
												onChange={(e,{value}) => topologyContext.setServiceFilter(value)}
										/>
									</Grid.Column>
								</Grid.Row>
							</Grid>
						</Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</Container>
	)
}


const FooterComponent = () => {
	return(
		<Container style={{position: "absolute", bottom: "0",right: "0"}}>
		<Grid>
			<Grid.Row columns={2}>
				<Grid.Column width={9}></Grid.Column>
				<Grid.Column width={7}>
					<Grid columns={2} stackable>
						<Grid.Column width={6} style={{maxWidth:"240px"}}>
						
						</Grid.Column>
						<Grid.Column width={10} style={{maxWidth:"300px"}}>
							<Segment style={{border:"1px solid rgb(213,223,233,.5)"}}>
							<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16} textAlign='center'>
										<p style={topologyChartTitle}>Summary</p>
									</Grid.Column>
								</Grid.Row>
								<Grid.Row columns={1} style={{marginBottom:"1em"}}>
									<Grid.Column width={16} textAlign='center'>
										<Grid columns={3}>
											<Grid.Column width='equal' style={noPadding}>
												<Label circular style={Object.assign({background:"#394867"},topologyChartValue)}>
													14
												</Label>
												<p style={topologyChartDesc}>Elements</p>
											</Grid.Column>
											<Grid.Column width='equal' style={noPadding}>
												<Label circular style={Object.assign({background:"#90A1B1"},topologyChartValue)}>
													18
												</Label>
												<p style={topologyChartDesc}>Paths</p>
											</Grid.Column>
											<Grid.Column width='equal' style={noPadding}>
												<Label circular style={Object.assign({background:"#6B637B"},topologyChartValue)}>
													4
												</Label>
												<p style={topologyChartDesc}>Networks</p>
											</Grid.Column>
										</Grid>
									</Grid.Column>
								</Grid.Row>
							</Grid>
							</Segment>
						</Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</Container>
	)
}

const networkTypes = [
	{ 'key': "L1 Network", 'text': "L1 Network", 'value': "L1 Network" },
	{ 'key': "L2 Network", 'text': "L2 Network", 'value': "L2 Network" },
	{ 'key': "L2.5 Network", 'text': "L2.5 Network", 'value': "L2.5 Network" },
	{ 'key': "L3 Network", 'text': "L3 Network", 'value': "L3 Network" }
]

const serviceTypes = [
	{ 'key': "L3 VPN", 'text': "L3 VPN", 'value': "L3 VPN" },
	{ 'key': "L2 VPN", 'text': "L2 VPN", 'value': "L2 VPN" }
]

export default ServiceTopology;