import React, { useContext, useEffect, useState } from 'react';

import { Tab,Menu, Grid, Checkbox, Icon, Segment } from 'semantic-ui-react';

import { 
    completeHeight, completeWidth, nMenuItem,
    fullHeight, tablePadding, noMarginLR, 
    noMarginTB, tableHeaderHeight, cardLayout
} from '../constants';

import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import NoaClient from '../utility/NoaClient';
import { RouteRediretContext } from '../utility/RouteRedirect';
import NoaTable from '../widget/NoaTable';
import { Link } from "react-router-dom";

import { NoaContainer} from '../widget/NoaWidgets';
import ServiceEndpointManager from './ServiceEndpointManager';
import ServicePathManager from './ServicePathManager';

const ServiceConnectivity = (props) => {
    const serviceId = sessionStorage.getItem("serviceId");
    const serviceType = sessionStorage.getItem("serviceType")

    const panes = [
        {
            menuItem: <Menu.Item key='paths' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Service Paths</Menu.Item>,
            render: () => <ServicePathManager serviceId={serviceId} serviceType={serviceType}/>
        },
        {
            menuItem: <Menu.Item key='endpoints' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Service Endpoints</Menu.Item>,
            render: () => <ServiceEndpointManager serviceId={serviceId} serviceType={serviceType}/>
        },
        {
            menuItem: <Menu.Item key='networks' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Provisioned Networks</Menu.Item>,
            render: () => <ProvisionedNetworks serviceId={serviceId} serviceType={serviceType}/>
        },
    ]

    return(
        <NoaContainer style={Object.assign({display: "flex",flexDirection: "column",minHeight:"100vh"},completeWidth)}>
            <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
                            <Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}} />
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Segment>
        </NoaContainer>
    )
}

const ProvisionedNetworks = (props) => {
    const serviceId = props.serviceId;
    const serviceType = props.serviceType;

    const [networks, setNetworks] = useState([]);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const getProvisionedNetworks = () => {
        context.setRenderLocation(['provisioned-network-list']);
        NoaClient.get(
            "/api/service/" + serviceId + "/network",
            (response) => {
                let responseData = response.data;
                setNetworks(responseData);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getProvisionedNetworks();
    },[]);

    return (
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16} verticalAlign='top'>
                    <ProvisionedNetworksList networks={networks} getNetworks={getProvisionedNetworks}/>
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const ProvisionedNetworksList = (props) => {
    const networks = props.networks;
    const getNetworks = props.getNetworks;

    const [selections,setSelections] = useState([]);
    
    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
		{
            label: "8",
            Header: "Network Name",
            Cell: ({row}) => {
                let networkId = row.original.networkId;
                let networkName = row.original.networkName;
                let networkType = row.original.networkType;

                const toNetworkInstance = { 
                    pathname: `/Networks/${networkName}`,
                }
                return <Link to={toNetworkInstance} onClick={() => {
                    sessionStorage.setItem("networkId",networkId);
                    sessionStorage.setItem("networkName",networkName);
                    sessionStorage.setItem("networkType",networkType);
                }}>{networkName}</Link>
            },
            width: 3
        },
		{
			label: "2",
			Header: "Network Type",
            accessor: "networkType",
            width: 2
		},
        {
			label: "4",
			Header: "Protocol",
            accessor: "protocol",
            width: 2
		},
        {
			label: "5",
			Header: "IP Range",
            accessor: "ipRange",
            width: 3
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"networkStatus")
            ),
            width: 3
        }
    ]
    return(
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                                                  
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={networks}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        resource="Provisioned Networks" 
                        fetchData={getNetworks} 
                        location="provisioned-network-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}
export default ServiceConnectivity;