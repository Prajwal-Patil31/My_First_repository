import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../widget/NoaTable';
import {
    Grid,
    Button,
    Divider,
    Checkbox,
    Dropdown,
    Icon,
    Input
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, noMarginTB, 
    noMarginLR, titleText,autoHeight,
    formHeader, formParameter, formTitle, 
    cardDurationItem, completeHeight, completeWidth, 
    tablePadding, tableHeaderHeight, applyButton, 
    cancelButton, fullHeight, dividerStyle,
    inputBoxStyle, dropdownStyle
} from '../constants';

import { NoaHeader, NoaContainer } from '../widget/NoaWidgets';
import NoaLineChart from '../widget/NoaLineChart';
import NoaClient from '../utility/NoaClient';
import NoaFilter from '../widget/NoaFilter';
import PathhopManager from './PathhopManager';
import NoaToolbar from '../widget/NoaToolbar';
import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../widget/NoaNotification';

const ServicePathManager = (props) => {
    const serviceId = props.serviceId;
    const serviceType = props.serviceType;
    
    const context = useContext(GlobalSpinnerContext);

    const [paths, setPaths] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const router = useRouter();
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = paths[sel[i]].pathId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getPaths = (filterObj) => {
        context.setRenderLocation(["paths-list"]);
        NoaClient.post(
            "/api/service/" + serviceId + "/path",
            filterObj,
            (response) => {
                let responseData = response.data;
                setPaths(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        context.setRenderLocation(["paths-list"]);
        NoaClient.get(
            "/api/service/" + serviceId + "/path/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        context.setRenderLocation(["paths-list"]);
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"vpn-service" : {"service-id":[serviceId],"path" :{}}}
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getPaths(filterCriteria);
    },[]);

    return (
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16}>
                    <PathTable paths={paths} getPaths={getPaths}
                                selectedRows={selectedRows}
                                setClearSelected={setClearSelected}
                                setSelected={setSelected} 
                                clearSelected={clearSelected}
                                serviceId={serviceId}
                                columns={columns}
                                filters={filters}
                                pageSize={pageSize}
                                totalPages={totalPages}
                                setPageSize={setPageSize}
                                totalEntries={totalEntries}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const PathTable = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const paths = props.paths;
    const getPaths = props.getPaths;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const serviceId = props.serviceId;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;
    
    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"vpn-service" : {"service-id":[serviceId],"path" :{}}});
    
    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
		{
			label: "1",
			Header: "Path Name",
            accessor: "pathName",
            width: 2
		},
		{
			label: "2",
			Header: "Source Element",
            accessor: "sourceElement",
            width: 2
		},
        {
			label: "4",
			Header: "Source Interface",
            accessor: "sourceInterface",
            width: 2
		},
        {
			label: "5",
			Header: "Destinaiton Element",
            accessor: "destinationElement",
            width: 2
        },
        {
			label: "6",
			Header: "Destination Interface",
            accessor: "destinationInterface",
            width: 2
        },
        {
			label: "8",
			Header: "Hops Count",
            accessor: "hopsCount",
            width: 1
        },
        {
			label: "9",
			Header: "Path Rate",
            accessor: "pathRate",
            width: 1
        },
        {
			label: "9",
			Header: "Bandwidth",
            accessor: "bandwidth",
            width: 1
        },
        {
			label: "9",
			Header: "Latency",
            accessor: "latency",
            width: 1
        },
        {
            label: "8",
            Header: "Path Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width: 1
        }
    ]

    const router = useRouter();

    const handleAddPath = () => {
        router.stateService.go("add-path",{fetchData: fetchData,serviceId:serviceId,clearSelection: clearSelection})
    }

    const clearSelection = () => {
        setClearSelected(true);
    }

    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('view-path',{id: paths[selId].pathId,serviceId:serviceId,fetchData: fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["paths-list"]);

        NoaClient.delete(
			"/api/service/" + serviceId + "/path/",
			selectedItems,
			(response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        });
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getPaths(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"vpn-service" : {"service-id":[serviceId],"path" :{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        } else {
            body["filters"]["vpn-service"] = [serviceId]
            setAppliedFilters(body)
        }
        getPaths(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getPaths(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddPath}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={paths}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="Service Paths" 
                        fetchData={fetchData} 
                        location="paths-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.pathStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddPath = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const getPaths = props.fetchData;
    const clearSelection = props.clearSelection;
    const serviceId = props.serviceId;

    const [path, setPath] = useState({});
    
    const [srcElements, setSrcElements] = useState([]);
    const [srcElement, setSrcElement] = useState(null);
    
    const [destElements, setDestElements] = useState([]);
    const [destElement, setDestElement] = useState(null);

    const [srcEndpoints, setSrcEndpoints] = useState([]);
    const [srcEndpoint, setSrcEndpoint] = useState(null);
    
    const [destEndpoints, setDestEndpoints] = useState([]);
    const [destEndpoint, setDestEndpoint] = useState(null);

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const getElements = () => {
        NoaClient.get(
            "/api/service/" + serviceId + "/endpoint",
            (response) => {
                let responseData = response.data;
                let elementsList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let elementObj = {'key' : item.endpointId, 'value' : item.endpointName, 'text': item.endpointName}
                        elementsList[index] = elementObj;
                    })
                }
                setSrcElements(elementsList);
            }
        )
    }

    useEffect(() => {
        context.setRenderLocation(["add-path"]);
        getElements();
    },[]);

    useEffect(() => {
        if(srcElement != null) {
            getSrcEndpoints();
            let nodes = srcElements.filter(node => node.text !== srcElement);
            setDestElements(nodes);
        }
    },[srcElement]);

    const getSrcEndpoints = () => {
        const srcNode = srcElements.find(node => node.text === srcElement);
        let elementId = srcNode.key;
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceName, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setSrcEndpoints(interfacesList);
            }
        )
    }

    useEffect(() => {
        if(destElement != null) {
            getDestEndpoints();
        }
    },[destElement]);

    const getDestEndpoints = () => {
        const destNode = destElements.find(node => node.text === destElement);
        let elementId = destNode.key
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceName, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setDestEndpoints(interfacesList);
            }
        )
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/service/" + serviceId + "/path",
            path,
            (response) => {
                noaNotification('success','Service Paths Created Successfully');
                closeFooter();
                getPaths();
            }
        )
    }

    const handleInput = (value, key) => {
		setPath(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const protocolTypes = [
        {
            key: 'bgp',
            text: 'BGP',
            value: 'bgp',
        },
        {
            key: 'ospf',
            text: 'OSPF',
            value: 'ospf',
        }
    ];
    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create Path</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="add-path">
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={3}>
                                <Grid.Column width={1}></Grid.Column>
                                <Grid.Column width={14}>
                                    <Grid>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} textAlign='center'>
                                                        <p style={formHeader}>Path Parameters</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                            <Grid columns={2} stackable>
                                                                <Grid.Column width={8} textAlign='left'>
                                                                    <p style={formParameter} className="required">Path Name</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={8} textAlign='left'>
                                                                    <Input type='text' name='pathName' 
                                                                        value={path.pathName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'pathName')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                            </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>

                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                            <Grid columns={2} stackable>
                                                                <Grid.Column width={8} textAlign='left'>
                                                                    <p style={formParameter}>Auto Negotiation</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={8} textAlign='left'>
                                                                    <Checkbox
                                                                        toggle={true}
                                                                        value={path.autoNegotiation}
                                                                        onChange={
                                                                            (e,data)=>handleInput(data.checked, 'autoNegotiation')
                                                                        }
                                                                    />
                                                                </Grid.Column>
                                                            </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>


                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                            <Grid columns={2} stackable>
                                                                <Grid.Column width={8} textAlign='left'>
                                                                    <p style={formParameter}>Protocol</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={8} textAlign='left'>
                                                                    <Dropdown clearable selection required
                                                                            placeholder="Protocol Type"
                                                                            options={protocolTypes}
                                                                            selectOnBlur={false}
                                                                            style={dropdownStyle}
                                                                            value={path.protocol ? path.protocol : ''}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'protocol')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                            </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                            <Grid.Column width={8}></Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={3} stackable>
                                                <Grid.Column computer={7} tablet={16} mobile={16}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16} textAlign='center'>
                                                                <p style={formHeader}>Source Parameters</p>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                                <Grid>
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid columns={2} stackable>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <p style={formParameter} className="required">Source Element</p>
                                                                        </Grid.Column>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <Dropdown clearable selection required
                                                                                    placeholder="Src Element"
                                                                                    options={srcElements}
                                                                                    style={dropdownStyle}
                                                                                    selectOnBlur={false}
                                                                                    onChange={(e,{value}) => {
                                                                                        let srcEle = value==='' ? null : value
                                                                                        let key = 'sourceElement'
                                                                                        setSrcElement(srcEle);
                                                                                        setPath(prevState => ({
                                                                                            ...prevState,
                                                                                            [key]: srcEle
                                                                                        }));
                                                                                    }}
                                                                            />
                                                                        </Grid.Column>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>

                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid columns={2} stackable>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <p style={formParameter} className="required">Source Endpoint</p>
                                                                        </Grid.Column>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <Dropdown clearable selection required
                                                                                    placeholder="Src Endpoint"
                                                                                    selectOnBlur={false}
                                                                                    style={dropdownStyle}
                                                                                    options={srcEndpoints} 
                                                                                    onChange={(e,{value}) => {
                                                                                        let srcEp = value==='' ? null : value
                                                                                        let key = 'sourceInterface'
                                                                                        setSrcEndpoint(srcEp);
                                                                                        setPath(prevState => ({
                                                                                            ...prevState,
                                                                                            [key]: srcEp
                                                                                        }));
                                                                                    }}
                                                                            />
                                                                        </Grid.Column>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                    </Grid>
                                                    </Grid.Column>                               
                                                <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                                <Grid.Column computer={7} tablet={16} mobile={16}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16} textAlign='center'>
                                                                <p style={formHeader}>Destination Parameters</p>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                                <Grid>
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid columns={2} stackable>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <p style={formParameter} className="required">Destination Element</p>
                                                                        </Grid.Column>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <Dropdown clearable selection required
                                                                                    placeholder="Dest Element"
                                                                                    selectOnBlur={false}
                                                                                    options={destElements} 
                                                                                    style={dropdownStyle}
                                                                                    onChange={(e,{value}) => {
                                                                                        let destEle = value==='' ? null : value
                                                                                        let key = 'destinationElement'
                                                                                        setDestElement(destEle);
                                                                                        setPath(prevState => ({
                                                                                            ...prevState,
                                                                                            [key]: destEle
                                                                                        }));
                                                                                    }}
                                                                            />
                                                                        </Grid.Column>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>

                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid columns={2} stackable>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <p style={formParameter} className="required">Destination Endpoint</p>
                                                                        </Grid.Column>
                                                                        <Grid.Column width={8} textAlign='left'>
                                                                            <Dropdown clearable selection required
                                                                                    placeholder="Dest Endpoint"
                                                                                    selectOnBlur={false}
                                                                                    style={dropdownStyle}
                                                                                    options={destEndpoints} 
                                                                                    onChange={(e,{value}) => {
                                                                                        let destEp = value==='' ? null : value
                                                                                        let key = 'destinationInterface'
                                                                                        setDestEndpoint(destEp);
                                                                                        setPath(prevState => ({
                                                                                            ...prevState,
                                                                                            [key]: destEp
                                                                                        }));
                                                                                    }}
                                                                            />
                                                                        </Grid.Column>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                                <Grid.Column width={1}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row style={{paddingTop: "2em"}} columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        <Button style={applyButton} onClick={() => {
                                        handleAdd()
                                        context.setRenderLocation(["add-path"]);
                                        }}>Add</Button>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ModifyPath = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const clearSelection = props.clearSelection;
    const getPaths = props.fetchData;

    const [serviceId, setServiceId] = useState(null);
    const [pathId, setPathId] = useState(null);
    const [path, setPath] = useState({});

    useEffect(() => {
        const pathId = props.id;
        context.setRenderLocation(['view-path']);
        if(pathId != null && pathId != undefined && props.serviceId != null) {
            setPathId(pathId);
            setServiceId(props.serviceId);
        }
    },[props.id]);
    
    useEffect(() => {
        if(pathId != null && pathId != undefined) {
            getPath(serviceId,pathId)
        }
    },[pathId]);

    const getPath = (serviceId,pathId) => {
        NoaClient.get(
            "/api/service/" + serviceId + "/path/" + pathId,
            (response) => {
                let responseData = response.data;
                setPath(responseData);
            }
        )
    }

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }
    
    return(
        <NoaContainer style={Object.assign({},completeWidth,autoHeight)}>
        <Grid style={Object.assign({},completeWidth,noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Path Detail: {path.pathName}</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1}>
                <Grid.Column width={16} style={{paddingLeft: "2em"}} id="view-path">
                    <Grid stackable>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <PathhopManager serviceId={serviceId} pathId={pathId}/>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <PathStatistics />
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row style={{paddingTop: "1.5em"}} columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2}>
                                    <Grid.Column width={8} textAlign='right'>
                                        
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const PathStatistics = (props) => {
    return(
        <NoaContainer style={Object.assign({},completeWidth)}>
            <Grid style={Object.assign({})}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                    <Grid stackable>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16} textAlign='left'>
                                <p style={titleText}>Path Statistics</p>
                            </Grid.Column>
                        </Grid.Row>
                        
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <NoaLineChart data={mockDeviceUtilization} lineType={"linear"} colors={lineChartColors}/>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2}>
                                    <Grid.Column width={8}>
                                        <p style={Object.assign({textAlign: "left"},cardDurationItem)}>1Hour</p>   
                                    </Grid.Column>
                                    <Grid.Column width={8}>
                                        <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>  
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const lineChartColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}
const mockDeviceUtilization = [
    {
        "DEL-PE-480": 2400,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 600,
        "BOM-CE-001": 1600,
        "VJA-P-980": 900,
    },
    {
        "DEL-PE-480": 1800,
        "BOM-CE-165": 1600,
        "DEL-PE-560": 200,
        "BOM-CE-001": 6800,
        "VJA-P-980": 2500,
    },
    {
        "DEL-PE-480": 5600,
        "BOM-CE-165": 5400,
        "DEL-PE-560": 200,
        "BOM-CE-001": 200,
        "VJA-P-980": 2400,
    },
    {
        "DEL-PE-480": 1526,
        "BOM-CE-165": 1426,
        "DEL-PE-560": 100,
        "BOM-CE-001": 3200,
        "VJA-P-980": 3000,
    },
    {
        "DEL-PE-480": 3600,
        "BOM-CE-165": 1800,
        "DEL-PE-560": 1800,
        "BOM-CE-001": 400,
        "VJA-P-980": 500,
    },
    {
        "DEL-PE-480": 3200,
        "BOM-CE-165": 1000,
        "DEL-PE-560": 1200,
        "BOM-CE-001": 800,
        "VJA-P-980": 1700,
    },
    {
        "DEL-PE-480": 3300,
        "BOM-CE-165": 2600,
        "DEL-PE-560": 700,
        "BOM-CE-001": 750,
        "VJA-P-980": 1800,
    },
]
export default ServicePathManager;
export {AddPath,ModifyPath};