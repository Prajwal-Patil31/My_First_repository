import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../widget/NoaTable';

import { 
    Grid, Button, Checkbox, 
    Dropdown, Icon, Divider, 
    Input 
} from 'semantic-ui-react';

import { 
    noBoxShadow,noPadding, noMarginTB, 
    noMarginLR, titleText, formHeader, 
    formParameter, applyButton, cancelButton, 
    completeHeight, completeWidth, formTitle,
    tablePadding, tableHeaderHeight, dividerStyle, 
    inputBoxStyle, dropdownStyle
} from '../constants';

import NoaClient from '../utility/NoaClient';

import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { RouteRediretContext } from '../utility/RouteRedirect';

import {NoaContainer, NoaHeader} from '../widget/NoaWidgets';
import NoaToolbar from '../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../widget/NoaNotification';

const PathhopManager = (props) => {
    const serviceId = props.serviceId;
    const pathId = props.pathId;

    const [pathHops,setPathHops] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = pathHops[sel[i]].hopId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getPathHops = () => {
        NoaClient.get(
            "/api/service/" + serviceId + "/path/" + pathId + "/pathhop",
            (response) => {
                let responseData = response.data;
                setPathHops(responseData);
            }
        )
    }
    useEffect(() => {
        NoaClient(context, redirectContext);
        context.setRenderLocation(["pathhops-list"]);
        getPathHops();
    },[props.pathId]);

    return(
        <NoaContainer style={Object.assign({},completeWidth)}>
            <Grid style={Object.assign({})}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <PathhopTable pathHops={pathHops} getPathHops={getPathHops}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected} 
                                    clearSelected={clearSelected}
                                    serviceId={serviceId}
                                    pathId={pathId}
                        />
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
        
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const PathhopTable = (props) => {
    const router = useRouter();

    const pathHops = props.pathHops;
    const getPathHops = props.getPathHops;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const serviceId = props.serviceId;
    const pathId = props.pathId;

    const [selections,setSelections] = useState([]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
        {
            label: "1",
            Header: "Hop Name",
            accessor: "hopName",
            width: 2
        },
        {
            label: "2",
            Header: "Source Element",
            accessor: "sourceElement",
            width: 2
        },
        {
            label: "4",
            Header: "Source Interface",
            accessor: "sourceInterface",
            width: 2
        },
        {
            label: "5",
            Header: "Destination Element",
            accessor: "destinationElement",
            width: 2
        },
        {
            label: "6",
            Header: "Destination Interface",
            accessor: "destinationInterface",
            width: 2
        },
        {
            label: "7",
            Header: "Protocol",
            accessor: "protocol",
            width: 2
        },
        {
            label: "8",
            Header: "Latency",
            accessor: "latency",
            width: 2
        },
        {
            label: "8",
            Header: "Hop Status",
            Cell: ({row}) => (
                renderBoolean(row)
            ),
            width: 1
        }
    ]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    const handleAddPathhop = () => {
        router.stateService.go(".addpathhop",{fetchData: getPathHops,serviceId:serviceId,pathId:pathId,clearSelection: clearSelection})
    }

    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        NoaClient.delete(
			"/api/service/" + serviceId + "/pathhop/",
			selectedItems,
			(response) => {
                getPathHops();
        });
    }

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Path Hops</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddPathhop}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={pathHops}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        resource="Pathhops" 
                        fetchData={getPathHops} 
                        location="pathhops-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView name="addpathhop"/>
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const renderBoolean = (row) => {
    const enabledState = row.original.hopStatus;
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddPathhop = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const fetchData = props.fetchData;
    const clearSelection = props.clearSelection;
    const serviceId = props.serviceId;   
    const pathId = props.pathId
    
    const [path, setPath] = useState({});
    
    const [srcElements, setSrcElements] = useState([]);
    const [srcElement, setSrcElement] = useState(null);
    
    const [destElements, setDestElements] = useState([]);
    const [destElement, setDestElement] = useState(null);

    const [srcEndpoints, setSrcEndpoints] = useState([]);
    const [srcEndpoint, setSrcEndpoint] = useState(null);
    
    const [destEndpoints, setDestEndpoints] = useState([]);
    const [destEndpoint, setDestEndpoint] = useState(null);

    const getElements = () => {
        NoaClient.get(
            "/api/service/" + serviceId + "/endpoint",
            (response) => {
                let responseData = response.data;
                let elementsList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let elementObj = {'key' : item.endpointId, 'value' : item.endpointName, 'text': item.endpointName}
                        elementsList[index] = elementObj;
                    })
                }
                setSrcElements(elementsList);
            }
        )
    }

    useEffect(() => {
        context.setRenderLocation(["add-pathhop"]);
        getElements();
    },[]);

    const closeFooter = () => {
        router.stateService.go('view-path',{id: pathId,serviceId:serviceId,fetchData: fetchData,clearSelection: clearSelection})
    }

    useEffect(() => {
        if(srcElement != null) {
            getSrcEndpoints();
            let nodes = srcElements.filter(node => node.text !== srcElement);
            setDestElements(nodes);
        }
    },[srcElement]);

    const getSrcEndpoints = () => {
        const srcNode = srcElements.find(node => node.text === srcElement);
        let elementId = srcNode.key;
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceName, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setSrcEndpoints(interfacesList);
            }
        )
    }

    useEffect(() => {
        if(destElement != null) {
            getDestEndpoints();
        }
    },[destElement]);

    const getDestEndpoints = () => {
        const destNode = destElements.find(node => node.text === destElement);
        let elementId = destNode.key
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceName, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setDestEndpoints(interfacesList);
            }
        )
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/service/" + serviceId + "/path/" + pathId + "/pathhop",
            path,
            (response) => {
                noaNotification('success','Pathhop Created Successfully');
                closeFooter();
                fetchData();
            }
        )
    }

    const handleInput = (value, key) => {
		setPath(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const protocolTypes = [
        {
            key: 'bgp',
            text: 'BGP',
            value: 'bgp',
        },
        {
            key: 'ospf',
            text: 'OSPF',
            value: 'ospf',
        }
    ];

    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} style={noPadding} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create PathHop</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="add-pathhop">
                    <Grid columns={3} stackable>
                        <Grid.Column width={2}></Grid.Column>
                        <Grid.Column width={12}>
                        <Grid>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={3} stackable>
                                    <Grid.Column computer={7} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>PathHop Parameters</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <p style={formParameter} className="required">Hop Name</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Input type='text' name='hopName' 
                                                                    value={path.hopName}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleInput(value==='' ? null : value, 'hopName')
                                                                    }>
                                                                        <input style={inputBoxStyle}></input>
                                                                </Input>
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <p style={formParameter} className="required">Hop Cost</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Input type='number' name='cost' 
                                                                    value={path.cost}
                                                                    fluid={false}
                                                                    onChange={
                                                                        (e, {value}) => handleInput(value==='' ? null : value, 'cost')
                                                                    }>
                                                                        <input style={inputBoxStyle}></input>
                                                                </Input>
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                    <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                    <Grid.Column computer={7} tablet={16} mobile={16}></Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={3} stackable>
                                    <Grid.Column computer={7} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Source Parameters</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <p style={formParameter} className="required">Source Element</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Source Element"
                                                                        options={srcElements}
                                                                        style={dropdownStyle}
                                                                        selectOnBlur={false}
                                                                        onChange={(e,{value}) => {
                                                                            let srcEle = value==='' ? null : value
                                                                            let key = 'sourceElement'
                                                                            setSrcElement(srcEle);
                                                                            setPath(prevState => ({
                                                                                ...prevState,
                                                                                [key]: srcEle
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <p style={formParameter} className="required">Source Endpoint</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Source Endpoint"
                                                                        options={srcEndpoints}
                                                                        style={dropdownStyle}
                                                                        selectOnBlur={false}
                                                                        onChange={(e,{value}) => {
                                                                            let srcEp = value==='' ? null : value
                                                                            let key = 'sourceInterface'
                                                                            setSrcEndpoint(srcEp);
                                                                            setPath(prevState => ({
                                                                                ...prevState,
                                                                                [key]: srcEp
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                    <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                    <Grid.Column computer={7} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Destination Parameters</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <p style={formParameter} className="required">Destination Element</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Destination Element"
                                                                        options={destElements}
                                                                        style={dropdownStyle}
                                                                        selectOnBlur={false}
                                                                        onChange={(e,{value}) => {
                                                                            let destEle = value==='' ? null : value
                                                                            let key = 'destinationElement'
                                                                            setDestElement(destEle);
                                                                            setPath(prevState => ({
                                                                                ...prevState,
                                                                                [key]: destEle
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <p style={formParameter} className="required">Destination Endpoint</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Source Endpoint"
                                                                        options={destEndpoints}
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        onChange={(e,{value}) => {
                                                                            let destEp = value==='' ? null : value
                                                                            let key = 'destinationInterface'
                                                                            setDestEndpoint(destEp);
                                                                            setPath(prevState => ({
                                                                                ...prevState,
                                                                                [key]: destEp
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        </Grid.Column>
                        <Grid.Column width={2}></Grid.Column>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row style={{paddingTop: "2em"}} columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2}>
                            <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    handleAdd()
                                    context.setRenderLocation(["add-pathhop"]);
                                }}>Add</Button>
                            </Grid.Column>
                            <Grid.Column width={8} textAlign='left'>
                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

export default PathhopManager;
export {AddPathhop};