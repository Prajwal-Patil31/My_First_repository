import React, { useContext } from 'react';
import { noBorder, noBoxShadow } from '../../constants';
import { MenuContext } from '../../utility/MenuContext';

const ServiceCatalog = () => {
    const menuContext = useContext(MenuContext);

    menuContext.setDisplayText("Service Catalogue");
    menuContext.setHideMenu(true);
    return(
        <div style={noBorder,noBoxShadow}></div>
    )
}
export default ServiceCatalog;