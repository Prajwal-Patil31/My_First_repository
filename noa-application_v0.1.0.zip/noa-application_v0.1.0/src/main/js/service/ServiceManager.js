import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../widget/NoaTable';
import { withRouter,Link } from 'react-router-dom';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Checkbox,
    Dropdown,
    Icon,
    Input,
    Label
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, cancelButton,
    noMarginTB, noMarginLR, titleText, 
    cardLayout, formTitle,applyButton,
    formParameter, completeHeight, completeWidth, 
    overviewStyle, tablePadding, fullHeight, 
    formHeader, tableHeaderHeight, dividerStyle, 
    inputBoxStyle, formContentSpacingTB, formSpacingTB, 
    dropdownStyle,
} from '../constants';

import NoaClient from '../utility/NoaClient';
import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { RouteRediretContext } from '../utility/RouteRedirect';
import NoaFilter from '../widget/NoaFilter';
import { NoaHeader, NoaContainer} from '../widget/NoaWidgets';
import NoaRadialBarChart from '../widget/NoaRadialBarChart';
import NoaRadialBar from '../widget/NoaRadialBar';
import NoaCard from '../widget/NoaCard';
import NoaToolbar from '../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import { MenuContext } from '../utility/MenuContext';
import noaNotification from '../widget/NoaNotification';

const pieChartColors = ["#903749", "#543864","#750550","#21325E"];

const ServiceManager = (props) => {
    const [services, setServices] = useState([]);
    const [serviceSummary, setServiceSummary] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);
    
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const menuContext = useContext(MenuContext);
    
    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = services[sel[i]].serviceId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getServices = (filterObj) => {
        context.setRenderLocation(["services-list"]);
        setServices([]);
        NoaClient.post(
            "/api/service",
            filterObj,
            (response) => {
                let responseData = response.data;
                setServices(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        context.setRenderLocation(["services-list"]);
        NoaClient.get(
            "/api/service/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    const getActiveServices = () => {
        NoaClient.get(
            "/api/service/overview",
            (response) => {
                let responseData = response.data;
                setServiceSummary(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        getActiveServices();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"vpn-service":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getServices(filterCriteria);
        
        menuContext.setHideMenu(true);
        menuContext.setDisplayText("Service List");
    },[]);

    const summaryObj = [
        [
            { name: "VPLS", value: 10, maxValue: 100 },
        ],
        [
            { name: "VPWS", value: 14, maxValue: 100 }
        ],
        [
            { name: "L3 VPN", value: 8, maxValue: 100 }
        ],
    ];

    const mockServiceSummary = [
        {name: "summary",value: 32}
    ]
    return (
        <NoaContainer style={Object.assign({}, fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={{maxHeight: "100vh"}}>
                <Grid.Column width={16} verticalAlign='top'>
                    <ServiceOverview data={serviceSummary}/>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16} verticalAlign='top'>
                    <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                        <ServicesTable 
                            services={services}
                            columns={columns}
                            getServices={getServices}
                            filters={filters}
                            setSelected={setSelected}
                            clearSelected={clearSelected}
                            setClearSelected={setClearSelected}
                            selectedRows={selectedRows}
                            pageSize={pageSize}
                            totalPages={totalPages}
                            setPageSize={setPageSize}
                            totalEntries={totalEntries}
                        />
                    </Segment>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const ServiceOverview = (props) => {
    const data = props.data;

    return(
        <NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1} stretched style={overviewStyle}>
                <Grid.Column width={16}>
                    <NoaCard title={"Active Services"} renderDuration={false}>
                    <NoaContainer style={Object.assign({paddingLeft: "1.5em", paddingRight: "1.5em"},completeWidth)}>
                        {Object.keys(data).length > 0 ? 
                        <Grid columns={2} stackable>
                            <Grid.Column computer={4} tablet={16} mobile={16}>
                                <NoaRadialBar data={data["summary"]} color={"#007EFF"}/>
                            </Grid.Column>
                            <Grid.Column computer={12} tablet={16} mobile={16}>
                                <Grid columns={3}>
                                    {data["detailed"].map((summaryData,index) => (
                                        <Grid.Column computer={index == 1 ? 6 : 5} tablet={index == 1 ? 6 : 5} mobile={16}>
                                            <NoaRadialBarChart data={summaryData} colors={pieChartColors[index]}/>
                                        </Grid.Column>
                                    ))}
                                </Grid>
                            </Grid.Column>
                        </Grid>
                        :""}
                    </NoaContainer>
                    </NoaCard>
                </Grid.Column>                
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const ServicesTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    
    const services = props.services;
    //const columns = props.columns;
    const getServices = props.getServices;
    const filters = props.filters;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const setClearSelected = props.setClearSelected;
    const selectedRows = props.selectedRows;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;

	const [selections, setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"vpn-service" : {}});

    useEffect(() => {
		setSelected(selections);
	}, [selections]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
        {
            label: "8",
            Header: "Service Name",
            Cell: ({row}) => {
                let serviceId = row.original.serviceId;
                let serviceName = row.original.serviceName;
                let serviceType = row.original.serviceType;
                
                const toServiceInstance = { 
                    pathname: `/Services/${serviceName}`,
                }
                return <Link to={toServiceInstance} onClick={() => {
                    sessionStorage.setItem("serviceId",serviceId);
                    sessionStorage.setItem("serviceName",serviceName);
                    sessionStorage.setItem("serviceType",serviceType);
                }}>{serviceName}</Link>
            },
            width: 2
        },
        {
            label: "2",
            Header: "Service Type",
            accessor: "serviceType",
            width: 2
        },
        {
            label: "4",
            Header: "Subscriber Name",
            accessor: "subscriberName",
            width: 2
        },
        {
            label: "5",
            Header: "Service Rate",
            accessor: "serviceRate",
            width: 2
        },
        {
            label: "6",
            Header: "End Points",
            accessor: "endpointsCount",
            width: 2
        },
        {
            label: "7",
            Header: "Paths",
            accessor: "pathsCount",
            width: 2
        },
        {
            label: "8",
            Header: "Admin Status",
            Cell: ({row}) => (
                renderBoolean(row,"adminStatus",false)
            ),
            width: 2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"enabled",true)
            ),
            width: 1
        }
    ]

    const handleAddService = () => {
        router.stateService.go("add-service",{fetchData: fetchData, clearSelection: clearSelection})
    }
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["services-list"]);

        NoaClient.delete(
			"/api/service/",
			selectedItems,
			(response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        });
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getServices(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"vpn-service" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getServices(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getServices(filterObj)
    }
    
    const fetchData = () => {
        fetchFilteredData({"filters":null})
    }

	if (!services && !services.length)
		return null;

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Service List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddService}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={services}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="VPN Services" 
                        fetchData={fetchData} 
                        location="services-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    );
}

const renderBoolean = (row,key,operational) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            operational ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' /> : 
            <Label basic color={'green'}>
                Enabled
            </Label>
            : 
            operational ?
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' /> :
            <Label basic color={'red'}>
                Disabled
            </Label>
        }
       </>
    )
}

const AddService = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const getServices = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const [service, setService] = useState({});

    const handleChange = (value, key) => {
		setService(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/service/",
            service,
            (response) => {
                noaNotification('success','VPN Service Created Successfully');
                getServices();
                closeFooter();
        })
    }

    const addressTypes = [
        { 'key': "ipv4", 'text': "IPV4", 'value': "ipv4" },
        { 'key': "ipv6", 'text': "IPV6", 'value': "ipv6" }
    ]

    const serviceTypes = [
        { 'key': "L3 VPN", 'text': "L3 VPN", 'value': "L3 VPN" },
        { 'key': "L2 VPN", 'text': "L2 VPN", 'value': "L2 VPN" }
    ]

    const labelType = [
        {
            key: 'perRouter',
            text: 'Per Router',
            value: 'perRouter',
        },
        {
            key: 'perInstance',
            text: 'Per Instance',
            value: 'perInstance',
        }
    ];

    const instanceTypes = [
        {
            key: 'vpls',
            text: 'VPLS',
            value: 'vpls',
        },
        {
            key: 'vpws',
            text: 'VPWS',
            value: 'vpws',
        }
    ];

    const protocolTypes = [
        {
            key: 'bgp',
            text: 'BGP',
            value: 'BGP',
        },
        {
            key: 'ldp',
            text: 'LDP',
            value: 'LDP',
        }
    ];

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create Service</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-service">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid columns={2} stackable>
                        <Grid.Column computer={8} tablet={16} mobile={16}>
                        <Grid>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16} textAlign='center'>
                                    <p style={formHeader}>Service Details</p>
                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={1} style={formSpacingTB}>
                                <Grid.Column width={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Service Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='serviceName' 
                                                            value={service.serviceName}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'serviceName')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Service Type</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection required
                                                            placeholder="Select Type"
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            options={serviceTypes} 
                                                            value={service.serviceType}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'serviceType')
                                                            }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter} className="required">Subscriber Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='subscriberName' 
                                                            value={service.subscriberName}
                                                            fluid={false}                                                            
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'subscriberName')
                                                            }
                                                >
                                                    <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Preserve CE-VLAN</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={service.ceVlanPreservation ? service.ceVlanPreservation : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'ceVlanPreservation')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Preserve CE-VLAN COS</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={service.ceVlanCosPreservation ? service.ceVlanCosPreservation : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'ceVlanCosPreservation')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Carrier Supporting Carrier</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Checkbox
                                                    toggle={true}
                                                    checked={service.carrierscarrier ? service.carrierscarrier : false}
                                                    onChange={
                                                        (e,data)=>handleChange(data.checked,'carrierscarrier')
                                                    }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        </Grid.Column>

                        <Grid.Column computer={8} tablet={16} mobile={16}>
                            {service.serviceType === "L3 VPN" ? (
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} textAlign='center'>
                                        <p style={formHeader}>L3VPN Details</p>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1} style={formSpacingTB}>
                                    <Grid.Column width={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Address Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection fluid required
                                                            placeholder="Addr Type"
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            options={addressTypes} 
                                                            value={service.addressType}
                                                            onChange={
                                                                (e, {value}) => handleChange(value, 'addressType')
                                                            }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Apply Label Mode</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                                placeholder="Label Mode"
                                                                selectOnBlur={false}
                                                                style={dropdownStyle}
                                                                options={labelType} 
                                                                value={service.applyLabelMode}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'applyLabelMode')
                                                                }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Routing Table Limit Number</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='routingTableLimitNumber' 
                                                                value={service.routingTableLimitNumber}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'routingTableLimitNumber')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Prefix Limit Number</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='prefixLimitNumber' 
                                                                value={service.prefixLimitNumber}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'prefixLimitNumber')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            )
                            : service.serviceType === "L2 VPN" ? (
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} textAlign='center'>
                                        <p style={formHeader}>L2VPN Details</p>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1} style={formSpacingTB}>
                                    <Grid.Column width={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Instance Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                                placeholder="Instance Types"
                                                                options={instanceTypes} 
                                                                selectOnBlur={false}
                                                                style={dropdownStyle}
                                                                value={service.instanceType}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'instanceType')
                                                                }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>


                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Discovery Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                                placeholder="Discovery Type"
                                                                options={protocolTypes} 
                                                                selectOnBlur={false}
                                                                style={dropdownStyle}
                                                                value={service.discoveryType}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'discoveryType')
                                                                }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Signaling Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                                placeholder="Signaling Type"
                                                                options={protocolTypes} selectOnBlur={false}
                                                                value={service.signalingType}
                                                                style={dropdownStyle}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'signalingType')
                                                                }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>MTU</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='mtu' 
                                                                value={service.mtu}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'mtu')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={2} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>MAC Aging Timer</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='macAgingTimer' 
                                                                value={service.macAgingTimer}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleChange(value, 'macAgingTimer')
                                                                }
                                                    >
                                                        <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            ) : ""}
                        </Grid.Column>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                handleAdd()
                                context.setRenderLocation(["add-service"]);
                            }}>Add</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}
export default withRouter(ServiceManager);
export {AddService};