import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../widget/NoaTable';

import { 
    Grid, Button, Checkbox, 
    Dropdown,Icon, Divider 
} from 'semantic-ui-react';

import { Link } from "react-router-dom";

import { 
    noBoxShadow,noPadding, noMarginTB, 
    noMarginLR, dividerStyle, completeHeight,
    formParameter, applyButton, cancelButton,
    tablePadding, tableHeaderHeight,formTitle,
    completeWidth, fullHeight
} from '../constants';

import NoaClient from '../utility/NoaClient';

import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { RouteRediretContext } from '../utility/RouteRedirect';
import NoaFilter from '../widget/NoaFilter';

import {NoaContainer, NoaHeader} from '../widget/NoaWidgets';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../widget/NoaNotification';

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const ServiceEndpointManager = (props) => {
    const serviceId = props.serviceId;
    const serviceType = props.serviceType;

    const [endpoints,setEndpoints] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = endpoints[sel[i]].endpointId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getEndpoints = () => {
        NoaClient.get(
            "/api/service/" + serviceId + "/endpoint",
            (response) => {
                let responseData = response.data;
                setEndpoints(responseData);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getEndpoints();
        context.setRenderLocation(["endpoints-list",]);
        router.stateService.go('default');
    },[]);
    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={fullHeight}>
                    <Grid.Column width={16}>
                        <EndpointTable endpoints={endpoints} getEndpoints={getEndpoints}
                                    selectedRows={selectedRows}
                                    setClearSelected={setClearSelected}
                                    setSelected={setSelected} 
                                    clearSelected={clearSelected}
                                    serviceId={serviceId}
                        />
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
const EndpointTable = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const endpoints = props.endpoints;
    const getEndpoints = props.getEndpoints;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const serviceId = props.serviceId;

    const [selections,setSelections] = useState([]);
    
    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
        {
            label: "8",
            Header: "Endpoint Name",
            Cell: ({row}) => {
                let deviceId = row.original.endpointId;
                let deviceName = row.original.endpointName;
                
                const toElementInstance = { 
                    pathname: `/Elements/${deviceName}`,
                }
                return <Link to={toElementInstance} onClick={() => {
                    sessionStorage.setItem("elementId",deviceId);
                    sessionStorage.setItem("elementName",deviceName);
                }}>{deviceName}</Link>
            },
            width: 2
        },
		{
			label: "2",
			Header: "Endpoint Role",
            accessor: "endpointRole",
            width: 2
		},
        {
			label: "4",
			Header: "Endpoint IP Address",
            accessor: "endpointIp",
            width: 3
		},
        {
			label: "5",
			Header: "Network",
            accessor: "networkId",
            width: 3
        },
        {
            label: "8",
            Header: "Endpoint Status",
            Cell: ({row}) => (
                renderBoolean(row,"endpointStatus")
            ),
            width: 3
        }
    ]

    const router = useRouter();

    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    const handleAddEndpoint = () => {
        router.stateService.go("add-endpoint",{serviceId:serviceId,fetchData: getEndpoints,clearSelection: clearSelection})
    }
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["endpoints-list"]);

        NoaClient.delete(
            "/api/service/" + serviceId + "/endpoint",
            selectedItems,
            (response) => {
                getEndpoints();
                clearSelection();
        })
    }

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    <NoaFilter filters={{}} getData={getEndpoints}/>
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                    {/* <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddEndpoint}
                                    />      */}                           
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={endpoints}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        resource="Service Endpoints" 
                        fetchData={getEndpoints} 
                        location="endpoints-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddEndpoint = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const getEndpoints = props.fetchData;
    const clearSelection = props.clearSelection;
    const serviceId = props.serviceId;

    const setRenderAdd = props.setRenderAdd;

    let serviceType = sessionStorage.getItem("serviceType");

    const [networks, setNetworks] = useState([]);
    const [network, setNetwork] = useState(null);

    const [networkNodes, setNetworkNodes] = useState([]);
    const [selectedNodes, setSelectedNodes] = useState([]);

    const closeFooter = () => {
        router.stateService.go('default');
    }

    useEffect(() => {
        context.setRenderLocation(["add-endpoint"]);
        let filter = {}
        if(serviceType === "L2 VPN") {
            filter = {
                "filters" : {
                    "ietf-network" : {
                        "network-type" : ["L2 Network"]
                    }
                }
            }
        } else {
            filter = {
                "filters" : {
                    "ietf-network" : {
                        "network-type" : ["L3 Network"]
                    }
                }
            }
        }
        getNetworks(filter);
    },[]);

    const getNetworks = (filter) => {
        NoaClient.post(
            "/api/network",
            filter,
            (response) => {
                let responseData = response.data;
                let networksList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let networkObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        networksList[index] = networkObj;
                    })
                }
                setNetworks(networksList);
            }
        )
    }

    useEffect(() => {
        if(network != null) {
            getNetworkNodes();
        }
    },[network]);

    const getNetworkNodes = () => {
        NoaClient.get(
            "/api/network/" + network + "/node",
            (response) => {
                let responseData = response.data;
                setNetworkNodes(responseData);
            }
        )
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/service/" + serviceId + "/endpoint",
            selectedNodes,
            (response) => {
                noaNotification('success','Endpoints Added to Service Successfully');
                getEndpoints();
                closeFooter();
        })
    }

    const checkboxHandler = (data) => {
        const nodeId = data.name;
        if (selectedNodes.includes(nodeId)) {
            setSelectedNodes(selectedNodes.filter(node => node !== nodeId));
        } else {
            setSelectedNodes(prevState => [...prevState, nodeId]);
        }
    }

    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Add Endpoint</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="add-endpoint">
                        <Grid>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={2} stackable>
                                    <Grid.Column computer={window.innerWidth > 1330 ? 8 : 16} tablet={16} mobile={16}>
                                        <Grid>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8} textAlign='right'>
                                                <p style={formParameter}>Select Network</p>
                                            </Grid.Column>
                                            <Grid.Column width={8} textAlign='left'>
                                                <Dropdown clearable selection required
                                                        placeholder="Select Network"
                                                        selectOnBlur={false}
                                                        options={networks} 
                                                        onChange={(e,{value}) => {
                                                            let network = value==='' ? null : value
                                                            setNetwork(network);
                                                        }}
                                                />
                                            </Grid.Column>
                                        </Grid.Row>
                                        </Grid>
                                    </Grid.Column>

                                    <Grid.Column computer={window.innerWidth > 1330 ? 8 : 16} tablet={16} mobile={16}>
                                        <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid columns={3}>
                                                    {networkNodes.map((node,index) => (
                                                        <Grid.Column width='equal'>
                                                            <Checkbox
                                                                key={index}
                                                                name={node.nodeId}
                                                                label={node.nodeName}
                                                                checked={selectedNodes.includes(node.nodeId)}
                                                                onChange={
                                                                    (e, data) => {checkboxHandler(data)}
                                                                }
                                                            />
                                                        </Grid.Column>
                                                    ))}
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        </Grid>
                                    </Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row style={{paddingTop: "2em"}} columns={1}>
                                <Grid.Column width={16}>
                                    <Grid columns={2} stackable>
                                        <Grid.Column width={8} textAlign='right'>
                                            <Button style={applyButton} onClick={() => {
                                                handleAdd()
                                                context.setRenderLocation(["add-endpoint"]);
                                            }}>Add</Button>
                                        </Grid.Column>
                                        <Grid.Column width={8} textAlign='left'>
                                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                        </Grid.Column>
                                    </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}


export default ServiceEndpointManager;
export {AddEndpoint}