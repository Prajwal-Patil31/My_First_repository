import React from 'react';
const ServiceStatistics = (props) => {
    return(
        <div></div>
    )
}
export default ServiceStatistics;