/**@module Login */

import React, { useContext, useState } from 'react';
import { AuthContext } from '../../utility/AuthContext';

import { Grid, Button, Checkbox, Input, Icon } from 'semantic-ui-react';

import { applyButton, checkboxDescription, formContentSpacingTB, inputStyle } from '../../constants';

import 'semantic-ui-css/semantic.min.css';

import * as yup from 'yup';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';

 /**
  * Validation Schema; Used for Login Form Validation.
  */
let loginSchema = yup.object().shape({
	username: yup.string()
				.min(4, "Too Short.")
				.required("Username is a Required Field."),
	password: yup.string().required("Password is a Required Field.")
})

const Login = (props) => {
    const authContext = useContext(AuthContext);
    const context = useContext(GlobalSpinnerContext);

    const [user, setUser] = useState({username: "",password: ""});
    const [redirect, setRedirect] = useState(false);
    
    const setRedirection = () => {
        setRedirect(true);
    }

    const handleInput = (value, key) => {
		setUser(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleSubmit = () => {
        context.setRenderLocation(["login"]);
        authContext.login(user,setRedirection);
    }
    
    return (
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid centered style={{paddingTop: '8px'}}>
                    <Grid.Row columns={1} style={formContentSpacingTB}>
                        <Grid.Column width={16} verticalAlign='middle'>
                            <Grid>
                                <Grid.Row columns={3}>
                                    <Grid.Column width={2}></Grid.Column>
                                    <Grid.Column width={12}>
                                        <Input
                                            name='username'
                                            value={user.username}
                                            onChange={
                                                (e, {value}) => handleInput(value==='' ? null : value, 'username')
                                            }
                                            iconPosition='left'
                                            placeholder='Username'
                                        >
                                            <Icon name="user"/>
                                            <input style={Object.assign({width:"15em"},inputStyle)}></input>
                                        </Input>
                                    </Grid.Column>
                                    <Grid.Column width={2}></Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={3} style={{paddingTop:"0px"}}>
                                    <Grid.Column width={2}></Grid.Column>
                                    <Grid.Column width={12}>
                                        <Input
                                            name='password'
                                            value={user.password}
                                            onChange={
                                                (e, {value}) => handleInput(value==='' ? null : value, 'password')
                                            }
                                            iconPosition='left'
                                            placeholder='Password'
                                            type='password'
                                        >
                                            <Icon name="lock"/>
                                            <input style={Object.assign({width:"15em"},inputStyle)}></input>
                                        </Input>
                                    </Grid.Column>
                                    <Grid.Column width={2}></Grid.Column>
                                </Grid.Row>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} verticalAlign='middle'>
                            <Grid columns={2} stackable>
                                <Grid.Column>
                                    <Checkbox label='Remember Me' style={checkboxDescription}/>
                                </Grid.Column>
                                <Grid.Column style={checkboxDescription}>
                                    Forgot Password?
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={3}>
                                <Grid.Column width={5}></Grid.Column>
                                <Grid.Column width={6}>
                                    <Button style={applyButton} onClick={handleSubmit}>
                                        Login
                                    </Button>
                                </Grid.Column>
                                <Grid.Column width={5}></Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
export default Login;