/**@module Logout */

import React, { useContext, useEffect } from 'react';
import { AuthContext } from '../../utility/AuthContext';
import { withRouter } from "react-router-dom";

/**
 * Component for Logging Out the User.
 * 
 * @class
 * @augments React.Component
 */
const Logout = (props) => {
    const authContext = useContext(AuthContext);
    
    const setRedirect = () => {
        props.history.push('/');
    }

    useEffect(() => {
        authContext.logout(setRedirect);
    },[]);

    return(
        <div>

        </div>
    )
}

export default withRouter(Logout);