/**@module UserGroups */

import React, { useContext, useEffect, useState } from 'react';

import {
	Grid,
	Segment,
	Button,
	Checkbox,
	Divider,
	Dropdown,
	Icon,
    Accordion,
    Input,
    Step,
    Card
} from 'semantic-ui-react';

import { 
    noBoxShadow, cardLayout, titleText,
    noMarginLR, noMarginTB, completeHeight, 
    completeWidth, tableHeaderHeight, tablePadding, 
    noPadding, accordionTitle, formParameter, 
    cancelButton, applyButton, formTitle, 
    formHeader, fullHeight, dividerStyle,
    accordionHeader, checkboxHeader, accordionFixedHeight,
    subAccordionTitle, formContentSpacingTB, noaCardTitle,
    noaCardDesc, accordionContentMargins, noaCardLayout,
    inputBoxStyle, dropdownStyle
} from '../../constants';

import 'semantic-ui-css/semantic.min.css';

import NoaTable from '../../widget/NoaTable';
import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';
import { NoaContainer, NoaHeader } from '../../widget/NoaWidgets';
import NoaFilter from '../../widget/NoaFilter';
import NoaToolbar from '../../widget/NoaToolbar';
import {DropdownIcon} from '../../widget/NoaIcons';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../widget/NoaNotification';
import NoaCard from '../../widget/NoaCard';

const RoleManager = (props) => {
    const [roles, setRoles] = useState([]);
    
    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
	const context = useContext(GlobalSpinnerContext);
	const redirectContext = useContext(RouteRediretContext);
	
	const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = roles[sel[i]].roleId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
	}

	const getRoles = (filterObj) => {
        context.setRenderLocation(["role-list"]);
        NoaClient.post(
            "/api/platform/security/rbac/role",
			filterObj,
            (response) => {
                let responseData = response.data;
                setRoles(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
	}

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"access-role":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getRoles(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({},completeHeight,cardLayout)}>
                            <RoleTable roles={roles} getRoles={getRoles}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const RoleTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);

    const roles = props.roles;
    const getRoles = props.getRoles;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"access-role" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "Role Name",
            accessor: "roleName",
            width:3
		},
		{
			label: "2",
			Header: "Role Code",
            accessor: "roleCode",
            width:3
		},
        {
			label: "4",
			Header: "User Count",
            accessor: "assignedUsers",
            width:2
        },
        {
			label: "5",
			Header: "Group Count",
            accessor: "assignedGroups",
            width:2
        },
        {
			label: "6",
			Header: "Enabled Features",
            accessor: "featuresEnabled",
            width:2
        },
        {
			label: "7",
			Header: "Admin Status",
			Cell: ({row}) => (
                renderBoolean(row,"adminStatus")
            ),
            width:2
        },
    ]

    const handleAddRole = () => {
        router.stateService.go("add-role",{fetchData: getRoles, clearSelection: clearSelection})
    }

    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-role',{id: roles[selId].roleId,fetchData: getRoles,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["role-list"]);

        NoaClient.delete(
            "/api/platform/security/rbac/role",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getRoles(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"access-role" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getRoles(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getRoles(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Role List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddRole}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={roles}
                                columns={columns}
                                selectedRows={selections}
                                onSelectedRowsChange={setSelections}
                                clearSelected={clearSelected}
                                setClearSelected={setClearSelected}
                                selectedPageSize={pageSize}
                                handlePagination={handlePagination}
                                totalPages={totalPages}
                                handlePageSize={handlePageSize}
                                totalEntries={totalEntries}
                                resource="Roles" 
                                fetchData={fetchData} 
                                location="role-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer> 
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddRole = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const getRoles = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const [step, setStep] = React.useState(0);
    const [role, setRole] = useState({});
    const [features, setFeatures] = useState([]);
    const [selectedFeatures, setSelectedFeatures] = useState([]);
    
    const [elementActions, setElementActions] = useState([]);
	const [networkActions, setNetworkActions] = useState([]);
	const [serviceActions, setServiceActions] = useState([]);
    const [platformActions, setPlatformActions] = useState([]);
    
    const [selectedPrivileges, setSelectedPrivileges] = useState([]);

    const [indexesState, setIndexesState] = useState({ activeIndexes: [] });
    const [childIndexesState, setChildIndexesState] = useState({ activeIndexes: [] });

    const [users, setUsers] = useState([]);
    const [userGroups, setUserGroups] = useState([]);
    const [selectedUsers, setSelectedUsers] = useState([]);
    const [selectedGroups, setSelectedGroups] = useState([]);

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 3 ? 3 : nextStep);
    };

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);    
    
    useEffect(() => {
        switch (step) {
            case 0:
                setRole({});
                context.setRenderLocation(["get-features"]);
                getFeatures();
                break;
            case 1:
                if(selectedFeatures.length > 0) {
                    context.setRenderLocation(["get-feature-actions"]);
                    getRelatedActions();
                } else {
                    alert("Select Feature");
                    setStep(0);
                }
                break;
            case 2:
                context.setRenderLocation(["get-users"]);
                getUserGroups();
                getUsers();       
                break;
            case 3:
                context.setRenderLocation(["add-role"]);
                handleAdd();
                break;
            default:
                break;
        }
    }, [step]);

    const getFeatures = () => {
		NoaClient.get(
            "/api/platform/feature",
			(response) => {
				let responseData = response.data;
				setFeatures(responseData);
		});
    }

    const getRelatedActions = () => {
		NoaClient.post(
			"/api/platform/action",
			selectedFeatures,
			(response) => {
				let responseData = response.data;
				setElementActions(responseData["Element Privileges"]);
				setNetworkActions(responseData["Network Privileges"]);
				setServiceActions(responseData["Service Privileges"]);
				setPlatformActions(responseData["Platform Privileges"]);
		});
    }

    const getUsers = () => {
        NoaClient.get(
            "/api/platform/security/rbac/user",
            (response) => {
                let responseData = response.data;
                let usersList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let userObj = {'key' : item.accountId, 'value' : item.accountId, 'text': item.userName}
                        usersList[index] = userObj;
                    })
                }
                setUsers(usersList);
            }
        )
    }

    const getUserGroups = () => {
        NoaClient.get(
            "/api/platform/security/rbac/group",
            (response) => {
                let responseData = response.data;
                let groups = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let groupObj = {'key' : item.userGroupName, 'value' : item.userGroupId, 'text': item.userGroupName}
                        groups[index] = groupObj;
                    })
                }
                setUserGroups(groups);
            }
        )
    }

    const handleAdd = () => {
        NoaClient.put(
			"/api/platform/security/rbac/role",
			role,
			(response) => {
                let responseData = response.data;
                noaNotification('success','Role Created Successfully');
                handleAddPrivileges(responseData.roleId,selectedPrivileges,selectedFeatures);
                handleAssignments(responseData.roleId,selectedUsers,selectedGroups);
                getRoles();
                closeFooter();
        });
    }

	const handleAddPrivileges = (roleId,selectedPrivileges,selectedFeatures) => {
		let body = {};
		body["actionIds"] = selectedPrivileges;
		body["featureIds"] = selectedFeatures;
		NoaClient.put(
			"/api/platform/security/rbac/role/" + roleId + "/privilege",
			body,
			(response) => {
                noaNotification('success','Privileges added to Role Successfully');
        });
    }
    
    const handleAssignments = (roleId,selectedUsers,selectedGroups) => {
		if(selectedUsers.length > 0) {
            body.users = selectedUsers;
            NoaClient.post(
                "/api/platform/security/rbac/role/" + roleId + "/user",
                selectedUsers,
                (response) => {
                    noaNotification('success','Assigned Role to Users Successfully');
            });
		}
		if(selectedGroups.length > 0) {
            body.groups = selectedGroups;
            NoaClient.post(
                "/api/platform/security/rbac/role/" + roleId + "/group",
                selectedGroups,
                (response) => {
                    noaNotification('success','Assigned Role to Group Successfully');
            });
		}
    }


    const handleInput = (value, key) => {
		setRole(prevState => ({
            ...prevState,
            [key]: value
        }));
    }
    
    const handleCheckBoxClick = (data) => {
		if(data.checked) {
            setSelectedFeatures([...selectedFeatures, data.name]);
        } else {
            setSelectedFeatures(selectedFeatures.filter(id => id !== data.name));       
        }
    }

    const handleClick = (e, titleProps,item) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(item);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(item);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;
    
    const handleChildClick = (e, titleProps,item) => {
        const { index } = titleProps;
        const activeIndexes = childIndexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(item);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(item);
        }
        setChildIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const childIndex = childIndexesState.activeIndexes;

    const checkboxHandler = (data,actionId) => {
		if(data.checked) {
            setSelectedPrivileges([...selectedPrivileges, actionId]);
		} else {
			setSelectedPrivileges(selectedPrivileges.filter(id => id !== actionId));
		}
    }
    
    console.log(platformActions)
    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create Role</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} style={{marginTop: "1.5em"}} id="add-role">
                        <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Step.Group style={{border: "0px"}} fluid>
                                    <Step style={{border: "0px"}} active={step == 0 ? true : false} completed={step > 0 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Role Details</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 1 ? true : false} completed={step > 1 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Role Privileges</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 2 ? true : false} completed={step > 2 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Assign Users/Group</Step.Title>
                                        </Step.Content>
                                    </Step>
                                </Step.Group>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1} style={{paddingTop: "2.5em"}} verticalAlign='middle' textAlign='left'>
                            <Grid.Column width={16} style={{paddingLeft: "2em", paddingRight: "2em"}} verticalAlign='middle' textAlign='left'>
                                {step === 0 ? (
                                <NoaContainer style={{minHeight: "34.375em"}}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} id="get-features">
                                        <Grid columns={3}>
                                            <Grid.Column width={1}></Grid.Column>
                                            <Grid.Column width={14}>
                                                <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <p style={formHeader}>Role Details</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} style={{paddingLeft:"4em",paddingRight:"4em"}}>
                                                    <Grid columns={3} stackable>
                                                        <Grid.Column computer={7} tablet={16} mobile={16}>
                                                        <Grid>
                                                            <Grid.Row columns={1}>
                                                                <Grid.Column width={16}>
                                                                <Grid columns={3} stackable>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <p style={formParameter} className="required">Role Name</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Input type='text' name='roleName' 
                                                                            value={role.roleName}
                                                                            fluid={false}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'roleName')
                                                                            }>
                                                                                <input style={inputBoxStyle}></input>
                                                                        </Input>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={4}></Grid.Column>
                                                                </Grid>
                                                                </Grid.Column>
                                                            </Grid.Row>

                                                            <Grid.Row columns={1}>
                                                                <Grid.Column width={16}>
                                                                <Grid columns={3} stackable>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <p style={formParameter}>Role Code</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Input type='text' name='roleCode' 
                                                                            value={role.roleCode}
                                                                            fluid={false}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'roleCode')
                                                                            }>
                                                                                <input style={inputBoxStyle}></input>
                                                                        </Input>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={4}></Grid.Column>
                                                                </Grid>
                                                                </Grid.Column>
                                                            </Grid.Row>

                                                            <Grid.Row columns={1}>
                                                                <Grid.Column width={16}>
                                                                <Grid columns={3} stackable>                                                                    
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <p style={formParameter}>Description</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Input type='text' name='description' 
                                                                            value={role.description}
                                                                            fluid={false}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'description')
                                                                            }>
                                                                                <input style={inputBoxStyle}></input>
                                                                        </Input>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={4}></Grid.Column>
                                                                </Grid>
                                                                </Grid.Column>
                                                            </Grid.Row>
                                                        </Grid>
                                                        </Grid.Column>
                                                        <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                                        <Grid.Column computer={7} tablet={16} mobile={16}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <p style={formHeader} className="required">Select Features</p>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} style={Object.assign({paddingLeft:"3em",paddingRight:"3em"},accordionContentMargins)}>
                                                        <Card.Group itemsPerRow={3}>
                                                        {features.length ? features.map((feature, index) =>
                                                            <Card link style={noaCardLayout}>
                                                                <Card.Content>
                                                                <Card.Header textAlign='left' style={noaCardTitle}>
                                                                    <NoaContainer style={completeWidth}>
                                                                    <Checkbox
                                                                        label={feature.featureName}
                                                                        name={feature.featureId}
                                                                        checked={selectedFeatures.includes(feature.featureId)}
                                                                        onChange={
                                                                            (e, data) => handleCheckBoxClick(data)
                                                                        }
                                                                    />
                                                                    </NoaContainer>
                                                                </Card.Header>
                                                                <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                    {feature.description}
                                                                </Card.Description>
                                                                </Card.Content>
                                                            </Card>
                                                        ) : ''}
                                                        </Card.Group>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                            <Grid.Column width={1}></Grid.Column>
                                        </Grid>
                                        
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </NoaContainer>
                                ) : 
                                step === 1 ? (
                                <NoaContainer style={{minHeight: "34.375em"}}>
                                <Grid verticalAlign='middle'>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} id="get-feature-actions">
                                        <Accordion>
                                            {Object.keys(platformActions).length > 0 ? 
                                            <>
                                            <Accordion.Title
                                                active={activeIndex.includes("feature")}
                                                index={0}
                                                onClick={(e,titleProps) => handleClick(e,titleProps,"feature")}
                                                style={Object.assign({textAlign:'left'},accordionTitle)}
                                            >
                                                <DropdownIcon />
                                                Role Privileges: Feature
                                            </Accordion.Title>
                                            <Accordion.Content active={activeIndex.includes("feature")} 
                                                style={Object.assign({borderBottom:"1px solid rgb(213,223,233)"})}>
                                            <NoaContainer style={Object.assign({paddingLeft:"5em",paddingRight:"5em"},accordionContentMargins,completeWidth)}>
                                                <NoaCard title={null} renderDuration={false}>
                                                <Grid style={accordionContentMargins}>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid>
                                                        {Object.keys(platformActions).map((keyItem,index) => (
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                            <Grid>
                                                                <Grid.Row columns={1} style={{paddingLeft:"2em",paddingRight:"2em"}}>
                                                                    <Grid.Column width={16} textAlign='left'>
                                                                        <p style={accordionHeader}>{keyItem}</p>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16} style={{paddingLeft:"4em",paddingRight:"4em"}}>
                                                                    <Card.Group itemsPerRow={3}>
                                                                        {platformActions[keyItem].length ? platformActions[keyItem].map((action, index) =>
                                                                            <Card link style={noaCardLayout}>
                                                                                <Card.Content>
                                                                                <Card.Header textAlign='left' style={noaCardTitle}>
                                                                                    <NoaContainer style={completeWidth}>
                                                                                    <Checkbox 
                                                                                        label={action.actionName}
                                                                                        name={action.actionId}
                                                                                        onChange={
                                                                                            (e, data) => checkboxHandler(data,action.actionId)
                                                                                        }
                                                                                    />
                                                                                    </NoaContainer>
                                                                                </Card.Header>
                                                                                <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                                    {action.actionReference}
                                                                                </Card.Description>
                                                                                </Card.Content>
                                                                            </Card>
                                                                        ) : ''}
                                                                    </Card.Group>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                            </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        ))}
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </NoaCard>
                                            </NoaContainer>
                                            </Accordion.Content>
                                            </>
                                            :""}
                                            
                                            {Object.keys(elementActions).length > 0 || Object.keys(networkActions).length > 0 
                                                || Object.keys(serviceActions).length > 0 ? 
                                            <>
                                            <Accordion.Title
                                                active={activeIndex.includes("resource")}
                                                index={1}
                                                onClick={(e,titleProps) => handleClick(e,titleProps,"resource")}
                                                style={Object.assign({textAlign:'left'},accordionTitle)}
                                            >
                                                <DropdownIcon />
                                                Role Privileges: Resource
                                            </Accordion.Title>
                                            <Accordion.Content active={activeIndex.includes("resource")} 
                                                style={Object.assign({borderBottom:"1px solid rgb(213,223,233)"})}>
                                            <NoaContainer style={Object.assign({paddingLeft:"4em",paddingRight:"4em"},accordionContentMargins,completeWidth)}>
                                            <NoaCard title={null} renderDuration={false}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Accordion>
                                                        {Object.keys(elementActions).length > 0 ? 
                                                        <>
                                                        <Accordion.Title
                                                            active={childIndex.includes("element")}
                                                            index={0}
                                                            onClick={(e,titleProps) => handleChildClick(e,titleProps,"element")}
                                                            style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                                        >
                                                            <DropdownIcon />
                                                            Element Privileges
                                                        </Accordion.Title>
                                                        <Accordion.Content active={childIndex.includes("element")}>
                                                        <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                                            <Grid.Row columns={1}>
                                                                <Grid.Column width={16} id="get-feature-actions">
                                                                <Grid style={{paddingLeft: "3.5em",paddingRight: "3.5em"}}>
                                                                {Object.keys(elementActions).map((keyItem,index) => (
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid>
                                                                        <Grid.Row columns={1}>
                                                                            <Grid.Column width={16} textAlign='left'>
                                                                                <p style={accordionHeader}>{keyItem}</p>
                                                                            </Grid.Column>
                                                                        </Grid.Row>
                                                                        <Grid.Row columns={1}>
                                                                            <Grid.Column width={16} style={{paddingLeft: "3em",paddingRight: "3em"}} textAlign='left'>
                                                                            <Card.Group itemsPerRow={3}>
                                                                            {elementActions[keyItem].length ? elementActions[keyItem].map((action, index) =>
                                                                                <Card link style={noaCardLayout}>
                                                                                    <Card.Content>
                                                                                    <Card.Header textAlign='left' style={noaCardTitle}>
                                                                                        <NoaContainer style={completeWidth}>
                                                                                        <Checkbox
                                                                                            label={action.actionName}
                                                                                            style={formParameter}
                                                                                            name={action.actionId}
                                                                                            onChange={
                                                                                                (e, data) => checkboxHandler(data,action.actionId)
                                                                                            }
                                                                                        />
                                                                                        </NoaContainer>
                                                                                    </Card.Header>
                                                                                    <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                                        {action.actionReference}
                                                                                    </Card.Description>
                                                                                    </Card.Content>
                                                                                </Card>
                                                                            ) : ''}
                                                                            </Card.Group>
                                                                            </Grid.Column>
                                                                        </Grid.Row>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                ))}
                                                                </Grid>
                                                                </Grid.Column>
                                                            </Grid.Row>
                                                        </Grid>
                                                        </Accordion.Content>
                                                        </>
                                                        : ""}
                                                        
                                                        {Object.keys(networkActions).length > 0 ? 
                                                        <>
                                                        <Accordion.Title
                                                            active={childIndex.includes("network")}
                                                            index={1}
                                                            onClick={(e,titleProps) => handleChildClick(e,titleProps,"network")}
                                                            style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                                        >
                                                            <DropdownIcon />
                                                            Network Privileges
                                                        </Accordion.Title>
                                                        <Accordion.Content active={childIndex.includes("network")}>
                                                        <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                                            <Grid.Row columns={1}>
                                                                <Grid.Column width={16} id="get-feature-actions">
                                                                <Grid style={{paddingLeft: "3.5em",paddingRight: "3.5em"}}>
                                                                {Object.keys(networkActions).map((keyItem,index) => (
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid>
                                                                        <Grid.Row columns={1}>
                                                                            <Grid.Column width={16} textAlign='left'>
                                                                                <p style={accordionHeader}>{keyItem}</p>
                                                                            </Grid.Column>
                                                                        </Grid.Row>
                                                                        <Grid.Row columns={1}>
                                                                            <Grid.Column width={16} style={{paddingLeft: "3em",paddingRight: "3em"}} textAlign='left'>
                                                                            <Card.Group itemsPerRow={3}>
                                                                            {networkActions[keyItem].length ? networkActions[keyItem].map((action, index) =>
                                                                                <Card link style={noaCardLayout}>
                                                                                    <Card.Content>
                                                                                    <Card.Header textAlign='left' style={noaCardTitle}>
                                                                                        <NoaContainer style={completeWidth}>
                                                                                        <Checkbox
                                                                                            label={action.actionName}
                                                                                            name={action.actionId}
                                                                                            style={formParameter}
                                                                                            onChange={
                                                                                                (e, data) => checkboxHandler(data,action.actionId)
                                                                                            }
                                                                                        />
                                                                                        </NoaContainer>
                                                                                    </Card.Header>
                                                                                    <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                                        {action.actionReference}
                                                                                    </Card.Description>
                                                                                    </Card.Content>
                                                                                </Card>
                                                                            ) : ''}
                                                                            </Card.Group>
                                                                            </Grid.Column>
                                                                        </Grid.Row>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                ))}
                                                                </Grid>
                                                                </Grid.Column>
                                                            </Grid.Row>
                                                        </Grid>
                                                        </Accordion.Content>
                                                        </>
                                                        :""}
                                                        {Object.keys(serviceActions).length > 0 ? 
                                                        <>
                                                        <Accordion.Title
                                                            active={childIndex.includes("service")}
                                                            index={2}
                                                            onClick={(e,titleProps) => handleChildClick(e,titleProps,"service")}
                                                            style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                                        >
                                                            <DropdownIcon />
                                                            Service Privileges
                                                        </Accordion.Title>
                                                        <Accordion.Content active={childIndex.includes("service")}>
                                                        <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                                            <Grid.Row columns={1}>
                                                                <Grid.Column width={16} id="get-feature-actions">
                                                                <Grid style={{paddingLeft: "3.5em",paddingRight: "3.5em"}}>
                                                                {Object.keys(serviceActions).map((keyItem,index) => (
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                    <Grid>
                                                                        <Grid.Row columns={1}>
                                                                            <Grid.Column width={16} textAlign='left'>
                                                                                <p style={accordionHeader}>{keyItem}</p>
                                                                            </Grid.Column>
                                                                        </Grid.Row>
                                                                        <Grid.Row columns={1}>
                                                                            <Grid.Column width={16} style={{paddingLeft: "3em",paddingRight: "3em"}} textAlign='left'>
                                                                            <Card.Group itemsPerRow={3}>
                                                                            {serviceActions[keyItem].length ? serviceActions[keyItem].map((action, index) =>
                                                                                <Card link style={noaCardLayout}>
                                                                                    <Card.Content>
                                                                                    <Card.Header textAlign='left' style={noaCardTitle}>
                                                                                        <NoaContainer style={completeWidth}>
                                                                                        <Checkbox
                                                                                            label={action.actionName}
                                                                                            name={action.actionId}
                                                                                            style={formParameter}
                                                                                            onChange={
                                                                                                (e, data) => checkboxHandler(data,action.actionId)
                                                                                            }
                                                                                        />
                                                                                        </NoaContainer>
                                                                                    </Card.Header>
                                                                                    <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                                        {action.actionReference}
                                                                                    </Card.Description>
                                                                                    </Card.Content>
                                                                                </Card>
                                                                            ) : ''}
                                                                            </Card.Group>
                                                                            </Grid.Column>
                                                                        </Grid.Row>
                                                                    </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                                ))}
                                                                </Grid>
                                                                </Grid.Column>
                                                            </Grid.Row>
                                                        </Grid>
                                                        </Accordion.Content>
                                                        </>
                                                        :""}
                                                    </Accordion>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </NoaCard>
                                            </NoaContainer>
                                            </Accordion.Content>
                                            </>
                                            :""}
                                        </Accordion>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </NoaContainer>
                                ) : 
                                step ===2 ? (
                                    <NoaContainer style={{minHeight: "34.375em"}}>
                                    <Grid verticalAlign='middle'>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} id="get-users">
                                                <Grid columns={3} stackable>
                                                    <Grid.Column width={1}></Grid.Column>
                                                    <Grid.Column width={14}>
                                                        <Grid columns={3} stackable>
                                                            <Grid.Column computer={7} tablet={16} mobile={16}>
                                                            <Grid>
                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                        <Grid columns={4} stackable>
                                                                            <Grid.Column width={2}></Grid.Column>
                                                                            <Grid.Column width={6}>
                                                                                <p style={formParameter}>Select Users</p>
                                                                            </Grid.Column>
                                                                            <Grid.Column width={6}>
                                                                            <Dropdown clearable selection required multiple
                                                                                    placeholder="Select Users"
                                                                                    selectOnBlur={false}
                                                                                    options={users}
                                                                                    value={selectedUsers}
                                                                                    style={dropdownStyle}
                                                                                    onChange={
                                                                                        (e, {value}) => setSelectedUsers(value)
                                                                                    }
                                                                            />
                                                                            </Grid.Column>
                                                                            <Grid.Column width={2}></Grid.Column>
                                                                        </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>

                                                                <Grid.Row columns={1}>
                                                                    <Grid.Column width={16}>
                                                                        <Grid columns={4} stackable>
                                                                            <Grid.Column width={2}></Grid.Column>
                                                                            <Grid.Column width={6}>
                                                                                <p style={formParameter}>Select User Groups</p>
                                                                            </Grid.Column>
                                                                            <Grid.Column width={6}>
                                                                            <Dropdown clearable selection required multiple
                                                                                    placeholder="Select User Groups"
                                                                                    selectOnBlur={false}
                                                                                    options={userGroups}
                                                                                    value={selectedGroups}
                                                                                    style={dropdownStyle}
                                                                                    onChange={
                                                                                        (e, {value}) => setSelectedGroups(value)
                                                                                    }
                                                                            />
                                                                            </Grid.Column>
                                                                            <Grid.Column width={2}></Grid.Column>
                                                                        </Grid>
                                                                    </Grid.Column>
                                                                </Grid.Row>
                                                            </Grid>
                                                            </Grid.Column>
                                                            <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                                            <Grid.Column computer={7} tablet={16} mobile={16}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                    <Grid.Column width={1}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </NoaContainer>
                                ) :
                                ""}
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={3} stackable>
                                    <Grid.Column width={5}></Grid.Column>
                                    <Grid.Column width={6}>
                                        <Grid columns={3} stackable>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={onPrevious} disabled={step === 0}>
                                                    Previous
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={applyButton} onClick={onNext} >
                                                    {step === 2 ? 'Add' : 'Next'}
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                            </Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                    <Grid.Column width={5}>
                                   
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ModifyRole = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const router = useRouter();
    const clearSelection = props.clearSelection;
    const getRoles = props.fetchData;

    const [roleId, setRoleId] = useState(null);

    useEffect(() => {
        const id = props.id;
        if(id != null && id != undefined) {
            setRoleId(id);
        }
    },[props.id]);

    const [data,setData] = useState({});
    const [indexesState, setIndexesState] = useState({ activeIndexes: [] });
    const [childIndexesState, setChildIndexesState] = useState({ activeIndexes: [] });
    
    const [features, setFeatures] = useState([]);

    const [elementActions, setElementActions] = useState([]);
	const [networkActions, setNetworkActions] = useState([]);
	const [serviceActions, setServiceActions] = useState([]);
    const [platformActions, setPlatformActions] = useState([]);

    const [users, setUsers] = useState([]);
    const [groups, setGroups] = useState([]);

    const [roleActions, setRoleActions] = useState([]);
    const [roleFeatures, setRoleFeatures] = useState([]);

    const [initialFeatures, setInitialFeatures] = useState([]);
    const [initialActions, setInitialActions] = useState([]);

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    useEffect(() => {
        if(roleId != null) {
            context.setRenderLocation(['role-detail','role-feature','role-assignments','role-action']);
            getRole();
            getFeatures();
            getRelatedUsers();
            getRelatedGroups();
            getRoleFeatures();
            getRoleActions();
            getActions();
        }
    },[roleId]);

    const getRole = () => {
		NoaClient.get(
            "/api/platform/security/rbac/role/" + roleId,
			(response) => {
				let responseData = response.data;
				setData(responseData);
            });
    }

    const getFeatures = () => {
		NoaClient.get(
            "/api/platform/feature",
			(response) => {
				let responseData = response.data;
				setFeatures(responseData);
		});
    }

    const getActions = () => {
		NoaClient.get(
            "/api/platform/action",
			(response) => {
				let responseData = response.data;
				setElementActions(responseData["Element Privileges"]);
				setNetworkActions(responseData["Network Privileges"]);
				setServiceActions(responseData["Service Privileges"]);
				setPlatformActions(responseData["Platform Privileges"]);
            });
    }

    const getRelatedUsers = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/" + roleId + "/user",
            (response) => {
                let responseData = response.data;
                setUsers(responseData);
            })
    }

    const getRelatedGroups = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/" + roleId + "/group",
            (response) => {
                let responseData = response.data;
                setGroups(responseData);
            }
        )
    }

    const getRoleActions = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/" + roleId + "/action",
            (response) => {
                let responseData = response.data;
                setRoleActions(responseData);
                setInitialActions(responseData);
            },
        )
    }

    const getRoleFeatures = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/" + roleId + "/feature",
            (response) => {
                let responseData = response.data;
                setRoleFeatures(responseData);
                setInitialFeatures(responseData)
            })
    }

    const handleCheckBoxClick = (data,feature) => {
		if(data.checked) {
            setRoleFeatures([...roleFeatures, feature.featureName]);
            
        } else {
            setRoleFeatures(roleFeatures.filter(id => id !== feature.featureName));       
        }
    }

    const checkboxHandler = (data,actionBody) => {
		if(data.checked) {
            setRoleActions([...roleActions,actionBody.actionName]);
		} else {
            setRoleActions(roleActions.filter(action => action !== actionBody.actionName));
		}
    }

	const handleModify = (roleId) => {
		/* let body = {};
		body["actionIds"] = selectedPrivileges;
		body["featureIds"] = selectedFeatures;
		NoaClient.put(
			"/api/platform/security/rbac/role/" + data.roleId + "/privilege",
			body,
			(response) => {
        }); */

        if(roleFeatures.length > 0) {
            let removedFeatures = initialFeatures.filter(item => !roleFeatures.includes(item))
            let newFeatures = roleFeatures.filter(item => !initialFeatures.includes(item))
            if(removedFeatures.length > 0) {
                handleRemoveFeatures(removedFeatures);
            }
            if(newFeatures.length > 0) {
                handleAddFeatures(newFeatures);
            }
        } else {
            handleRemoveFeatures(initialFeatures)
        }

        if(roleActions.length > 0) {
            let removedActions = initialActions.filter(item => !roleActions.includes(item))
            let newActions = roleActions.filter(item => !initialActions.includes(item))
            if(removedActions.length > 0) {
                handleRemoveActions(removedActions);
            }
            if(newActions.length > 0) {
                handleAddActions(newActions);
            }
        } else {
            handleRemoveFeatures(initialActions)
        }
    }

    const handleAddFeatures = (newFeatures) => {
        NoaClient.post(
			"/api/platform/security/rbac/role/" + roleId + "/feature",
			newFeatures,
			(response) => {
        });
    }

    const handleRemoveFeatures = (removedFeatures) => {
        NoaClient.delete(
			"/api/platform/security/rbac/role/" + roleId + "/feature",
			removedFeatures,
			(response) => {
        });
    }

    const handleAddActions = (newActions) => {
        NoaClient.post(
			"/api/platform/security/rbac/role/" + roleId + "/action",
			newActions,
			(response) => {
        });
    }

    const handleRemoveActions = (removedActions) => {
        NoaClient.delete(
			"/api/platform/security/rbac/role/" + roleId + "/action",
			removedActions,
			(response) => {
        });
    }

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;

    const handleChildClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = childIndexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setChildIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const childIndex = childIndexesState.activeIndexes;

    return(
        <NoaContainer style={Object.assign({},completeHeight,completeWidth)}>
            <Grid>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Role Details: {data.roleName}</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1} style={formContentSpacingTB}>
                    <Grid.Column width={16} id="modify-role">
                    <Accordion>
                        <Accordion.Title
                            active={activeIndex.includes(0)}
                            index={0}
                            onClick={handleClick}
                            style={Object.assign({textAlign:'left'},accordionTitle)}
                        >
                            <DropdownIcon />
                            Role Details
                        </Accordion.Title>
                        <Accordion.Content active={activeIndex.includes(0)} style={{borderBottom:"1px solid rgb(213,223,233)"}}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} id="role-detail">
                                    <Grid columns={4} stackable>
                                        <Grid.Column width={4}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} verticalAlign='middle' textAlign='center'>
                                                                <p style={formParameter}>Name</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='center'>
                                                                <p style={formHeader}>{data.roleName}</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>

                                        <Grid.Column width={4}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} verticalAlign='middle' textAlign='center'>
                                                                <p style={formParameter}>Code</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='center'>
                                                                <p style={formHeader}>{data.roleCode}</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>

                                        <Grid.Column width={4}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} verticalAlign='middle' textAlign='center'>
                                                                <p style={formParameter}>User Count</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='center'>
                                                                <p style={formHeader}>{data.assignedUsers}</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>

                                        <Grid.Column width={4}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={2}></Grid.Column>
                                                            <Grid.Column width={6} verticalAlign='middle' textAlign='center'>
                                                                <p style={formParameter}>Group Count</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='center'>
                                                                <p style={formHeader}>{data.assignedGroups}</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={2}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                        </Accordion.Content>
                        <Accordion.Title
                            active={activeIndex.includes(1)}
                            index={1}
                            onClick={handleClick}
                            style={Object.assign({textAlign:'left'},accordionTitle)}
                        >
                            <DropdownIcon />
                            Role Privileges: Feature
                        </Accordion.Title>
                        <Accordion.Content active={activeIndex.includes(1)} style={{borderBottom:"1px solid rgb(213,223,233)"}}>
                            <NoaContainer style={Object.assign({paddingLeft:"5em",paddingRight:"5em"},accordionContentMargins,completeWidth)}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} id="role-feature">
                                        <Card.Group itemsPerRow={4}>
                                        {features.length ? features.map((feature, index) =>
                                            <Card link style={noaCardLayout}>
                                                <Card.Content>
                                                <Card.Header textAlign='left' style={noaCardTitle}>
                                                    <NoaContainer style={completeWidth}>
                                                    <Checkbox 
                                                        label={feature.featureName}
                                                        name={feature.featureId}
                                                        style={checkboxHeader}
                                                        checked={roleFeatures.includes(feature.featureName)}
                                                        onChange={
                                                            (e, data) => handleCheckBoxClick(data,feature)
                                                        }
                                                    />
                                                    </NoaContainer>
                                                </Card.Header>
                                                <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                    {feature.description}
                                                </Card.Description>
                                                </Card.Content>
                                            </Card>
                                        ) : ''}
                                        </Card.Group>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </NoaContainer>
                        </Accordion.Content>
                        
                        <Accordion.Title
                            active={activeIndex.includes(2)}
                            index={2}
                            onClick={handleClick}
                            style={Object.assign({textAlign:'left'},accordionTitle)}
                        >
                            <DropdownIcon />
                            Role Privileges: Resource
                        </Accordion.Title>
                        <Accordion.Content active={activeIndex.includes(2)} 
                            style={Object.assign({borderBottom:"1px solid rgb(213,223,233)",paddingLeft:"4em",paddingRight:"4em"},accordionContentMargins)}>
                        <NoaCard title={null} renderDuration={false}>
                        <Grid style={accordionContentMargins}>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16} id="role-action">
                                <Accordion style={{marginTop:"0px"}}>
                                    <Accordion.Title
                                        active={childIndex.includes(0)}
                                        index={0}
                                        onClick={handleChildClick}
                                        style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                    >
                                        <DropdownIcon />
                                        Element Privileges
                                    </Accordion.Title>
                                    <Accordion.Content active={childIndex.includes(0)}>
                                    <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid style={{paddingLeft: "3.5em",paddingRight: "4em"}}>
                                                {Object.keys(elementActions).map((keyItem,index) => (
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16} textAlign='left'>
                                                                <p style={accordionHeader}>{keyItem}</p>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16} style={{paddingLeft:"2em",paddingRight:"2em"}}>
                                                            <Card.Group itemsPerRow={3}>
                                                                {elementActions[keyItem].length ? elementActions[keyItem].map((action, index) =>
                                                                    <Card link style={noaCardLayout}>
                                                                        <Card.Content>
                                                                        <Card.Header textAlign='left' style={noaCardTitle}>
                                                                            <NoaContainer style={completeWidth}>
                                                                            <Checkbox 
                                                                                label={action.actionName}
                                                                                name={action.actionId}
                                                                                checked={roleActions.includes(action.actionName)}
                                                                                style={formParameter}
                                                                                onChange={
                                                                                    (e, data) => checkboxHandler(data,action)
                                                                                }
                                                                            />
                                                                            </NoaContainer>
                                                                        </Card.Header>
                                                                        <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                            {action.actionReference}
                                                                        </Card.Description>
                                                                        </Card.Content>
                                                                    </Card>
                                                                ) : ''}
                                                            </Card.Group>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                ))}
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Accordion.Content>

                                    <Accordion.Title
                                        active={childIndex.includes(1)}
                                        index={1}
                                        onClick={handleChildClick}
                                        style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                    >
                                        <DropdownIcon />
                                        Network Privileges
                                    </Accordion.Title>
                                    <Accordion.Content active={childIndex.includes(1)}>
                                    <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid style={{paddingLeft: "3.5em",paddingRight: "4em"}}>
                                            {Object.keys(networkActions).map((keyItem,index) => (
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16} textAlign='left'>
                                                            <p style={formHeader}>{keyItem}</p>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16} style={{paddingLeft:"2em",paddingRight:"2em"}}>
                                                        <Card.Group itemsPerRow={3}>
                                                            {networkActions[keyItem].length ? networkActions[keyItem].map((action, index) =>
                                                                <Card link style={noaCardLayout}>
                                                                    <Card.Content>
                                                                    <Card.Header textAlign='left'style={noaCardTitle}>
                                                                        <NoaContainer style={completeWidth}>
                                                                        <Checkbox 
                                                                            label={action.actionName}
                                                                            name={action.actionId}
                                                                            checked={roleActions.includes(action.actionName)}
                                                                            style={formParameter}
                                                                            onChange={
                                                                                (e, data) => checkboxHandler(data,action)
                                                                            }
                                                                        />
                                                                        </NoaContainer>
                                                                    </Card.Header>
                                                                    <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                        {action.actionReference}
                                                                    </Card.Description>
                                                                    </Card.Content>
                                                                </Card>
                                                            ) : ''}
                                                        </Card.Group>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            ))}
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Accordion.Content>

                                    <Accordion.Title
                                        active={childIndex.includes(2)}
                                        index={2}
                                        onClick={handleChildClick}
                                        style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                    >
                                        <DropdownIcon />
                                        Service Privileges
                                    </Accordion.Title>
                                    <Accordion.Content active={childIndex.includes(2)}>
                                    
                                    <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid style={{paddingLeft: "3.5em",paddingRight: "4em"}}>
                                            {Object.keys(serviceActions).map((keyItem,index) => (
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16} textAlign='left'>
                                                            <p style={formHeader}>{keyItem}</p>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16} style={{paddingLeft:"2em",paddingRight:"2em"}}>
                                                        <Card.Group itemsPerRow={3}>
                                                            {serviceActions[keyItem].length ? serviceActions[keyItem].map((action, index) =>
                                                                <Card link style={noaCardLayout}>
                                                                    <Card.Content>
                                                                    <Card.Header textAlign='left' style={noaCardTitle}>
                                                                        <NoaContainer style={completeWidth}>
                                                                        <Checkbox 
                                                                            label={action.actionName}
                                                                            name={action.actionId}
                                                                            checked={roleActions.includes(action.actionName)}
                                                                            style={formParameter}
                                                                            onChange={
                                                                                (e, data) => checkboxHandler(data,action)
                                                                            }
                                                                        />
                                                                        </NoaContainer>
                                                                    </Card.Header>
                                                                    <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                        {action.actionReference}
                                                                    </Card.Description>
                                                                    </Card.Content>
                                                                </Card>
                                                            ) : ''}
                                                        </Card.Group>
                                                        </Grid.Column>
                                                        <Grid.Column width={16}>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            ))}
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Accordion.Content>

                                    <Accordion.Title
                                        active={childIndex.includes(3)}
                                        index={3}
                                        onClick={handleChildClick}
                                        style={Object.assign({textAlign:'left',borderBottom:"1px solid rgb(37, 37, 37,.3)"},subAccordionTitle)}
                                    >
                                        <DropdownIcon />
                                        Platform Privileges
                                    </Accordion.Title>
                                    <Accordion.Content active={childIndex.includes(3)}>
                                    
                                    <Grid style={Object.assign({},accordionFixedHeight,accordionContentMargins)} className="content">
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid style={{paddingLeft: "3.5em",paddingRight: "4em"}}>
                                            {Object.keys(platformActions).map((keyItem,index) => (
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16} textAlign='left'>
                                                            <p style={formHeader}>{keyItem}</p>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16} style={{paddingLeft:"2em",paddingRight:"2em"}}>
                                                        <Card.Group itemsPerRow={3}>
                                                            {platformActions[keyItem].length ? platformActions[keyItem].map((action, index) =>
                                                                <Card link style={noaCardLayout}>
                                                                    <Card.Content>
                                                                    <Card.Header textAlign='left' style={noaCardTitle}>
                                                                        <NoaContainer style={completeWidth} style={noaCardTitle}>
                                                                        <Checkbox 
                                                                            label={action.actionName}
                                                                            name={action.actionId}
                                                                            checked={roleActions.includes(action.actionName)}
                                                                            onChange={
                                                                                (e, data) => checkboxHandler(data,action)
                                                                            }
                                                                        />
                                                                        </NoaContainer>
                                                                    </Card.Header>
                                                                    <Card.Description style={Object.assign({marginLeft:"2.2em"},noaCardDesc)} textAlign='left'>
                                                                        {action.actionReference}
                                                                    </Card.Description>
                                                                    </Card.Content>
                                                                </Card>
                                                            ) : ''}
                                                        </Card.Group>
                                                        </Grid.Column>
                                                        <Grid.Column width={16}>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            ))}
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </Accordion.Content>
                                </Accordion>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        </NoaCard>
                        </Accordion.Content>

                        <Accordion.Title
                            active={activeIndex.includes(3)}
                            index={3}
                            onClick={handleClick}
                            style={Object.assign({textAlign:'left'},accordionTitle)}
                        >
                            <DropdownIcon />
                            Users and Groups
                        </Accordion.Title>
                        <Accordion.Content active={activeIndex.includes(3)} style={{borderBottom:"1px solid rgb(213,223,233)",paddingBottom:"2em"}}>
                            <Grid style={Object.assign({paddingLeft:"5em",paddingRight:"5em"},accordionContentMargins)}>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} id="role-assignments">
                                        <Grid columns={2} stackable stretched>
                                            <Grid.Column computer={8} mobile={16} tablet={16}>
                                                <NoaCard title={"Users"} renderDuration={false}>
                                                <NoaContainer style={{marginTop:"1.5em",marginBottom:"1.5em"}}>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid>
                                                                <Card.Group itemsPerRow={users.length > 2 ? 3 : users.length}>
                                                                {users.map((user,index) => (
                                                                    <Card link style={noaCardLayout}>
                                                                        <Card.Content>
                                                                        <Card.Header textAlign='left' style={noaCardTitle}>
                                                                            {user.userName}
                                                                        </Card.Header>
                                                                        <Card.Description style={noaCardDesc} textAlign='left'>
                                                                            <Grid columns={2} stackable doubling>
                                                                                <Grid.Column width={12}>
                                                                                    Account Status
                                                                                </Grid.Column>
                                                                                <Grid.Column width={4}>
                                                                                {user.accountStatus ? 
                                                                                    <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
                                                                                    : 
                                                                                    <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
                                                                                }
                                                                                </Grid.Column>
                                                                            </Grid>
                                                                        </Card.Description>
                                                                        </Card.Content>
                                                                    </Card>
                                                                ))}
                                                                </Card.Group>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </NoaContainer>
                                                </NoaCard>
                                            </Grid.Column>
                                            
                                            <Grid.Column computer={8} mobile={16} tablet={16} style={{paddingLeft:"3em"}}>
                                                <NoaCard title={"Groups"} renderDuration={false}>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid>
                                                            <Card.Group itemsPerRow={groups.length > 2 ? 3 : groups.length}>
                                                            {groups.map((group,index) => (
                                                                <Card link style={noaCardLayout}>
                                                                    <Card.Content>
                                                                    <Card.Header textAlign='left' style={noaCardTitle}>
                                                                        {group.userGroupName}
                                                                    </Card.Header>
                                                                    <Card.Description style={noaCardDesc} textAlign='left'>
                                                                        <Grid columns={2} stackable doubling>
                                                                            <Grid.Column width={12}>
                                                                                User Count
                                                                            </Grid.Column>
                                                                            <Grid.Column width={4}>
                                                                                {group.userCount}
                                                                            </Grid.Column>
                                                                        </Grid>
                                                                    </Card.Description>
                                                                    </Card.Content>
                                                                </Card>
                                                            ))}
                                                            </Card.Group>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </NoaCard>
                                            </Grid.Column>

                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                        </Accordion.Content>
                    </Accordion>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2}>
                            <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    handleModify()
                                    context.setRenderLocation(["modify-role"]);
                                }}>Save</Button>
                            </Grid.Column>
                            <Grid.Column width={8} textAlign='left'>
                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
export default RoleManager;
export {AddRole,ModifyRole};