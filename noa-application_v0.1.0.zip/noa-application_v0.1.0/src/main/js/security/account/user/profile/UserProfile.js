import React, { useEffect, useState,useContext } from 'react';

import {
	Grid,
	Segment,
	Button,
	Tab,
	Menu,
	Input
} from 'semantic-ui-react';

import 'semantic-ui-css/semantic.min.css';

import { 
	formFieldStyle, applyButton, formParameter, 
	completeWidth, formDisplay, cardLayout, 
	fullHeight, nMenuItem, inputBoxStyle
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import noaNotification from '../../../../widget/NoaNotification';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import { NoaContainer } from '../../../../widget/NoaWidgets';
import { MenuContext } from '../../../../utility/MenuContext';

const UserProfile = (props) => {
	const [user, setUser] = useState({});

	const context = useContext(GlobalSpinnerContext);
	const redirectContext = useContext(RouteRediretContext);
	const menuContext = useContext(MenuContext);

	const getUserProfile = () => {
		NoaClient.get('/api/profile',
			(response) => {
				let responseData = response.data;
				console.log(responseData)
				setUser(responseData);
			}
		)
	}

	useEffect(() => {
		NoaClient(context, redirectContext);
		context.setRenderLocation(["user-profile"]);
		getUserProfile();
		menuContext.setDisplayText("User Profile");
		menuContext.setHideMenu(true);
	}, []);

	const panes = [
		{
            menuItem: <Menu.Item key='user-details' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>User Details</Menu.Item>,
            render: () => <UserDetails user={user} getUserProfile={getUserProfile}/>
        },
		{
            menuItem: <Menu.Item key='password' style={Object.assign({paddingLeft:"0px",paddingRight:"4em"},nMenuItem)}>Password Management</Menu.Item>,
            render: () => <PasswordManagement user={user} getUserProfile={getUserProfile}/>
        }
	]
	return (
		<NoaContainer style={Object.assign({display: "flex",flexDirection: "column"},fullHeight,completeWidth)}>
            <Segment style={Object.assign({minHeight:"100vh"},cardLayout)}>
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} style={{marginTop:"2em",marginLeft:"4em",marginRight:"4em",marginBottom:"2em"}}>
							<Tab panes={panes} menu={{secondary: true,style: {borderBottom:"1px solid #D5DFE9"},pointing: true}}/>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Segment>
        </NoaContainer>
	)
}

const UserDetails = (props) => {
	const [user, setUser] = useState({});
	const context = useContext(GlobalSpinnerContext);
	const getUserProfile = props.getUserProfile;

	const handleInput = (value, key) => {
		setUser(prevState => ({
            ...prevState,
            [key]: value
        }));
	}
	
	useEffect(() => {
		setUser(props.user);
	},[props.user]);

	const updateUserDetails = () => {
		const body = user;
		context.setRenderLocation(["user-profile"]);
		NoaClient.post(
			"/api/profile",
			body,
			(response) => {
				noaNotification('success', 'User Details Updated Successfully');
				getUserProfile();
		})
	}

	return (
		<NoaContainer style={Object.assign({},completeWidth)}>
		<Grid verticalAlign='middle'>
			<Grid.Row columns={1} style={{marginTop:"4em",marginBottom:"4em"}}>
				<Grid.Column width={16} id="user-profile">
					<Grid columns={3} stackable>
						<Grid.Column width={2}></Grid.Column>
						<Grid.Column width={12}>
							<Grid columns={2} stackable>
								<Grid.Column computer={8} mobile={16} tablet={16}>
									<Grid>
									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>User Name</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.userName}
														name="userName"
														onChange={handleInput}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>First Name</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.firstName}
														name="firstName"
														onChange={
															(e, {value}) => handleInput(value==='' ? null : value, 'firstName')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Middle Initial</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.middleInitial}
														name="middleInitial"
														onChange={
															(e, {value}) => handleInput(value==='' ? null : value, 'middleInitial')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Last Name</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.lastName}
														name="lastName"
														onChange={
															(e, {value}) => handleInput(value==='' ? null : value, 'lastName')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Mobile Number</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.mobileNumber}
														name="mobileNumber"
														onChange={
															(e, {value}) => handleInput(value==='' ? null : value, 'mobileNumber')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Email Id</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.emailId}
														name="emailId"
														onChange={
															(e, {value}) => handleInput(value==='' ? null : value, 'emailId')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>User Type</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.userType}
														name="userType"
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>
									</Grid>
								</Grid.Column>
								<Grid.Column computer={8} mobile={16} tablet={16}>
								<Grid>
									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Role Name</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.roleName}
														name="roleName"
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Password Policy</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.policyName}
														name="policyName"
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>User Groups Count</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.assignedGroups}
														name="assignedGroups"
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Latest Password Change</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														value={user.latestPasswordTimeStamp}
														name="latestPasswordTimeStamp"
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>
								</Grid>
								</Grid.Column>
							</Grid>
						</Grid.Column>
						<Grid.Column width={2}></Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid.Row>
			<Grid.Row columns={1}>
				<Grid.Column width={16} textAlign='center'>
					<Button style={applyButton} onClick={updateUserDetails}>Update</Button>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</NoaContainer>
	)
}

const PasswordManagement = (props) => {
	const context = useContext(GlobalSpinnerContext);
	const [user, setUser] = useState({});
	const [passwordObj, setPasswordObj] = useState({});
	const [policy, setPolicy] = useState({});

	const getUserProfile = props.getUserProfile;
	
	const handleChange = (value, key) => {
		setPasswordObj(prevState => ({
            ...prevState,
            [key]: value
        }));
	}

	const getUserPolicy = (user) => {
		NoaClient.get('/api/platform/security/rbac/user/' + user.accountId + "/policy",
			(response) => {
				let responseData = response.data;
				setPolicy(responseData);
			}
		)
	}

	useEffect(() => {
		setUser(props.user);
		context.setRenderLocation(["password-management"]);
		getUserPolicy(props.user);
	},[props.user]);

	const handleChangePassword = () => {
		if (passwordObj.confirmPassword !== passwordObj.password) {
			alert("Passwords don't Match");
		} else {
			let body = {};
			body["accountId"] = user.accountId;
			body["oldPassword"] = passwordObj.oldPassword;
			body["password"] = passwordObj.password;
			console.log(body)
			NoaClient.post(
				"/api/profile/change-password",
				body,
				(response) => {
					noaNotification('success', 'Password Changed Successfully');
					getUserProfile();
				});
		}
	}

	return(
		<NoaContainer style={Object.assign({},completeWidth)}>
		<Grid>
			<Grid.Row columns={1} style={{marginTop:"4em",marginBottom:"4em"}}>
				<Grid.Column width={16} verticalAlign='top' id="password-management">
					<Grid columns={3} stackable>
						<Grid.Column width={2}></Grid.Column>
						<Grid.Column width={12}>
							<Grid columns={3} stackable>
								<Grid.Column computer={7} tablet={16} mobile={16}>
								<Grid>
									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Current Password</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														type="password"
														required={true}
														name="oldPassword"
														value={passwordObj.oldPassword}
														onChange={
															(e, {value}) => handleChange(value==='' ? null : value, 'oldPassword')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>New Password</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														type="password"
														required={true}
														name="password"
														value={passwordObj.password}
														onChange={
															(e, {value}) => handleChange(value==='' ? null : value, 'password')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formParameter}>Confirm New Password</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<Input style={formFieldStyle}
														required={true}
														type="password"
														name="confirmPassword"
														value={passwordObj.confirmPassword}
														onChange={
															(e, {value}) => handleChange(value==='' ? null : value, 'confirmPassword')
														}
													>
														<input style={inputBoxStyle}></input>
													</Input>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>
								</Grid>
								</Grid.Column>
								<Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
								<Grid.Column computer={7} tablet={16} mobile={16}>
								<Grid>
									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formDisplay}>Min Length</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<p style={formDisplay}>{policy.minLength}</p>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formDisplay}>Min Digits</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<p style={formDisplay}>{policy.minDigits}</p>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formDisplay}>Min Spl Char</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<p style={formDisplay}>{policy.minSplChar}</p>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formDisplay}>Upper Char</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<p style={formDisplay}>{policy.minUpperChar}</p>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>

									<Grid.Row columns={1}>
										<Grid.Column width={16}>
											<Grid columns={4} stackable>
												<Grid.Column width={3}></Grid.Column>
												<Grid.Column width={4} textAlign='left'>
													<p style={formDisplay}>Lower Char</p>
												</Grid.Column>
												<Grid.Column width={6} textAlign='left'>
													<p style={formDisplay}>{policy.minLowChar}</p>
												</Grid.Column>
												<Grid.Column width={3}></Grid.Column>
											</Grid>
										</Grid.Column>
									</Grid.Row>
								</Grid>
								</Grid.Column>
							</Grid>
						</Grid.Column>
						<Grid.Column width={2}></Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid.Row>
			<Grid.Row columns={1}>
				<Grid.Column width={16} textAlign='center'>
					<Button style={applyButton} onClick={() => {
						context.setRenderLocation(["password-management"]);
						handleChangePassword()
					}}>Update</Button>
				</Grid.Column>
			</Grid.Row>
		</Grid>
		</NoaContainer>
	)
}

export default UserProfile;