import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../../widget/NoaTable';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Checkbox,
    Input
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, noMarginTB,
    noMarginLR, titleText, cardLayout,
    formTitle, formParameter, applyButton,
    cancelButton, completeHeight, completeWidth, 
    tablePadding, tableHeaderHeight, fullHeight, 
    dividerStyle, inputBoxStyle, formContentSpacingTB
} from '../../../../constants';

import NoaClient from '../../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../../utility/RouteRedirect';
import NoaFilter from '../../../../widget/NoaFilter';

import { NoaHeader, NoaContainer} from '../../../../widget/NoaWidgets';
import NoaToolbar from '../../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../../widget/NoaNotification';

const PasswordPolicyManager = (props) => {
    const [passwordPolicies, setPasswordPolicies] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = passwordPolicies[sel[i]].policyId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getPasswordPolicies = (filterObj) => {
        context.setRenderLocation(["password-policy-list"]);
        NoaClient.post(
            "/api/platform/security/policy/password",
            filterObj,
            (response) => {
                let responseData = response.data;
                setPasswordPolicies(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/security/policy/password/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"password-policy":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getPasswordPolicies(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({},completeHeight, cardLayout)}>
                            <PasswordPolicyTable passwordPolicies={passwordPolicies}
                                                    selectedRows={selectedRows}
                                                    setClearSelected={setClearSelected}
                                                    getPasswordPolicies={getPasswordPolicies}
                                                    setSelected={setSelected} 
                                                    clearSelected={clearSelected}
                                                    columns={columns}
                                                    filters={filters}
                                                    pageSize={pageSize}
                                                    totalPages={totalPages}
                                                    setPageSize={setPageSize}
                                                    totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const PasswordPolicyTable = (props) => {
    const passwordPolicies = props.passwordPolicies;
    const getPasswordPolicies = props.getPasswordPolicies;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"password-policy" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()}/>
            ),
            width:1
        },
		{
			label: "1",
			Header: "Policy Name",
            accessor: "policyName",
            width:3
		},
		{
			label: "2",
			Header: "Max Fail Attempts",
            accessor: "maxFailAttempt",
            width:2
		},
        {
			label: "4",
			Header: "Password Expiry",
            accessor: "passExpDays",
            width:2
		},
        {
			label: "5",
			Header: "Min Length",
            accessor: "minLength",
            width:2
        },
        {
			label: "6",
			Header: "Num of Logins",
            accessor: "numMultipleLogin",
            width:2
        },
        {
			label: "8",
			Header: "Password History",
            accessor: "numOldPassword",
            width:2
        },
        {
			label: "9",
			Header: "Min Reuse",
            accessor: "minReuseDays",
            width:2
        }
    ]

    const handleAddPasswordPolicy = () => {
        router.stateService.go("add-password-policy",{fetchData: getPasswordPolicies, clearSelection: clearSelection})
    }    

    const router = useRouter();

    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {            
            let selId = keys[0];
            router.stateService.go('modify-password-policy',{id: passwordPolicies[selId].policyId,fetchData: getPasswordPolicies,clearSelection: clearSelection})
        } else {            
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        NoaClient.delete(
            "/api/platform/security/policy/password",
            selectedItems,
            (response) => {
                getPasswordPolicies();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        getPasswordPolicies(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"password-policy" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getPasswordPolicies(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getPasswordPolicies(filterObj)
    }
    
    const fetchData = () => {
        fetchFilteredData({"filters":null})
    }

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Password Policies</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddPasswordPolicy}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={passwordPolicies}
                                columns={columns}
                                selectedRows={selections}
                                onSelectedRowsChange={setSelections}
                                clearSelected={clearSelected}
                                setClearSelected={setClearSelected}
                                selectedPageSize={pageSize}
                                handlePagination={handlePagination}
                                totalPages={totalPages}
                                handlePageSize={handlePageSize}
                                totalEntries={totalEntries}
                                resource="Password Policies" 
                                fetchData={fetchData} 
                                location="password-policy-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const AddPasswordPolicy = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const getPasswordPolicies = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const [passwordPolicy, setPasswordPolicy] = useState({});

    const handleChange = (e, d) => {
        const target = e.target;
        const value = target.value==='' ? null : target.value;
        const name = target.name;

        setPasswordPolicy(prevState => ({
            ...prevState,
            [name]:value
        }));
    }

    const handleAdd = () => {
        if(passwordPolicy != null) {
            NoaClient.put(
                "/api/platform/security/policy/password",
                passwordPolicy,
                (response) => {
                    //context.setRenderLocation(['password-policy-list'])
                    noaNotification('success','Password Policy Created Successfully');
                    getPasswordPolicies();
                    closeFooter();
            })
        }
    }
    
    const closeFooter = () => {
        router.stateService.go('default');
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create Password Policy</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-password-policy">
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                        <Grid columns={3}>
                            <Grid.Column width={2}></Grid.Column>
                            <Grid.Column width={12} style={noPadding}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Policy Name</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='policyName' 
                                                        value={passwordPolicy.policyName}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Incorrect Attempts</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='maxFailAttempt' 
                                                        value={passwordPolicy.maxFailAttempt}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Days for Expiry</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='passExpDays' 
                                                        value={passwordPolicy.passExpDays}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                        
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Min Digits</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='minDigits' 
                                                        value={passwordPolicy.minDigits}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Min Upper Char</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='minUpperChar' 
                                                        value={passwordPolicy.minUpperChar}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    </Grid>
                                </Grid.Column>

                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Min Length</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='minLength' 
                                                        value={passwordPolicy.minLength}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Concurrent Logins</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='numMultipleLogin' 
                                                        value={passwordPolicy.numMultipleLogin}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Passwords Count</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='numOldPassword' 
                                                        value={passwordPolicy.numOldPassword}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Days Before Reuse</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='minReuseDays' 
                                                        value={passwordPolicy.minReuseDays}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Min Lower Char</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='number' name='minLowChar' 
                                                        value={passwordPolicy.minLowChar}
                                                        fluid={false}
                                                        onChange={
                                                            (event, data) => handleChange(event, data)
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column width={2}></Grid.Column>
                        </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            handleAdd()
                            context.setRenderLocation(["add-password-policy"]);
                        }}>Add</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const ModifyPasswordPolicy = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const clearSelection = props.clearSelection;
    const getPasswordPolicies = props.fetchData;

    const router = useRouter();
    
    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    const [passwordPolicy, setPasswordPolicy] = useState({});
    
    useEffect(() => {
        const policyId = props.id;
        context.setRenderLocation(['modify-password-policy']);
        if(policyId != null && policyId != undefined) {
            getPasswordPolicy(policyId);
        }
    },[]);

    const getPasswordPolicy = (policyId) => {
        NoaClient.get(
            "/api/platform/security/policy/password/" + policyId,
            (response) => {
                let responseData = response.data;
                setPasswordPolicy(responseData);
            }
        )
    }

    const handleChange = (e, d) => {
        const target = e.target;
        const value = target.value==='' ? null : target.value;
        const name = target.name;

        setPasswordPolicy(prevState => ({
            ...prevState,
            [name]:value
        }));
    }

    const handleModify = () => {
        if(passwordPolicy != null) {
            const policyId = passwordPolicy.policyId;
            NoaClient.post(
                "/api/platform/security/policy/password/" + policyId,
                passwordPolicy,
                (response) => {
                    //context.setRenderLocation(['password-policy-list'])
                    noaNotification('success','Password Policy Updated Successfully');
                    getPasswordPolicies();
                    closeFooter();
                    setPasswordPolicy({});
            })
        }
    }
    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Password Policy Details: {passwordPolicy.policyName}</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1} style={formContentSpacingTB}>
                    <Grid.Column width={16} id="modify-password-policy">
                    <Grid columns={3}>
                        <Grid.Column width={2}></Grid.Column>
                        <Grid.Column width={12} style={noPadding}>
                        <Grid columns={2} stackable>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Policy Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='text' name='policyName' 
                                                    value={passwordPolicy.policyName}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Incorrect Attempts</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='maxFailAttempt' 
                                                    value={passwordPolicy.maxFailAttempt}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Days for Expiry</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='passExpDays' 
                                                    value={passwordPolicy.passExpDays}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                    
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Min Digits</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='minDigits' 
                                                    value={passwordPolicy.minDigits}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Min Upper Char</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='minUpperChar' 
                                                    value={passwordPolicy.minUpperChar}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Min Length</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='minLength' 
                                                    value={passwordPolicy.minLength}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                                
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Concurrent Logins</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='numMultipleLogin' 
                                                    value={passwordPolicy.numMultipleLogin}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Passwords Count</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='numOldPassword' 
                                                    value={passwordPolicy.numOldPassword}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Days Before Reuse</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='minReuseDays' 
                                                    value={passwordPolicy.minReuseDays}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>

                                <Grid.Row columns={1}>
                                    <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Min Lower Char</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Input type='number' name='minLowChar' 
                                                    value={passwordPolicy.minLowChar}
                                                    fluid={false}
                                                    onChange={
                                                        (event, data) => handleChange(event, data)
                                                    }>
                                                        <input style={inputBoxStyle}></input>
                                                </Input>
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                        </Grid>
                        </Grid.Column>
                        <Grid.Column width={2}></Grid.Column>
                    </Grid>  
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                context.setRenderLocation(["modify-password-policy"]);
                                handleModify()
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
export default PasswordPolicyManager;
export {AddPasswordPolicy, ModifyPasswordPolicy}