import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../../widget/NoaTable';
import update from 'react-addons-update';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Checkbox,
    Dropdown,
    Step,
    Input,
    Icon
} from 'semantic-ui-react';

import { 
    noBoxShadow,noPadding, noMarginTB, 
    noMarginLR, titleText, cardLayout, 
    formHeader, formParameter, formTitle, 
    applyButton, cancelButton, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight, 
    fullHeight, dividerStyle, inputBoxStyle, 
    formContentSpacingTB, dropdownStyle
} from '../../../constants';

import NoaClient from '../../../utility/NoaClient';

import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';
import NoaFilter from '../../../widget/NoaFilter';
import { NoaHeader, NoaContainer} from '../../../widget/NoaWidgets';
import NoaToolbar from '../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../widget/NoaNotification';

const UserManager = (props) => {
    const [users, setUsers] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);
    
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = users[sel[i]].accountId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getUsers = (filterObj) => {
        context.setRenderLocation(["user-list"]);
        NoaClient.post(
            "/api/platform/security/rbac/user",
            filterObj,
            (response) => {
                let responseData = response.data;
                setUsers(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/security/rbac/user/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }


    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"user-account":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getUsers(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({},completeHeight,cardLayout)}>
                            <UserTable users={users} getUsers={getUsers}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const renderBoolean = (row) => {
    const enabledState = row.original.accountStatus;
    return (
       <>
        {enabledState ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const UserTable = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const users = props.users;
    const getUsers = props.getUsers;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"user-account" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
		{
			label: "1",
			Header: "User Id",
            accessor: "userName",
            width:2
		},
		{
			label: "2",
			Header: "First Name",
            accessor: "firstName",
            width:2
		},
        {
			label: "4",
			Header: "Last Name",
            accessor: "lastName",
            width:2
		},
        {
			label: "5",
			Header: "Account Type",
            accessor: "userType",
            width:2
        },
        {
			label: "6",
			Header: "User Role",
            accessor: "roleName",
            width:3
        },
        {
			label: "8",
			Header: "Password Policy",
            accessor: "policyName",
            width:3
        },
        {
			label: "7",
			Header: "Status",
			Cell: ({row}) => (
                renderBoolean(row)
            ),
            width:3
        },
    ]

    const router = useRouter();

    const handleAddUser = () => {
        router.stateService.go("add-user",{fetchData: fetchData, clearSelection: clearSelection})
    }

    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-user',{id: users[selId].accountId,fetchData: fetchData,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["user-list"]);

        NoaClient.delete(
            "/api/platform/security/rbac/user",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getUsers(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"user-account" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getUsers(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getUsers(filterObj)
    }

    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>User Accounts</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddUser}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={users}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="Users" 
                        fetchData={fetchData} 
                        location="user-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const AddUser = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();
    
    const clearSelection = props.clearSelection;
    const getUsers = props.fetchData;
    
    const [step, setStep] = React.useState(0);
    const [user, setUser] = useState({});
    const [passwordPolicies, setPasswordPolicies] = useState([]);
    const [roles, setRoles] = useState([]);
    const [userGroups, setUserGroups] = useState([]);
    
    const [selectedGroups, setSelectedGroups] = useState([]);
    const [selectedRole, setSelectedRole] = useState(null);

    const [roleActions, setRoleActions] = useState([]);
    
    const [elements, setElements] = useState([]);
    const [networks, setNetworks] = useState([]);
    const [services, setServices] = useState([]);

    const [resources, setResources] = useState({});

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 3 ? 3 : nextStep);
    };

    const getPasswordPolicies = () => {
        NoaClient.get(
            "/api/platform/security/policy/password",
            (response) => {
                let responseData = response.data;
                let policyList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let policyObj = {'key' : item.policyId, 'value' : item.policyName, 'text': item.policyName}
                        policyList[index] = policyObj;
                    })
                }
                setPasswordPolicies(policyList);
            }
        )
    }

    const getRoles = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role",
            (response) => {
                let responseData = response.data;
                let rolesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let roleObj = {'key' : item.roleName, 'value' : item.roleId, 'text': item.roleName}
                        rolesList[index] = roleObj;
                    })
                }
                setRoles(rolesList);
            }
        )
    }

    const getUserGroups = () => {
        NoaClient.get(
            "/api/platform/security/rbac/group",
            (response) => {
                let responseData = response.data;
                let groups = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let groupObj = {'key' : item.userGroupName, 'value' : item.userGroupId, 'text': item.userGroupName}
                        groups[index] = groupObj;
                    })
                }
                setUserGroups(groups);
            }
        )
    }

    const handleAdd = () => {
        
        let policyName = user.policyName;
        const selPolicy = passwordPolicies.find(node => node.value === policyName);
        user["userGroups"] = selectedGroups.length
        NoaClient.put(
			"/api/platform/security/rbac/user",
			user,
			(response) => {
                let responseData = response.data;
                let accountId = responseData.accountId;
                noaNotification('success','User Account Created Successfully');
                if(selectedGroups.length > 0) {
                    handleAddUserGroups(accountId,selectedGroups);
                }
                assignRoleToUser(accountId,selectedRole,resources);
                assignPolicy(accountId,selPolicy.key);
                getUsers();
                closeFooter();
        });
    }

    const handleAddUserGroups = (accountId,groupIds) => {
        NoaClient.put(
			"/api/platform/security/rbac/user/" + accountId + "/group",
			groupIds,
			(response) => {
                noaNotification('success','Added to Groups Successfully');
        });
    }

    const assignRoleToUser = (accountId,roleId,resources) => {
        NoaClient.post(
            "/api/platform/security/rbac/user/" + accountId + "/role/" + roleId,
            resources,
            (response) => {
                noaNotification('success','Role Assigned to User Successfully');
        })
    }

    const assignPolicy = (accountId,policyId) => {
        NoaClient.post(
            "/api/platform/security/rbac/user/" + accountId + "/policy/" + policyId,
            null,
            (response) => {
                noaNotification('success','Password Policy Assigned to User Successfully');
        })
    }


    useEffect(() => {
        switch (step) {
            case 0:
                setUser({});
                context.setRenderLocation(["get-assignments"]);
                getPasswordPolicies();
                getRoles();
                break;
            case 1:
                if(selectedRole != null) {
                    context.setRenderLocation(["get-role-actions"]);
                    getRoleActions();
                } else {
                    setStep(0);
                    alert("Please Select Role");
                }
                break;
            case 2:
                context.setRenderLocation(["get-user-groups"]);
                getUserGroups();        
                break;
            case 3:
                context.setRenderLocation(["add-user"]);
                handleAdd();
                break;
            default:
                break;
        }
    }, [step]);

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);

    const handleInput = (value, key) => {
		setUser(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleRoleSelection = (value,key) => {
        const role_sel = roles.find(node => node.value === value);
        handleInput(role_sel.text,key);
        setSelectedRole(value);
    }

    const getRoleActions = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/" + selectedRole + "/resourceAction",
            (response) => {
                let responseData = response.data;
                setRoleActions(responseData);
        })
    }

    useEffect(() => {
        getResources()
    },[roleActions]);

    const getResources = () => {
        if(roleActions.includes("ServiceManagement")) {
            NoaClient.get(
                "/api/service",
                (response) => {
                    let responseData = response.data;
                    let servicesList = [];
                    if(Array.isArray(responseData)) {
                        responseData.map((item,index) => {
                            let serviceObj = {'key' : item.serviceId, 'value' : item.serviceId, 'text': item.serviceName}
                            servicesList[index] = serviceObj;
                        })
                    }
                    setServices(servicesList);
            })
        }

        if(roleActions.includes("ElementManagement")) {
            NoaClient.get(
                "/api/element",
                (response) => {
                    let responseData = response.data;
                    let elementsList = [];
                    if(Array.isArray(responseData)) {
                        responseData.map((item,index) => {
                            let deviceObj = {'key' : item.deviceId, 'value' : item.deviceId, 'text': item.deviceName}
                            elementsList[index] = deviceObj;
                        })
                    }
                    setElements(elementsList);
            })
        }

        if(roleActions.includes("NetworkManagement")) {
            NoaClient.get(
                "/api/network",
                (response) => {
                    let responseData = response.data;
                    let networksList = [];
                    if(Array.isArray(responseData)) {
                        responseData.map((item,index) => {
                            let networkObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                            networksList[index] = networkObj;
                        })
                    }
                    setNetworks(networksList);
            })
        }
    }

    const handleResourceSelection = (value,key) => {
        let keys = Object.keys(resources);
        if(keys.includes(key)) {
            setResources(
                update(resources, {
                    [key]: {
                     $set : value
                    }
                })
            );
        } else {
            let resourceObj = {...resources}
            resourceObj[key] = value;
            setResources(resourceObj);
        }
    }

    const closeFooter = () => {
        router.stateService.go('default');
    }
    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create User</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} id="add-user">
                        <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Step.Group style={{border: "0px"}} fluid>
                                    <Step style={{border: "0px"}} active={step == 0 ? true : false} completed={step > 0 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Account Details</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 1 ? true : false} completed={step > 1 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Assign Resources</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 2 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Assign Group</Step.Title>
                                        </Step.Content>
                                    </Step>
                                </Step.Group>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1} style={formContentSpacingTB}>
                            <Grid.Column width={16}>
                                <Grid columns={3} stackable>
                                <Grid.Column width={2}></Grid.Column>
                                <Grid.Column width={12}>
                                    {step === 0 ? (
                                    <NoaContainer>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} id="get-assignments">
                                            <Grid columns={2} stackable>
                                                <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='top'>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter} className="required">User ID</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='text' name='accountId' 
                                                                        value={user.userName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'userName')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter} className="required">Password</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='password' name='password' 
                                                                        value={user.password}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'password')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter} className="required">First Name</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='text' name='firstName' 
                                                                        value={user.firstName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'firstName')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter}>Middle Initial</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='text' name='middleInitial' 
                                                                        value={user.middleInitial}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'middleInitial')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter} className="required">Last Name</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6}textAlign="left">
                                                                    <Input type='text' name='lastName' 
                                                                        value={user.lastName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'lastName')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </Grid.Column>

                                                <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='top'>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter}>Mobile Number</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='text' name='mobileNumber' 
                                                                        value={user.mobileNumber}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'mobileNumber')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter}>Email</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='email' name='emailId' 
                                                                        value={user.emailId}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'emailId')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter} className="required">Password Policy</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Dropdown clearable selection required
                                                                            placeholder="Select Policy Name"
                                                                            selectOnBlur={false}
                                                                            style={dropdownStyle}
                                                                            options={passwordPolicies}
                                                                            value={user.policyName}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'policyName')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    {/* <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <p style={formParameter}>Account Type</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Input type='text' name='accountType' 
                                                                        value={user.accountType}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'accountType')
                                                                        }>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row> 

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <p style={formParameter}>Date of Expiry</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <DatePicker format="dd-MM-yyyy" onChange={(date) => 
                                                                        handleInput(value==='' ? null : date, 'expirationDate')
                                                                    }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>*/}
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign="left">
                                                                    <p style={formParameter} className="required">Role</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign="left">
                                                                    <Dropdown clearable selection required selectOnBlur={false}
                                                                            placeholder="Select Role"
                                                                            options={roles}
                                                                            style={dropdownStyle}
                                                                            value={selectedRole}
                                                                            onChange={
                                                                                (e, {value}) => handleRoleSelection(value==='' ? null : value, 'roleName')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </NoaContainer>
                                    ) : 
                                    step === 1 ? (
                                    <NoaContainer>
                                    <Grid style={{minHeight:"300px"}}>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} id="get-role-actions">
                                            <Grid columns={3} stackable>
                                            <Grid.Column width={6}>
                                                <Grid>
                                                    {elements.length > 0 ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>Elements</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Dropdown clearable selection required multiple
                                                                            selectOnBlur={false}
                                                                            placeholder="Select Elements"
                                                                            options={elements}
                                                                            style={dropdownStyle}
                                                                            value={resources.element}
                                                                            onChange={
                                                                                (e, {value}) => handleResourceSelection(value==='' ? null : value, 'element')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    : <p style={formHeader}>No Element Related Privileges</p>}

                                                    {services.length > 0 ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>Services</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Dropdown clearable selection required multiple
                                                                            placeholder="Select Services"
                                                                            options={services}
                                                                            style={dropdownStyle}
                                                                            selectOnBlur={false}
                                                                            value={resources.service}
                                                                            onChange={
                                                                                (e, {value}) => handleResourceSelection(value==='' ? null : value, 'service')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    : <p style={formHeader}>No Service Related Privileges</p>}

                                                    {networks.length > 0 ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4}>
                                                                    <p style={formParameter}>Networks</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} >
                                                                    <Dropdown clearable selection required multiple
                                                                            placeholder="Select Networks"
                                                                            options={networks}
                                                                            style={dropdownStyle}
                                                                            selectOnBlur={false}
                                                                            value={resources.network}
                                                                            onChange={
                                                                                (e, {value}) => handleResourceSelection(value==='' ? null : value, 'network')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    : <p style={formHeader}>No Network Related Privileges</p>}
                                                </Grid>
                                                </Grid.Column>
                                                <Grid.Column width={5}></Grid.Column>
                                                <Grid.Column width={5}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </NoaContainer>
                                    ) : 
                                    step ===2 ? (
                                        <NoaContainer>
                                        <Grid style={{minHeight:"300px"}}>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16} id="get-user-groups">
                                                <Grid columns={3} stackable>
                                                    <Grid.Column width={6}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter}>User Groups</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection multiple search
                                                                        placeholder="Select User Groups"
                                                                        options={userGroups}
                                                                        value={selectedGroups}
                                                                        style={dropdownStyle}
                                                                        selectOnBlur={false}
                                                                        onChange={
                                                                            (e, {value}) => {
                                                                                setSelectedGroups(value)}
                                                                        }
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                    </Grid.Column>
                                                    <Grid.Column width={5}></Grid.Column>
                                                    <Grid.Column width={5}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                        </NoaContainer>
                                    ) :
                                    ""}
                                </Grid.Column>
                                <Grid.Column width={2}></Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={3} stackable>
                                    <Grid.Column width={5}></Grid.Column>
                                    <Grid.Column width={6}>
                                        <Grid columns={3}>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={onPrevious} disabled={step === 0}>
                                                    Previous
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={applyButton} onClick={onNext} >
                                                    {step === 2 ? 'Add' : 'Next'}
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                            </Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                    <Grid.Column width={5}>
                                   
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ModifyUser = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const router = useRouter();

    const clearSelection = props.clearSelection;
    const getUsers = props.fetchData;

    const [userId, setUserId] = useState(null);
    
    const [user, setUser] = useState({});

    const [initialRole, setInitialRole] = useState(null);
    const [initialGroups, setInitialGroups] = useState([]);
    const [initialPolicy, setInitialPolicy] = useState(null);

    const [roles,setRoles] = useState([]);
    const [userGroups, setUserGroups] = useState([]);
    const [passwordPolicies, setPasswordPolicies] = useState([]);
    const [groups, setGroups] = useState([]);
    
    const [userResources, setUserResources] = useState({});

    const getPasswordPolicies = () => {
        NoaClient.get(
            "/api/platform/security/policy/password",
            (response) => {
                let responseData = response.data;
                let policyList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let policyObj = {'key' : item.policyId, 'value' : item.policyName, 'text': item.policyName}
                        policyList[index] = policyObj;
                    })
                }
                setPasswordPolicies(policyList);
            }
        )
    }

    const getRoles = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role",
            (response) => {
                let responseData = response.data;
                let rolesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let roleObj = {'key' : item.roleId, 'value' : item.roleName, 'text': item.roleName}
                        rolesList[index] = roleObj;
                    })
                }
                setRoles(rolesList);
            }
        )
    }

    const getUserGroups = () => {
        NoaClient.get(
            "/api/platform/security/rbac/group",
            (response) => {
                let responseData = response.data;
                let groups = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let groupObj = {'key' : item.userGroupId, 'value' : item.userGroupName, 'text': item.userGroupName}
                        groups[index] = groupObj;
                    })
                }
                setUserGroups(groups);
            }
        )
    }

    const getUserGroup = () => {
        NoaClient.get(
            "/api/platform/security/rbac/user/" + userId + "/group",
            (response) => {
                let responseData = response.data;
                setGroups(responseData);
                setInitialGroups(responseData)
            }
        )
    }

    const getUser = () => {
        NoaClient.get(
            "/api/platform/security/rbac/user/" + userId,
            (response) => {
                let responseData = response.data;
                setUser(responseData);
                setInitialPolicy(responseData.policyName);
                setInitialRole(responseData.roleName);
            }
        )
    }

    useEffect(() => {
        const id = props.id;
        context.setRenderLocation(['modify-user']);
        if(id != null && id != undefined) {
            setUserId(id);
        }
    },[props.id]);

    useEffect(() => {
        context.setRenderLocation(["modify-user"]);
        getUser();
        //getAccessibleResources(props.data);
        getUserGroup();
        getUserGroups();
        getRoles();
        getPasswordPolicies();
    },[userId]);

    const getAccessibleResources = (userDetail) => {
        const accountId = userDetail.accountId;
        NoaClient.get(
            "/api/platform/security/rbac/user/" + accountId + "/resource",
            (response) => {
                let responseData = response.data;
                setGroups(responseData);
            }
        )
    }

    const handleInput = (value, key) => {
		setUser(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleModify = () => {
        NoaClient.post(
			"/api/platform/security/rbac/user/" + user.accountId,
			user,
			(response) => {
                noaNotification('success','User Account Updated Successfully');
        });

        if(initialRole != user.roleName) {
            assignRoleToUser();
        }

        if(initialPolicy != user.policyName) {
            assignPolicy();
        }
        
        if(groups.length > 0) {
            let removedGroups = initialGroups.filter(item => !groups.includes(item))
            let newGroups = groups.filter(item => !initialGroups.includes(item))
            if(removedGroups.length > 0) {
                handleRemoveUserGroups(removedGroups);
            }
            if(newGroups.length > 0) {
                handleAddUserGroups(newGroups);
            }
        } else {
            handleRemoveUserGroups(initialGroups);
        }
    }

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    const handleAddUserGroups = (newGroups) => {
        let groupIds = []
        newGroups.map((item) => {
            let userGroup = userGroups.find(group => group.value === item)
            groupIds.push(userGroup.key)
        })
        NoaClient.post(
			"/api/platform/security/rbac/user/" + user.accountId + "/group",
			groupIds,
			(response) => {
        });
    }

    const handleRemoveUserGroups = (removedGroups) => {
        let groupIds = []
        removedGroups.map((item) => {
            let userGroup = userGroups.find(group => group.value === item)
            groupIds.push(userGroup.key)
        })
        NoaClient.delete(
			"/api/platform/security/rbac/user/" + user.accountId + "/group",
			groupIds,
			(response) => {
        });
    }

    const assignRoleToUser = () => {
        const role = roles.find(node => node.value === user.roleName);
        NoaClient.post(
            "/api/platform/security/rbac/user/" + user.accountId + "/role/" + role.key,
            null,
            (response) => {
        })
    }

    const assignPolicy = () => {
        const policy = passwordPolicies.find(node => node.value === user.policyName);
        NoaClient.post(
            "/api/platform/security/rbac/user/" + user.accountId + "/policy/" + policy.key,
            null,
            (response) => {
        })
    }

    return(
        <NoaContainer style={completeWidth} id="modify-user">
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>User Details: {user.userName}</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="modify-user">
                <Grid columns={3} stackable>
                    <Grid.Column width={1}></Grid.Column>
                    <Grid.Column width={14} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16} textAlign='left'>
                                <p style={formHeader}>User Details</p>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid >
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>User ID</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='accountId' 
                                                        value={user.userName}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'userName')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>First Name</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='firstName' 
                                                        value={user.firstName}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'firstName')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Last Name</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='lastName' 
                                                        value={user.lastName}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'lastName')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={3} stackable>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Mobile Number</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='mobileNumber' 
                                                        value={user.mobileNumber}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'mobileNumber')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={6}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={3} stackable>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Email</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='email' name='emailId' 
                                                        value={user.emailId}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'emailId')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={6}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={3} stackable>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Account Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='accountType' 
                                                        value={user.accountType}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'accountType')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={6}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>

                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                            <Grid columns={3} stackable>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter}>Expiry Date</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='expirationDate' 
                                                        value={user.expirationDate}
                                                        fluid={false}
                                                        >
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={6}></Grid.Column>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16} textAlign='left'>
                                <p style={formHeader}>Role Details</p>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Role Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection
                                                        placeholder="Select Role"
                                                        options={roles}
                                                        value={user.roleName}
                                                        style={dropdownStyle}
                                                        selectOnBlur={false}
                                                        onChange={
                                                            (e, {value}) => {
                                                                handleInput(value==='' ? null : value, 'roleName')      
                                                            }}
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16} textAlign='left'>
                                <p style={formHeader}>Password Policy Details</p>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Policy Name</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection
                                                        placeholder="Select Policy Name"
                                                        options={passwordPolicies}
                                                        value={user.policyName}
                                                        style={dropdownStyle}
                                                        selectOnBlur={false}
                                                        onChange={
                                                            (e, {value}) => {
                                                                handleInput(value==='' ? null : value, 'policyName')      
                                                        }}
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>

                        <Grid.Row columns={1}>
                            <Grid.Column width={16} textAlign='left'>
                                <p style={formHeader}>User Group Details</p>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={4} stackable>
                                            <Grid.Column width={3}></Grid.Column>                                                
                                            <Grid.Column width={4} textAlign='left'>
                                                <p style={formParameter}>Assigned Groups</p>
                                            </Grid.Column>
                                            <Grid.Column width={6} textAlign='left'>
                                                <Dropdown clearable selection multiple
                                                        placeholder="Select User Groups"
                                                        options={userGroups}
                                                        style={dropdownStyle}
                                                        selectOnBlur={false}
                                                        value={groups}
                                                        onChange={
                                                            (e, {value}) => setGroups(value)
                                                        }
                                                />
                                            </Grid.Column>
                                            <Grid.Column width={3}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                                </Grid.Column>
                                <Grid.Column computer={8} tablet={16} mobile={16}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={1}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column textAlign='center' width={16}>
                    <Grid columns={2}>
                        <Grid.Column textAlign='right' width={8}>
                            <Button style={applyButton} onClick={() => {
                                handleModify();
                                context.setRenderLocation(["modify-user"]);
                            }}>Update</Button>
                        </Grid.Column>
                        <Grid.Column textAlign='left' width={8}>
                            <Button style={cancelButton} onClick={closeFooter}>cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

export default UserManager;
export {AddUser, ModifyUser};