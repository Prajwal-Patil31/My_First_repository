/**@module UserGroups */

import React, { useContext, useEffect, useState } from 'react';
import update from 'react-addons-update';
import {
	Grid,
	Segment,
	Button,
	Checkbox,
	Divider,
	Dropdown,
    Input,
    Step
} from 'semantic-ui-react';

import { 
    noBoxShadow, cardLayout, titleText, 
    noMarginLR, noMarginTB, formTitle, 
    formHeader, formParameter, noPadding, 
    applyButton, cancelButton, completeHeight, 
    completeWidth, tablePadding, tableHeaderHeight, 
    fullHeight, dividerStyle, formContentSpacingTB, 
    formSpacingTB, inputBoxStyle, dropdownStyle
} from '../../../constants';

import 'semantic-ui-css/semantic.min.css';

import NoaTable from '../../../widget/NoaTable';
import NoaClient from '../../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../../utility/RouteRedirect';
import { NoaContainer, NoaHeader } from '../../../widget/NoaWidgets';
import NoaFilter from '../../../widget/NoaFilter';
import NoaToolbar from '../../../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../../widget/NoaNotification';

const UserGroupManager = (props) => {
    const [userGroups, setUserGroups] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const router = useRouter();
    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = userGroups[sel[i]].userGroupId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getUserGroups = (filterObj) => {
        context.setRenderLocation(["user-group-list"]);
        NoaClient.post(
            "/api/platform/security/rbac/group",
            filterObj,
            (response) => {
                let responseData = response.data;
                setUserGroups(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/security/rbac/group/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"user-group":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getUserGroups(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({},completeHeight,cardLayout)}>
                            <UserGroupsTable userGroups={userGroups} getUserGroups={getUserGroups}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                                            columns={columns}
                                            filters={filters}
                                            pageSize={pageSize}
                                            totalPages={totalPages}
                                            setPageSize={setPageSize}
                                            totalEntries={totalEntries}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const UserGroupsTable = (props) => {
    const context = useContext(GlobalSpinnerContext);

    const userGroups = props.userGroups;
    const getUserGroups = props.getUserGroups;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"user-group" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
		{
			label: "1",
			Header: "Group Name",
            accessor: "userGroupName",
            width: 4
		},
		{
			label: "2",
			Header: "Group Code",
            accessor: "userGroupCode",
            width: 3
		},
        {
			label: "4",
			Header: "Users Count",
            accessor: "userCount",
            width: 3
		},
        {
			label: "5",
			Header: "Assigned Role",
            accessor: "roleName",
            width: 4
        }
    ]

    const router = useRouter();

    const handleAddGroup = () => {
        router.stateService.go("add-user-group",{fetchData: getUserGroups, clearSelection: clearSelection})
    }

    useEffect(() => {
        setSelected(selections);
        let keys = Object.keys(selections);
        if(keys.length == 1) {
            let selId = keys[0];
            router.stateService.go('modify-user-group',{id: userGroups[selId].userGroupId,fetchData: getUserGroups,clearSelection: clearSelection})
        } else {
            router.stateService.go('default')
        }
    }, [selections]);
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["user-group-list"]);

        NoaClient.delete(
            "/api/platform/security/rbac/group",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getUserGroups(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"user-group" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getUserGroups(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getUserGroups(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>User Groups</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddGroup}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={userGroups}
                            columns={columns}
                            selectedRows={selections}
                            onSelectedRowsChange={setSelections}
                            clearSelected={clearSelected}
                            setClearSelected={setClearSelected}
                            selectedPageSize={pageSize}
                            handlePagination={handlePagination}
                            totalPages={totalPages}
                            handlePageSize={handlePageSize}
                            totalEntries={totalEntries}
                            resource="User Groups" 
                            fetchData={fetchData} 
                            location="user-group-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const AddUserGroup = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const getUserGroups = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const [step, setStep] = React.useState(0);
    const [userGroup, setUserGroup] = useState({});

    const [users, setUsers] = useState([]);
    const [roles, setRoles] = useState([]);

    const [selectedUsers, setSelectedUsers] = useState([]);
    const [selectedRole, setSelectedRole] = useState(null);

    const [roleActions, setRoleActions] = useState([]);

    const [elements, setElements] = useState([]);
    const [networks, setNetworks] = useState([]);
    const [services, setServices] = useState([]);

    const [resources, setResources] = useState({});

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 2 ? 2 : nextStep);
    };

    useEffect(() => {
        switch (step) {
            case 0:
                setUserGroup({});
                context.setRenderLocation(["add-user-group"])
                getUsers();
                getRoles();
                break;
            case 1:
                if(selectedRole != null) {
                    context.setRenderLocation(["add-user-group"])
                    getRoleActions();
                } else {
                    alert("Select a Role")
                    setStep(0)
                }
                break;
            case 2:
                context.setRenderLocation(["add-user-group"]);
                handleAdd();
                break;
            default:
                break;
        }
    }, [step]);

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);

    const handleInput = (value, key) => {
		setUserGroup(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleAdd = () => {
        const users = selectedUsers;
        const roleId = selectedRole;
        userGroup["userCount"] = users.length;
        NoaClient.put(
            "/api/platform/security/rbac/group",
            userGroup,
            (response) => {
                let responseData = response.data;
                let groupId = responseData.userGroupId;
                noaNotification('success','User Group Created Successfully');
                getUserGroups();
                closeFooter()
                if(users.length > 0) {
                    handleAddUsers(groupId,users);
                }
                assignRoleToGroup(groupId,roleId,resources);
        })   
    }

    const handleAddUsers = (groupId,users) => {
        NoaClient.put(
            "/api/platform/security/rbac/group/" + groupId + "/user",
            users,
            (response) => {
                noaNotification('success','Users added to Group Successfully');
        })
    }

    const assignRoleToGroup = (groupId,roleId,resources) => {
        NoaClient.put(
            "/api/platform/security/rbac/group/" + groupId + "/role/" + roleId,
            resources,
            (response) => {
                noaNotification('success','Role Assigned to Group Successfully');
        })
    }

    const getUsers = () => {
        NoaClient.get(
            "/api/platform/security/rbac/user/",
            (response) => {
                let responseData = response.data;
                let usersList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let userObj = {'key' : item.accountId, 'value' : item.accountId, 'text': item.userName}
                        usersList[index] = userObj;
                    })
                }
                setUsers(usersList);
        })
    }

    const getRoles = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/",
            (response) => {
                let responseData = response.data;
                let rolesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let roleObj = {'key' : item.roleId, 'value' : item.roleId, 'text': item.roleName}
                        rolesList[index] = roleObj;
                    })
                }
                setRoles(rolesList);
        })
    }
    
    const getRoleActions = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role/" + selectedRole + "/resourceAction",
            (response) => {
                let responseData = response.data;
                setRoleActions(responseData);
        })
    }

    useEffect(() => {
        getResources()
    },[roleActions]);

    const getResources = () => {
        if(roleActions.includes("ServiceManagement")) {
            NoaClient.get(
                "/api/service",
                (response) => {
                    let responseData = response.data;
                    let servicesList = [];
                    if(Array.isArray(responseData)) {
                        responseData.map((item,index) => {
                            let serviceObj = {'key' : item.serviceId, 'value' : item.serviceId, 'text': item.serviceName}
                            servicesList[index] = serviceObj;
                        })
                    }
                    setServices(servicesList);
            })
        }

        if(roleActions.includes("ElementManagement")) {
            NoaClient.get(
                "/api/element",
                (response) => {
                    let responseData = response.data;
                    let elementsList = [];
                    if(Array.isArray(responseData)) {
                        responseData.map((item,index) => {
                            let deviceObj = {'key' : item.deviceId, 'value' : item.deviceId, 'text': item.deviceName}
                            elementsList[index] = deviceObj;
                        })
                    }
                    setElements(elementsList);
            })
        }

        if(roleActions.includes("NetworkManagement")) {
            NoaClient.get(
                "/api/network",
                (response) => {
                    let responseData = response.data;
                    let networksList = [];
                    if(Array.isArray(responseData)) {
                        responseData.map((item,index) => {
                            let networkObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                            networksList[index] = networkObj;
                        })
                    }
                    setNetworks(networksList);
            })
        }
    }

    const handleRoleSelection = (value,key) => {
        if(value != null) {
            const role_sel = roles.find(node => node.value === value);
            handleInput(role_sel.text,key);
            setSelectedRole(value);
        } else {
            handleInput(null,key);
            setSelectedRole(null);
        }
    }

    const handleResourceSelection = (value,key) => {
        let keys = Object.keys(resources);
        if(keys.includes(key)) {
            setResources(
                update(resources, {
                    [key]: {
                     $set : value
                    }
                })
            );
        } else {
            let resourceObj = {...resources}
            resourceObj[key] = value;
            setResources(resourceObj);
        }
    }

    const closeFooter = () => {
        router.stateService.go('default');
    }
    return(
        <NoaContainer style={completeWidth}>
            <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create User Group</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} id="add-user-group">
                        <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Step.Group style={{border: "0px"}} fluid>
                                    <Step style={{border: "0px"}} active={step == 0 ? true : false} completed={step > 0 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>User Group Details</Step.Title>
                                        </Step.Content>
                                    </Step>
                                    <Step style={{border: "0px"}} active={step == 1 ? true : false}>
                                        <Step.Content>
                                            <Step.Title style={formTitle}>Select Resources</Step.Title>
                                        </Step.Content>
                                    </Step>
                                </Step.Group>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1} style={formContentSpacingTB}>
                            <Grid.Column width={16}>
                            <Grid columns={3} stackable>
                                <Grid.Column width={3}></Grid.Column>
                                <Grid.Column width={10}>
                                {step === 0 ? (
                                    <NoaContainer >
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter} className="required">User Group Name</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Input type='text' name='userGroupName' 
                                                                        value={userGroup.userGroupName}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'userGroupName')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter}>User Group Code</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Input type='text' name='userGroupCode' 
                                                                        value={userGroup.userGroupCode}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'userGroupCode')
                                                                        }>
                                                                            <input style={inputBoxStyle}></input>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    {/* <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={2}></Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <p style={formParameter}>User Group Type</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Input type='text' name='userGroupType' 
                                                                        value={userGroup.userGroupType}
                                                                        fluid={false}
                                                                        onChange={
                                                                            (e, {value}) => handleInput(value==='' ? null : value, 'userGroupType')
                                                                        }>
                                                                    </Input>
                                                                </Grid.Column>
                                                                <Grid.Column width={2}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row> */}

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter} className="required">Select Users</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Dropdown clearable selection required multiple
                                                                            placeholder="Select Users"
                                                                            selectOnBlur={false}
                                                                            options={users}
                                                                            style={dropdownStyle}
                                                                            value={selectedUsers}
                                                                            onChange={
                                                                                (e, {value}) => setSelectedUsers(value)
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <Grid columns={4} stackable>
                                                                <Grid.Column width={3}></Grid.Column>
                                                                <Grid.Column width={4} textAlign='left'>
                                                                    <p style={formParameter} className="required">Select Role</p>
                                                                </Grid.Column>
                                                                <Grid.Column width={6} textAlign='left'>
                                                                    <Dropdown clearable selection required
                                                                            placeholder="Select Role"
                                                                            selectOnBlur={false}
                                                                            options={roles}
                                                                            style={dropdownStyle}
                                                                            value={selectedRole}
                                                                            onChange={
                                                                                (e, {value}) => handleRoleSelection(value == '' ? null : value, 'roleName')
                                                                            }
                                                                    />
                                                                </Grid.Column>
                                                                <Grid.Column width={3}></Grid.Column>
                                                            </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                    </NoaContainer>
                                    ) : 
                                    step === 1 ? (
                                    <NoaContainer>
                                    <Grid verticalAlign='middle'>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={2} stackable>
                                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                                <Grid>
                                                {elements.length > 0 ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter}>Select Elements</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required multiple
                                                                        placeholder="Select Elements"
                                                                        selectOnBlur={false}
                                                                        options={elements}
                                                                        style={dropdownStyle}
                                                                        onChange={
                                                                            (e, {value}) => handleResourceSelection(value==='' ? null : value, 'element')
                                                                        }
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    : <p>No Element Related Privileges</p>}

                                                    {services.length > 0 ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter}>Select Services</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required multiple
                                                                        placeholder="Select Services"
                                                                        selectOnBlur={false}
                                                                        options={services}
                                                                        style={dropdownStyle}
                                                                        onChange={
                                                                            (e, {value}) => handleResourceSelection(value==='' ? null : value, 'service')
                                                                        }
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    : <p>No Service Related Privileges</p>}

                                                    {networks.length > 0 ? 
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter}>Select Networks</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required multiple
                                                                        placeholder="Select Networks"
                                                                        selectOnBlur={false}
                                                                        options={networks}
                                                                        style={dropdownStyle}
                                                                        onChange={
                                                                            (e, {value}) => handleResourceSelection(value==='' ? null : value, 'network')
                                                                        }
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    : <p>No Network Related Privileges</p>}
                                                </Grid>
                                                </Grid.Column>
                                                <Grid.Column computer={8} tablet={16} mobile={16}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                    </NoaContainer>
                                    ) : ""}
                                </Grid.Column>
                                <Grid.Column width={3}></Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={3} stackable>
                                    <Grid.Column width={5}></Grid.Column>
                                    <Grid.Column width={6}>
                                        <Grid columns={3}>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={onPrevious} disabled={step === 0}>
                                                    Previous
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={applyButton} onClick={onNext} >
                                                    {step === 1 ? 'Add' : 'Next'}
                                                </Button>
                                            </Grid.Column>
                                            <Grid.Column width="equal">
                                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                                            </Grid.Column>
                                        </Grid>
                                    </Grid.Column>
                                    <Grid.Column width={5}>
                                   
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ModifyUserGroup = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const router = useRouter();
    const clearSelection = props.clearSelection;
    const getUserGroups = props.fetchData;

    const [groupId, setGroupId] = useState(null);

    const [data,setData] = useState({});
    const [roles, setRoles] = useState([]);
    const [users, setUsers] = useState([]);
    const [groupUsers, setGroupUsers] = useState([]);

    const [initialUsers, setInitialUsers] = useState([])
    const [initialRole, setInitialRole] = useState(null);

    const getRoles = () => {
        NoaClient.get(
            "/api/platform/security/rbac/role",
			(response) => {
				let responseData = response.data;
                let rolesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let roleObj = {'key' : item.roleId, 'value' : item.roleName, 'text': item.roleName}
                        rolesList[index] = roleObj;
                    })
                }
                setRoles(rolesList)
		});
    }
    
    const getUsers = () => {
        NoaClient.get(
            "/api/platform/security/rbac/user",
			(response) => {
				let responseData = response.data;
                let usersList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let userObj = {'key' : item.accountId, 'value' : item.userName, 'text': item.userName}
                        usersList[index] = userObj;
                    })
                }
                setUsers(usersList)
		});
    }

    const getGroupUsers = () => {
        NoaClient.get(
            "/api/platform/security/rbac/group/" + groupId + "/user",
			(response) => {
                let responseData = response.data;
                let usersList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        usersList[index] = item.userName;
                    })
                }
                setGroupUsers(usersList)
                setInitialUsers(usersList)
		});
    }

    useEffect(() => {
        const id = props.id;
        context.setRenderLocation(['modify-user-group']);
        if(id != null && id != undefined) {
            setGroupId(id);
        }
    },[props.id]);
    
    useEffect(() =>{ 
        if(groupId != null) {
            context.setRenderLocation(["modify-user-group"]);
            getUserGroup();
            getRoles();
            getUsers();
            getGroupUsers();
        }
    },[groupId]);

    const getUserGroup = () => {
		NoaClient.get(
			"/api/platform/security/rbac/group/" + groupId,
			(response) => {
                setData(response.data);
                setInitialRole(response.data.roleName)
        });
    }

    const handleInput = (value, key) => {
		setData(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleModify = () => {
		NoaClient.post(
			"/api/platform/security/rbac/group/" + data.userGroupId,
			data,
			(response) => {
                noaNotification('success','User Group Updated Successfully');
                getUserGroups();
        });

        if(initialRole != data.roleName) {
            assignRoleToUser();
        }

        if(groupUsers.length > 0) {
            let removedUsers = initialUsers.filter(item => !groupUsers.includes(item))
            let newUsers = groupUsers.filter(item => !initialUsers.includes(item))
            if(removedUsers.length > 0) {
                handleRemoveUsers(removedUsers);
            }
            if(newUsers.length > 0) {
                handleAddUsers(newUsers);
            }
        } else {
            handleRemoveUsers(initialUsers);
        }
    }

    const handleAddUsers = (newUsers) => {
        let userIds = []
        newUsers.map((item) => {
            let user = users.find(account => account.value === item)
            userIds.push(user.key)
        })
        NoaClient.post(
			"/api/platform/security/rbac/group/" + data.userGroupId + "/user",
			userIds,
			(response) => {
        });
    }
    
    const handleRemoveUsers = (removedUsers) => {
        let userIds = []
        removedUsers.map((item) => {
            let user = users.find(account => account.value === item)
            userIds.push(user.key)
        })
        NoaClient.delete(
			"/api/platform/security/rbac/group/" + data.userGroupId + "/user",
			userIds,
			(response) => {
        });
    }

    const assignRoleToUser = () => {
        const role = roles.find(node => node.value === data.roleName);
        NoaClient.put(
            "/api/platform/security/rbac/group/" + data.userGroupId + "/role/" + role.key,
            null,
            (response) => {
        })
    }

    const closeFooter = () => {
        router.stateService.go('default');
        clearSelection();
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>User Group Details: {data.groupName}</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="modify-user-group">
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                        <Grid columns={3}>
                            <Grid.Column width={1}></Grid.Column>
                            <Grid.Column width={14}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={2} stackable>
                                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} textAlign='center'>
                                                        <p style={formHeader}>User Group Details</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1} style={formSpacingTB}>
                                                    <Grid.Column width={16}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                                <Grid stackable columns={4}>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                    <Grid.Column width={4} textAlign='left'>
                                                                        <p style={formParameter} >Group Name</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Input type='text' name='userGroupName' 
                                                                            value={data.userGroupName}
                                                                            fluid={false}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'userGroupName')
                                                                            }>
                                                                                <input style={inputBoxStyle}></input>
                                                                        </Input>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>

                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                                <Grid stackable columns={4}>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                    <Grid.Column width={4} textAlign='left'>
                                                                        <p style={formParameter}>Group Code</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Input type='text' name='userGroupCode' 
                                                                            value={data.userGroupCode}
                                                                            fluid={false}
                                                                            onChange={
                                                                                (e, {value}) => handleInput(value==='' ? null : value, 'userGroupCode')
                                                                            }>
                                                                                <input style={inputBoxStyle}></input>
                                                                        </Input>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                            <Grid.Column computer={8} tablet={16} mobile={16}></Grid.Column>
                                        </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16}>
                                        <Grid columns={2} stackable>
                                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} textAlign='center'>
                                                        <p style={formHeader}>Role Details</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1} style={formSpacingTB}>
                                                    <Grid.Column width={16}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                                <Grid stackable columns={4}>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                    <Grid.Column width={4} textAlign='left'>
                                                                        <p style={formParameter}>Assigned Role</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Dropdown clearable selection search
                                                                                options={roles}
                                                                                selectOnBlur={false}
                                                                                value={data.roleName}
                                                                                style={dropdownStyle}
                                                                                onChange={
                                                                                    (e, {value}) => handleInput(value==='' ? null : value, 'roleName')
                                                                                }
                                                                        />
                                                                    </Grid.Column>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16} textAlign='center'>
                                                        <p style={formHeader}>User Details</p>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                <Grid.Row columns={1} style={formSpacingTB}>
                                                    <Grid.Column width={16}>
                                                    <Grid>
                                                        <Grid.Row columns={1}>
                                                            <Grid.Column width={16}>
                                                                <Grid stackable columns={4}>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                    <Grid.Column width={4} textAlign='left'>
                                                                        <p style={formParameter}>Assigned Users</p>
                                                                    </Grid.Column>
                                                                    <Grid.Column width={6} textAlign='left'>
                                                                        <Dropdown clearable selection required multiple
                                                                                options={users}
                                                                                value={groupUsers}
                                                                                selectOnBlur={false}
                                                                                style={dropdownStyle}
                                                                                onChange={
                                                                                    (e, {value}) => 
                                                                                    setGroupUsers(value)
                                                                                }
                                                                        />
                                                                    </Grid.Column>
                                                                    <Grid.Column width={3}></Grid.Column>
                                                                </Grid>
                                                            </Grid.Column>
                                                        </Grid.Row>
                                                        </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid>
                                        </Grid.Column>

                                    </Grid.Row>
                                </Grid>
                            </Grid.Column>
                            <Grid.Column width={1}></Grid.Column>
                        </Grid>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <Grid columns={2}>
                    <Grid.Column width={8} textAlign='right'>
                        <Button style={applyButton} onClick={() => {
                            context.setRenderLocation(["modify-user-group"]);
                            handleModify()
                        }}>save</Button>
                    </Grid.Column>
                    <Grid.Column width={8} textAlign='left'>
                        <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                    </Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

export default UserGroupManager;
export {AddUserGroup,ModifyUserGroup};