import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../widget/NoaTable';

import {
    Grid,
    Segment,
    Checkbox,
    Button
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, titleText, 
    cardLayout, completeHeight, completeWidth, 
    applyButton, tableHeaderHeight, tablePadding,
    fullHeight
} from '../../constants';

import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';
import { NoaContainer} from '../../widget/NoaWidgets';

const SessionManager = (props) => {
    const [sessions, setSessions] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = sessions[sel[i]].sessionId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getSessions = () => {
        NoaClient.get(
			"/api/platform/security/session",
			(response) => {
                let responseData = response.data
                let sessionList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item) => {
                        let session = {
                            'sessionId': item.sessionId,
                            'lastRequest': item.lastRequest,
                            'expired': item.expired,
                            'username': item.principal.userName
                        }
                        sessionList.push(session);
                    })
                }
                setSessions(sessionList)
			});
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        context.setRenderLocation(["session-list"]);
        getSessions();
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={Object.assign({},fullHeight)}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({},completeHeight, cardLayout)}>
                            <SessionTable sessions={sessions} getSessions={getSessions}
                                            selectedRows={selectedRows}
                                            setClearSelected={setClearSelected}
                                            setSelected={setSelected} 
                                            clearSelected={clearSelected}
                            />
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const SessionTable = (props) => {
    const sessions = props.sessions;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    const getSessions = props.getSessions;
    
    const [selections,setSelections] = useState([]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
		{
			label: "1",
			Header: "Session Id",
            accessor: "sessionId",
            width: 3
        },
        {
			label: "2",
			Header: "Username",
            accessor: "username",
            width: 4
        },
		{
			label: "4",
			Header: "Last Login",
            accessor: "lastRequest",
            width: 4
		},
        {
			label: "4",
			Header: "Expiry Time",
            accessor: "expired",
            width: 4
		}
    ]
    
    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Active Sessions</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    {/* <NoaFilter filters={{}} getData={getBridges}/> */}
                                </Grid.Column>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                    <SessionsToolbar selectedRows={selectedRows} getSessions={getSessions} setClearSelected={setClearSelected}/>                             
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={sessions}
                        columns={columns}
                        selectedRows={selectedRows}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        resource="User Sessions" 
                        fetchData={getSessions} 
                        location="session-list"
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const SessionsToolbar = (props) => {
    const selectedRows = props.selectedRows;
    const getSessions = props.getSessions;
    const setClearSelected = props.setClearSelected;

    const handleDelete = () => {
		NoaClient.delete(
			"/api/platform/security/session",
			selectedRows,
			(response) => {
                getSessions();
                setClearSelected(true);
			})
    }
    return(
        <Button style={applyButton} onClick={handleDelete}>Terminate</Button>
    )
}
export default SessionManager;