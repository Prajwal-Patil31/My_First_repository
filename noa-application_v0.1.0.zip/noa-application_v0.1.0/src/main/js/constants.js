export const tbButton = {
	color: "#FFFFFF", 
	background: "#2699FB", 
	padding: '0 !important',
	borderRadius: '24px',
	paddingTop: '10px',
	paddingBottom: '10px',
	paddingRight: '12px',
	paddingLeft: '12px',
}

export const stButton = {
	width: '75px',
	color: "#FFFFFF",
	padding: '0 !important', 
	borderRadius: '24px',
	paddingTop: '10px',
	paddingBottom: '10px',
	paddingRight: '12px',
	paddingLeft: '12px',
}

export const noPadding = {
	padding: '0',
	paddingTop: '0',
	paddingBottom: '0',
}

export const noBorder = {
	border: '0px',
	borderRadius: '0px',
	borderLeft: '0px',
	borderRight: '0px',
}

export const noMarginLR = {
	marginLeft: '0px',
	marginRight: '0px',
}

export const noMarginTB = {
	marginTop: '0px',
	marginBottom: '0px',
}

export const noBoxShadow = {
	boxShadow: 'none',
	border: '0px'
}

export const priFgnd = {
	background: '#dfe6ec',
}

export const activeMenuItem = {
	borderBottom: '1px #252525',
	fontWeight: 'bold'
}

export const priBgnd = {
	background: '#f5f6f8',
}

export const stdTable = {
	borderCollapse: 'collapse',
    borderSpacing: 0,
    borderRadius: 0,
	borderColor: 'lightgray',
	borderStyle: 'double',
	borderWidth: 'thin',
	color: 'darkslategray',
}

export const menuStyle = {
	border: '0px',
	borderRadius: '0px',
	boxShadow: 'none',
	marginBottom: '0em',
	marginTop: '0em',
	transition: 'box-shadow 0.5s ease, padding 0.5s ease',
}
  
export const fixedMenuStyle = {
	backgroundColor: '#fff',
	border: '1px solid #ddd',
	boxShadow: '0px 3px 5px rgba(0, 0, 0, 0.2)',
}

export const overlayStyle = {
	float: 'left',
	margin: '0em 3em 1em 0em',
 }
  
export const fixedOverlayStyle = {
	...overlayStyle,
	position: 'fixed',
	top: '80px',
	zIndex: 10,
 }
  
export const overlayMenuStyle = {
	position: 'relative',
	left: '0px',
	transition: 'left 0.5s ease',
}
  
export const fixedOverlayMenuStyle = {
	...overlayMenuStyle,
	left: '800px',
}

export const segmentStyle = {
	display: 'flex',
	alignItems: 'center',
	justifyContent: 'space-between',
	margin: 0,
	padding: 0,
}

export const formStyle = {
	textAlign: 'left',
}

export const formFieldStyle = {
	textAlign: 'left',
	color: "#696969",
	opacity: '1',
}

export const drawerStyle = {
	textAlign: 'center',
}

export const gridScroll = {
	flex: 1,
  	overflowY: 'auto',
	overflowX: 'hidden'
}

export const noMargin ={
	margin:'0 !important'
}

//Page Layout
export const fullHeight = {
	minHeight: '100vh',
}

export const pageLayout = {
	marginLeft: '12em',
	marginTop: '3.25em',
	marginRight: '12em'
}

export const autoHeight = {
	height: "auto"
}

export const footerText = {
	fontFamily: "OpenSansLight",
	fontSize: "1em"
}

export const completeWidth = {
	width: "100%"
}

export const completeHeight = {
	height: "100%"
}

//NoaHeader
export const toolbarItem = {
	fontFamily: "Montserrat",
	fontSize: "1em"
}

//Main Menu
export const menuItemLayout = {
	display: "flex",
	justifyContent: "flex-start",
	maxWidth:"180px"
}

export const menuOptionsLayout = {
	textAlign: "right",
	paddingBottom: "0.5em",
	paddingTop: "0.5em",
	position: "absolute",
	zIndex: 2,
	right:0,
	top:"5px"
}

export const nMenuItem = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "1.2em",
	fontWeight:600
}

export const noMenuBorder = {
	borderBottom: "0px"
}

//Sub-Menu
export const subMenuLayout = {
	marginBottom:"0px",
	borderBottom:"1px solid #D5DFE9"
}

export const subMenuItem = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "1.20em",
	display: "flex",
	justifyContent: "flex-start"
}

export const titleText = {
	...textColor,
	fontFamily: "MontserratSemiBold",
	fontSize: "1.25em",
	textTransform: "capitalize"
}

//Breadcrumb
export const breadCrumbItem = {
	...textColor,
	fontFamily: "MontserratLight",
	fontSize: "1em"
}

//Card
export const cardLayout = {
	borderRadius: "10px",
	boxShadow: "1px 1px 2px #D5DFE9",
	border:"1px solid rgb(213,223,233,.5)"
}

export const cardTitleItem = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "1.2em",
	textTransform: "capitalize",
	fontWeight: "bold",
}

export const cardKeyItem = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.1em",
	textTransform: "uppercase"
}

export const cardValueItem = {
	...textColor,
	fontFamily: "OpenSansSemiBold",
	fontSize: "1.3em",
	textTransform: "capitalize"
}

export const pieKeyItem = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.1em",
	textTransform: "uppercase"
}

export const pieValueItem = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.5em",
	textTransform: "capitalize",
	fontWeight:600
}

export const cardDurationItem = {
	fontFamily: "OpenSansLight",
	fontSize: "1em"
}

//Forms
export const formTitle = {
	...textColor,
	fontFamily: "OpenSansSemiBold",
	fontSize: "1.25em",
	textTransform: "capitalize"
}

export const formHeader = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.2em",
	textTransform: "capitalize",
	fontWeight:600
}

export const formParameter = {
	fontFamily: "OpenSansRegular",
	fontSize: "1em",
	textTransform: "capitalize"
}

export const formDisplay = {
	fontFamily: "MontserratSemiBold",
	fontSize: "1em",
	textTransform: "uppercase"
}
export const applyButton = {
	width:"auto",
	color: "#FFFFFF", 
	background: " #074EE8",
	borderRadius: "16px",
	textTransform: "uppercase",
	fontFamily: "MontserratLight",
	minWidth:"7.5em",
}

export const cancelButton = {
	width:"auto",
	color: " #074EE8", 
	background: "#FFFFFF",
	border: "1px solid  #074EE8",
	borderRadius: "16px",
	textTransform: "uppercase",
	fontFamily: "MontserratLight",
	minWidth:"7.5em",
}

//Accordions
export const accordionTitle = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "1.4em",
	fontWeight:600,
	textTransform: "capitalize",
}

export const subAccordionTitle = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "1.25em",
	textTransform: "capitalize",
	fontWeight:600
}

export const accordionHeader = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.2em",
	textTransform: "capitalize",
}

export const checkboxHeader = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.1em",
	textTransform: "capitalize",
}

export const checkboxDescription = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1em",
	textTransform: "capitalize",
}

export const accordionContentMargins = {
	marginTop:"1em",
	marginBottom:"1em",
}

export const accordionFixedHeight = {
	...accordionContentMargins,
	maxHeight:"31.25em",
	overflowY:"auto"
}

//Charts
export const pieChartLabel = {
	fontFamily: "OpenSansSemiBold",
	fontSize: "1.4em",
	textTransform: "capitalize",
}

export const radialBarLabel = {
	...textColor,
	position: "center",
	fontFamily:"OpenSansSemiBold",
	fontSize: "2.2em"
}

export const semiRadialBarLabel = {
	...textColor,
	position: "center",
	fontFamily:"OpenSansSemiBold",
	fontSize: "2em",
	fill: "#1c1717"
}

export const semiRadialBarText = {
	fontFamily: "OpenSansSemiBold",
	fontSize: "1.25em",
	textTransform: "uppercase"
}

export const progressBarLabel = {
	...textColor,
	fontFamily:"OpenSansRegular",
	fontSize:"1em",
	marginLeft: "10px"
}

export const lineChartTitle = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.25em",
	textTransform: "uppercase"
}

export const progressBarRightAxisFont = {
	...textColor,
	fontFamily:"OpenSansLight",
	fontSize:"1.125em",
	marginRight: "100px"
}


//Table
export const tablePadding = {
	paddingLeft: "2em", 
	paddingRight: "2em",
	paddingTop: "1em",
	paddingBottom: "1em"
}

export const tableHeaderHeight = {
	maxHeight: "7.5em"
}

export const tableHeaderItem = {
	...textColor,
	fontFamily: "OpenSansLight",
	fontSize: "1.2em",
	borderBottom: "1px solid #252525"
}

export const tableBodyItem = {
	...textColor,
	fontFamily: "OpenSansRegular",
	fontSize: "1.1em"
}

export const tableSummaryItem = {
	...noPadding,
	...textColor,
	height: "100%",
	minHeight:"2.5em",
	maxWidth:"9.5em",
	border:"1px solid rgb(213,223,233,.5)",
	borderRadius: "1.25em",
	fontFamily: "OpenSansRegular",
	fontSize: "1em"
}

//Toolbar
export const toolBarStyle = {
	minHeight: "40px",
	border: "1px solid rgb(213, 223, 233,.5)",
	borderRadius: "30px",
}

export const actionIconStyle = {
	border: "1px solid #252525"
}

//Filter
export const filterDropdownStyle = {
	borderRadius: "18px",
	border: "1px solid rgb(213, 223, 233)"
}


//Other
export const bodyLayoutFlex = {
	display: "flex",
	flexDirection:"column"
}

export const textColor = {
	color:"#252525"
}

export const overviewStyle = {
	//marginTop: "1.5em",
	marginBottom: "1em"
}

//Topology
export const topologyContainer = {
	border:"1px solid rgb(37, 37, 37,.1)",
	width:"95%",
	minHeight:"100vh"
}

export const tooltipTitle = {
	fontFamily: "MontserratSemiBold",
	fontSize: "1.2em",
	textTransform: "capitalize"
}

export const tooltipHeading = {
	fontFamily: "OpenSansRegular",
	fontSize: "1.2em",
	textTransform: "capitalize"
}

export const tooltipValue = {
	fontFamily: "OpenSansRegular",
	fontSize: "1em",
	textTransform: "uppercase",
	fontWeight:600
}

export const topologyChartTitle = {
	...textColor,
	fontFamily: "MontserratLight",
	fontSize: "1.2em",
	textTransform: "uppercase",
}

export const topologyChartDesc = {
	...textColor,
	fontFamily: "MontserratLight",
	fontSize: "1em",
	textTransform: "uppercase",
	fontWeight: 600,
}

export const topologyChartValue = {
	...textColor,
	fontFamily: "MontserratLight",
	fontSize: "1.4em",
	margin: "auto",
	color: "white"
}

//other
export const dividerStyle = {
	border:"1px solid rgb(213, 223, 233,.3)",
}

export const inputStyle = {
	...textColor,
	fontFamily:"OpenSansRegular",
	border:"1px solid rgb(213, 223, 233)",
	borderRadius:"10px"
}

export const inputBoxStyle = {
	...inputStyle,
	maxWidth:"11.25em"	
}

export const dropdownStyle = {
	...inputStyle,
	minWidth:"11.25em"	
}

export const formContentSpacingTB = {
	marginTop:"2em",
	marginBottom:"2em"
}

export const formSpacingTB = {
	marginTop:"1.5em",
	marginBottom:"1.5em"
}

export const noaCardLayout = {
	boxShadow:"none",
	border:"1px solid rgb(213,223,233,.5)"
}

export const noaCardTitle = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "1em",
	textTransform: "capitalize",
	fontWeight: 600,
}

export const noaCardDesc = {
	...textColor,
	fontFamily: "Montserrat",
	fontSize: "0.9em",
}

/* export const customScrollbar = {
	webkitScrollbar {
		width: 16px;
	  }
	
	webkit-scrollbar-track {
		background: #ffffff;
	}
} */