import React, { useEffect, useState } from "react";
import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
} from "recharts";

import { Grid } from 'semantic-ui-react';

import { cardKeyItem, completeWidth,noPadding, progressBarLabel } from '../constants'
import { NoaContainer } from "./NoaWidgets";

const NoaProgressBar = (props) => {
    const [data, setData] = useState([]);
    const [title, setTitle] = useState(null);

    useEffect(() => {
        setData(props.data)
    },[props.data]);

    useEffect(() => {
        setTitle(props.title)
    },[props.title]);

    const CustomTooltip = props.customTooltip;
    return(
        <NoaContainer style={Object.assign({textAlign: "center"},completeWidth)}>
            <Grid>
                {title != null ? 
                    <Grid.Row columns={1}>
                        <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                            <p style={cardKeyItem}>{title}</p>
                        </Grid.Column>
                    </Grid.Row>
                : ""}
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='center' verticalAlign='middle'>
                        <ResponsiveContainer width={"100%"} height={50 * data.length}>
                            <BarChart
                                data={data}
                                layout="vertical"
                                margin={{left:40,right: 35}}
                            >
                                <XAxis hide type="number" domain={[0,data[0] != undefined ? data[0].maxValue : 0]}/>
                                <YAxis yAxisId={0} orientation='left' type="category" dataKey="name" fill="#252525"
                                        axisLine={false} tickLine={false} style={Object.assign({},progressBarLabel)} 
                                        /* tick={CustomTooltip != undefined ? <CustomTooltip /> : ""} *//>
                                <YAxis yAxisId={1} orientation='right' type="category" dataKey="total" fill="#252525"
                                        axisLine={false} tickLine={false} style={Object.assign({},progressBarLabel)}/>
                                <Bar background dataKey="count" fill={data[0] != undefined ? data[0].color : ""} barSize={12}></Bar>
                            </BarChart>
                        </ResponsiveContainer>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

export default NoaProgressBar;