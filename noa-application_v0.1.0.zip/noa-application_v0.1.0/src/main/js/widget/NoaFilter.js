import React, { useEffect, useState } from 'react';
import update from 'react-addons-update';

import { Grid, Dropdown } from 'semantic-ui-react';

import 'semantic-ui-css/semantic.min.css';
import { filterDropdownStyle } from '../constants';

const NoaFilter = (props) => {
    const getData =  props.getData;
    const setAppliedFilters = props.setAppliedFilters;

    const [allFilters, setAllFilters] = useState([]);
    const [filterOptions, setFilterOptions] = useState([]);
    const [valueSelection, setValueSelection] = useState(true);
    const [filterValues, setFilterValues] = useState({});
    const [filterSelected, setFilterSelected] = useState(0);
    const [categorySelected, setCategorySelected] = useState(null);
    const [valueSelected, setValueSelected] = useState([]);
    const [filterData, setFilterData] = useState({});
    const [tags, setTags] = useState([]);

    useEffect(() => {
        parseFilters(props.filters);
    },[props.filters]);

    const parseFilters = (filters) => {
        
        let categories_dd = [];
        let options_dd = {};
        if(Object.keys(filters).length > 0) {
            let dropdownHeaders = Object.keys(filters);
            dropdownHeaders.forEach((dropdownHeader,index) => {
            
                let filterTypes = filters[dropdownHeader];
                let parentFilters = filterTypes["filterCriteria"];
                let childFilters = filterTypes["childCriteria"];
                
                parentFilters.forEach((parentFilter,index) => {
                    let parentCategory = { 'key': parentFilter.filterCategory, 'text': parentFilter.filterName, 'value': parentFilter.filterName,'header':dropdownHeader,'category': parentFilter.filterCategory};
                    
                    let parentOptionsList = [];
                    let parentFilterOptions = parentFilter.filterValue;

                    if(parentFilterOptions) {
                        parentFilterOptions.forEach((parentFilterOption,optionIndex) => {
                            let optValue = { 'key': parentFilterOption, 'text': parentFilterOption, 'value': parentFilterOption,'header':dropdownHeader,'category':parentFilter.filterCategory};
                            parentOptionsList.push(optValue);
                            setAllFilters(prevState => [...prevState,optValue]);
                        })
                    }

                    if(parentOptionsList.length > 0) {
                        let keysList = Object.keys(options_dd);
                        
                        if(!keysList.includes(parentFilter.filterName)) {
                            options_dd[parentFilter.filterName] = parentOptionsList;
                        } else {
                            let existingOptions = options_dd[parentFilter.filterName];
                            let diffOptionsInExisting = existingOptions.filter(existingOption => !parentOptionsList.some(currentOption => existingOption.value == currentOption.value));
                            let diffOptionsInCurrent = parentOptionsList.filter(currentOption => !existingOptions.some(existingOption => existingOption.value == currentOption.value));

                            let combinedOptions = [...diffOptionsInExisting, ...diffOptionsInCurrent];
                            
                            if(combinedOptions.length > 0) {
                                options_dd[parentFilter.filterName] = combinedOptions;
                            }
                        }
                    }
                    
                    const searchIndex = categories_dd.findIndex(category => category.value === parentCategory.value);
                    if(searchIndex === -1) {
                        categories_dd.push(parentCategory);
                    }
                });

                childFilters.forEach((childFilter,index) => {
                    let childCategory = { 'key': childFilter.filterCategory, 'text': childFilter.filterName, 'value': childFilter.filterName,'header':dropdownHeader,'childName':childFilter.childName,'category':childFilter.filterCategory};
                    
                    let childOptionsList = [];
                    let childFilterOptions = childFilter.filterValue;

                    if(childFilterOptions) {
                        childFilterOptions.forEach((childFilterOption,optionIndex) => {
                            let optValue = { 'key': childFilterOption, 'text': childFilterOption, 'value': childFilterOption,'header':dropdownHeader,'childName':childFilter.childName,'category':childFilter.filterCategory};
                            childOptionsList.push(optValue);
                            setAllFilters(prevState => [...prevState,optValue]);
                        })
                    }
                    
                    if(childOptionsList.length > 0) {
                        
                        let keysList = Object.keys(options_dd);
                        
                        if(!keysList.includes(childFilter.filterName)) {
                            options_dd[childFilter.filterName] = childOptionsList;
                        }
                    }
                    //options_dd.push(childOptionsList);
                    const searchIndex = categories_dd.findIndex(category => category.value === childCategory.value);
                    if(searchIndex === -1) {
                        categories_dd.push(childCategory);
                    }
                    
                });
                
            })
        }
        setFilterOptions(categories_dd);
        setFilterValues(options_dd);
    }
    
    const handleChange = (e, {value}) => {
        const selectedCategory = value==='' ? null : value;
        let optionIndex = filterOptions.findIndex(item => item.value == selectedCategory);
        setFilterSelected(optionIndex);
        setCategorySelected(selectedCategory);
        setValueSelection(false);
    }

    useEffect(() => {
        if(categorySelected != null && categorySelected != undefined) {
            setFilterData({});
            setValueSelected([]);
        }
    },[categorySelected]);

    const addChild = (result,header,filterCategory,selectedVal) => {
        if(filterData[header] !== undefined) {
            if(Object.keys(filterData[header]).includes(result.childName)) {
                if(Object.keys(filterData[header][result.childName]).includes(filterCategory)) {
                    if(!filterData[header][result.childName][filterCategory].includes(selectedVal)) {
                        
                        let items = filterData[header][result.childName][filterCategory]
                        items.push(selectedVal)
                        let obj = {...filterData[header]}
                        obj[result.childName] = items
                        setFilterData(
                            update(filterData, {
                                $set : {
                                    [header] : obj
                                }
                            })
                        );
                    }
                } else {
                    let obj = {...filterData[header][result.childName]}
                    let childObj = {}
                    childObj[filterCategory] = [selectedVal];

                    let mergedObj = Object.assign(obj,childObj);

                    setFilterData(
                        update(filterData, {
                            $set : {
                                [header] : mergedObj
                            }
                        })
                    );
                }
            } else {
                let obj = {...filterData[header]}
                let childNameObj = {}
                childNameObj[result.childName] = {[filterCategory] : [selectedVal]};

                let mergedObj = Object.assign(obj,childNameObj)
                setFilterData(
                    update(filterData, {
                        $set : {
                            [header] : mergedObj
                        }
                    })
                );
            }
            
        } else {
            let childNameObj = {}
            childNameObj[result.childName] = {[filterCategory] : [selectedVal]};            
            setFilterData(
                update(filterData, {
                        ...filterData,
                        $set : {
                            [header]: childNameObj
                        }                    
                })
            );
        }
    }

    const handleValueChange = (e, {value}) => {
        const values = value;
        let filterCategory = filterOptions[filterSelected].value;
        let body = {};
        if(values.length > 0) {
            const selectedValue = values[0];
            let result = allFilters.find(item => item.value === selectedValue && item.category == filterCategory);
            let header = result.header;
            
            let attributesObj = {};
            attributesObj[filterCategory] = values;

            let filterObj = {}
            
            filterObj[header] = attributesObj;

            setFilterData(filterObj);
            
            if(Object.keys(filterObj).length === 0) {
                body["filters"] = null;
            } else  {
                body["filters"] = filterObj
            }
            getData(body);
            setAppliedFilters(filterObj);
        } else {
            setFilterData({});
            body["filters"] = null;
            getData(body);
        }
        
        setValueSelected(values);
    }

    const addTags = (result,filterCategory,selectedVal) => {
        let tagsData = [];
        let tagsObj = {};

        tagsObj["category"] = filterCategory;
        tagsObj["value"] = selectedVal;
        tagsObj["childName"] = result.childName;
        
        const indexInAllTags = tags.findIndex(tag => tag.category === filterCategory && tag.value === selectedVal);
        const indexInLocalArray = tagsData.findIndex(tag => tag.category === filterCategory && tag.value === selectedVal);
        if(indexInAllTags === -1 && indexInLocalArray === -1) {
            tagsData.push(tagsObj);
        }

        setTags(prevState => [...prevState,...tagsData]);
    }

    const removeTags = (category,val,childName) => {
        let items = {...filterData};
        let headers = Object.keys(items);
        
        headers.map((header) => {
            if(childName != undefined && childName != null) {
                if(Object.keys(items[header][childName]).includes(category)) {
                    let selectedVal = items[header][childName][category].indexOf(val);
                    items[header][childName][category].splice([selectedVal],1);

                    if(items[header][childName][category].length < 1) {
                        delete items[header][childName][category];
                    }
                }
            } else {
                if(Object.keys(items[header]).includes(category)) {
                    let filteredItems = items[header][category].filter(item => item != val);
                    items[header][category] = filteredItems;
                    if(items[header][category].length == 0) {
                        delete items[header][category];
                    }
                }
            }
        })
                
        let tagItems = tags;
        const index = tagItems.findIndex(tag => tag.category === category && tag.value === val);
        tagItems.splice([index],1);
        setTags(tagItems);
        setFilterData(items);
    }
    
    const applyFilter = () => {
        let body = {};
        if(Object.keys(filterData).length === 0) {
            body["filters"] = null;
        } else  {
            body["filters"] = filterData
        }
        getData(body);
    }
    
    return(
    <Grid>
        <Grid.Row columns={1}>
            <Grid.Column width={16} verticalAlign='bottom'>
                <Grid columns={1} verticalAlign='bottom'>
                    <Grid.Column computer={16} tablet={16} mobile={16} textAlign='right' verticalAlign='bottom' style={{paddingRight:"0px"}}>
                        <Dropdown placeholder='Filter By' selection
                                clearable
                                style={Object.assign({width:"130px",marginRight:"1em"},filterDropdownStyle)}
                                options={filterOptions}
                                selectOnBlur={false}
                                onChange={handleChange}
                        />
                        <Dropdown placeholder='Select Value' selection multiple
                                value={valueSelected}
                                options={categorySelected == null ? [] : filterValues[categorySelected]}
                                style={filterDropdownStyle}
                                selectOnBlur={false}
                                onChange={handleValueChange}
                        />
                    </Grid.Column>
                </Grid>
            </Grid.Column>
        </Grid.Row>
    </Grid>
    )
}
export default NoaFilter;