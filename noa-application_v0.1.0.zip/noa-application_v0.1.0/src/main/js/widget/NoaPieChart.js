import React, { useEffect, useState } from 'react';
import { 
    PieChart, Pie, Cell, 
    ResponsiveContainer,Label, Tooltip 
} from 'recharts';

import { cardKeyItem, pieChartLabel } from '../constants'

const NoaPieChart = (props) => {
    const colors = props.colors;
    const labelValue = props.labelValue;
    const renderDetails = props.renderDetails;

    const [data, setData] = useState([]);
    const [styles, setStyles] = useState({});

    useEffect(() => {
        if(props.data != undefined && props.data != null) {
            let dataArray = [];
            const dataObj = props.data;
            let keys = Object.keys(dataObj);
            keys.map((keyValue,index) => {
                let obj = {};
                obj["name"] = keyValue;
                obj["value"] = dataObj[keyValue];
                dataArray.push(obj);
            });
            setData(dataArray);
        }
    },[props.data]);

    useEffect(() => {
        setStyles(props.styles);
    },[props.styles]);

    return (
        <ResponsiveContainer width={"100%"} height={"100%"} minHeight={200}>
            <PieChart
                key={Math.random()}
            >
                <Pie
                    data={data}
                    innerRadius={styles != undefined ? styles.innerRadius : 60}
                    outerRadius={styles != undefined ? styles.outerRadius : 85}
                    dataKey="value"
                    labelLine={false}
                    label={renderDetails ? ({ cx, cy, midAngle, innerRadius, outerRadius, percent, index,name,value }) => {
                        const radius = 25 + innerRadius + (outerRadius - innerRadius);
                        const x = cx + radius * Math.cos(-midAngle * RADIAN);
                        const y = cy + radius * Math.sin(-midAngle * RADIAN);
                      
                        return (
                          <text
                              x={x}
                              y={y}
                              fill="#252525"
                              textAnchor={x > cx ? "start" : "end"}
                              dominantBaseline="central"
                              style={cardKeyItem}
                            >
                                {name} (<tspan fill={colors[index % colors.length]}>{value}</tspan>) 
                            </text>
                        );
                    } : null}
                >
                    {data.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                    ))}
                    <Label width={10} position='center' style={pieChartLabel}>
                        {labelValue}
                    </Label>
                </Pie>
            </PieChart>
        </ResponsiveContainer>
    )
}
const RADIAN = Math.PI / 180;


export default NoaPieChart;