import React, { useEffect, useState } from 'react';
import {
    AreaChart,
    Area,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer
} from "recharts";
import { Grid } from 'semantic-ui-react';

const NoaAreaChart = (props) => {
    const [data, setData] = useState([]);
    const [colors, setColors] = useState({});

    useEffect(() => {
        if (Array.isArray((props.data))) {
            setData(props.data);
        }
    }, [props.data]);

    useEffect(() => {
        setColors(props.colors);
    }, [props.colors]);

    let prefix = 'color';
    const nameGenerator = (item) => {
        let name;
        name = prefix + item
        return name;
    }

    const colorPicker = (item) => {
        let name;
        name = prefix + item
        
        return "url(#" + name + ")";
    }
    return (
        <Grid style={{ padding: "1em" }} >
            <Grid.Row columns={1} >
                <Grid.Column width='16'>
                    <ResponsiveContainer width={"100%"} height={200}>
                        <AreaChart
                            width={500}
                            height={400}
                            data={data}
                            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                            <defs>
                                {Object.keys(colors).map((item, index) => (
                                    <linearGradient key={index} id={nameGenerator(item)} x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor={colors[item]} stopOpacity={0.8} />
                                        <stop offset="95%" stopColor={colors[item]} stopOpacity={0} />
                                    </linearGradient>
                                ))}
                            </defs>

                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" hide />
                            <YAxis hide />
                            <Tooltip />

                            {data.length > 0 ?
                                Object.keys(data[0]).map((item) => (
                                    <Area dataKey={item} stroke={colors[item]} fillOpacity={1} fill={colorPicker(item)} strokeWidth={1}/>
                                ))
                            : ""}
                        </AreaChart>
                    </ResponsiveContainer>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}
export default NoaAreaChart;