import React, { useEffect, useState } from 'react';
import { 
    LineChart, CartesianGrid, Line, 
    ResponsiveContainer, Tooltip
} from 'recharts';

import { Grid } from 'semantic-ui-react';

const NoaLineChart = (props) => {
    const lineType = props.lineType;

    const [data, setData] = useState([]);
    const [colors, setColors] = useState({});

    useEffect(() => {
        if (Array.isArray(props.data)) {
            setData(props.data);
        }
    }, [props.data]);

    useEffect(() => {
        setColors(props.colors);        
    }, [props.colors]);

    return (
        <Grid style={{ padding: "1em" }} >
            <Grid.Row columns={1} >
                <Grid.Column width='16'>
                    <ResponsiveContainer width={"100%"} height={200}>
                        <LineChart width={"100%"} height={200} data={data}>
                            <CartesianGrid strokeDasharray="3 3" />
                            {data.length > 0 ? 
                            Object.keys(data[0]).map((item) => (
                                <Line type={lineType} dataKey={item} stroke={colors[item]} strokeWidth={2} />
                            ))
                            
                            :""}
                            <Tooltip />
                        </LineChart>
                    </ResponsiveContainer>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

export default NoaLineChart;