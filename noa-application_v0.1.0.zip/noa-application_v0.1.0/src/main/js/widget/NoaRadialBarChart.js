import React, { useEffect, useState } from 'react';
import { RadialBarChart, PolarAngleAxis, RadialBar, ResponsiveContainer} from 'recharts';
import { Grid } from 'semantic-ui-react';

import { semiRadialBarText, semiRadialBarLabel, completeHeight } from '../constants'

const NoaRadialBarChart = (props) => {

    const [data, setData] = useState([]);

    useEffect(() => {
        if(Array.isArray(props.data)) {
            setData(props.data);
        }
    },[props.data]);

    const colors = props.colors;

    return (
        <Grid stackable columns={1} style={completeHeight}>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                <ResponsiveContainer width={"100%"} height={120} minWidth={150}>
                    <RadialBarChart
                        innerRadius={65}
                        outerRadius={140}
                        barSize={22}
                        data={data}
                        cy={110}
                        startAngle={180}
                        endAngle={0}
                        key={Math.random()}
                    >
                        <PolarAngleAxis
                            type="number"
                            domain={[0, data[0] != undefined ? data[0].maxValue : 0]}
                            angleAxisId={0}
                            tick={false}
                        />
                        <RadialBar
                            background
                            clockWise
                            dataKey="value"
                            fill={colors}
                            isAnimationActive={true}
                            label={semiRadialBarLabel}
                        />
                    </RadialBarChart>
                </ResponsiveContainer>
                </Grid.Column>      
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} textAlign='center' verticalAlign='middle' >
                    {data.length > 0 ? <p style={Object.assign({textAlign: 'center'},semiRadialBarText)}>{data[0].name}</p> : ""}
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

export default NoaRadialBarChart;