'use strict';
import React,{ useEffect, useState,useContext } from 'react';

import { Menu, Grid,Container} from 'semantic-ui-react'

import 'semantic-ui-css/semantic.min.css';

import { useHistory } from 'react-router';

import { 
    subMenuLayout, completeWidth, fullHeight, 
    menuItemLayout, noMenuBorder, noPadding, 
    titleText, nMenuItem 
} from '../constants';

import { MenuContext } from '../utility/MenuContext';
import { NoaContainer } from './NoaWidgets';

const NoaSubMenu = (props) => {

    const history = useHistory();
    const menuContext = useContext(MenuContext);

    const [displayName, setDisplayName] = useState(null);
    const [options,setOptions] = useState([]);
    
    const [activeItem , setActiveItem] = useState(menuContext.activeItem);
    const [childActiveItem, setChildActiveItem] = useState(null);
    
    const [childMenuOptions, setChildMenuOptions] = useState([]);
    const [hide,setHide] = useState(false);
    const [childMenuVisibility, setChildMenuVisibility] = useState(false);

    useEffect(() => {
        setOptions(menuContext.data);
    },[menuContext.data])

    useEffect(() => {
        setHide(menuContext.hideMenu);
    },[menuContext.hideMenu]);

    useEffect(() => {
        setDisplayName(menuContext.displayText);
    },[menuContext.displayText]);

    useEffect(() => {
        setActiveItem(menuContext.activeItem);
    },[menuContext.activeItem]);

    useEffect(() => {
        if(hide) {
            setChildMenuVisibility(false)
        }
    },[hide]);

    useEffect(() => {
        setChildMenuVisibility(false);        
        setChildActiveItem(null)
    },[menuContext.layout]);

    const handleItemClick = (e,{name}) => {
        const selectedItem = options.find(item => item.name == name);
        let itemIndex = options.findIndex(item => item.name == name);
        
        //menuContext.setActiveItem(itemIndex);
        if(selectedItem.children.length > 0) {
            setChildMenuOptions(selectedItem.children);
            setChildMenuVisibility(true);
        } else {
            setChildMenuVisibility(false);
            history.push({
                pathname: selectedItem.url,
            })
            setChildMenuOptions([]);
        }
        setActiveItem(itemIndex)
        sessionStorage.setItem("subActiveItem", itemIndex);
    };

    const handleChildMenuClick = (e,{name}) => {
        const selIndex = childMenuOptions.findIndex(item => item.name == name);
        const selectedItem = childMenuOptions[selIndex];
        history.push({
            pathname: selectedItem.url,
        });
        setChildActiveItem(selIndex);
    }

    useEffect(() => {
        setChildActiveItem(null);
    },[activeItem]);
    
    return (
        <NoaContainer style={Object.assign({minHeight: "60px"},fullHeight,completeWidth)}>
        <Grid stackable style={fullHeight}>
            <Grid.Row columns={1} style={noPadding} verticalAlign='top'>
                <Grid.Column width={16} verticalAlign='top' style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1} style={{paddingBottom:"0px"}}>
                            <Grid.Column width={16}>
                                <Menu pointing secondary stackable style={subMenuLayout} compact fluid>
                                    <Menu.Item position="left" style={{textAlign: "left",paddingLeft:"0px",display: "flex",justifyContent: "flex-start"}}>
                                        <p style={titleText}>{displayName}</p>   
                                    </Menu.Item>
                                    {hide ? "" : 
                                    options.map((option,index) => {
                                        const IconComponent = option.icon
                                        return(
                                        <Menu.Item index={index} onClick={handleItemClick} name={option.name} active={index == activeItem} 
                                            style={{paddingLeft:"0px",paddingRight:"4em"}}>
                                            {option.icon != undefined ?  <IconComponent /> : ""}
                                            <span style={Object.assign({paddingLeft:"0.3em"},nMenuItem)}>{option.name}</span>
                                        </Menu.Item>
                                        )})
                                    }
                                </Menu>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2} style={Object.assign({minHeight:"50px",zIndex:1},noPadding)}>
                            <Grid.Column width={6}></Grid.Column>
                            <Grid.Column width={10}>
                                {childMenuVisibility ?
                                    <Menu pointing secondary style={noMenuBorder} widths={childMenuOptions.length}>
                                        {childMenuOptions.map((option, index) => {
                                            const IconComponent = option.icon
                                            return (
                                                <Menu.Item index={index} onClick={handleChildMenuClick} name={option.name} active={index == childActiveItem}
                                                style={Object.assign({},menuItemLayout)}>
                                                    {option.icon != undefined ?  <IconComponent /> : ""}
                                                    <span style={Object.assign({paddingLeft:"0.3em"},nMenuItem)}>{option.name}</span>
                                                </Menu.Item>
                                            )
                                        })}   
                                    </Menu>
                                
                                : ""}
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1} style={Object.assign({zIndex:0},fullHeight)} verticalAlign='top'>
                <Grid.Column width={16} style={Object.assign({paddingLeft:"0px",paddingRight:"0px"},fullHeight)}>
                    <Container style={Object.assign({},fullHeight,completeWidth)}>
                        {props.children}
                    </Container>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

export default NoaSubMenu;