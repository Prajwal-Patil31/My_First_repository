import React, { useContext } from 'react';

import { Grid } from 'semantic-ui-react';

import { cardTitleItem, completeWidth } from '../constants';

import { GlobalSpinnerContext } from '../utility/GlobalSpinner';

import { RefreshIcon } from './NoaIcons';
import { NoaContainer } from './NoaWidgets';

const BlankView = (props) => {
    const resource = props.resource;
    const location = props.location;
    const fetchData = props.fetchData;

    const context = useContext(GlobalSpinnerContext);
    return(
        <NoaContainer style={Object.assign({minHeight:"25vh"},completeWidth)} /* id={location} */>
            <Grid centered style={{minHeight:"25vh"}}>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} verticalAlign='middle' textAlign='center'>
                        {context.requestCount == 0 ? 
                        <Grid>
                            <Grid.Row columns={3}>
                                <Grid.Column width={6}></Grid.Column>
                                <Grid.Column width={4} textAlign='center'>
                                    <p style={cardTitleItem}>No {resource} Found</p><br/>
                                </Grid.Column>
                                <Grid.Column width={6}></Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={3}>
                                <Grid.Column width={7}></Grid.Column>
                                <Grid.Column width={2}>
                                    <RefreshIcon handleClick={fetchData} centered={true}/> 
                                </Grid.Column>
                                <Grid.Column width={7}></Grid.Column>
                            </Grid.Row>                        
                        </Grid>
                        : ""}
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
export default BlankView;