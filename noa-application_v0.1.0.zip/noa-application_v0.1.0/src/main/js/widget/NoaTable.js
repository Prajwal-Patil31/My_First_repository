import React, { Fragment, useState } from "react";
import {
	useTable,
	useRowSelect,
	usePagination,
	useSortBy,
	useFilters,
	useGlobalFilter,
	useExpanded
} from "react-table";

import {
	Table,
	Input,
	Grid,
	Button,
	Container,
	Label,
	Icon,
	Pagination,
	Segment,
	Dropdown
} from 'semantic-ui-react';

import { 
	tbButton,noMarginTB, tableSummaryItem,
	noMarginLR, tableHeaderItem, tableBodyItem, 
	noPadding 
} from '../constants';

import 'semantic-ui-css/semantic.min.css';
import BlankView from "./BlankView";

const EditableCell = ({
    value: initialValue,
    row: { index },
    column: { id },
    updateMyData,
  }) => {
    const [value, setValue] = React.useState(initialValue)
  
    const onChange = e => {
	  setValue(e.target.value)
    }
  
    const onBlur = () => {
      	updateMyData(index, id, value)
    }
  
    React.useEffect(() => {
      setValue(initialValue)
    }, [initialValue])

    return <Input value={value} onChange={onChange} onBlur={onBlur} size='mini'/>
}

export default function NoaTable({ columns, data, selectedRows, onSelectedRowsChange, clearSelected, 
									updateMyData,handleAdd, inLineAdd, getRowDetails, getRowID, 
									editableComponentBelow,hidePagination,handlePagination, selectedPageSize,
									totalPages,handlePageSize,totalEntries,resource,fetchData,location
									}) {
	const {
		getTableProps,
		getTableBodyProps,
		headerGroups,
		page,
		prepareRow,
		toggleRowExpanded,
		visibleColumns,
		toggleAllRowsSelected,
		setPageSize,
		state: { selectedRowIds, pageIndex },
	} = useTable(
		{
			columns,
			columns_dd,
			data,
			updateMyData,
			initialState: {
				selectedRowIds: selectedRows,
				pageIndex: 0,
				pageSize: selectedPageSize == undefined ? 10 : selectedPageSize
			},
			autoResetPage: false
		},
		useGlobalFilter,
		useFilters,
		useSortBy,
		useExpanded,
		usePagination,
		useRowSelect
	);
	
	const [editableRow, setEditableRow] = useState(false);
	const [editableId, setEditableId] = useState(null);

	React.useEffect(() => {
		if(clearSelected) {
			toggleAllRowsSelected(false);
		}
	}, [clearSelected]);

	React.useEffect(() => {
		onSelectedRowsChange && onSelectedRowsChange(selectedRowIds);
	}, [onSelectedRowsChange, selectedRowIds]);

	const [columns_dd, setColumns_dd] = useState([]);
	const columns_list = [];
	const [renderAction, setRenderAction] = useState(false);
	const parseColumns = (data) => {
		data.forEach((item, index) => {
			if (item.filterable === true) {
				let column = { 'key': index, 'text': item.Header, 'value': item.accessor };
				columns_list.push(column);
			}
		});
		setColumns_dd(columns_list);
	}

	React.useEffect(() => {
		parseColumns(columns);
	}, columns);

	const handleEditClick =(row) => {
		if(editableComponentBelow) {
			getRowID(row.original);
		} else {
			const id = row.id;
			toggleRowExpanded(row.id,true)
			getRowDetails(row.original);
			setEditableRow(true)
			setEditableId(id);
			setRenderAction(true);
		}
	}

	const addRow = () => {
		if(editableComponentBelow) {
			getRowID();
		}else{
			setEditableRow(true);
        	handleAdd();
		}
	}

	return (
		<Container fluid>
			<Grid style={Object.assign({},noMarginLR,noMarginTB)}>
				<Grid.Row columns={1}>
				<Grid.Column width={16}>
				{inLineAdd ? 
				<Container style={{textAlign: 'right'}}>
					<Button onClick={() => addRow()} style={tbButton}>Add</Button>
				</Container>
				: ""}
				
				<Table {...getTableProps()} basic='very' fixed>
				<Table.Header style={tableHeaderItem}>
					{headerGroups.map(headerGroup => (
						<Table.Row  {...headerGroup.getHeaderGroupProps()}>
						{headerGroup.headers.map((column,index) => (
							<Table.HeaderCell {...column.getHeaderProps({width:"10px"})} width={column.width}>
								{column.render("Header")}
								{column.isSorted
								? column.isSortedDesc
									? <Icon name='sort' style={{ color: "#00bfff" }} />
									: <Icon name='sort' style={{ color: "#00bfff" }} />
							: ''}
							</Table.HeaderCell>
						))}
						</Table.Row>
					))}
				</Table.Header>
				<Table.Body {...getTableBodyProps()} style={tableBodyItem} id={location}>
					{data.length > 0 ? 
						page.map(
							(row, index) => { 
								prepareRow(row); 
								return (
								<Fragment key={row.getRowProps().key}>
								<Table.Row  
									{...row.getRowProps()}
								>
									{row.cells.map(cell => {
										return (
										<Table.Cell {...cell.getCellProps()}>
											{cell.column.editable || cell.column.deletable || cell.column.isBoolean ? 
											(
												cell.column.isBoolean ? (
												<>
												<Label as='a' basic color='blue'>
													{cell.render("Cell")}
												</Label>
												</>)
												: (
												
												cell.column.editable ? (
												cell.row.id == editableId ? (
													editableRow ? cell.render(EditableCell) : cell.render("Cell")
												) : cell.render("Cell")
												) : 
												(
													
												(
													cell.column.deletable ? 
													<>
													<Icon name='edit' onClick={()=>{													
														handleEditClick(cell.row)}}/>
													</>
													: ''
													)
												)
											) ): cell.render("Cell")
											}
										</Table.Cell>
										);
									})}
								</Table.Row>
								</Fragment>
							)}
						)
					: 
					<Table.Row width={1}>
						<Table.Cell colSpan={visibleColumns.length}>
							<Segment basic>
								<BlankView resource={resource} fetchData={fetchData} location={location}/>
							</Segment>
						</Table.Cell>
					</Table.Row>
				}		
				</Table.Body>
				</Table>
				</Grid.Column>
				</Grid.Row>
				{hidePagination ? 
				""
				: 
				<Grid.Row columns={1}>
					<Grid.Column width={16}>
						<Grid columns={3} stackable>
							<Grid.Column width={6}>
							</Grid.Column>
							<Grid.Column width={6} textAlign='center'verticalAlign='middle'>
								{totalPages > 1 ? 
								<Pagination defaultActivePage={pageIndex} 
										totalPages={totalPages}
										ellipsisItem={null}
										prevItem={pageIndex == 0 ? null : {'aria-label': 'Previous item',content: '⟨',}}
										nextItem={pageIndex == totalPages ? null :{'aria-label': 'Next item',content: '⟩',}}
										pointing
										secondary
										style={{borderBottom:"1px solid #D5DFE9"}}
										onPageChange={(e,data) => {
											handlePagination(data.activePage)
										}}
								/>
								: ""}
							</Grid.Column>
							<Grid.Column width={4}>
								<Grid columns={2}>
									<Grid.Column width={8}>
										<Segment style={tableSummaryItem}>
											<Grid columns={1} style={Object.assign({height: "100%"},noMarginLR,noMarginTB)} stackable>
												<Grid.Column width={16} verticalAlign="middle" textAlign='center' style={noPadding}>
													{page.length} of {totalEntries}{' '}results
												</Grid.Column>
											</Grid>
										</Segment>
									</Grid.Column>
									<Grid.Column width={8} verticalAlign='middle' textAlign='left'>
										<span>
											Show {' '}
											<Dropdown
												inline
												options={pageSizes}
												defaultValue={selectedPageSize}
												onChange={(e,{value}) => {
													setPageSize(Number(value))
													handlePageSize(value)
												}}
											/>
										</span>
									</Grid.Column>
								</Grid>
							</Grid.Column>
						</Grid>
					</Grid.Column>
				</Grid.Row>
				}
			</Grid>
			</Container>
	);
}

const pageSizes = [
	{
		key: '5',
		text: '5',
		value: 5,
	},
	{
		key: '10',
		text: '10',
		value: 10,
	},
	{
		key: '15',
		text: '15',
		value: 15,
	},
	{
		key: '20',
		text: '20',
		value: 20,
	},
	{
		key: '25',
		text: '25',
		value: 25,
	}
]