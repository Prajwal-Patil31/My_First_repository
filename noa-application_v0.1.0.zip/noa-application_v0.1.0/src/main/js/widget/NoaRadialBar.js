import React, { useEffect, useState } from 'react';
import { RadialBarChart, PolarAngleAxis, RadialBar, ResponsiveContainer} from 'recharts';
import { Grid } from 'semantic-ui-react';

import { radialBarLabel } from '../constants'

const NoaRadialBar = (props) => {
    const [data, setData] = useState([]);
    const [color, setColor] = useState(null);

    useEffect(() => {
        if(Array.isArray(props.data)) {
            setData(props.data);
        }
    },[props.data]);

    useEffect(() => {
        setColor(props.color);
    },[props.color]);

    return (
        <Grid stackable columns={1}>
            <Grid.Column width={16}>
                <ResponsiveContainer width={"100%"} height={200} minWidth={200}>
                    <RadialBarChart
                        innerRadius={60}
                        outerRadius={60}
                        barSize={18}
                        data={data}
                        startAngle={90}
                        endAngle={-360}
                        key={Math.random()}
                    >
                        <PolarAngleAxis
                            type="number"
                            domain={[0, 100]}
                            angleAxisId={0}
                            tick={false}
                        />
                        <RadialBar
                            background
                            clockWise
                            dataKey="value"
                            fill={color}
                            isAnimationActive={true}
                            label={<CustomLabel />}
                        />
                    </RadialBarChart>
                </ResponsiveContainer>
            </Grid.Column>
        </Grid>
    )
}

const CustomLabel = (props) => {
    const { cx, cy, name } = props;
    return (
        <g>
          <text x={cx-30} y={cy+10} style={radialBarLabel}>
            {name}
          </text>
        </g>
      );
}

export default NoaRadialBar;
