'use strict';
import React, { useEffect, useState } from 'react';
import { Menu, Grid,Transition } from 'semantic-ui-react'
import 'semantic-ui-css/semantic.min.css';

import { useLocation } from "react-router-dom";
import { useHistory } from 'react-router';

import { 
    noPadding, noMarginTB, noMarginLR, 
    nMenuItem, autoHeight, menuOptionsLayout, 
    noMenuBorder, menuItemLayout
} from '../constants';

import '../index.css'

import useOutsideClickAlert from '../utility/useOutsideClickAlert';

const NoaMainMenu = (props) => {
    const options = props.options;

    const history = useHistory();
    const location = useLocation();
    
    const { ref, isClickedOutside } = useOutsideClickAlert(false);

    const [path, setPath] = useState(location.pathname);
    const [activeItem, setActiveItem] = useState(sessionStorage.getItem("mainActiveItem") != null ? sessionStorage.getItem("mainActiveItem"): "Dashboard");
    const [childActiveItem, setChildActiveItem] = useState(0);
    const [menuOptions, setMenuOptions] = useState([]);
    const [submenuVisibility, setSubmenuVisibility] = useState(false);

    useEffect(() => {
        setPath(location.pathname);
        /* const selectedItem = options.find(item => item.url == location.pathname);
        if(selectedItem == undefined) {
            setSubmenuVisibility(false);
        } */
    }, [location.pathname]);

    /* useEffect(() => {
        setSubmenuVisibility(false);
    },[menuContext.layout]); */

    const handleItemClick = (e, { name }) => {
        setActiveItem(name);
        const selectedIndex = options.findIndex(item => item.name == name);
        const selectedItem = options[selectedIndex];
        if(selectedItem != undefined && selectedItem !== null) {
            if (selectedItem.children.length > 0) {
                setMenuOptions(selectedItem.children);
                setSubmenuVisibility(true)
                const subOptions = selectedItem.children
                history.push({
                    pathname: subOptions[0].url,
                })
            } else {
                setSubmenuVisibility(false)
                history.push({
                    pathname: selectedItem.url,
                })
                setMenuOptions([]);
            }
            sessionStorage.setItem("mainActiveItem", name);
        }
    };

    useEffect(() => {
        /* let currentActiveItem = sessionStorage.getItem("mainActiveItem");
        if(currentActiveItem != null) {
            setActiveItem(currentActiveItem);
        } */
        if(path != undefined && path != null) {
            var results = path.split('/');
            
            if(path != "/") {
                let currentIdentifier = results[1];
                const activeIndex = options.findIndex(item => item.identifier == currentIdentifier);
                const selectedItem = options[activeIndex];
                if(selectedItem != undefined) {
                    setActiveItem(selectedItem.name);
                } else {
                    setActiveItem(null);
                }
            } else {
                setActiveItem("Dashboard");
            }
        } else {
            setActiveItem(null)
        }
    },[path]);

    const handleChildMenuClick = (e, { name }) => {
        const selIndex = menuOptions.findIndex(item => item.name == name);
        const selectedItem = menuOptions[selIndex];
        
        history.push({
            pathname: selectedItem.url,
        });
        setSubmenuVisibility(false);
        setChildActiveItem(selIndex);
    }

    useEffect(() => {
        if(submenuVisibility) {
            setChildActiveItem(0);
        }
    },[submenuVisibility]);
    
    useEffect(() => {
		if(isClickedOutside) {
			setSubmenuVisibility(false);
		}
    }, [isClickedOutside])
    
    return (
        <Grid columns={1} style={Object.assign({},autoHeight,noMarginTB,noMarginLR)}>
            <Grid.Column style={noPadding} verticalAlign='top' only="tablet computer" tablet={16} computer={16}>
                <Menu pointing secondary compact fluid widths={options.length} stackable style={noMenuBorder}>
                    {options.map((option, index) => {
                        const IconComponent = option.icon
                        return (
                            <>
                            <Menu.Item index={index} onClick={handleItemClick} name={option.name} active={option.name == activeItem}
                                style={menuItemLayout}>
                                {option.icon != undefined ? <IconComponent /> :""} 
                                <span style={Object.assign({paddingLeft:"0.3em"},nMenuItem)}>{option.name}</span>
                            </Menu.Item>
                            
                            </>
                        )
                    })}
                </Menu>
                
                {submenuVisibility > 0 ?
                    <div className={`transition slide ${submenuVisibility ? "in" : "out"}`}>
                    <Transition.Group
                        animation="slide up"
                        duration={1000}
                        unmountOnHide={true}
                        visible={submenuVisibility}
                    >
                        <div style={menuOptionsLayout} ref={ref}>
                            <Menu pointing secondary stackable style={Object.assign({minWidth:"400px"},noMenuBorder)} compact fluid widths={menuOptions.length}>
                                {menuOptions.map((option, index) => {
                                    const IconComponent = option.icon
                                    return (
                                        <Menu.Item index={index} onClick={handleChildMenuClick} active={index == childActiveItem}
                                                    name={option.name} position="right" style={menuItemLayout}>
                                            {option.icon != undefined ? <IconComponent /> :""} 
                                            <span style={Object.assign({paddingLeft:"0.3em"},nMenuItem)}>{option.name}</span>
                                        </Menu.Item>
                                    )
                                })}   
                            </Menu>
                        </div>
                    </Transition.Group>
                    </div>
                : ""}
            </Grid.Column>
            <Grid.Column style={noPadding} verticalAlign='top' only="mobile" mobile={16}>
                <Menu pointing secondary widths={options.length} stackable style={noMenuBorder}>
                    {options.map((option, index) => {
                        const IconComponent = option.icon
                        return (
                            <>
                            <Menu.Item index={index} onClick={handleItemClick} name={option.name} active={option.name == activeItem}
                                style={{paddingLeft:"0px",paddingRight:"4em"}}>
                                {option.icon != undefined ? <IconComponent /> :""} 
                                <span style={Object.assign({paddingLeft:"0.3em"},nMenuItem)}>{option.name}</span>
                            </Menu.Item>
                            
                            </>
                        )
                    })}
                </Menu>
                
                {submenuVisibility > 0 ?
                    <div className={`transition slide ${submenuVisibility ? "in" : "out"}`}>
                    <Transition.Group
                        animation="slide up"
                        duration={1000}
                        unmountOnHide={true}
                        visible={submenuVisibility}
                    >
                        <div style={menuOptionsLayout}>
                            <Menu pointing secondary stackable style={Object.assign({minWidth:"400px"},noMenuBorder)} compact fluid widths={menuOptions.length}>
                                {menuOptions.map((option, index) => {
                                    const IconComponent = option.icon
                                    return (
                                        <Menu.Item index={index} onClick={handleChildMenuClick} active={index == childActiveItem}
                                                    name={option.name} position="right" style={menuItemLayout}>
                                            {option.icon != undefined ? <IconComponent /> :""} 
                                            <span style={Object.assign({paddingLeft:"0.3em"},nMenuItem)}>{option.name}</span>
                                        </Menu.Item>
                                    )
                                })}   
                            </Menu>
                        </div>
                    </Transition.Group>
                    </div>
                : ""}
            </Grid.Column>
        </Grid>

    )
}
export default NoaMainMenu;
