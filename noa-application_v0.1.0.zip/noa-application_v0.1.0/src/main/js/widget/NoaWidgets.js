import { Button, Container, Header, Menu, Table } from 'semantic-ui-react';
import styled from "styled-components";

export const NoaContainer = styled(Container)`
    background: ${({ theme }) => theme.background}!important;
    color: ${({ theme }) => theme.textsColor}!important;
`
export const MainContainer = styled(Container)`
    margin-left: 8em !important;
    margin-right: 8em !important;
`

export const NoaMenuItem = styled(Menu.Item)`
    color: ${({ theme }) => theme.menuTextsColor}!important;
`
export const NoaMenu = styled(Menu)`
    background: ${({ theme }) => theme.menuColor}!important;
`
export const NoaHeader = styled(Header)`
    color: ${({ theme }) => theme.textsColor}!important;
`
export const NoaButton = styled(Button)`
    background: ${({ theme }) => theme.buttonBg}!important;
    color: ${({ theme }) => theme.buttonTextColor}!important;
    padding: '0 !important';
	borderRadius: '24px';
	paddingTop: '10px';
	paddingBottom: '10px';
	paddingRight: '12px';
	paddingLeft: '12px';
`;
export const NoaStyledTable = styled(Table)`
    background: ${({ theme }) => theme.background}!important;
    color: ${({ theme }) => theme.textsColor}!important;
`;

export const NoaTableHeader = styled(Table.HeaderCell)`
    background: ${({ theme }) => theme.background}!important;
    color: ${({ theme }) => theme.textsColor}!important;
`;