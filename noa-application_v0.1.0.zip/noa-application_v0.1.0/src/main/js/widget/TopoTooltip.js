import React from 'react';

import { Divider, Grid, Segment,Icon, Label } from 'semantic-ui-react';

import { 
    tooltipHeading, tooltipValue, noMarginLR, 
    noMarginTB, noPadding, completeHeight,
    tooltipTitle, dividerStyle, completeWidth
} from '../constants';
import { NoaContainer } from './NoaWidgets';

const LinkTooltip = (props) => {
    const linkDetails = props.data;
    return(
        
        <Grid style={{height:"360px",width:"350px",overflowY:"auto",marginTop:"1em",marginBottom:"1em"}} className="content">
            <Grid.Row columns={1} style={noPadding} style={{paddingLeft:"1em",paddingRight:"1em"}}>
                <Grid.Column width={16} textAlign='left'>
                    <p style={tooltipTitle}>Link Details</p>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={{paddingLeft:"1em",paddingRight:"1em"}}>
                <Grid.Column width={16} id="tooltip-link">
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2}>
                                    <Grid.Column width={8}>
                                        <p style={tooltipHeading}>Link Name</p><br/>
                                        <p style={tooltipValue}>{linkDetails.name}</p>
                                    </Grid.Column>
                                    <Grid.Column width={8}>
                                        <p style={tooltipHeading}>Link Type</p><br/>
                                        <p style={tooltipValue}>{linkDetails.type}</p>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2}>
                                    <Grid.Column width={8}>
                                        <p style={tooltipHeading}>Src Element</p><br/>
                                        <p style={tooltipValue}>{linkDetails.source}</p>
                                    </Grid.Column>
                                    <Grid.Column width={8}>
                                        <p style={tooltipHeading}>Dest Element</p><br/>
                                        <p style={tooltipValue}>{linkDetails.target}</p>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2}>
                                    <Grid.Column width={8}>
                                        <p style={tooltipHeading}>Src Interface</p><br/>
                                        <p style={tooltipValue}>{linkDetails.sourceInterface}</p>
                                    </Grid.Column>
                                    <Grid.Column width={8}>
                                        <p style={tooltipHeading}>Dest Interface</p><br/>
                                        <p style={tooltipValue}>{linkDetails.destinationInterface}</p>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                                <Grid columns={2} stackable>
                                    <Grid.Column width={8} textAlign='left'>
                                        <p style={tooltipHeading}>Status</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='right'>
                                        <Segment style={{borderRadius: "20px"}}>
                                            <Grid columns={1} style={Object.assign({},completeHeight,noMarginLR,noMarginTB)} stackable>
                                                <Grid.Column width={16} verticalAlign="middle" textAlign='center' style={noPadding}>
                                                    {linkDetails.status ? 
                                                    <span style={Object.assign({color: "green"},tooltipValue)}>Forwarding</span>
                                                    : 
                                                    <span style={Object.assign({color: "red"},tooltipValue)}>Halted</span>
                                                    }
                                                </Grid.Column>
                                            </Grid>
                                        </Segment>
                                    </Grid.Column>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const NodeTooltip = (props) => {
    const nodeDetails = props.data;
    return(
    <Grid style={{height: "360px",width: "350px",overflowY:"auto",marginTop:"1em",marginBottom:"1em"}} className="content">
        <Grid.Row columns={1} style={{paddingLeft:"1em",paddingRight:"1em",paddingBottom:"0px"}}>
            <Grid.Column width={16} textAlign='left'>
                <p style={tooltipTitle}>Element Details</p>
            </Grid.Column>
        </Grid.Row>
        <Divider style={dividerStyle}/>
        <Grid.Row columns={1} style={{paddingLeft:"1em",paddingRight:"1em"}}>
            <Grid.Column width={16} id="tooltip-node">
                <Grid>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={2}>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Name</p><br/>
                                    <p style={tooltipValue}>{nodeDetails.deviceName}</p>
                                </Grid.Column>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>IP Address</p><br/>
                                    <p style={tooltipValue}>{nodeDetails.host}</p>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={2}>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Status</p><br/>
                                    <Label basic color={nodeDetails.elementStatus == true ? "green" : "red"}>
                                        {nodeDetails.elementStatus == true ? "Enabled" : "Disabled"}
                                    </Label>
                                </Grid.Column>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Forward State</p><br/>
                                    <Label basic color={nodeDetails.forwardingStatus == "up" ? "green" : "red"}>
                                        {nodeDetails.forwardingStatus == "up" ? "Enabled" : "Disabled"}
                                    </Label>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={2} relaxed>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Uptime</p><br/>
                                    <p style={tooltipValue}>24Hrs</p>
                                </Grid.Column>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Location</p><br/>
                                    <p style={tooltipValue}>16.49, 80.6542</p>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={2} relaxed>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Manufacturer</p><br/>
                                    <p style={tooltipValue}>{nodeDetails.vendor}</p>
                                </Grid.Column>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Port</p><br/>
                                    <p style={tooltipValue}>{nodeDetails.port}</p>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={2} relaxed>
                                <Grid.Column width={8}>
                                    <p style={tooltipHeading}>Software Version</p><br/>
                                    <p style={tooltipValue}>{nodeDetails.softwareVersion}</p>
                                </Grid.Column>
                                <Grid.Column width={8}>
                                <p style={tooltipHeading}>Hardware Version</p><br/>
                                    <p style={tooltipValue}>{nodeDetails.hardwareVersion}</p>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={1}>
                        <Grid.Column width={16}>
                            <Grid columns={2} stackable relaxed>
                                <Grid.Column width={8} textAlign='left' style={tooltipHeading}>
                                    Faults
                                </Grid.Column>
                                <Grid.Column width={8} textAlign='right'>
                                    <Segment.Group horizontal>
                                        <Segment textAlign='center' style={Object.assign({color: "red"},tooltipValue)}>
                                            12
                                        </Segment>  
                                        <Segment textAlign='center' style={Object.assign({color: "orange"},tooltipValue)}>
                                            8
                                        </Segment>  
                                        <Segment textAlign='center' style={Object.assign({color: "yellow"},tooltipValue)}>
                                            6
                                        </Segment>  
                                        <Segment textAlign='center' style={Object.assign({color: "skyblue"},tooltipValue)}>
                                            13
                                        </Segment>
                                    </Segment.Group>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                </Grid>
            </Grid.Column>
        </Grid.Row>
    </Grid>
    )
}
export {LinkTooltip,NodeTooltip};