/**@module Footer */

'use strict';
import React from 'react';

import { Grid } from 'semantic-ui-react'

import { noMarginTB, footerText } from '../constants'

import 'semantic-ui-css/semantic.min.css';
import { NoaContainer, NoaHeader } from './NoaWidgets';

/**
 * Component to Render a Footer at the Bottom of the page.
 * 
 * @class
 * @augments React.Component
*/
class Footer extends React.Component {
	constructor(props) {
		super(props);
	}

	/**
     * Renders Footer view .
	 * 
    */
	render() {
		return (
			<NoaContainer style={{height: "64px"}}>
				<Grid style={Object.assign({}, noMarginTB)} columns={1} textAlign='center' verticalAlign='middle'>
					<Grid.Column width={16} verticalAlign="middle" textAlign="center">
						<NoaHeader  verticalAlign='middle' style={footerText}>
							Copyright (C) 2021 NOA Platform - United Telecoms. All Rights Reserved.
						</NoaHeader>
					</Grid.Column>
				</Grid>
			</NoaContainer>
			
		)
	}
}

export default Footer;