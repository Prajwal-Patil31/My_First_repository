/**@module BreadCrumb */

'use strict';
import React,{ Fragment } from 'react';

import { Breadcrumb, Grid} from 'semantic-ui-react'

import 'semantic-ui-css/semantic.min.css';
import { useHistory } from 'react-router-dom';

import { useLocation } from 'react-router-dom';
import { noBoxShadow,noMarginTB, breadCrumbItem, completeWidth } from '../constants';
import {NoaContainer} from '../widget/NoaWidgets';
import { HomeIcon } from './NoaIcons';

/**
 * Renders a BreadCrumb component after getting Location. 
 * Gets location using useLocation() hook.
 * 
 * @returns {jsx} Rendered BreadCrumb.
*/
const BreadCrumb = (props) => {
	let location = useLocation();
	const path = location.pathname;
	const results = path.split('/');
	
	const history = useHistory();

	let redirectPath = {
		pathname:'/'
	}
	
	const handleRedirect = (currentIndex) => {
		let rootPath = redirectPath.pathname;
		if(currentIndex != null) {
			results.map((item,index) => {
				if(item != null && item !="") {
					if(index <= currentIndex) {
						rootPath = rootPath + item + "/"
					}
				}
			})
		}
		history.push({
			pathname: rootPath
		})
	}

	return(
		<NoaContainer style={completeWidth}>
		<Grid style={Object.assign({},completeWidth,noBoxShadow, noMarginTB)} columns={2} stackable verticalAlign='middle'>
			<Grid.Column width={8} textAlign='left' style={{paddingLeft:"0px"}}>
				<Breadcrumb data-testid="location-display" size={"large"}>
					<Breadcrumb.Section style={breadCrumbItem} /* link onClick={() => handleRedirect(null)} */ as={HomeIcon}></Breadcrumb.Section>
					<Breadcrumb.Divider style={{color:"#252525"}}/>
					{results.map((result,index) => (
						result != null && result != ""? 
						<Fragment>
							<Breadcrumb.Section /* onClick={() => handleRedirect(index)} */ style={Object.assign({textIndent:"5px"},breadCrumbItem)}>
								{result}
								<Breadcrumb.Divider/>
							</Breadcrumb.Section>
						</Fragment>
						: ''
					))}
				</Breadcrumb>
			</Grid.Column>
			<Grid.Column width={8} textAlign='left' verticalAlign='middle'>
			</Grid.Column>
		</Grid>
		</NoaContainer>
	)
}

export default BreadCrumb;