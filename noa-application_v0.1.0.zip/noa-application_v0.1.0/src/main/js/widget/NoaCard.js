import React from 'react';

import { Grid, Segment } from 'semantic-ui-react';
import { 
    cardDurationItem, cardTitleItem, noMarginTB,
    noMarginLR, cardLayout, noPadding, 
    completeHeight, completeWidth 
} from '../constants';

import { NoaContainer } from './NoaWidgets';

const NoaCard = (props) => {
    const title = props.title;
    const DurationComponent = props.durationComponent;
    const renderDuration = props.renderDuration;

    return (
        <Segment style={Object.assign({},cardLayout)}>
        <NoaContainer style={Object.assign({},completeWidth,completeHeight)} id="test">
            <Grid stackable style={Object.assign({},completeHeight,noMarginTB,noMarginLR)}>
                {title != null && title != undefined ? 
                <Grid.Row columns={2} verticalAlign='top' style={noPadding}>
                    <Grid.Column width={8} textAlign="left" verticalAlign="top">   
                        <p style={cardTitleItem}>{title}</p>
                    </Grid.Column>
                </Grid.Row>
                : ""}
                <Grid.Row columns={1}>
                    <Grid.Column width={16} textAlign='center'>
                        {props.children}
                    </Grid.Column>
                </Grid.Row>
                {renderDuration ? 
                <Grid.Row columns={1} verticalAlign='bottom' style={noPadding}>
                    <Grid.Column width={16}>
                        {DurationComponent != null ? <DurationComponent />:
                            <Grid columns={2}>
                                <Grid.Column width={8}>
                                    <p style={Object.assign({textAlign: "left"},cardDurationItem)}>
                                        {new Date().toLocaleString()}
                                    </p>   
                                </Grid.Column>
                            </Grid>
                        }
                    </Grid.Column>
                </Grid.Row>
                : ""}
            </Grid>
        </NoaContainer>
        </Segment>
    )

}
export default NoaCard;