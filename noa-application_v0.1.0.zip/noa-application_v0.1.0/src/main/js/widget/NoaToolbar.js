import React, { useContext, useState } from 'react';
import { Button, Grid, Modal } from 'semantic-ui-react';
import { 
    applyButton, cancelButton, completeHeight, 
    noMarginLR, noMarginTB, noPadding, 
    toolBarStyle 
} from '../constants';

import { NoaContainer } from './NoaWidgets';

import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { AddIcon, DeleteIcon } from './NoaIcons';

const NoaToolbar = (props) => {
    const context = useContext(GlobalSpinnerContext);
    
    const invokeAdd = props.invokeAdd;
    const deleteMethod = props.deleteMethod;
    const selectedRows = props.selectedRows;
    const clearSelection = props.clearSelection;

    const [showModal, setShowModal] = useState(false);

	const closeModal = () => {
        setShowModal(false);
    }

    const handleDelete = () => {
        deleteMethod(selectedRows);
        closeModal();
    }

    
    const openModal = () => {
        setShowModal(true);
    }

    return(
        <NoaContainer style={Object.assign({minWidth:"100px"},toolBarStyle)}>
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16} style={{paddingLeft:"2.1em",paddingTop:"0.5em"}}>
                    <Grid columns={1}>
                        <Grid.Column width={16}>
                        <Grid columns={2} style={Object.assign({},completeHeight, noMarginLR,noMarginTB)}>
                            <Grid.Column width={8} verticalAlign='middle'style={noPadding}>
                                <AddIcon handleClick={invokeAdd}/>
                            </Grid.Column>
                            <Grid.Column width={8} verticalAlign="middle" style={noPadding}>
                                <Modal dimmer='inverted' open={showModal} onClose={closeModal}
                                    trigger={
                                        <DeleteIcon handleClick={openModal} disabled={selectedRows.length == 0 ? true : false}/>
                                    }>
                                    <Modal.Content>
                                        <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} id="delete-component">
                                                <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                            <p>Are you sure you want to delete?</p>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    <Grid.Row></Grid.Row>
                                                    <Grid.Row columns={2}>
                                                        <Grid.Column width={10}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='right'>
                                                            <Button style={applyButton} onClick={() => {
                                                                context.setRenderLocation(['delete-component'])
                                                                handleDelete()
                                                            }}>Yes</Button>
                                                            <Button style={cancelButton} onClick={closeModal}>No</Button>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        </Grid>
                                    </Modal.Content>
                                </Modal>
                            </Grid.Column>
                        </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

export default NoaToolbar;