import { Notification } from 'rsuite';

export default function noaNotification(funcName, description) {
    Notification[funcName]({
        title: funcName,
        description: description
    });
}