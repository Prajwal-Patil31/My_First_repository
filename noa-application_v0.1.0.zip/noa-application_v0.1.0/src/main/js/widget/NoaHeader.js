'use strict';
import React, { useEffect, useState, useContext } from 'react';
import { AuthContext } from '../utility/AuthContext';

import {
	Grid,
	Image,
	Menu,
	Container,
	Dropdown,
	Popup,
	Divider,
	Icon
} from 'semantic-ui-react'

import 'semantic-ui-css/semantic.min.css';

import { 
	noPadding, noBoxShadow, noMarginTB, 
	noMarginLR, completeWidth, toolbarItem, 
	dividerStyle 
} from '../constants'

import NoaClient from '../utility/NoaClient';
import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { NotificationContext } from '../utility/NotificationContext';

import { RouteRediretContext } from '../utility/RouteRedirect';
import { GlobalThemeContext } from '../utility/GlobalThemeContext';
import { useHistory } from "react-router";
import NoaMainMenu from './NoaMainMenu';
import {NoaContainer} from './NoaWidgets';

import { 
	DashboardIcon, TopologyIcon, FaultsIcon, 
	ElementsIcon, NetworksIcon, ServiceIcon,
	SettingsIcon, SearchbarIcon, ProfileIcon, 
	NotificationIcon,InventoryIcon, DiscoveryIcon, 
	ServiceListIcon, CatalogueIcon, StatusIcon, 
	RbacIcon, LogoutIcon, SecurityIcon, 
	ConfMgmtIcon, TaskIcon
} from './NoaIcons';


const NoaHeader = (props) => {
	const [notifications, setNotifications] = useState([]);
	const [notifCount, setNotifCount] = useState(0);
	const [alertVisibility, setAlertVisibility] = useState(false);

	const spinnerContext = useContext(GlobalSpinnerContext);
	const routeRedirectContext = useContext(RouteRediretContext);
	const context = useContext(NotificationContext);
	const themeContext = useContext(GlobalThemeContext);
	const authContext = useContext(AuthContext);

	const history = useHistory();
	
	useEffect(() => {
		NoaClient(spinnerContext, routeRedirectContext);
	},[]);

	const getNotifications = () => {
		NoaClient.get(
            "/api/global/event/new",
            (response) => {
				let responseData = response.data;
				if(responseData) {
					setNotifications(responseData);
				}
            }
        )
	}

	useEffect(() => {
		let notifArray = context.notificationObjects;
		if(notifArray.length > 0) {
			setNotifications(notifArray);
		}
	},[context.notificationObjects])
	
	useEffect(() => {
		if(notifications.length >0) {
			setNotifCount(notifications.length);
			setAlertVisibility(true);
		}
	},[notifications]);

	const handleSelection = (selectedItem) => {
		sessionStorage.setItem("mainActiveItem", null);
		history.push({
			pathname: selectedItem.url,
		})
	}

	const redirectToHome = () => {
		history.push({
			pathname: `/`,
		})
	}

	const changeTheme = themeContext.changeTheme
	return (
		
		<NoaContainer style={Object.assign({},completeWidth,noBoxShadow,noPadding)}>
			<Grid style={Object.assign({})} columns={3} stackable>
				<Grid.Column style={{paddingLeft:"0px",paddingRight:"0px"}} textAlign='left' verticalAlign='bottom' computer={2} tablet={16} mobile={16}>
					<Image size={"medium"} style={{width:"160px",cursor: "pointer"}} src="/images/unoa-l.png" onClick={redirectToHome}/>
				</Grid.Column>
				<Grid.Column style={{paddingRight:"0px",zIndex:2}} verticalAlign='bottom' computer={12} tablet={16} mobile={16} textAlign='center'>
					<NoaMainMenu options={mainMenuItems}/>
				</Grid.Column>
				<Grid.Column style={{zIndex:1}}computer={2} verticalAlign='bottom' textAlign='right' tablet={16} mobile={16}>
				
					<Grid columns={1} style={Object.assign({}, noBoxShadow, noPadding,noMarginTB,noMarginLR)}>
					<Grid.Column width={16} verticalAlign='bottom' style={noPadding}>
						<NoaContainer style={{textAlign:'right'},completeWidth}>
						<Menu borderless compact style={Object.assign({}, noBoxShadow)} fluid widths={4} size='large'>
							<Menu.Item>
							<Dropdown icon={SettingsIcon} style={toolbarItem} selectOnBlur={false}>
								<Dropdown.Menu>
									{securityMenuItems.map((item,index) => {
										const IconComponent = item.icon;
										return (
										<Dropdown.Item onClick={() => handleSelection(item)}>
											{item.icon != undefined ? <IconComponent /> :""}
											<span>{item.text}</span>
										</Dropdown.Item>
										)
									})}
									{/* <Dropdown.Item onClick={changeTheme}>Change Theme</Dropdown.Item> */}
								</Dropdown.Menu>
							</Dropdown>
							</Menu.Item>
							<Menu.Item>
								<Dropdown icon={SearchbarIcon} style={toolbarItem} selectOnBlur={false}/>
							</Menu.Item>
							
							<Menu.Item>
								<Dropdown icon={NotificationIcon} style={toolbarItem} selectOnBlur={false}/>
								{/* <NotificationLayout notifications={notifications}
													getNotifications={getNotifications}
													setAlertVisibility={setAlertVisibility}
													alertVisibility={alertVisibility}
								/> */}
							</Menu.Item>
							<Menu.Item>
								<Dropdown icon={ProfileIcon} style={toolbarItem}>
									<Dropdown.Menu>
										<Dropdown.Item onClick={() => {
											sessionStorage.setItem("mainActiveItem", null);
											history.push({
												pathname: `/User/Profile`
											})
										}}>
											<ProfileIcon/>
											User Profile
										</Dropdown.Item>
										<Dropdown.Item  onClick={() => {
											let url = authContext.isAuth ? `/logout`: `/login`
											history.push({
												pathname: url
											})
											}}
										>{authContext.isAuth ? 
										<>
										<LogoutIcon />
										Logout
										</> : 
										<>Login</>}</Dropdown.Item>
									</Dropdown.Menu>
								</Dropdown>
							</Menu.Item>
						</Menu>
						</NoaContainer>
					</Grid.Column>
					</Grid>
				</Grid.Column>
			</Grid>
		</NoaContainer>
	)
}

const mainMenuItems = [
	{ key: 'dashboard', name: 'Dashboard',url:"/",children : [],icon: DashboardIcon},
	{ key: 'topology', name: 'Topology',url:"/Topology",children : [],icon: TopologyIcon,identifier:"Topology"},
	{ key: 'faults&events', name: 'Alarms',url:"/Faults",children : [],icon: FaultsIcon,identifier:"Faults"},
	{ key: 'elements', name: 'Elements',children : [
		{key: 'inventory', name: 'Inventory',url:"/Elements",icon: InventoryIcon},
		{key: 'discovery', name: 'Discovery',url:"/Elements/Discovery",icon: DiscoveryIcon}
	],icon: ElementsIcon,identifier:"Elements"},
	{ key: 'networks', name: 'Networks',url:"/Networks",children : [],icon:NetworksIcon,identifier:"Networks"},
	{ key: 'services', name: 'Services',url:"/Services",children : [
		{key: 'service-list', name: 'Instances',url:"/Services",icon:ServiceListIcon},
		{key: 'catalog', name: 'Catalog',url:"/Services/Catalog",icon:CatalogueIcon}
	],icon:ServiceIcon,identifier:"Services"}  
]

const securityMenuItems = [
	{ key: 'system-status',text: 'System Status',value:"system-status",url:"/Platform/System/Status",icon: StatusIcon},
	{ key: 'rbac',text: 'RBAC',value:"rbac",url:"/Platform/RBAC/User",icon: "shield",icon: RbacIcon},
	{ key: 'security-management',text: 'Security Management',value:"security-management",url:"/Platform/Security/Policy/Password",icon:SecurityIcon},
	{ key: 'configuration-management',text: 'Configuration Management',value:"configuration-management",url:"/Platform/Configuration/Rollback",icon: ConfMgmtIcon},
	{ key: 'task-scheduling',text: 'Task Scheduling',value:"task-scheduling",url:"/Platform/Task/Scheduling",icon:TaskIcon},
]

const NotificationLayout = (props) => {
	const getNotifications = props.getNotifications;
	const notifications = props.notifications;
	const alertVisibility = props.alertVisibility;
	const setAlertVisibility = props.setAlertVisibility;

	const [open, setOpen] = useState(false);

	const handleClick = () => {
		setAlertVisibility(false);
		getNotifications();
		setOpen(!open);
	}

	return (
		<Popup
			on='click'
			//className={`transition slide ${open ? "in" : "out"}`}
			trigger={
				<span textAlign='right' item>
					<Icon.Group size='large'>
						<NotificationIcon clickMethod={handleClick}/>
						{alertVisibility ? <Icon corner='top right' name='circle'></Icon> : ""}
					</Icon.Group>
				</span>
			}
			position='bottom center'
		>
			<GlobalNotifications getNotifications={getNotifications} notifications={notifications}
				/>
			{/* <Transition.Group
				animation="slide up"
				duration={1000}
				unmountOnHide={true}
				visible={open}
			>
				<div>
				
				</div>
				
			</Transition.Group> */}
		</Popup>
	)
}

const GlobalNotifications = (props) => {
	const getNotifications = props.getNotifications;
	const notifications = props.notifications;

	const acknowledgeAllEvents = () => {
		if(notifications.length > 0) {
			NoaClient.post(
				"/api/global/event",
				notifications,
				(response) => {
					getNotifications();
			});
		} else {
			alert("No Notifications to Acknowledge");
		}
	}

	const acknowledgeEvent = (notification) => {
		let body = [notification];
		NoaClient.post(
			"/api/global/event",
			body,
			(response) => {
				getNotifications();
		});
		
	}

	const clearAllEvents = () => {
		if(notifications.length > 0) {
			NoaClient.delete(
				"/api/global/event",
				notifications,
				(response) => {
					getNotifications();
			});
		} else {
			alert("No Notifications to Clear");
		}
	}

	return (
		<Grid>
		<Grid.Row style={noPadding}>
			<Grid.Column>
				<Grid columns={1}>
					<Grid.Column width={16}>
					<Grid>
						<Grid.Row style={{borderBottom: "0.1px solid"}}>
							<Grid.Column>	
							<Grid columns={3}>
								<Grid.Column width={5}textAlign='left'>
								</Grid.Column>
								<Grid.Column width={11} textAlign='right'>
									{/* {visibility ? 
										<p onClick={acknowledgeAllEvents} 
											style={{cursor: "pointer", fontSize: "4"}}>
												Acknowledge All
										</p>
									: ""} */}
									{/* <Grid columns={2}>
										<Grid.Column width={6}>
										
										</Grid.Column>
										<Grid.Column width={5}>
											<Icon name="options">Options</Icon>
										</Grid.Column>
									</Grid> */}
								</Grid.Column>
							</Grid>
							</Grid.Column>
						</Grid.Row>
						<Grid.Row style={{borderBottom: "0.5px solid", height:"250px",overflowY: "scroll"}}>
							<Grid.Column>
								<Grid>
								<Grid.Row columns={1}>
									<Grid.Column width={16}>
									{notifications != undefined && notifications.length > 0 ?
									notifications.map((notification,index) => (
										<Container key={index} style={{width: "350px"}}>
											<Grid columns={2}>
												<Grid.Column width={13}>
													<Container /* onClick={() => acknowledgeEvent(notification)} */>
														<p>{notification.description}</p>
														<p>Severity: {notification.severity}</p>
														<p>Count: {notification.count}</p>
														<p>Time: {notification.timeStamp}</p>
													</Container>
												</Grid.Column>
												<Grid.Column width={3} verticalAlign='middle'>
													<Icon name='delete' link onClick={() => acknowledgeEvent(notification)}/>
												</Grid.Column>
											</Grid>
											<Divider style={dividerStyle}/>
										</Container>
									))
									: "No Notifications"}
									</Grid.Column>
								</Grid.Row>
								</Grid>
							</Grid.Column>
						</Grid.Row>
						<Grid.Row>
							<Grid.Column>	
							<Grid columns={3}>
								<Grid.Column width={5}textAlign='left'>
								</Grid.Column>
								<Grid.Column width={8}textAlign='left' verticalAlign="middle">
								<p onClick={acknowledgeAllEvents} style={{cursor: "pointer"}}>Acknowledge All</p>
								</Grid.Column>
								<Grid.Column width={3} textAlign='right'>
								</Grid.Column>
							</Grid>
							</Grid.Column>
						</Grid.Row>
						</Grid>
					</Grid.Column>
				</Grid>
			</Grid.Column>
		</Grid.Row>
		</Grid>
	)
}

NoaHeader.contextType = GlobalSpinnerContext;

export default NoaHeader;