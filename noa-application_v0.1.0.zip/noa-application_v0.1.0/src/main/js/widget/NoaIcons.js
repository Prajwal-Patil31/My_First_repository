import React from 'react';
import { Icon, Image } from 'semantic-ui-react';

import arrowBackIcon from '../../resources/static/icons/arow-back.svg';

import homeLine from '../../resources/static/icons/home-line.svg';

import dashboardLine from '../../resources/static/icons/dashboard-line.svg';
import topologyLine from '../../resources/static/icons/topology-line.svg';
import faultLine from '../../resources/static/icons/fault-line.svg';
import elementLine from '../../resources/static/icons/element-line.svg';
import networkLine from '../../resources/static/icons/network-line.svg';
import serviceLine from '../../resources/static/icons/service-line.svg';

import settingsLine from '../../resources/static/icons/settings-line.svg';
import searchLine from '../../resources/static/icons/search-line.svg';
import notificationLine from '../../resources/static/icons/notification-line.svg';
import logoutLine from '../../resources/static/icons/logout-line.svg';
import loginLine from '../../resources/static/icons/login-line.svg';

import discoveryLine from '../../resources/static/icons/discovery-line.svg';
import inventoryLine from '../../resources/static/icons/inventory-line.svg';

import serviceListLine from '../../resources/static/icons/servicelist-line.svg';
import catalogueLine from '../../resources/static/icons/catalogue-line.svg';

import generalLine from '../../resources/static/icons/general-line.svg';
import bridgeLine from '../../resources/static/icons/bridge-line.svg';
import interfaceLine from '../../resources/static/icons/interface-line.svg';
import mplsLine from '../../resources/static/icons/mpls-line.svg';
import routingLine from '../../resources/static/icons/routing-line.svg';
import resourceLine from '../../resources/static/icons/resource-line.svg';

import summaryLine from '../../resources/static/icons/summary-line.svg';
import statLine from '../../resources/static/icons/stat-line.svg';
import connectionLine from '../../resources/static/icons/connectivity-line.svg';

import statusLine from '../../resources/static/icons/status-line.svg';
import rbacLine from '../../resources/static/icons/rbac-line.svg';
import securityLine from '../../resources/static/icons/security-line.svg';
import confMgmtLine from '../../resources/static/icons/confmgmt-line.svg';
import taskLine from '../../resources/static/icons/task-line.svg';

import groupLine from '../../resources/static/icons/group-line.svg';
import roleLine from '../../resources/static/icons/role-line.svg';

import sessionLine from '../../resources/static/icons/session-line.svg';
import auditLogLine from '../../resources/static/icons/auditlog-line.svg';
import ppolicyLine from '../../resources/static/icons/ppolicy-line.svg';

import refreshLine from '../../resources/static/icons/refresh-line.svg';
import loaderLine from '../../resources/static/icons/loader-line.svg';
import performanceLine from '../../resources/static/icons/performance-line.svg';
import userLine from '../../resources/static/icons/user-line.svg';

import addLine from '../../resources/static/icons/add-line.svg';
import deleteLine from '../../resources/static/icons/delete-line.svg';

import eventsLine from '../../resources/static/icons/event-line.svg';
import fpolicyLine from '../../resources/static/icons/fpolicy-line.svg';
//Main Menu
export const DashboardIcon = (props) => {
    return(
        <Image src={dashboardLine}/>
    )
}

export const TopologyIcon = (props) => {
    return(
        <Image src={topologyLine}/>
    )
}

export const FaultsIcon = (props) => {
    return(
        <Image src={faultLine}/>
    )
}

export const ElementsIcon = (props) => {
    return(
        <Image src={elementLine}/>
    )
}

export const NetworksIcon = (props) => {
    return(
        <Image src={networkLine}/>
    )
}

export const ServiceIcon = (props) => {
    return(
        <Image src={serviceLine}/>
    )
}

//Breadcrumb
export const HomeIcon = (props) => {
    return(
        <Image src={homeLine} style={{display:"inline",paddingBottom:"5px"}}/>
    )
}

//Main Toolbar
export const SettingsIcon = (props) => {
    return(
        <Image src={settingsLine}/>
    )
}

export const SearchbarIcon = (props) => {
    return(
        <Image src={searchLine}/>
    )
}

export const NotificationIcon = (props) => {
    const clickMethod = props.clickMethod;
    return(
        <Image src={notificationLine} onClick={clickMethod} style={{cursor:"pointer"}}/>
    )
}

export const ProfileIcon = (props) => {
    return(
        <Image src={userLine}/>
    )
}


//Element Menu Options
export const InventoryIcon = (props) => {
    return(
        <Image src={inventoryLine}/>
    )
}

export const DiscoveryIcon = (props) => {
    return(
        <Image src={discoveryLine}/>
    )
}


//Service Menu Options
export const ServiceListIcon = (props) => {
    return(
        <Image src={serviceListLine}/>
    )
}

export const CatalogueIcon = (props) => {
    return(
        <Image src={catalogueLine}/>
    )
}


//Toolbar Menu

export const StatusIcon = (props) => {
    return(
        <Image src={statusLine}/>
    )
}

export const RbacIcon = (props) => {
    return(
        <Image src={rbacLine}/>
    )
}

export const SecurityIcon = (props) => {
    return(
        <Image src={securityLine} />
    )
}

export const ConfMgmtIcon = (props) => {
    return(
        <Image src={confMgmtLine} />
    )
}
export const TaskIcon = (props) => {
    return(
        <Image src={taskLine} />
    )
}
export const LoginIcon = (props) => {
    return(
        <Image src={loginLine}/>
    )
}

export const LogoutIcon = (props) => {
    return(
        <Image src={logoutLine}/>
    )
}


//Sub Menu:
export const SummaryIcon = (props) => {
    return(
        <Image src={summaryLine}/>
    )
}

export const ConnectivityIcon = (props) => {
    return(
        <Image src={connectionLine}/>
    )
}

export const StatIcon = (props) => {
    return(
        <Image src={statLine}/>
    )
}

//Element 3rd Level Menu Options

export const GeneralIcon = (props) => {
    return(
        <Image src={generalLine} />
    )
}

export const ResourcesIcon = (props) => {
    return(
        <Image src={resourceLine}/>
    )
}

export const InterfaceIcon = (props) => {
    return(
        <Image src={interfaceLine} />
    )
}

export const BridgeIcon = (props) => {
    return(
        <Image src={bridgeLine} />
    )
}

export const RoutingIcon = (props) => {
    return(
        <Image src={routingLine} />
    )
}

export const MplsIcon = (props) => {
    return(
        <Image src={mplsLine} />
    )
}

//RBAC Layout
export const RoleIcon = (props) => {
    return(
        <Image src={roleLine} />
    )
}

export const GroupIcon = (props) => {
    return(
        <Image src={groupLine} />
    )
}

//Security Layout
export const SessionIcon = (props) => {
    return(
        <Image src={sessionLine} />
    )
}

export const AuditLogIcon = (props) => {
    return(
        <Image src={auditLogLine} />
    )
}

export const PPolicyIcon = (props) => {
    return(
        <Image src={ppolicyLine} />
    )
}

//Others:
export const RefreshIcon = (props) => {
    const handleClick = props.handleClick
    const centered = props.centered;
    return(
        <Image src={refreshLine} onClick={handleClick} style={{cursor:"pointer"}} centered={centered}/>
    )
}
export const PerformanceIcon = (props) => {
    return(
        <Image src={performanceLine} />
    )
}

export const AddIcon = (props) => {
    const handleClick = props.handleClick
    return(
        <Image src={addLine} style={{cursor:"pointer"}} onClick={handleClick}/>
    )
}

export const DeleteIcon = (props) => {
    const handleClick = props.handleClick;
    const disabled = props.disabled;
    return(
        <Image src={deleteLine} style={{cursor:"pointer"}} onClick={() => {
            if(!disabled) {
                handleClick()
            }
        }} disabled={disabled}/>
    )
}

export const EventsIcon = (props) => {
    return(
        <Image src={eventsLine}/>
    )
}

export const FPolicyIcon = (props) => {
    return(
        <Image src={fpolicyLine} />
    )
}

export const PreviousIcon = (props) => {
    const invokeMethod = props.invokeMethod
    return(
        <Image src={arrowBackIcon} onClick={invokeMethod}/>
    )
}

export const DropdownIcon = (props) => {
    return(
        <Icon name='dropdown' />
    )
}
