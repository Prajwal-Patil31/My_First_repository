import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../widget/NoaTable';
import { withRouter,Link } from 'react-router-dom';

import {
    Grid,
    Segment,
    Button,
    Divider,
    Checkbox,
    Icon,
    Input,
    Dropdown,
    Label
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding,noMarginTB, 
    noMarginLR, titleText, cardLayout,
    formTitle,formParameter, completeHeight, 
    completeWidth, overviewStyle, tablePadding, 
    cancelButton, applyButton, fullHeight, 
    formHeader, tableHeaderHeight, dividerStyle, 
    inputBoxStyle, formContentSpacingTB, formSpacingTB, 
    dropdownStyle
} from '../constants';

import NoaClient from '../utility/NoaClient';

import { GlobalSpinnerContext } from '../utility/GlobalSpinner';
import { RouteRediretContext } from '../utility/RouteRedirect';
import NoaFilter from '../widget/NoaFilter';

import { NoaHeader, NoaContainer} from '../widget/NoaWidgets';

import NoaRadialBarChart from '../widget/NoaRadialBarChart';
import NoaRadialBar from '../widget/NoaRadialBar';
import NoaCard from '../widget/NoaCard';
import NoaToolbar from '../widget/NoaToolbar';
import { UIView, useRouter } from '@uirouter/react';
import { MenuContext } from '../utility/MenuContext';
import noaNotification from '../widget/NoaNotification';

const pieChartColors = ["#903749", "#543864","#750550","#21325E"];

const NetworkManager = (props) => {
    const [networks, setNetworks] = useState([]);
    const [networkSummary, setNetworkSummary] = useState({});

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);
    
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const menuContext = useContext(MenuContext);
    
    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = networks[sel[i]].networkId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getNetworks = (paginationObj) => {
        context.setRenderLocation(["networks-list"]);
        NoaClient.post(
            "/api/network",
            paginationObj,
            (response) => {
                let responseData = response.data;
                setNetworks(responseData.data);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/network/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    const getActiveNetworks = () => {
        NoaClient.get(
            "/api/network/overview",
            (response) => {
                let responseData = response.data;
                setNetworkSummary(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        getActiveNetworks();
        let filterCriteria = {};
        filterCriteria["filters"] = {"ietf-network":{}};
        filterCriteria["pagination"] = null;
        filterCriteria["sort"] = null;
        getNetworks(filterCriteria);
        menuContext.setHideMenu(true);
        menuContext.setDisplayText("Network List");
        router.stateService.go('default');
    },[]);

    return (
        <NoaContainer style={Object.assign({}, fullHeight,completeWidth)}>
        <Grid style={Object.assign({},fullHeight)}>
            <Grid.Row columns={1} style={{maxHeight: "100vh"}}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NetworkOverview data={networkSummary}/>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16} verticalAlign='top'>
                    <Segment style={Object.assign({minHeight: "100vh"},cardLayout)}>
                        <NetworkTable 
                            networks={networks}
                            columns={columns}
                            getNetworks={getNetworks}
                            filters={filters}
                            setSelected={setSelected}
                            clearSelected={clearSelected}
                            setClearSelected={setClearSelected}                                  
                            selectedRows={selectedRows}
                            pageSize={pageSize}
                            totalPages={totalPages}
                            setPageSize={setPageSize}
                            totalEntries={totalEntries}
                        />
                    </Segment>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const NetworkOverview = (props) => {
    const data = props.data;

    return(
        <NoaContainer style={completeWidth}>
        <Grid>
            <Grid.Row columns={1} stretched style={overviewStyle}>
                <Grid.Column width={16} id="network-overview">
                    <NoaCard title={"Active Networks"} renderDuration={false}>
                        <NoaContainer style={Object.assign({paddingLeft: "1.5em", paddingRight: "1.5em"},completeWidth)}>
                        {Object.keys(data).length > 0 ? 
                            <Grid columns={2} stackable>
                                <Grid.Column computer={4} tablet={16} mobile={16}>
                                    <NoaRadialBar data={data["summary"]} color={"#007EFF"}/>
                                </Grid.Column>
                                <Grid.Column computer={12} tablet={16} mobile={16}>
                                    <Grid columns={3} stackable>
                                        {data["detailed"].map((summaryData,index) => (
                                            <Grid.Column computer={index == 1 ? 6 : 5} tablet={index == 1 ? 6 : 5} mobile={16}>
                                                <NoaRadialBarChart data={summaryData} colors={pieChartColors[index]}/>
                                            </Grid.Column>
                                        ))}
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                        :""}
                        </NoaContainer>
                    </NoaCard>
                </Grid.Column>                
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const NetworkTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;

    const networks = props.networks;
    const selectedRows = props.selectedRows;
    const getNetworks = props.getNetworks;
    const filters = props.filters;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const setClearSelected = props.setClearSelected;
    //const columns = props.columns;

	const [selections, setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"ietf-network" : {}});

	useEffect(() => {
		setSelected(selections);
    }, [selections]);
    
    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width:1
        },
        {
            label: "8",
            Header: "Network Name",
            Cell: ({row}) => {
                let networkId = row.original.networkId;
                let networkName = row.original.networkName;
                let networkType = row.original.networkType;

                const toNetworkInstance = { 
                    pathname: `/Networks/${networkName}`,
                }
                return <Link to={toNetworkInstance} onClick={() => {
                    sessionStorage.setItem("networkId",networkId);
                    sessionStorage.setItem("networkName",networkName);
                    sessionStorage.setItem("networkType",networkType);
                }}>{networkName}</Link>
            },
            width:2
        },
		{
			label: "2",
			Header: "Network Type",
            accessor: "networkType",
            width:2
		},
        {
			label: "4",
			Header: "Support Network",
            accessor: "supportNetworksCount",
            width:2
		},
        {
			label: "5",
			Header: "Link Type",
            accessor: "linkType",
            width:2
        },
        {
			label: "6",
			Header: "Link Rate",
            accessor: "linkRate",
            width:2
        },
        {
			label: "7",
			Header: "External",
            accessor: "external",
            width:2
        },
        {
			label: "8",
			Header: "Shared",
            accessor: "shared",
            width:1
        },
        {
            label: "8",
            Header: "Admin Status",
            Cell: ({row}) => (
                renderBoolean(row,"adminStatus",false)
            ),
            width:1
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"networkStatus",true)
            ),
            width:1
        }
    ]

    const handleAddNetwork = () => {
        router.stateService.go("add-network",{fetchData: fetchData, clearSelection: clearSelection})
    }
    
    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["networks-list"]);
        
        NoaClient.delete(
            "/api/network/",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getNetworks(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"ietf-network" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getNetworks(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getNetworks(filterObj)
    }

    const fetchData = () => fetchFilteredData({"filters":null})
    
	if (!networks && !networks.length)
		return null;

    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Network List</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddNetwork}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={networks}
                                columns={columns}
                                selectedRows={selections}
                                onSelectedRowsChange={setSelections}
                                clearSelected={clearSelected}
                                selectedPageSize={pageSize}
                                handlePagination={handlePagination}
                                totalPages={totalPages}
                                handlePageSize={handlePageSize}
                                totalEntries={totalEntries}
                                resource="Networks" 
                                fetchData={fetchData} 
                                location="networks-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    );
}

const renderBoolean = (row,key,operational) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            operational ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' /> : 
            <Label basic color={'green'}>
                Enabled
            </Label>
            : 
            operational ?
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' /> :
            <Label basic color={'red'}>
                Disabled
            </Label>
        }
       </>
    )
}

const AddNetwork = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const fetchData = props.fetchData;
    const clearSelection = props.clearSelection;
    const router = useRouter();

    const [network, setNetwork] = useState({});
    
    const [networks,setNetworks] = useState([]);
    
    const [elements, setElements] = useState([]);
    const [selectedElements, setSelectedElements] = useState([]);

    const [supportingNetworks, setSupportingNetworks] = useState([]);
    const [selectedBaseNetworks, setSelectedBaseNetworks] = useState([]);
    
    const networkTypes = [
        { 'key': "L1 Network", 'text': "L1 Network", 'value': "L1 Network" },
        { 'key': "L2 Network", 'text': "L2 Network", 'value': "L2 Network" },
        { 'key': "L2.5 Network", 'text': "L2.5 Network", 'value': "L2.5 Network" },
        { 'key': "L3 Network", 'text': "L3 Network", 'value': "L3 Network" }
    ]
    
    useEffect(() => {
        context.setRenderLocation(["add-network"]);
        getNetworks();
        getElements();
    },[]);

    const getNetworks = () => {
        NoaClient.get(
            "/api/network/",
            (response) => {
                let responseData = response.data;
                setNetworks(responseData);
            }
        )
    }

    const getElements = () => {
        NoaClient.get(
            "/api/element/",
            (response) => {
                let responseData = response.data;
                let elementsList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let elementObj = {'key' : item.deviceId, 'value' : item.deviceId, 'text': item.deviceName}
                        elementsList[index] = elementObj;
                    })
                }
                setElements(elementsList);
            }
        )
    }

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const handleAdd = () => {
        let body = network;
        body['supportNetworksCount'] = selectedBaseNetworks.length;
        
        NoaClient.put(
            "/api/network/",
            network,
            (response) => {
                const network = response.data;
                noaNotification('success','Network Created Successfully');
                closeFooter();
                fetchData();
                if(selectedElements.length > 0) {
                    handleAddNodes(network.networkId,selectedElements);
                }
                if(selectedBaseNetworks.length > 0) {
                    handleAddSupportNetworks(network.networkId);
                }
            }
        )
    }

    const handleAddNodes = (networkId,selectedElements) => {
        NoaClient.put(
            "/api/network/" + networkId + "/node",
            selectedElements,
            (response) => {
                noaNotification('success','Nodes Added to Network')
            }
        )
    }

    const handleAddSupportNetworks = (networkId) => {
        NoaClient.put(
            "/api/network/" + networkId + "/l-network",
            selectedBaseNetworks,
            (response) => {
            }
        )
    }

    useEffect(() => {
        getSupportingNetworks();
    },[network.networkType]);

    const getSupportingNetworks = () => {
        let parsedL1 = [];
        switch (network.networkType) {
            case "L2 Network":
                let l1Networks = networks.filter(networkObj => networkObj.networkType === "L1 Network");
                if(Array.isArray(l1Networks)) {
                    l1Networks.map((item,index) => {
                        let networkObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        parsedL1.push(networkObj);
                    })
                }
                setSupportingNetworks(parsedL1);
                break;
            case "L2.5 Network":
                let networkList = networks.filter(networkObj => networkObj.networkType === "L1 Network");
                if(Array.isArray(networkList)) {
                    networkList.map((item,index) => {
                        let networkObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        parsedL1.push(networkObj);
                    })
                }
                setSupportingNetworks(parsedL1);
                break;
            case "L3 Network":
                let l2Networks = networks.filter(networkObj => networkObj.networkType === "L2 Network");
                let parsedL2 = [];
                if(Array.isArray(l2Networks)) {
                    l2Networks.map((item,index) => {
                        let networkObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        parsedL2.push(networkObj);
                    })
                }
                setSupportingNetworks(parsedL2);
                break;
            default:
                break;
        }
    }

    const handleInput = (value, key) => {
		setNetwork(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create Network</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-network">
                <Grid columns={3} stackable>
                    <Grid.Column width={3}></Grid.Column>
                    <Grid.Column width={10} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}> 
                            <Grid columns={2} stackable>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} textAlign='center'>
                                        <p style={formHeader}>Network Parameters</p>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1} style={formSpacingTB}>
                                    <Grid.Column width={16}>
                                        <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Name</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Input type='text' name='networkName' 
                                                        value={network.networkName}
                                                        fluid={false}
                                                        onChange={
                                                            (e, {value}) => handleInput(value==='' ? null : value, 'networkName')
                                                        }>
                                                            <input style={inputBoxStyle}></input>
                                                    </Input>
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>

                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Type</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required
                                                            placeholder="Network Type"
                                                            value={network.networkType ? network.networkType : ''}
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            options={networkTypes} 
                                                            onChange={(e,{value}) => handleInput(value==='' ? null : value,'networkType')}
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Base Networks</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required multiple
                                                            placeholder="Select Networks"
                                                            options={supportingNetworks}
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            disabled={network.networkType =="L1 Network" ? true : false}
                                                            onChange={
                                                                (e, {value}) => {
                                                                    const networkIds = value==='' ? [] : value;
                                                                    setSelectedBaseNetworks(networkIds)
                                                                }
                                                            }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                            <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} textAlign='center'>
                                        <p style={formHeader}>Network Elements</p>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={1} style={formSpacingTB}>
                                    <Grid.Column width={16}>
                                        <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                            <Grid columns={4} stackable>
                                                <Grid.Column width={3}></Grid.Column>
                                                <Grid.Column width={4} textAlign='left'>
                                                    <p style={formParameter} className="required">Elements</p>
                                                </Grid.Column>
                                                <Grid.Column width={6} textAlign='left'>
                                                    <Dropdown clearable selection required multiple
                                                            placeholder="Select Elements"
                                                            selectOnBlur={false}
                                                            style={dropdownStyle}
                                                            options={elements}
                                                            onChange={
                                                                (e, {value}) => {
                                                                    const elementIds = value==='' ? [] : value;
                                                                    setSelectedElements(elementIds)
                                                                }
                                                            }
                                                    />
                                                </Grid.Column>
                                                <Grid.Column width={3}></Grid.Column>
                                            </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                        </Grid>
                                    </Grid.Column>
                                </Grid.Row>
                            </Grid>
                            </Grid.Column>
                        </Grid>
                        </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={3}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                context.setRenderLocation(["add-network"]);
                                handleAdd()
                            }}>Add</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}
export default withRouter(NetworkManager);
export {AddNetwork};