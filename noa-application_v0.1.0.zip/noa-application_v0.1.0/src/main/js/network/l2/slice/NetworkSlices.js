import React, { Fragment, useContext, useEffect, useState } from 'react';
import NoaTable from '../Widgets/NoaTable';
import BreadCrumb from '../Widgets/BreadCrumb';
import { withRouter,useHistory } from 'react-router-dom';

import {
    Grid,
    Segment,
    Button,
    Header,
    Divider,
    Form,
    Checkbox,
    Container,
    Modal,
    Popup,
    Dropdown,
    Step,
    Icon
} from 'semantic-ui-react';

import { noBoxShadow, tbButton, gridScroll, noPadding, noMarginTB, noMarginLR, titleText, cardLayout} from '../../constants';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';
import NoaFilter from '../Widgets/NoaFilter';
import { CSSTransition, TransitionGroup } from "react-transition-group";
import styled,{useTheme} from "styled-components";
import { MenuContext } from '../Widgets/MenuContext';
import { NoaButton,NoaHeader, NoaContainer} from '../Widgets/NoaWidgets';
import NoaRadialBarChart from '../Widgets/NoaRadialBarChart';
import NoaCard from '../Widgets/NoaCard';

const NetworkSlices = (props) => {
    return(
        <div></div>
    )
}
export default NetworkSlices;