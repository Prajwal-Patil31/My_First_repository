import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../widget/NoaTable';

import {
    Grid,
    Divider,
    Input,
    Icon,
    Dropdown,
    Button,
    Checkbox,
    Segment
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, noMarginTB, 
    noMarginLR, titleText, cardLayout, 
    formHeader, formParameter, formTitle, 
    completeHeight, completeWidth, applyButton, 
    cancelButton, tablePadding, fullHeight, 
    tableHeaderHeight, dividerStyle, formContentSpacingTB, 
    formSpacingTB, inputBoxStyle, dropdownStyle
} from '../../constants';

import { NoaHeader, NoaContainer} from '../../widget/NoaWidgets';
import NoaClient from '../../utility/NoaClient';
import NoaFilter from '../../widget/NoaFilter';
import NoaToolbar from '../../widget/NoaToolbar';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../widget/NoaNotification';

const NetworkLspManager = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const networkId = sessionStorage.getItem("networkId");

    const [lsps,setLsps] = useState([]);
    
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router = useRouter();
    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = lsps[sel[i]].lspId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getLsps = (filterObj) => {
        setLsps([]);
        context.setRenderLocation(["lsp-list"]);
        NoaClient.post(
            "/api/network/" + networkId + "/lsp",
            filterObj,
            (response) => {
                let responseData = response.data;
                setLsps(responseData.data)
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        context.setRenderLocation(["lsp-list"]);
        
        NoaClient.get(
            "/api/network/" + networkId + "/lsp/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"ietf-network":{"network-id" : [networkId],lsp : {}}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getLsps(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={fullHeight}>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16}>
                <Segment style={Object.assign({minHeight:"100vh"}, cardLayout)}>
                    <NetworkLspTable 
                        lsps={lsps}
                        getLsps={getLsps}
                        columns={columns}
                        filters={filters}
                        networkId={networkId}
                        setSelected={setSelected}
                        clearSelected={clearSelected}
                        selectedRows={selectedRows}
                        setClearSelected={setClearSelected}
                        pageSize={pageSize}
                        totalPages={totalPages}
                        setPageSize={setPageSize}
                        totalEntries={totalEntries}
                    />
                </Segment>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const NetworkLspTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);
    
    const lsps = props.lsps;
    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;

    //const columns = props.columns;
    const filters = props.filters;

    const networkId = props.networkId;
    const getLsps = props.getLsps;
    
    const setClearSelected = props.setClearSelected;
    const selectedRows = props.selectedRows;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    
    const [selections, setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"ietf-network" : {"network-id":[networkId],lsp:{}}});
    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
        {
			label: "2",
			Header: "LSP Name",
            accessor: "lspName",
            width: 2
		},
		{
			label: "3",
			Header: "Source Element",
            accessor: "sourceElement",
            width: 2
		},
        {
			label: "4",
			Header: "Source Interface",
            accessor: "sourceInterface",
            width: 2
		},
        {
			label: "5",
			Header: "Destination Element",
            accessor: "destinationElement",
            width: 2
        },
        {
			label: "6",
			Header: "Destination Interface",
            accessor: "destinationInterface",
            width: 2
        },
        {
			label: "7",
			Header: "Tunnel ID",
            accessor: "tunnelId",
            width: 2
        },
        {
			label: "8",
			Header: "Admin Status",
			Cell: ({row}) => (
                renderBoolean(row,"adminStatus")
            ),
            width: 2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"lspStatus")
            ),
            width: 1
        }
    ]

    const handleAddLsp = () => {
        router.stateService.go("add-lsp",{networkId:networkId,fetchData:fetchData,clearSelection: clearSelection})
    }

    useEffect(() => {
        setSelected(selections);
    }, [selections]);
    
    

    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["lsp-list"]);

        NoaClient.delete(
            "/api/network/" + networkId + "/lsp",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getLsps(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"ietf-network" : {"network-id":[networkId],lsp:{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getLsps(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getLsps(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Network Lsps</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddLsp}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={lsps}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="LSPs" 
                        fetchData={fetchData} 
                        location="lsp-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddLsp = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const fetchData = props.fetchData;
    const clearSelection = props.clearSelection;
    const networkId = props.networkId;

    const router = useRouter();

    const [lsp, setLsp] = useState({});
    
    const [baseNetworks, setBaseNetworks] = useState([]);
    const [srcNetwork, setSrcNetwork] = useState(null);
    const [destNetwork, setDestNetwork] = useState(null);

    const [srcElements, setSrcElements] = useState([]);
    const [destElements, setDestElements] = useState([]);
    const [srcElement, setSrcElement] = useState(null);
    const [destElement, setDestElement] = useState(null);

    const [srcInterfaces, setSrcInterfaces] = useState([]);
    const [destInterfaces, setDestInterfaces] = useState([]);
    const [srcInterface, setSrcInterface] = useState(null);
    const [destInterface, setDestInterface] = useState(null);
    
    useEffect(() => {
        context.setRenderLocation(["add-lsp"]);
        getBaseNetworks()
    },[]);

    const closeFooter = () => {
        router.stateService.go('default');
    }
    const getBaseNetworks = () => {
        let filter = {
            "filters" : {
                "ietf-network" : {
                    "network-type" : ["L2.5 Network"]
                }
            }
        }

        NoaClient.post(
            "/api/network",
            filter,
            (response) => {
                let responseData = response.data;
                let baseNetworksList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        baseNetworksList[index] = nodeObj;
                    })
                }
                setBaseNetworks(baseNetworksList);
            }
        )
    }

    useEffect(() => {
        if(srcNetwork != null) {
            getSrcElements();
        }
    },[srcNetwork]);

    const getSrcElements = () => {
        NoaClient.get(
            "/api/network/" + srcNetwork + "/node",
            (response) => {
                let responseData = response.data;
                let nodesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.nodeId, 'value' : item.nodeName, 'text': item.nodeName}
                        nodesList[index] = nodeObj;
                    })
                }
                setSrcElements(nodesList);
            }
        )
    }

    useEffect(() => {
        if(srcElement != null) {
            getSrcInterfaces();
        }
    },[srcElement]);
    
    const getSrcInterfaces = () => {
        const srcNode = srcElements.find(node => node.text === srcElement);

        let elementId = srcNode.key
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceName, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setSrcInterfaces(interfacesList);
            }
        )
    }

    useEffect(() => {
        if(destNetwork != null) {
            if(destNetwork === srcNetwork) {
                let nodes = srcElements.filter(node => node.text !== srcElement);
                setDestElements(nodes);
            } else {
                getDestElements();
            }
        }
    },[destNetwork]);

    const getDestElements = () => {
        NoaClient.get(
            "/api/network/" + destNetwork + "/node",
            (response) => {
                let responseData = response.data;
                let nodesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.nodeId, 'value' : item.nodeName, 'text': item.nodeName}
                        nodesList[index] = nodeObj;
                    })
                }
                setDestElements(nodesList);
            }
        )
    }

    useEffect(() => {
        if(destElement != null) {
            getDestInterfaces();
        }
    },[destElement]);
    
    const getDestInterfaces = () => {
        const destNode = destElements.find(node => node.text === destElement);
        let elementId = destNode.key
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.interfaceId, 'value' : item.interfaceName, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setDestInterfaces(interfacesList);
            }
        )
    }

    useEffect(() => {
        if(destInterface != null) {
            checkLspExistence();
        }
    },[destInterface]);

    const checkLspExistence = () => {
        let obj = {}
        obj["sourceElement"] = srcElement;
        obj["sourceInterface"] = srcInterface;
        obj["destinationElement"] = destElement;
        obj["destinationInterface"] = destInterface;

        if(srcElement != null && destElement != null && srcInterface != null) {
            NoaClient.post(
                "/api/network/" + networkId + "/lsp",
                obj,
                (response) => {
                    let responseData = response.data;
                    if(responseData) {
                        setDestInterface(null);
                        alert("LSP Already Exists");
                    }
                }
            )
        }
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/network/" + networkId + "/lsp",
            lsp,
            (response) => {
                noaNotification('success','LSP Created Successfully');          
                fetchData();
            }
        )
    }

    const handleInput = (value, key) => {
		setLsp(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({width:"100%"}, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Create LSP</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1} style={formContentSpacingTB}>
                <Grid.Column width={16} id="add-lsp">
                <Grid columns={3} stackable>
                    <Grid.Column width={2}></Grid.Column>
                    <Grid.Column width={12} style={noPadding}>
                    <Grid>
                        <Grid.Row columns={2}>
                            <Grid.Column width={8}>
                                <Grid>
                                    <Grid.Row columns={1}>
                                        <Grid.Column width={16} textAlign='center'>
                                            <p style={formHeader}>LSP Parameters</p>
                                        </Grid.Column>
                                    </Grid.Row>
                                    <Grid.Row columns={1} style={formSpacingTB}>
                                        <Grid.Column width={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter} className="required">LSP Name</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Input type='text' name='lspName' 
                                                            value={lsp.lspName}
                                                            fluid={false}
                                                            onChange={
                                                                (e, {value}) => handleInput(value==='' ? null : value, 'lspName')
                                                            }>
                                                                <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>

                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16}>
                                                <Grid columns={4} stackable>
                                                    <Grid.Column width={3}></Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <p style={formParameter} className="required">Admin Status</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={6} textAlign='left'>
                                                        <Checkbox
                                                            toggle={true}
                                                            value={lsp.adminStatus}
                                                            onChange={
                                                                (e,data)=>handleInput(data.checked, 'adminStatus')
                                                            }
                                                        />
                                                    </Grid.Column>
                                                    <Grid.Column width={3}></Grid.Column>
                                                </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                            </Grid>
                                        </Grid.Column>
                                    </Grid.Row>
                                </Grid>
                            </Grid.Column>
                            <Grid.Column width={8}></Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={1}>
                            <Grid.Column width={16}>
                            <Grid columns={2} stackable>
                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Source Parameters</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1} style={formSpacingTB}>
                                            <Grid.Column width={16}>
                                                <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter}>Select Base Network</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Src Network"
                                                                    selectOnBlur={false}
                                                                    options={baseNetworks}
                                                                    style={dropdownStyle}
                                                                    onChange={(e,{value}) => setSrcNetwork(value==='' ? null : value)}
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter} className="required">Source Element</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Src Element"
                                                                    options={srcElements}
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    onChange={(e,{value}) => {
                                                                        let srcEle = value==='' ? null : value
                                                                        let key = 'sourceElement'
                                                                        setSrcElement(srcEle);
                                                                        setLsp(prevState => ({
                                                                            ...prevState,
                                                                            [key]: srcEle
                                                                        }));
                                                                    }}
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>


                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={2}></Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <p style={formParameter} className="required">Source Endpoint</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Src Endpoint"
                                                                    options={srcInterfaces}
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    onChange={(e,{value}) => {
                                                                        let srcEp = value==='' ? null : value
                                                                        let key = 'sourceInterface'
                                                                        setSrcInterface(srcEp);
                                                                        setLsp(prevState => ({
                                                                            ...prevState,
                                                                            [key]: srcEp
                                                                        }));
                                                                    }}
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={2}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>

                                <Grid.Column computer={8} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Destination Parameters</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1} style={formSpacingTB}>
                                            <Grid.Column width={16}>
                                                <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter}>Select Base Network</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Dest Network"
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    options={baseNetworks} 
                                                                    onChange={(e,{value}) => setDestNetwork(value==='' ? null : value)}
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Destination Element</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Dest Element"
                                                                    options={destElements}
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    onChange={(e,{value}) => {
                                                                        let destEle = value==='' ? null : value
                                                                        let key = 'destinationElement'
                                                                        setDestElement(destEle);
                                                                        setLsp(prevState => ({
                                                                            ...prevState,
                                                                            [key]: destEle
                                                                        }));
                                                                    }}
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Destination Endpoint</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Dest Endpoint"
                                                                    options={destElements}
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    onChange={(e,{value}) => {
                                                                        let destEp = value==='' ? null : value
                                                                        let key = 'destinationInterface'
                                                                        setDestInterface(destEp);
                                                                        setLsp(prevState => ({
                                                                            ...prevState,
                                                                            [key]: destEp
                                                                        }));
                                                                    }}
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    <Grid.Column width={2}></Grid.Column>
                </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton} onClick={() => {
                                handleAdd()
                                context.setRenderLocation(["add-lsp"]);
                            }}>Add</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}
const duplexTypes = [
    {
        key: 'full',
        text: 'Full',
        value: 'full',
    },
    {
        key: 'half',
        text: 'Half',
        value: 'half',
    }
];
export default NetworkLspManager;
export {AddLsp};