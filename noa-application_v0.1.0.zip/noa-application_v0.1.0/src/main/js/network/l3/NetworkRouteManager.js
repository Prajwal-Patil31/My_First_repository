import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../widget/NoaTable';

import {
    Grid,
    Divider,
    Input,
    Icon,
    Dropdown,
    Button,
    Checkbox,
    Segment
} from 'semantic-ui-react';

import { 
    noBoxShadow, noPadding, noMarginTB, 
    noMarginLR, titleText, cardLayout, 
    formHeader, formParameter, formTitle, 
    completeHeight, completeWidth, applyButton, 
    cancelButton, tablePadding, fullHeight, 
    tableHeaderHeight, dividerStyle, formSpacingTB, 
    formContentSpacingTB, inputBoxStyle, dropdownStyle
} from '../../constants';

import { NoaHeader, NoaContainer} from '../../widget/NoaWidgets';
import NoaClient from '../../utility/NoaClient';
import NoaFilter from '../../widget/NoaFilter';
import NoaToolbar from '../../widget/NoaToolbar';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { UIView, useRouter } from '@uirouter/react';
import noaNotification from '../../widget/NoaNotification';

const NetworkRouteManager = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const networkId = sessionStorage.getItem("networkId");

    const [routes,setRoutes] = useState([]);
    
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const router =useRouter();

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = routes[sel[i]].routeId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getRoutes = (filterObj) => {
        setRoutes([]);
        context.setRenderLocation(["route-list"]);
        NoaClient.post(
            "/api/network/" + networkId + "/route",
            filterObj,
            (response) => {
                let responseData = response.data;
                setRoutes(responseData.data)
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        context.setRenderLocation(["route-list"]);
        
        NoaClient.get(
            "/api/network/" + networkId + "/route/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        getFilterCriteria();
        router.stateService.go('default');

        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"ietf-network":{"network-id" : [networkId],route : {}}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getRoutes(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
        <Grid style={fullHeight}>
            <Grid.Row columns={1} style={fullHeight}>
                <Grid.Column width={16}>
                <Segment style={Object.assign({minHeight:"100vh"}, cardLayout)}>
                    <NetworkRouteTable 
                        routes={routes}
                        getRoutes={getRoutes}
                        columns={columns}
                        filters={filters}
                        networkId={networkId}
                        setSelected={setSelected}
                        clearSelected={clearSelected}
                        selectedRows={selectedRows}
                        setClearSelected={setClearSelected}
                        pageSize={pageSize}
                        totalPages={totalPages}
                        setPageSize={setPageSize}
                        totalEntries={totalEntries}
                    />
                </Segment>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const NetworkRouteTable = (props) => {
    const router = useRouter();
    const context = useContext(GlobalSpinnerContext);

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;

    //const columns = props.columns;
    const filters = props.filters;

    const routes = props.routes;
    const networkId = props.networkId;
    const getRoutes = props.getRoutes;
    
    const setClearSelected = props.setClearSelected;
    const selectedRows = props.selectedRows;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    
    const [selections, setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"ietf-network" : {"network-id":[networkId],route:{}}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
        {
			label: "2",
			Header: "Route Name",
            accessor: "routeName",
            width: 2
		},
		{
			label: "3",
			Header: "Source Element",
            accessor: "sourceElement",
            width: 2
		},
        {
			label: "4",
			Header: "Local Address",
            accessor: "localAddress",
            width: 2
		},
        {
			label: "5",
			Header: "Destination Element",
            accessor: "destinationElement",
            width: 2
        },
        {
			label: "6",
			Header: "Nexthop Address",
            accessor: "nexthopAddress",
            width: 2
        },
        {
			label: "7",
			Header: "Protocol",
            accessor: "protocol",
            width: 2
        },
        {
			label: "8",
			Header: "Admin Status",
			Cell: ({row}) => (
                renderBoolean(row,"adminStatus")
            ),
            width: 2
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"routeStatus")
            ),
            width: 1
        }
    ]

    const handleAddRoute = () => {
        router.stateService.go("add-route",{networkId:networkId,fetchData:fetchData,clearSelection: clearSelection})
    }

    useEffect(() => {
        setSelected(selections);
    }, [selections]);

    const clearSelection = () => {
        setClearSelected(true);
    }

    const handleDelete = (selectedItems) => {
        router.stateService.go('default')
        context.setRenderLocation(["route-list"]);

        NoaClient.delete(
            "/api/network/" + networkId + "/route",
            selectedItems,
            (response) => {
                fetchFilteredData({"filters":null});
                clearSelection();
        })
    }

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getRoutes(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"ietf-network" : {"network-id":[networkId],route:{}}};
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getRoutes(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getRoutes(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left'>
                            <p style={titleText}>Network Routes</p>
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={14} tablet={14} mobile={14}>
                                    <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={2} mobile={2}>
                                    <NoaToolbar deleteMethod={handleDelete}
                                                selectedRows={selectedRows}
                                                clearSelection={clearSelection}
                                                invokeAdd={handleAddRoute}
                                    />                                
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={routes}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        setClearSelected={setClearSelected}
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                        resource="Routes" 
                        fetchData={fetchData} 
                        location="route-list"
                    />
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <UIView />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

const AddRoute = (props) => {
    const context = useContext(GlobalSpinnerContext);
    const fetchData = props.fetchData;
    const clearSelection = props.clearSelection;
    const networkId = props.networkId;

    const router = useRouter();

    const [route, setRoute] = useState({});
    
    const [baseNetworks, setBaseNetworks] = useState([]);
    const [srcNetwork, setSrcNetwork] = useState(null);
    const [destNetwork, setDestNetwork] = useState(null);

    const [srcNodes, setSrcNodes] = useState([]);
    const [destNodes, setDestNodes] = useState([]);
    const [selectedSrcNode, setSelectedSrcNode] = useState(null);
    const [selectedDestNode, setSelectedDestNode] = useState(null);

    const [srcEndpoints, setSrcEndpoints] = useState([]);
    const [destEndpoints, setDestEndpoints] = useState([]);
    const [srcEndpoint, setSrcEndpoint] = useState(null);
    const [destEndpoint, setDestEndpoint] = useState(null);

    useEffect(() => {
        context.setRenderLocation(["add-route"]);
        getBaseNetworks()
    },[]);

    const closeFooter = () => {
        router.stateService.go('default');
    }

    const getBaseNetworks = () => {
        let filter = {
            "filters" : {
                "ietf-network" : {
                    "network-type" : ["L3 Network"]
                }
            }
        }

        NoaClient.post(
            "/api/network",
            filter,
            (response) => {
                let responseData = response.data;
                let baseNetworksList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.networkId, 'value' : item.networkId, 'text': item.networkName}
                        baseNetworksList[index] = nodeObj;
                    })
                }
                setBaseNetworks(baseNetworksList);
            }
        )
    }

    useEffect(() => {
        if(srcNetwork != null) {
            getSrcNodes();
        }
    },[srcNetwork]);

    const getSrcNodes = () => {
        NoaClient.get(
            "/api/network/" + srcNetwork + "/node",
            (response) => {
                let responseData = response.data;
                let nodesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.nodeId, 'value' : item.nodeName, 'text': item.nodeName}
                        nodesList[index] = nodeObj;
                    })
                }
                setSrcNodes(nodesList);
            }
        )
    }

    useEffect(() => {
        if(selectedSrcNode != null) {
            getSrcEndpoints();
        }
    },[selectedSrcNode]);
    
    const getSrcEndpoints = () => {
        const srcNode = srcNodes.find(node => node.text === selectedSrcNode);

        let elementId = srcNode.key
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.ipAddress, 'value' : item.ipAddress, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setSrcEndpoints(interfacesList);
            }
        )
    }

    useEffect(() => {
        if(destNetwork != null) {
            if(destNetwork === srcNetwork) {
                let nodes = srcNodes.filter(node => node.text !== selectedSrcNode);
                setDestNodes(nodes);
            } else {
                getDestNodes();
            }
        }
    },[destNetwork]);

    const getDestNodes = () => {
        NoaClient.get(
            "/api/network/" + destNetwork + "/node",
            (response) => {
                let responseData = response.data;
                let nodesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let nodeObj = {'key' : item.nodeId, 'value' : item.nodeName, 'text': item.nodeName}
                        nodesList[index] = nodeObj;
                    })
                }
                setDestNodes(nodesList);
            }
        )
    }

    useEffect(() => {
        if(selectedDestNode != null) {
            getDestEndpoints();
        }
    },[selectedDestNode]);
    
    const getDestEndpoints = () => {
        const destNode = destNodes.find(node => node.text === selectedDestNode);
        let elementId = destNode.key
        NoaClient.get(
            "/api/element/" + elementId + "/interface",
            (response) => {
                let responseData = response.data;
                let interfacesList = [];
                if(Array.isArray(responseData)) {
                    responseData.map((item,index) => {
                        let interfaceObj = {'key' : item.ipAddress, 'value' : item.ipAddress, 'text': item.interfaceName}
                        interfacesList[index] = interfaceObj;
                    })
                }
                setDestEndpoints(interfacesList);
            }
        )
    }

    useEffect(() => {
        if(destEndpoint != null) {
            checkRouteExistence();
        }
    },[destEndpoint]);

    const checkRouteExistence = () => {
        let obj = {}
        obj["sourceElement"] = selectedSrcNode;
        obj["localAddress"] = srcEndpoint;
        obj["destinationElement"] = selectedDestNode;
        obj["nexthopAddress"] = destEndpoint;

        if(selectedSrcNode != null && selectedDestNode != null && srcEndpoint != null) {
            NoaClient.post(
                "/api/network/" + networkId + "/route",
                obj,
                (response) => {
                    let responseData = response.data;
                    if(responseData) {
                        setDestEndpoint(null);
                        alert("Route Already Exists");
                    }
                }
            )
        }
    }

    const handleAdd = () => {
        NoaClient.put(
            "/api/network/" + networkId + "/route",
            route,
            (response) => {
                noaNotification('success','Route Created Successfully');               
                fetchData();
            }
        )
    }

    const handleInput = (value, key) => {
		setRoute(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    return(
        <NoaContainer style={{width: "100%"}}>
            <Grid style={Object.assign({width:"100%"}, noBoxShadow, noMarginTB,noMarginLR)} stackable>
                <Grid.Row columns={1} style={noPadding}>
                    <Grid.Column width={16} textAlign='left' verticalAlign='top'>
                        <NoaHeader style={formTitle}>Create Route</NoaHeader>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row columns={1} style={formContentSpacingTB}>
                    <Grid.Column width={16}  id="add-route">
                    <Grid columns={3} stackable>
                        <Grid.Column width={2}></Grid.Column>
                        <Grid.Column width={12} style={noPadding}>
                        <Grid>
                            <Grid.Row columns={2}>
                                <Grid.Column width={8}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16} textAlign='center'>
                                                <p style={formHeader}>Route Parameters</p>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={1} style={formSpacingTB}>
                                            <Grid.Column width={16}>
                                            <Grid>
                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter} className="required">Route Name</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Input type='text' name='routeName' 
                                                                value={route.routeName}
                                                                fluid={false}
                                                                onChange={
                                                                    (e, {value}) => handleInput(value==='' ? null : value, 'routeName')
                                                                }>
                                                                    <input style={inputBoxStyle}></input>
                                                            </Input>
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>

                                                <Grid.Row columns={1}>
                                                    <Grid.Column width={16}>
                                                    <Grid columns={4} stackable>
                                                        <Grid.Column width={3}></Grid.Column>
                                                        <Grid.Column width={4} textAlign='left'>
                                                            <p style={formParameter}>Protocol</p>
                                                        </Grid.Column>
                                                        <Grid.Column width={6} textAlign='left'>
                                                            <Dropdown clearable selection required
                                                                    placeholder="Select Protocol"
                                                                    selectOnBlur={false}
                                                                    style={dropdownStyle}
                                                                    options={protocolTypes}
                                                                    value={route.protocol ? route.protocol : ''}
                                                                    onChange={
                                                                        (e, {value}) => handleInput(value==='' ? null : value, 'protocol')
                                                                    }
                                                            />
                                                        </Grid.Column>
                                                        <Grid.Column width={3}></Grid.Column>
                                                    </Grid>
                                                    </Grid.Column>
                                                </Grid.Row>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                                <Grid.Column width={8}></Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={1}>
                                <Grid.Column width={16}>
                                <Grid columns={2} stackable>
                                    <Grid.Column computer={8} tablet={16} mobile={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16} textAlign='center'>
                                                    <p style={formHeader}>Source Parameters</p>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1} style={formSpacingTB}>
                                                <Grid.Column width={16}>
                                                    <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter}>Select Base Network</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Src Network"
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        options={baseNetworks} 
                                                                        onChange={(e,{value}) => setSrcNetwork(value==='' ? null : value)}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter} className="required">Source Element</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Src Element"
                                                                        options={srcNodes}
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        onChange={(e,{value}) => {
                                                                            let srcEle = value==='' ? null : value
                                                                            let key = 'sourceElement'
                                                                            setSelectedSrcNode(srcEle);
                                                                            setRoute(prevState => ({
                                                                                ...prevState,
                                                                                [key]: srcEle
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>


                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter} className="required">Source Endpoint</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Src Endpoint"
                                                                        options={srcEndpoints}
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        onChange={(e,{value}) => {
                                                                            let srcEp = value==='' ? null : value
                                                                            let key = 'localAddress'
                                                                            setSrcEndpoint(srcEp);
                                                                            setRoute(prevState => ({
                                                                                ...prevState,
                                                                                [key]: srcEp
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                    </Grid.Column>

                                    <Grid.Column computer={8} tablet={16} mobile={16}>
                                        <Grid>
                                            <Grid.Row columns={1}>
                                                <Grid.Column width={16} textAlign='center'>
                                                    <p style={formHeader}>Destination Parameters</p>
                                                </Grid.Column>
                                            </Grid.Row>
                                            <Grid.Row columns={1} style={formSpacingTB}>
                                                <Grid.Column width={16}>
                                                    <Grid>
                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter}>Select Base Network</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Dest Network"
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        options={baseNetworks} 
                                                                        onChange={(e,{value}) => setDestNetwork(value==='' ? null : value)}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter} className="required">Destination Element</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Dest Element"
                                                                        options={destNodes}
                                                                        selectOnBlur={false}
                                                                        style={dropdownStyle}
                                                                        onChange={(e,{value}) => {
                                                                            let destEle = value==='' ? null : value
                                                                            let key = 'destinationElement'
                                                                            setSelectedDestNode(destEle);
                                                                            setRoute(prevState => ({
                                                                                ...prevState,
                                                                                [key]: destEle
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>

                                                    <Grid.Row columns={1}>
                                                        <Grid.Column width={16}>
                                                        <Grid columns={4} stackable>
                                                            <Grid.Column width={3}></Grid.Column>
                                                            <Grid.Column width={4} textAlign='left'>
                                                                <p style={formParameter} className="required">Destination Endpoint</p>
                                                            </Grid.Column>
                                                            <Grid.Column width={6} textAlign='left'>
                                                                <Dropdown clearable selection required
                                                                        placeholder="Select Dest Endpoint"
                                                                        options={destEndpoints}
                                                                        selectOnBlur={false} 
                                                                        style={dropdownStyle}
                                                                        onChange={(e,{value}) => {
                                                                            let destEp = value==='' ? null : value
                                                                            let key = 'nexthopAddress'
                                                                            setDestEndpoint(destEp);
                                                                            setRoute(prevState => ({
                                                                                ...prevState,
                                                                                [key]: destEp
                                                                            }));
                                                                        }}
                                                                />
                                                            </Grid.Column>
                                                            <Grid.Column width={3}></Grid.Column>
                                                        </Grid>
                                                        </Grid.Column>
                                                    </Grid.Row>
                                                    </Grid>
                                                </Grid.Column>
                                            </Grid.Row>
                                        </Grid>
                                    </Grid.Column>
                                </Grid>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                        </Grid.Column>
                        <Grid.Column width={2}></Grid.Column>
                    </Grid>

                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2}>
                            <Grid.Column width={8} textAlign='right'>
                                <Button style={applyButton} onClick={() => {
                                    handleAdd()
                                    context.setRenderLocation(["add-route"]);
                                }}>Add</Button>
                            </Grid.Column>
                            <Grid.Column width={8} textAlign='left'>
                                <Button style={cancelButton} onClick={closeFooter}>Cancel</Button>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}
const ModifyRoute = (props) => {
    const networkId = props.networkId;
    const closeFooter = props.closeFooter;
    const getRoutes = props.getRoutes;

    const [route, setRoute] = useState({});

    useEffect(() => {
        setRoute(props.data);
    },[props.data]);

    const handleInput = (value, key) => {
		setRoute(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleModify = () => {
		NoaClient.post(
            "/api/network/" + networkId + "/route/" + route.routeId,
            route,
            (response) => {
                closeFooter(false);
                getRoutes();
            }
        )
    }

    return(
        <NoaContainer style={completeWidth}>
        <Grid style={Object.assign({},completeWidth, noBoxShadow, noMarginTB,noMarginLR)} stackable>
            <Grid.Row columns={1} style={noPadding}>
                <Grid.Column width={16} style={noPadding} textAlign='left' verticalAlign='top'>
                    <NoaHeader style={formTitle}>Route Detail : {route.routeName}</NoaHeader>
                </Grid.Column>
            </Grid.Row>
            <Divider style={dividerStyle}/>
            <Grid.Row columns={1}>
                <Grid.Column width={16} style={{paddingLeft: "2em"}}>
                    <Grid>
                        <Grid.Row columns={2}>
                            <Grid.Column computer={window.innerWidth > 1330 ? 8 : 16} tablet={16} mobile={16}>
                                <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} textAlign='center'>
                                        <p style={formHeader}>Route Statistics</p>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='left'>
                                        <p style={formParameter}>Latency</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='text' name='linkLatency' 
                                            value={route.linkLatency}
                                            fluid={false}
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='left'>
                                        <p style={formParameter}>Link Rate</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='text' name='linkRate' 
                                            value={route.linkRate}
                                            fluid={false}
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='left'>
                                        <p style={formParameter}>Delay</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Input type='text' name='delay' 
                                            value={route.delay}
                                            fluid={false}
                                        >
                                        </Input>
                                    </Grid.Column>
                                </Grid.Row>
                                </Grid>
                            </Grid.Column>

                            <Grid.Column computer={window.innerWidth > 1330 ? 8 : 16} tablet={16} mobile={16}>
                                <Grid>
                                <Grid.Row columns={1}>
                                    <Grid.Column width={16} textAlign='center'>
                                        <p style={formHeader}>Route Parameters</p>
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2} textAlign='left'>
                                    <Grid.Column width={8}>
                                        <p style={formParameter}>Duplex Mode</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Dropdown clearable selection required
                                                placeholder="Select Duplex Mode"
                                                options={duplexTypes}
                                                selectOnBlur={false}
                                                value={route.duplexMode ? route.duplexMode : ''}
                                                onChange={
                                                    (e, {value}) => handleInput(value==='' ? null : value, 'duplexMode')
                                                }
                                        />
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='left'>
                                        <p style={formParameter}>Auto Negotiation</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Checkbox
                                            toggle={true}
                                            value={route.autoNegotiation}
                                            onChange={
                                                (e,data)=>handleInput(data.checked, 'autoNegotiation')
                                            }
                                        />
                                    </Grid.Column>
                                </Grid.Row>
                                <Grid.Row columns={2}>
                                    <Grid.Column width={8} textAlign='left'>
                                        <p style={formParameter}>Admin Status</p>
                                    </Grid.Column>
                                    <Grid.Column width={8} textAlign='left'>
                                        <Checkbox
                                            toggle={true}
                                            value={route.adminStatus}
                                            onChange={
                                                (e,data)=>handleInput(data.checked, 'adminStatus')
                                            }
                                        />
                                    </Grid.Column>
                                </Grid.Row>
                                </Grid>
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1} style={{marginTop: "1.5em"}}>
                <Grid.Column textAlign='center' width={16}>
                    <Button style={applyButton} onClick={handleModify}>Update</Button>
                    <Button style={Object.assign({paddingLeft: "10px"},cancelButton)} onClick={()=>closeFooter(false)}>Cancel</Button>
                </Grid.Column>
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}
const protocolTypes = [
    {
        key: 'bgp',
        text: 'BGP',
        value: 'bgp',
    },
    {
        key: 'ospf',
        text: 'OSPF',
        value: 'ospf',
    }
];
export default NetworkRouteManager;
export {AddRoute,ModifyRoute};