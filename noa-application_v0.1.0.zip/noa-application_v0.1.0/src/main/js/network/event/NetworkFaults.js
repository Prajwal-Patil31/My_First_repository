import React, { useContext, useEffect, useState } from 'react';
import NoaTable from '../../widget/NoaTable';

import {
    Button,
    Checkbox,
    Grid,
    Segment
} from 'semantic-ui-react';

import { 
    noMarginTB, noMarginLR, titleText, 
    cardLayout, cardDurationItem, completeHeight, 
    completeWidth, tableHeaderHeight, tablePadding, 
    applyButton
} from '../../constants';

import { NoaContainer} from '../../widget/NoaWidgets';
import NoaRadialBarChart from '../../widget/NoaRadialBarChart';
import NoaCard from '../../widget/NoaCard';
import NoaPieChart from '../../widget/NoaPieChart';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';
import NoaClient from '../../utility/NoaClient';

const alarmColors = ['#FB4E4E','#F6A609','#667EFF','#FFDB1F','#66B2FF'];

const NetworkFaults = (props) => {
    const networkId = sessionStorage.getItem("networkId");

    const [faults, setFaults] = useState([]);
    const [faultSummary, setFaultSummary] = useState({});

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);

    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});
    
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = faults[sel[i]].faultId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getFaults = (filterObj) => {
        context.setRenderLocation(["network-fault-list"]);
        NoaClient.post(
            "/api/global/fault",
            filterObj,
            (response) => {
                let responseData = response.data;
                let faultsList = [];
                responseData.data.map((item) => {
                    let severity = item.severity;

                    item["severity"] = faultSeverityObj[severity]
                    faultsList.push(item);
                })
                setFaults(faultsList);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            });
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/global/fault/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }
    
    const getNetworkFaultsOverview = () => {
        NoaClient.get(
            "/api/network/" + networkId + "/fault/overview",
            (response) => {
                let responseData = response.data;
                setFaultSummary(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        getNetworkFaultsOverview();
        let filterCriteria = {}
        
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"fault":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getFaults(filterCriteria);
    },[]);

    return(
        <NoaContainer style={Object.assign({display: "flex",flexDirection:"column"},completeHeight,completeWidth)}>
        <Grid>
            <NoaContainer style={{width: "100%"}}>
            <Grid.Row columns={1} style={Object.assign({marginTop: "1em",marginBottom: "1.5em"})}>
                <Grid.Column width={16}>
                    <NetworkFaultsOverview data={faultSummary}/>
                </Grid.Column>
            </Grid.Row>
            </NoaContainer>
        </Grid>
        <Grid style={{height: "100%"}}>
            <NoaContainer style={{width: "100%",height: "100%"}}>
                <Grid.Row columns={1} style={{height: "100%"}} className="card-spacing">
                    <Grid.Column width={16} style={{height: "100%"}}>
                        <Segment style={Object.assign({minHeight:"65vh"}, cardLayout)}>
                            <NoaContainer style={{width: '100%',height: "100%"}}>
                                <NetworkFaultTable 
                                        faults={faults} getFaults={getFaults}                                            
                                        selectedRows={selectedRows}
                                        setClearSelected={setClearSelected}
                                        setSelected={setSelected} 
                                        clearSelected={clearSelected}
                                        columns={columns}
                                        filters={filters}
                                        pageSize={pageSize}
                                        totalPages={totalPages}
                                        setPageSize={setPageSize}
                                        totalEntries={totalEntries}
                                />
                            </NoaContainer>
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </NoaContainer>
        </Grid>
        </NoaContainer>
    )
}

const NetworkFaultsOverview = (props) => {
    const data = props.data;

    return(
        <NoaContainer style={{width: "100%"}}>
        <Grid>
            <Grid.Row columns={1} stretched>
                <Grid.Column width={16}>
                    <NoaCard title={"Network Fault Overview"} renderDuration={true} durationComponent={timeInHours}>
                        {Object.keys(data).length > 0 ? 
                        <Grid columns={2} stackable>
                            <Grid.Column computer={window.innerWidth < 1300 ? 5 : 3} tablet={8} mobile={16}>
                                <NoaPieChart data={data["summary"]} colors={alarmColors} labelValue={"225 Faults"}/>
                            </Grid.Column>
                            <Grid.Column computer={13} tablet={13} mobile={16}>
                                <Grid columns={5}>
                                    {data["detailed"].map((severityData,index) => (
                                        <Grid.Column computer={window.innerWidth < 1600 ? 5 : 3} tablet={8} mobile={16}>
                                            <NoaRadialBarChart data={severityData} colors={alarmColors[index]}/>
                                        </Grid.Column>
                                    ))}
                                </Grid>
                            </Grid.Column>
                        </Grid>
                        :""}
                    </NoaCard>
                </Grid.Column>                
            </Grid.Row>
        </Grid>
        </NoaContainer>
    )
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const NetworkFaultTable = (props) => {
    const faults = props.faults;
    const getFaults = props.getFaults;

    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState([]);
    const [appliedFilters, setAppliedFilters] = useState({"fault" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
		{
			label: "2",
			Header: "Fault Code",
            accessor: "faultCode",
            width: 1
		},
        {
			label: "4",
			Header: "Description",
            accessor: "faultContent",
            width: 3
		},
        {
			label: "5",
			Header: "Resource",
            accessor: "resource",
            width: 2
        },
        {
			label: "5",
			Header: "Resource Id",
            accessor: "resourceId",
            width: 2
        },
        {
            label: "9",
            Header: "Severity",
            accessor: "severity",
            width: 2
        },
        {
			label: "7",
			Header: "Occurance",
            accessor: "faultDate",
            width: 3
        },
        {
			label: "8",
			Header: "Count",
            accessor: "count",
            width: 1
        },
        {
            label: "9",
            Header: "Status",
            accessor: "status",
            width: 1
        }
    ]

    useEffect(() => {
		setSelected(selections);
    }, [selections]);

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getFaults(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"fault" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getFaults(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getFaults(filterObj)
    }

    const fetchData = () => {
        fetchFilteredData({"filters":null})
        setClearSelected(true);
    }
    return (
        <NoaContainer style={Object.assign({},tablePadding, completeWidth, completeHeight)}>
        <Grid style={Object.assign({},noMarginTB,noMarginLR)}>
            <Grid.Row style={tableHeaderHeight}>
                <Grid.Column verticalAlign='middle'>
                    <Grid columns={2} verticalAlign='middle'>
                        <Grid.Column computer={3} tablet={16} mobile={16} verticalAlign='bottom' textAlign='left' style={titleText}>
                            Faults List
                        </Grid.Column>
                        <Grid.Column computer={13} tablet={16} mobile={16} verticalAlign='bottom' textAlign='right'>
                            <Grid columns={2}>
                                <Grid.Column computer={3} tablet={3} mobile={3}>
                                    
                                </Grid.Column>
                                <Grid.Column computer={13} tablet={13} mobile={13}>
                                    <FaultsToolbar selectedRows={selectedRows} fetchData={fetchData}/>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row columns={1}>
                <Grid.Column width={16} verticalAlign='top'>
                    <NoaTable data={faults}
                        columns={columns}
                        selectedRows={selections}
                        onSelectedRowsChange={setSelections}
                        clearSelected={clearSelected}
                        resource="Network Faults" 
                        fetchData={fetchData} 
                        location="network-fault-list"
                        selectedPageSize={pageSize}
                        handlePagination={handlePagination}
                        totalPages={totalPages}
                        handlePageSize={handlePageSize}
                        totalEntries={totalEntries}
                    />
                </Grid.Column>
            </Grid.Row>
        </Grid>    
        </NoaContainer>  
    )
}

const FaultsToolbar = (props) => {
    const selectedRows = props.selectedRows;
    const fetchData = props.fetchData;

    const handleAck = () => {
		NoaClient.post(
			"/api/global/fault/acknowledge",
			selectedRows,
			(response) => {
				fetchData();
			})
    }

    const handleClear = () => {
		NoaClient.post(
			"/api/global/fault/clear",
			selectedRows,
			(response) => {
				fetchData();
			})
    }
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={12} textAlign='right'>
                            <Button style={applyButton} onClick={handleAck} disabled={selectedRows.length > 0 ? false : true}>Ack</Button>
                        </Grid.Column>
                        <Grid.Column width={4} textAlign='left'>
                            <Button style={applyButton} onClick={handleClear} disabled={selectedRows.length > 0 ? false : true}>Clear</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const timeInHours = () => {
    return(
        <Grid>
            <Grid.Row columns={1} verticalAlign='bottom'>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>5Hour</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const faultStatusObj = {
    1 : "-",
    2 : "Cleared",
    3 : "Acknowledged"
}

const faultSeverityObj = {
    1 : "Information",
    2 : "Warning",
    3 : "Minor",
    4 : "Major",
    5 : "Critical"
}

const mockFaults =[
    {
        "faultId" : "1",
        "faultCode" : "1001",
        "description" : "End-Device not Discoverable",
        "element" : "BLR-PE-088",
        "severity" : "Critical",
        "occurance" : "4th May 2022",
        "count" : "4",
        "status" : "Acknowledged",
    },
    {
        "faultId" : "2",
        "faultCode" : "1002",
        "description" : "Max CPU Usage",
        "element" : "BOM-P-564",
        "severity" : "Minor",
        "occurance" : "4th May 2022",
        "count" : "10",
        "status" : "Cleared",
    },
    {
        "faultId" : "3",
        "faultCode" : "1165",
        "description" : "Max VLANs Count Reached",
        "element" : "BLR-PE-088",
        "severity" : "Minor",
        "occurance" : "4th May 2022",
        "count" : "1",
        "status" : "Cleared",
    },
    {
        "faultId" : "4",
        "faultCode" : "1428",
        "description" : "Interface ethernet0 down",
        "element" : "HYD-CE-233",
        "severity" : "Critical",
        "occurance" : "3rd May 2022",
        "count" : "16",
        "status" : "Acknowledged",
    },
    {
        "faultId" : "5",
        "faultCode" : "2505",
        "description" : "Max Bandwidth Reached",
        "element" : "HYD-CE-145",
        "severity" : "Major",
        "occurance" : "3rd May 2022",
        "count" : "18",
        "status" : "Cleared",
    },
    {
        "faultId" : "6",
        "faultCode" : "298",
        "description" : "Bad MPLS Configuration",
        "element" : "DEL-PE-088",
        "severity" : "Information",
        "occurance" : "3rd May 2022",
        "count" : "2",
        "status" : "Acknowledged",
    },
    {
        "faultId" : "7",
        "faultCode" : "1002",
        "description" : "Max CPU Usage",
        "element" : "BOM-P-564",
        "severity" : "Minor",
        "occurance" : "4th May 2022",
        "count" : "10",
        "status" : "Cleared",
    },
    {
        "faultId" : "8",
        "faultCode" : "1165",
        "description" : "Max VLANs Count Reached",
        "element" : "BLR-PE-088",
        "severity" : "Minor",
        "occurance" : "4th May 2022",
        "count" : "1",
        "status" : "Cleared",
    },
    {
        "faultId" : "9",
        "faultCode" : "1428",
        "description" : "Interface ethernet0 down",
        "element" : "HYD-CE-233",
        "severity" : "Critical",
        "occurance" : "3rd May 2022",
        "count" : "16",
        "status" : "Acknowledged",
    },
    {
        "faultId" : "10",
        "faultCode" : "1001",
        "description" : "End-Device not Discoverable",
        "element" : "HYD-PE-265",
        "severity" : "Critical",
        "occurance" : "4th May 2022",
        "count" : "10",
        "status" : "Acknowledged",
    }
]
export default NetworkFaults;