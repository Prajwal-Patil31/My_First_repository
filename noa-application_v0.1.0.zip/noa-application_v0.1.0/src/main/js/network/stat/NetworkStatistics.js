import React from 'react';

const NetworkStatistics = (props) => {
    return(
        <div></div>
    )
}
export default NetworkStatistics;