import React, { useEffect, useState, useContext } from 'react';

import { Grid } from 'semantic-ui-react';

import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';

import { MenuContext } from '../../utility/MenuContext';

import { cardDurationItem, cardKeyItem, cardValueItem, completeWidth, noPadding } from '../../constants';
import NoaRadialBarChart from '../../widget/NoaRadialBarChart.js';
import NoaLineChart from '../../widget/NoaLineChart';
import NoaCard from '../../widget/NoaCard';
import { NoaContainer } from '../../widget/NoaWidgets';
import NoaProgressBar from '../../widget/NoaProgressBar';
import NoaRadialBar from '../../widget/NoaRadialBar';

const NetworkSummary = (props) => {

    const networkId = sessionStorage.getItem("networkId");

    const [networkDetails, setNetworkDetails] = useState({});
    const [networkState, setNetworkState] = useState([]);
    const [deviceAvailability, setDeviceAvailability] = useState([]);
    const [linkAvailability, setLinkAvailability] = useState([]);
    const [linkUtilization, setLinkUtilization] = useState([]);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const menuContext = useContext(MenuContext);

    const getNetworkDetails = () => {
        NoaClient.get(
            "/api/network/" + networkId + "/overview",
            (response) => {
                let responseData = response.data;
                setNetworkDetails(responseData);
            });
    }

    const getNetworkInventory = () => {
        NoaClient.get(
            "/api/network/" + networkId + "/state",
            (response) => {
                let responseData = response.data;
                setNetworkState(responseData);
            });
    }

    const getDeviceAvailability = () => {
        NoaClient.get(
            "/api/network/" + networkId + "/node/availability",
            (response) => {
                let responseData = response.data;
                setDeviceAvailability(responseData);
            });
    }

    const getLinkAvailability = () => {
        NoaClient.get(
            "/api/network/" + networkId + "/link/availability",
            (response) => {
                let responseData = response.data;
                setLinkAvailability(responseData);
            });
    }

    const getLinkUtilization = () => {
        NoaClient.get(
            "/api/network/" + networkId + "/link/utilization",
            (response) => {
                let responseData = response.data;
                setLinkUtilization(responseData);
            });
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getNetworkDetails();
        getNetworkInventory();
        getDeviceAvailability();
        getLinkAvailability();
        getLinkUtilization();
        menuContext.setHideMenu(false);
        menuContext.setActiveItem(0);
    }, []);

    return(
        <NoaContainer style={completeWidth}>
            <Grid>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Grid columns={2} stackable stretched relaxed='very'>
                            <Grid.Column computer={5} tablet={16} mobile={16}>
                                <NoaCard title={"Network Status"} renderDuration={true} durationComponent={timeInHours}>
                                    <NoaContainer style={{width: "100%",textAlign: "center"}}>
                                        {Object.keys(networkDetails).length > 0 ? 
                                            <NetworkDetailCard data={networkDetails["summary"]} color={"#007EFF"} listData={networkDetails["detailed"]}/>
                                        :""}
                                    </NoaContainer>
                                </NoaCard>
                            </Grid.Column>
                            <Grid.Column computer={11} tablet={16} mobile={16}>
                                <NoaCard title={"Network Inventory"} renderDuration={true}>
                                    {networkState.length > 0 ? 
                                    <Grid columns={3}>
                                        {networkState.map((networkData,index) => (
                                            <Grid.Column computer={index == 1 ? 6 : 5} tablet={8} mobile={16}>
                                                <NoaRadialBarChart data={networkData} colors={pieChartColors[index]}/>
                                            </Grid.Column>
                                        ))}
                                    </Grid>
                                    :""}
                                </NoaCard>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <Grid columns={2} stackable stretched relaxed='very'>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                <NoaCard title={"Device Availability"} renderDuration={true}>
                                    <NoaContainer style={{width: "100%",textAlign: "center",paddingLeft:"1.5em",paddingRight:"1.5em"}}>
                                        {deviceAvailability.length > 0 ? 
                                            (deviceAvailability.map((item) => (
                                                <NoaProgressBar data={item} title={null}/>
                                            )))
                                        :""}
                                    </NoaContainer>
                                </NoaCard>
                            </Grid.Column>
                            <Grid.Column computer={8} tablet={16} mobile={16}>
                                <NoaCard title={"Link Availability"} renderDuration={true}>
                                    <NoaContainer style={{width: "100%",textAlign: "center",paddingLeft:"1.5em",paddingRight:"1.5em"}}>
                                        {linkAvailability.length > 0 ? 
                                            (linkAvailability.map((item) => (
                                                <NoaProgressBar data={item} title={null}/>
                                            )))
                                        :""}
                                    </NoaContainer>
                                </NoaCard>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1} className="card-spacing">
                    <Grid.Column width={16}>
                        <NoaCard title={"Top Links by Utilization"} renderDuration={true} durationComponent={periodicalDuration}>
                            <NoaContainer style={{textAlign: "center",width: "100%"}}>
                                {linkUtilization.length > 0 ? 
                                    <NoaLineChart data={linkUtilization} lineType={"linear"} colors={serviceThroughputColors}/>
                                :""}
                            </NoaContainer>
                        </NoaCard>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const NetworkDetailCard = (props) => {
    const [data, setData] = useState([]);
    const [color, setColor] = useState(null);
    const [listData, setListData] = useState({});

    useEffect(() => {
        setData(props.data)
    },[props.data]);

    useEffect(() => {
        setColor(props.color)
    },[props.color]);

    useEffect(() => {
        setListData(props.listData)
    },[props.listData]);
    
    return(
        <NoaContainer style={{width: "100%",textAlign: "center"}}>
            <Grid columns={2} stackable relaxed='very'>
                <Grid.Column computer={8} tablet={16} mobile={16} verticalAlign='middle' textAlign='left' style={{minWidth:"200px"}}>
                    <NoaRadialBar data={data} color={color}/>
                </Grid.Column>
                <Grid.Column computer={8} tablet={16} mobile={16}>
                    <Grid stackable textAlign='center'>
                        {Object.keys(listData).map((keyValue,index) => (
                            <Grid.Row columns={1} style={{paddingBottom:"0px"}}>
                                <Grid.Column width={16} style={noPadding} textAlign='left'>
                                    <span style={cardKeyItem}>{keyValue}</span><br/>
                                    <span style={cardValueItem}>{listData[keyValue]}</span>
                                </Grid.Column>
                            </Grid.Row>
                        ))}
                    </Grid>
                </Grid.Column>
            </Grid>
        </NoaContainer>
    )
}

const multipleDuration = () => {
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>{new Date().toLocaleString()}</p>   
                        </Grid.Column>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "right",cursor: "pointer"},cardDurationItem)}>Show All</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const timeInHours = () => {
    return(
        <Grid>
            <Grid.Row columns={1} verticalAlign='bottom'>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>5Hour</p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const periodicalDuration = () => {
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={10}>
                            <p style={Object.assign({textAlign: "left"},cardDurationItem)}>
                                {new Date(Date.now() - ( 3600 *1000 * 1 )).toLocaleString()}-{new Date().toLocaleString()}
                            </p>   
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const pieChartColors = ["#903749", "#543864","#750550","#21325E"];
const chartColors = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042'];

const serviceThroughputColors = {
    "DEL-PE-480": "#ffac01",
    "BOM-CE-165": "#9839d2",
    "DEL-PE-560": "#ff8a1f",
    "BOM-CE-001": "#37d463",
    "VJA-P-980": "#1271ff",
}
export default NetworkSummary;