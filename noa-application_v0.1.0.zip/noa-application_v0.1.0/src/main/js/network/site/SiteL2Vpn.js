import React, { Fragment, useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Modal,
    Button,
    Header,
    Container,
    Popup,
    Checkbox,
    Input,
    Dropdown,
    Divider,
    Tab
} from 'semantic-ui-react';

import { Link, useLocation } from "react-router-dom";

import 'semantic-ui-css/semantic.min.css';

import { gridScroll, noBoxShadow, tbButton } from '../../constants';

import NoaTable from '../Widgets/NoaTable';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';

function SiteL2Vpn(props) {
    const siteId = props.siteId;
    const [l2Vpns, setL2Vpns] = useState([]);
    const [selectedRows, setSelectedRows] = useState({});
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = l2Vpns[sel[i]].vpnId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getL2Vpns = () => {
        NoaClient.get(
            "/api/site/"+siteId+"/l2-vpn",
            (response) => {
                setL2Vpns(response.data);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getL2Vpns();
    }, []);

    return (
        <Container style={{height: '500px'}}>
            <L2VpnTable 
                l2Vpns={l2Vpns} 
                setSelected={setSelected}
                clearSelected={clearSelected}
            />
        </Container>
    )
}

const L2VpnTable = (props) => {
    const l2Vpns = props.l2Vpns;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;

    const [selectedRows, setSelectedRows] = useState({});

    useEffect(() => {
		setSelected(selectedRows);
	}, [selectedRows]);

    const columns = [
        {
            label: "1",
            Header: "Template Name",
            accessor: "vpnName",
            filterable: true,
            hasAccordian: false
        },
        {
            label: "2",
            Header: "Instance Type",
            accessor: "instanceType",
            filterable: true,
            hasAccordian: false
        },
        {
            label: "3",
            Header: "Discovery Type",
            accessor: "discoveryType",
            filterable: false,
            hasAccordian: false
        },
        {
            label: "4",
            Header: "Signaling Type",
            accessor: "signalingType",
            filterable: false,
            hasAccordian: false
        }
    ]

    return(
        <Grid.Row style={noBoxShadow}>
            <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                <NoaTable data={l2Vpns}
                    columns={columns}
                    selectedRows={selectedRows}
                    onSelectedRowsChange={setSelectedRows}
                    clearSelected={clearSelected}
                />
            </Grid.Column>
        </Grid.Row>
    )
}

export default SiteL2Vpn