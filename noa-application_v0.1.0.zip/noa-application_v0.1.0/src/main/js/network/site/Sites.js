import React, { Fragment, useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Modal,
    Button,
    Header,
    Container,
    Popup,
    Checkbox,
    Input,
    Dropdown,
    Divider,
    Step
} from 'semantic-ui-react';

import { useHistory } from "react-router-dom";

import 'semantic-ui-css/semantic.min.css';

import { dividerStyle, gridScroll, noBoxShadow, tbButton } from '../../constants';

import NoaTable from '../Widgets/NoaTable';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';
import BreadCrumb from '../Widgets/BreadCrumb';
import update from 'react-addons-update';

const Sites = (props) => {
    const [sites, setSites] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);
    const [clickedRowId, setClickedRowId] = useState(null);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const history = useHistory();

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = sites[sel[i]].siteId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getSites = () => {
        NoaClient.get(
            "/api/site",
            (response) => {
                setSites(response.data);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getSites();
    },[]);

    useEffect(() => {
        if(clickedRowId !== null) {
            const site = sites[clickedRowId]
            const siteId = site.siteId;

            history.push({
                pathname: `/service/sites/${siteId}`,
                state: {
                    siteId: siteId,
                }
            })
        }
    }, [clickedRowId]);

    return(
        <Container>
            <Grid style={noBoxShadow} centered verticalAlign='middle'>
                <Grid.Row style={noBoxShadow}>
                <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                    <Segment style={noBoxShadow}>
                        <Grid columns={3} verticalAlign='middle'>
                            <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                                {<BreadCrumb />}
                                <Header size='medium'>Sites</Header>
                            </Grid.Column>
                            <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                            </Grid.Column>
                            <Grid.Column width={6} textAlign='right' verticalAlign='middle'>
                                <SitesToolBar 
                                    sites={sites}
                                    selectedRows={selectedRows}
                                    getSites={getSites}
                                    setClearSelected={setClearSelected}
                                />
                            </Grid.Column>
                        </Grid>
                    </Segment>
                </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row style={noBoxShadow}>
                <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                    <Segment style={noBoxShadow}>
                        <Grid style={noBoxShadow}>
                            <Grid.Column style={noBoxShadow}>
                                <SitesTable 
                                    sites={sites}
                                    setSelected={setSelected}
                                    clearSelected={clearSelected}
                                    setClickedRowId={setClickedRowId}
                                />
                            </Grid.Column>
                        </Grid>
                    </Segment>
                </Grid.Column>
                </Grid.Row>
            </Grid>
        </Container>
    )
}

const SitesToolBar = (props) => {
    const sites = props.sites;
    const getSites = props.getSites;
    const setClearSelected = props.setClearSelected;
    const selectedRows = props.selectedRows;

    return(
        <Fragment>
            <AddSites
                sites={sites}
                getSites={getSites}
                setClearSelected={setClearSelected}
            />
            <DeleteSites
                selectedRows={selectedRows}
                getSites={getSites}
                setClearSelected={setClearSelected}
            /> 
        </Fragment>
    )
}

const AddSites = (props) => {
    const sites = props.sites;
    const getSites = props.getSites;
    const setClearSelected = props.setClearSelected;
    const toolTipMessage= "Click to Add Site";

    const [site, setSite] = useState({});
    const [devices, setDevices] = useState({});
    const [locations, setLocations] = useState([]);
    const [location, setLocation] = useState({});
    const [locationDevicesObject, setLocationDevicesObject] = useState({});
    const [deviceRows, setDeviceRows] = useState([]);
    const [deviceId, setDeviceId] = useState(null);

    const vpnFlavours = [
        { 'key': "single", 'text': "Single", 'value': "site-vpn-flavor-single" },
        { 'key': "multi", 'text': "Multi", 'value': "site-vpn-flavor-multi" },
        { 'key': "nni", 'text': "NNI", 'value': "site-vpn-flavor-nni" }
    ]

    const bundlingTypes = [
        { 'key': "multi-svc", 'text': "Multi SVC", 'value': "multi-svc-bundling" },
        { 'key': "one2one", 'text': "One2One", 'value': "one2one-bundling" },
        { 'key': "all2one", 'text': "All2One", 'value': "all2one-bundling" }
    ]

    const managementTypes = [
        { 'key': "co", 'text': "Co Manged", 'value': "co-managed" },
        { 'key': "producer", 'text': "Producer Managed", 'value': "producer-managed" },
        { 'key': "consumer", 'text': "Consumer Managed", 'value': "consumer-managed" }
    ]

    const loopPreventionTypes = [
        { 'key': "shut", 'text': "shut", 'value': "shut" },
        { 'key': "trap", 'text': "Trap", 'value': "trap" }
    ]

    const [showModal, setShowModal] = useState(false);
    const [step, setStep] = React.useState(0);

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 3 ? 3 : nextStep);
    };

	const openModal = () => {
		setShowModal(true);
	}

	const closeModal = () => {
        setShowModal(false);
        handleReset();
		setClearSelected(true);
    }
    
    const handleReset = () => {
        setSite({});
        setDevices({});
        setLocation({});
        setLocations([]);
        setDeviceRows([]);
        setDeviceId(null);
        setStep(0);
        setLocationDevicesObject({});
    }

	/**
	 * Invokes a REST request to Add new Site.
	 * Also fetches the updated list of Sites.
	 * 
	*/
	const addSite = () => {
        const modifiedSite = site;
        modifiedSite.locations = {
            "location": locations
        }

		NoaClient.put(
            "/api/site",
            modifiedSite,
			(response) => {
				noaNotification('success', 'Site Added Successfully');
                addDevices();
            })
        closeModal();
    }

    const addLocation = () => {
        const locationDeviceId = deviceId;
        setLocationDevicesObject(prevState => ({
            ...prevState,
            [location.locationId] : locationDeviceId
        }));
        setDevices(devices.filter(deviceObj => locationDeviceId !== deviceObj.deviceId));
        setLocations(prevState => [...prevState, location]);
        setLocation({});
        setDeviceId(null);
    }

    const addDevices = () =>{
        NoaClient.put(
            "/api/site/"+site.siteId+"/device",
            locationDevicesObject,
			(response) => {
                noaNotification('success', 'Devices Added Successfully');
                getSites();
            })
    }

    const handleInputChange = (e, subObject) => {
        const key = e.target.name;
        const value = e.target.value;
        if(subObject !== null && typeof subObject !== 'undefined') {
            setSite(prevState => ({
                ...prevState,
                [subObject]: (typeof prevState[subObject] !== 'undefined' && prevState[subObject] !== null ? 
                update(
                    prevState[subObject], {
                    [0]:{
                        $set:  {
                            ...prevState[subObject][0],
                            [key]: value
                        } 
                    }
                }): [{
                    [key]: value
                }])
            }))
        } else {
            setSite(prevState => ({
                ...prevState,
                [key]: value
            }));
        }
    }

    const handleLocationInputChange = (e) => {
        const key = e.target.name;
        const value = e.target.value;
        
        setLocation(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const handleDropDownChange = (e, value, key, subObject) => {
        if(subObject !== null && typeof subObject !== 'undefined') {
            setSite(prevState => ({
                ...prevState,
                [subObject]: (typeof prevState[subObject] !== 'undefined' && prevState[subObject] !== null ? 
                update(
                    prevState[subObject], {
                    [0]:{
                        $set:  {
                            ...prevState[subObject][0],
                            [key]: value
                        } 
                    }
                }): [{
                    [key]: value
                }])
            }))
        } else {
            setSite(prevState => ({
                ...prevState,
                [key]: value
            }));
        }
    }

    useEffect(() => {
        if(devices.length) {
            const rows = [...Array( Math.ceil(devices.length / 2) )];
            const deviceRows = rows.map( (row, idx) => devices.slice(idx * 2, idx * 2 + 2) );
            setDeviceRows(deviceRows);
        } else {
            setDeviceRows([]);
        }
    }, [devices]);

    const getAvailableDevices = () => {
        NoaClient.get(
            "/api/site/available-device",
            (response) => {
                setDevices(response.data);
            }
        )
    }

    useEffect(() => {
        if(step == 1) {
            getAvailableDevices();
        } else if(step == 2) {
            addSite();
        }
    }, [step]);
 
	/**
	 * Renders a Button view to initiate Add operation on Networks.
	*/
    return (
        <Modal dimmer='inverted' open={showModal} onClose={closeModal}
            trigger={
                <Popup  content={toolTipMessage}
                    trigger={
                        <div style={{ display: "inline-block" }}>
                            <Button style={tbButton} 
                                    onClick={openModal}>
                                Create
                            </Button>
                        </div>
                    }
                    inverted
                    size='mini'
                />
            }>
            <Modal.Header>
                <Step.Group fluid >
                    <Step active={step===0} title="Site Details" />
                    <Step active={step===1} title="Add Locations" />
                </Step.Group>
            </Modal.Header>
            <Modal.Content>
                {
                step === 0 ? (
                    <div >
                    <Container style={{height: '400px'}}>
                    <Grid columns='2'>
                    <Grid.Column>
                        <Grid>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Site Id
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='siteId'
                                    value={site.siteId ? site.siteId : ''}
                                    onChange={e=>handleInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                VPN Flavor
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Dropdown clearable selection fluid required
                                        placeholder="Select"
										options={vpnFlavours} 
										onChange={
                                            (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'siteVpnFlavor')
                                        }
								/>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Bundling Type
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Dropdown clearable selection fluid required
										placeholder="Select"
										options={bundlingTypes} 
										onChange={
                                            (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'bundlingType')
                                        }
								/>
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                CE-VlanId
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    type='number'
                                    name='defaultCeVlanId'
                                    value={site.defaultCeVlanId ? site.defaultCeVlanId : ''}
                                    onChange={e=>handleInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                    <Grid.Column>
                    <Grid>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Management Type
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Dropdown clearable selection fluid required
										placeholder="Select"
										options={managementTypes} 
										onChange={
                                            (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'type', 'management')
                                        }
								/>
                            </Grid.Column>
                        </Grid.Row>
                        {typeof site.management !== 'undefined' && site.management !== null ? 
                        site.management[0].type === 'co-managed' ? 
                        <Grid>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Transport
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='transport'
                                    value={site.management[0].transport}
                                    onChange={e=>handleInputChange(e, 'management')}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Address
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='address'
                                    value={site.management[0].address}
                                    onChange={e=>handleInputChange(e, 'management')}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                        : '' : ''}
                        <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Protection Type
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Dropdown clearable selection fluid required
                                placeholder="Select"
                                options={loopPreventionTypes}
                                onChange={
                                    (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'protectionType', 'macLoopPrevention')
                                }
                            />
                        </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns='2'>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Frequency
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input 
                                    style={{width:'100%', height:'100%'}}
                                    name='frequency'
                                    value={site.macLoopPrevention ? site.macLoopPrevention[0].frequency : ''}
                                    onChange={e=>handleInputChange(e, 'macLoopPrevention')}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns='2'>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Retry Timer
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input 
                                    style={{width:'100%', height:'100%'}}
                                    name='retryTimer'
                                    value={site.macLoopPrevention ? site.macLoopPrevention[0].retryTimer : ''}
                                    onChange={e=>handleInputChange(e, 'macLoopPrevention')}
                                />
                            </Grid.Column>
                        </Grid.Row>
                    </Grid>
                    </Grid.Column>
                    </Grid>
                    </Container>
                    </div>)
                    : step == 1 || step == 2 ? (
                    <Grid columns='2'>
                    <Grid.Column>
                        <Grid>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Location Name
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='locationId'
                                    value={location.locationId ? location.locationId : ''}
                                    onChange={e=>handleLocationInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Address
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='address'
                                    value={location.address ? location.address : ''}
                                    onChange={e=>handleLocationInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Postal Code
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='postalCode'
                                    value={location.postalCode ? location.postalCode : ''}
                                    onChange={e=>handleLocationInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                State
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='state'
                                    value={location.state ? location.state : ''}
                                    onChange={e=>handleLocationInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                City
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='city'
                                    value={location.city ? location.city : ''}
                                    onChange={e=>handleLocationInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        <Grid.Row columns={2}>
                            <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                                Country Code
                            </Grid.Column>
                            <Grid.Column width='8' textAlign='left'>
                                <Input
                                    style={{ width: '100%', height: '100%' }}
                                    name='countryCode'
                                    value={location.countryCode ? location.countryCode : ''}
                                    onChange={e=>handleLocationInputChange(e)}
                                />
                            </Grid.Column>
                        </Grid.Row>
                        </Grid>
                    </Grid.Column>
                    <Grid.Column>
                        <div style={gridScroll}>
                        <Container style={{height: '400px'}}>
                        <Grid>
                            <Grid.Row columns='3'>
                                <Grid.Column />
                                <Grid.Column>
                                    <Header>Select Devices</Header>
                                </Grid.Column>
                                <Grid.Column />
                            </Grid.Row>
                            {Array.isArray(devices) ? 
                            devices.length ?
                            deviceRows.map((row,index) => (
                                <Grid.Row columns={2} key={index}>
                                    {row.map((device,idx) => (
                                        <Grid.Column key={idx} verticalAlign='middle' textAlign='left'>
                                            <Checkbox
                                                label={device.deviceId}
                                                checked={deviceId === device.deviceId}
                                                onChange={
                                                    (e, data) => {data.checked ? setDeviceId(data.label) : setDeviceId(null)}
                                                }
                                            />
                                        </Grid.Column>
                                    ))}
                                </Grid.Row>
                            ))
                            :<Grid.Row><Grid.Column> No Devices Found to Add </Grid.Column></Grid.Row> 
                            :<Grid.Row><Grid.Column> Loading... </Grid.Column></Grid.Row>}
                        </Grid>
                        </Container>
                        </div>
                    </Grid.Column>
                    </Grid>)
                : ''
                }
            </Modal.Content>
            <Modal.Actions>
                <div>
                    <Button style={tbButton} onClick={onPrevious} disabled={step === 0}>
                        Previous
                    </Button>
                    {step === 1 ? 
                    <Button style={tbButton} onClick={addLocation} >
                        Add Location
                    </Button> : ''}
                    <Button style={tbButton} onClick={onNext} >
                        {step === 1 || step === 2 ? 'Add Site' : 'Next'}
                    </Button>
                </div>
            </Modal.Actions>
        </Modal>
    );
}

const DeleteSites = (props) => {
    const selectedRows = props.selectedRows;
    const getSites = props.getSites;
    const setClearSelected = props.setClearSelected;

    const [showModal, setShowModal] = useState(false);
    const [buttonStatus, setButtonStatus] = useState(true);
    const [toolTipMessage, setToolTipMessage] = useState("Select to Enable");


	const openModal = () => {
		setShowModal(true);
	}

	const closeModal = () => {
		setShowModal(false);
		setClearSelected(true);
	}

	/**
	 * Invokes a REST request to Delete the User selcted Sites.
	 * Also fetches the updated list of Sites.
	 * 
	*/
	const deleteSites = () => {
        const siteIds= selectedRows;
		NoaClient.delete(
            "/api/site",
            siteIds,
			(response) => {
				noaNotification('success', 'Sites Deleted Successfully');
                getSites();
            })
        closeModal();
    }
    
    useEffect(()=>{
        setButtonAndToolTipStatus();
    },[selectedRows]);

    const setButtonAndToolTipStatus = () => {
        if(selectedRows.length < 1) {
            setButtonStatus(true);
            setToolTipMessage("Select to Enable");
        } else if (selectedRows.length >= 1) {
            setButtonStatus(false);
            setToolTipMessage("Click to Delete");
        }
    }
 
	/**
	 * Renders a Button view to initiate Delete operation on selected Sites and 
	 * the Modal view to seek User confirmation.
	*/
    return (
        <Modal dimmer='inverted' open={showModal} onClose={closeModal}
            trigger={
                <Popup  content={toolTipMessage}
                    trigger={
                        <div style={{ display: "inline-block" }}>
                            <Button style={tbButton} 
                                    onClick={openModal}
                                    disabled={buttonStatus}>
                                Delete
                            </Button>
                        </div>
                    }
                    inverted
                    size='mini'
                />
            }>
            <Modal.Header>Delete Sites</Modal.Header>
            <Modal.Content>
                <Grid columns='equal'>
                <Grid.Row>
                    <p>Are you sure you want to delete these Sites</p>
                </Grid.Row>
                <Grid.Row></Grid.Row>
                <Grid.Row>
                    <Grid.Column>
                    </Grid.Column>
                    <Grid.Column>
                        <Button style={tbButton}
                            content='Yes'
                            labelPosition='left'
                            icon='checkmark'
                            floated='right'
                            onClick={deleteSites}
                        />
                        <Button style={tbButton} content='No'
                            labelPosition='right'
                            icon='x'
                            floated='right'
                            onClick={closeModal}
                        />
                    </Grid.Column>
                </Grid.Row>
                </Grid>
            </Modal.Content>
        </Modal>
    );
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const SitesTable = (props) => {
    const sites = props.sites;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;
    const setClickedRowId = props.setClickedRowId;

    const [selectedRows, setSelectedRows] = useState({});

    useEffect(() => {
		setSelected(selectedRows);
	}, [selectedRows]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            )
        },
        {
            label: "1",
            Header: "Site Id",
            accessor: "siteId",
            filterable: true,
            hasAccordian: false
        },
        {
            label: "2",
            Header: "Vpn Flavor",
            accessor: "siteVpnFlavor",
            filterable: true,
            hasAccordian: false
        },
        {
            label: "3",
            Header: "Bundling Type",
            accessor: "bundlingType",
            filterable: false,
            hasAccordian: false
        },
        {
            label: "4",
            Header: "Ce Vlan Id",
            accessor: "defaultCeVlanId",
            filterable: false,
            hasAccordian: false
        }
    ]

    const onRowClick = (id) => {
        setClickedRowId(id);
    }

    return(
        <Grid.Row style={noBoxShadow}>
            <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                <NoaTable data={sites}
                    columns={columns}
                    selectedRows={selectedRows}
                    onSelectedRowsChange={setSelectedRows}
                    clearSelected={clearSelected}
                    onRowClick={onRowClick}
                    redirectable={true}
                />
            </Grid.Column>
        </Grid.Row>
    )
}

export default Sites