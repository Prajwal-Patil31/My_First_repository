import React, { Fragment, useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Modal,
    Button,
    Header,
    Container,
    Popup,
    Checkbox,
    Input,
    Dropdown,
    Divider,
    Tab
} from 'semantic-ui-react';

import { Link, useLocation } from "react-router-dom";

import 'semantic-ui-css/semantic.min.css';

import { dividerStyle, gridScroll, noBoxShadow, tbButton } from '../../constants';

import NoaTable from '../Widgets/NoaTable';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';
import BreadCrumb from '../Widgets/BreadCrumb';
import SiteDevices from './SiteDevices';
import SiteL2Vpn from './SiteL2Vpn';
import update from 'react-addons-update';
import SiteLocations from './SiteLocations';
import SiteL3Vpn from './SiteL3Vpn';


const SiteManagement = (props) => {
    const location = useLocation();
    const siteId = location.state.siteId;

    return (
        <Container>
            <Grid style={noBoxShadow} centered verticalAlign='middle'>
                <Grid.Row style={noBoxShadow}>
                <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                    <Segment style={noBoxShadow}>
                        <Grid columns={3} verticalAlign='middle'>
                            <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                                {<BreadCrumb />}
                                <Header size='medium'>Site Management: {siteId}</Header>
                            </Grid.Column>
                            <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                            </Grid.Column>
                            <Grid.Column width={6} textAlign='right' verticalAlign='middle'>
                            </Grid.Column>
                        </Grid>
                    </Segment>
                </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row style={noBoxShadow}>
                <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                    <Segment style={noBoxShadow}>
                        <Grid style={noBoxShadow}>
                            <Grid.Column style={noBoxShadow}>
                                <SiteConfig
                                    siteId={siteId}
                                />
                            </Grid.Column>
                        </Grid>
                    </Segment>
                    <Segment style={noBoxShadow}>
                        <Grid style={noBoxShadow}>
                            <Grid.Column style={noBoxShadow}>
                                <SiteComponenets
                                    siteId={siteId}
                                />
                            </Grid.Column>
                        </Grid>
                    </Segment>
                </Grid.Column>
                </Grid.Row>
            </Grid>
        </Container>
    )
}

const SiteConfig = (props) => {
    const siteId = props.siteId;
    const [site, setSite] = useState({});

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const vpnFlavours = [
        { 'key': "single", 'text': "Single", 'value': "site-vpn-flavor-single" },
        { 'key': "multi", 'text': "Multi", 'value': "site-vpn-flavor-multi" },
        { 'key': "nni", 'text': "NNI", 'value': "site-vpn-flavor-nni" }
    ]

    const bundlingTypes = [
        { 'key': "multi-svc", 'text': "Multi SVC", 'value': "multi-svc-bundling" },
        { 'key': "one2one", 'text': "One2One", 'value': "one2one-bundling" },
        { 'key': "all2one", 'text': "All2One", 'value': "all2one-bundling" }
    ]

    const managementTypes = [
        { 'key': "co", 'text': "Co Manged", 'value': "co-managed" },
        { 'key': "producer", 'text': "Producer Managed", 'value': "producer-managed" },
        { 'key': "consumer", 'text': "Consumer Managed", 'value': "consumer-managed" }
    ]

    const loopPreventionTypes = [
        { 'key': "shut", 'text': "shut", 'value': "shut" },
        { 'key': "trap", 'text': "Trap", 'value': "trap" }
    ]

    const getSite = () => {
        NoaClient.get(
            "/api/site/"+siteId,
            (response) => {
                setSite(response.data);
            }
        )
    }

    const updateSite = () => {
        const siteId = site.siteId;

        NoaClient.post(
            "/api/site/" + siteId,
            site,
			(response) => {
				noaNotification('success', 'Site Modified Successfully');
                getSite();
            })
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getSite();
    },[]);

    const handleInputChange = (e, subObject) => {
        const key = e.target.name;
        const value = e.target.value;
        if(subObject !== null && typeof subObject !== 'undefined') {
            setSite(prevState => ({
                ...prevState,
                [subObject]: (typeof prevState[subObject] !== 'undefined' && prevState[subObject] !== null ? 
                update(
                    prevState[subObject], {
                    [0]:{
                        $set:  {
                            ...prevState[subObject][0],
                            [key]: value
                        } 
                    }
                }): [{
                    [key]: value
                }])
            }))
        } else {
            setSite(prevState => ({
                ...prevState,
                [key]: value
            }));
        }
    }

    const handleDropDownChange = (e, value, key, subObject) => {
        if(subObject !== null && typeof subObject !== 'undefined') {
            setSite(prevState => ({
                ...prevState,
                [subObject]: (typeof prevState[subObject] !== 'undefined' && prevState[subObject] !== null ? 
                update(
                    prevState[subObject], {
                    [0]:{
                        $set:  {
                            ...prevState[subObject][0],
                            [key]: value
                        } 
                    }
                }): [{
                    [key]: value
                }])
            }))
        } else {
            setSite(prevState => ({
                ...prevState,
                [key]: value
            }));
        }
    }

    return(
        <Segment style={{height:'100%'}}>
            <Grid columns='3'>
                <Grid.Column textAlign='left'>
                    <Header>Site Details</Header>
                    <Grid>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle'  textAlign='left'>
                            VPN Flavor
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Dropdown clearable selection fluid required
                                placeholder="Select"
                                options={vpnFlavours}
                                value={site.siteVpnFlavor}
                                onChange={
                                    (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'siteVpnFlavor')
                                }
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Bundling Type
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Dropdown clearable selection fluid required
                                placeholder="Select"
                                options={bundlingTypes} 
                                value={site.bundlingType}
                                onChange={
                                    (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'bundlingType')
                                }
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Default CE-VlanId
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                name='defaultCeVlanId'
                                value={site.defaultCeVlanId}
                                onChange={e=>handleInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Actual Start Time
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                disabled={true}
                                name='actualSiteStart'
                                value={site.actualSiteStart}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Actual Stop Time
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                disabled={true}
                                name='actualSiteStop'
                                value={site.actualSiteStop}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    </Grid>
                </Grid.Column>
                <Grid.Column textAlign='left'>
                    <Header>Management</Header>
                    {typeof site.management !== 'undefined' && site.management !== null ?
                    <Grid>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Type
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Dropdown clearable selection fluid required
                                placeholder="Select"
                                options={managementTypes}
                                value={site.management[0].type}
                                onChange={
                                    (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'type', 'management')
                                }
                            />
                        </Grid.Column>
                    </Grid.Row>
                    {site.management[0].type === 'co-managed' ? 
                    <Grid>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Transport
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                name='transport'
                                value={site.management[0].transport}
                                onChange={e=>handleInputChange(e, 'management')}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Address
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                name='address'
                                value={site.management[0].address}
                                onChange={e=>handleInputChange(e, 'management')}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    </Grid>
                    :''}
                    </Grid>
                    :'' }
                </Grid.Column>
                <Grid.Column textAlign='left'>
                    <Header>Mac Loop Prevention</Header>
                    {typeof site.macLoopPrevention !== 'undefined' && site.macLoopPrevention !== null ?
                    <Grid>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Protection Type
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Dropdown clearable selection fluid required
                                placeholder="Select"
                                options={loopPreventionTypes}
                                value={site.macLoopPrevention[0].protectionType}
                                onChange={
                                    (e, {value}) => handleDropDownChange(e, value==='' ? null : value, 'protectionType', 'macLoopPrevention')
                                }
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Frequency
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                name='frequency'
                                value={site.macLoopPrevention[0].frequency}
                                onChange={e=>handleInputChange(e, 'macLoopPrevention')}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns='2'>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Retry Timer
                        </Grid.Column>
                        <Grid.Column width='8' textAlign='left'>
                            <Input 
                                style={{width:'100%', height:'100%'}}
                                name='retryTimer'
                                value={site.macLoopPrevention[0].retryTimer}
                                onChange={e=>handleInputChange(e, 'macLoopPrevention')}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    </Grid>
                    : '' }
                </Grid.Column>
            </Grid>
            <div align='right'>
                <Button style={tbButton} onClick={updateSite} > Update </Button>
            </div>
        </Segment>
    )
}

const SiteComponenets = (props) => {
    const siteId = props.siteId;

    const panes = [
        {
            menuItem: 'Devices',
            pane: {
                key: 'devices',
                content: (
                    <SiteDevices siteId={siteId}/>
                ),
            },
        },
        {
            menuItem: 'Locations',
            pane: {
                key: 'locations',
                content: (
                    <SiteLocations siteId={siteId}/>
                ),
            },
        },
        {
            menuItem: 'L2 Vpn',
            pane: {
                key: 'l2-vpn',
                content: (
                    <SiteL2Vpn siteId={siteId}/>
                ),
            },
        },
        {
            menuItem: 'L3 Vpn',
            pane: {
                key: 'l3-vpn',
                content: (
                    <SiteL3Vpn siteId={siteId}/>
                ),
            },
        }
    ]

    return(
        <Tab panes={panes} renderActiveOnly={false} />
    )
}

export default SiteManagement;