import React, { Fragment, useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Modal,
    Button,
    Header,
    Container,
    Popup,
    Checkbox,
    Input,
    Dropdown,
    Divider,
    Form,
    Tab,
    Step
} from 'semantic-ui-react';

import { Link, useLocation } from "react-router-dom";

import 'semantic-ui-css/semantic.min.css';

import { dividerStyle, gridScroll, noBoxShadow, tbButton } from '../../constants';

import NoaTable from '../Widgets/NoaTable';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';

function SiteDevices(props) {
    const siteId = props.siteId;
    const [deviceObjects, setDeviceObjects] = useState([]);
    const [selectedRows, setSelectedRows] = useState({});
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
            let selectedObj = {};
			for (let i = 0; i < sel.length; i++) {
                let deviceId = deviceObjects[sel[i]].deviceId;
                let locationId = deviceObjects[sel[i]].locationId;
                setSelectedRows(prevState => ({
                    ...prevState,
                    [deviceId] : locationId
                }));
            }
		}
    }

    const getDevices = () => {
        NoaClient.get(
            "/api/site/"+ siteId +"/device-location",
            (response) => {
                parseDeviceData(response.data);
            }
        )
    }

    const parseDeviceData = (responseObj) => {
        const keys = Object.keys(responseObj);
        const deviceObjects = [];
        keys.map((key, index) => {
            let deviceObject = {};
            deviceObject["deviceId"] = key;
            deviceObject["locationId"] = responseObj[key]["locationId"];
            deviceObject["address"] = responseObj[key]["address"];
            deviceObject["postalCode"] = responseObj[key]["postalCode"];
            deviceObject["state"] = responseObj[key]["state"];
            deviceObject["city"] = responseObj[key]["city"];
            deviceObject["countryCode"] = responseObj[key]["countryCode"];
            deviceObjects.push(deviceObject);
        })
        setDeviceObjects(deviceObjects);
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getDevices();
    }, []);

    return (
        <Container style={{height: '500px'}}>
            <div align='right'>
                <AddSiteDevices 
                    siteId={siteId}
                    getDevices={getDevices}
                    setClearSelected={setClearSelected}
                />
                {/* TODO: Modify Device Modal to change the Location of the Device */}
                {/* <Button disabled={true} style={tbButton}> Modify </Button> */}
                <ChangeLocation siteId={siteId} getDevices={getDevices} selectedRows={selectedRows} setClearSelected={setClearSelected}/>
                <RemoveSiteDevices
                    siteId={siteId}
                    deviceObjects={deviceObjects}
                    getDevices={getDevices}
                    selectedRows={selectedRows}
                    setClearSelected={setClearSelected}
                />
            </div>
            <DevicesTable 
                deviceObjects={deviceObjects} 
                setSelected={setSelected}
                clearSelected={clearSelected}
            />
        </Container>
    )
}

const AddSiteDevices = (props) => {
    const siteId = props.siteId;
    const getDevices = props.getDevices;
    const setClearSelected = props.setClearSelected;

    const [site, setSite] = useState({});
    const [location, setLocation] = useState({});
    const [locations, setLocations] = useState([]);
    const [locationsLength, setLocationsLength] = useState(0);
    const [locationDevicesObject, setLocationDevicesObject] = useState({});
    const [devices, setDevices] = useState({});
    const [deviceRows, setDeviceRows] = useState([]);
    const [deviceId, setDeviceId] = useState(null);
    const [locationRows, setLocationRows] = useState([]);
    const [locationId, setLocationId] = useState(null);

    const [showModal, setShowModal] = useState(false);
    const [step, setStep] = React.useState(0);

    const onNext = () => onChange(step + 1);
    const onPrevious = () => onChange(step - 1);

    const onChange = nextStep => {
        setStep(nextStep < 0 ? 0 : nextStep > 4 ? 4 : nextStep);
    };

	const openModal = () => {
        getAvailableDevices();
        getSite();
		setShowModal(true);
	}

	const closeModal = () => {
		setShowModal(false);
        setClearSelected(true);
        handleReset();
        setStep(0);
    }

    const handleReset = () => {
        setDevices({});
        setLocation({});
        setDeviceRows([]);
        setDeviceId(null);
        setLocationId(null);
    }

    const getSite = () => {
        NoaClient.get(
            "/api/site/"+siteId,
            (response) => {
                setSite(response.data);
            }
        )
    }

    useEffect(() => {
        if(step == 3) {
            addLocation();
        }
    }, [step]);

    useEffect(() => {
        if(site.locations) {
            if(site.locations.location) {
                const locations = site.locations.location;
                setLocationsLength(locations.length);                
                setLocations(locations);
                const rows = [...Array( Math.ceil(locations.length / 4) )];
                const locationRows = rows.map( (row, idx) => locations.slice(idx * 4, idx * 4 + 4) );
                setLocationRows(locationRows);
            }
        }
    }, [site])

    useEffect(() => {
        if(locations.length === locationsLength+1) {
            addToSite();
        }
    }, [locations])
    
    const addLocation = () => {
        const locationDeviceId = deviceId;
        setLocationDevicesObject({
            [location.locationId] : locationDeviceId
        });
        setLocations(prevState => [...prevState, location]);
    }

    const addToSite = () => {
        const modifiedSite = site;
        modifiedSite.locations = {
            "location": locations
        }

        NoaClient.post(
            "/api/site/"+siteId,
            modifiedSite,
			(response) => {
                addDevices();
            })
        closeModal();
    }

	const addDevices = () => {
		NoaClient.put(
            "/api/site/"+site.siteId+"/device",
            locationDevicesObject,
			(response) => {
                noaNotification('success', 'Devices Added Successfully');
                getDevices();
            })
        closeModal();
    }

    useEffect(() => {
        if(devices.length) {
            const rows = [...Array( Math.ceil(devices.length / 4) )];
            const deviceRows = rows.map( (row, idx) => devices.slice(idx * 4, idx * 4 + 4) );
            setDeviceRows(deviceRows);
        } else {
            setDeviceRows([]);
        }
    }, [devices]);

    const getAvailableDevices = () => {
        NoaClient.get(
            "/api/site/available-device",
            (response) => {
                setDevices(response.data);
            }
        )
    }

    const handleLocationInputChange = (e) => {
        const key = e.target.name;
        const value = e.target.value;
        
        setLocation(prevState => ({
            ...prevState,
            [key]: value
        }));
    }

    const locationCheckBoxHandler = (data) => {
        const locationId = data.label;
        if(data.checked) {
            setLocationId(locationId);
            setLocationDevicesObject(
                {
                    [locationId] : deviceId
                }
            )
        } else {
            setLocationId(null);
            setLocationDevicesObject({});
        }
    }
 
	/**
	 * Renders a Button view to initiate Delete operation on selected Sites and 
	 * the Modal view to seek User confirmation.
	*/
    return (
        <Modal dimmer='inverted' open={showModal} onClose={closeModal}
            trigger={
                <Popup  content={"Click to Add Device"}
                    trigger={
                        <div style={{ display: "inline-block" }}>
                            <Button style={tbButton} 
                                    onClick={openModal}
                            >
                                Add
                            </Button>
                        </div>
                    }
                    inverted
                    size='mini'
                />
            }>
            <Modal.Header>
                <Step.Group fluid >
                    <Step active={step===0} title="Select Devices" />
                    <Step active={step===1} title="Add to Existing Location" />
                    <Step active={step===2} title="Add to New Location" />
                </Step.Group>
            </Modal.Header>
            <Modal.Content>
                {step === 0 ? 
                <div style={gridScroll}>
                <Container style={{height: '400px'}}>
                <Grid>
                    {Array.isArray(devices) ? 
                    devices.length ?
                    deviceRows.map((row,index) => (
                        <Grid.Row columns={4} key={index}>
                            {row.map((device,idx) => (
                                <Grid.Column key={idx} verticalAlign='middle' textAlign='left'>
                                    <Checkbox
                                        label={device.deviceId}
                                        checked={deviceId === device.deviceId}
                                        onChange={
                                            (e, data) => {data.checked ? setDeviceId(data.label) : setDeviceId(null)}
                                        }
                                    />
                                </Grid.Column>
                            ))}
                        </Grid.Row>
                    ))
                    :<Grid.Row><Grid.Column> No Devices Found to Add </Grid.Column></Grid.Row> 
                    :<Grid.Row><Grid.Column> Loading... </Grid.Column></Grid.Row>}
                </Grid>
                </Container>
                </div>
                :
                step === 1 ? 
                <div style={gridScroll}>
                <Container style={{height: '400px'}}>
                <Grid>
                    {locationRows.map((row,index) => (
                        <Grid.Row columns={4} key={index}>
                            {row.map((location,idx) => (
                                <Grid.Column key={idx} verticalAlign='middle' textAlign='left'>
                                    <Checkbox
                                        label={location.locationId}
                                        disabled={locationId!==null && locationId !== location.locationId}
                                        checked={locationId === location.locationId}
                                        onChange={
                                            (e, data) => {locationCheckBoxHandler(data)}
                                        }
                                    />
                                </Grid.Column>
                            ))}
                        </Grid.Row>
                    ))}
                </Grid>
                </Container>
                </div> 
                : step === 2 || step === 3 ?
                <Container style={{height: '400px'}}>
                <Grid columns='3'>
                <Grid.Column width='4' />
                <Grid.Column width='8'>
                    <Grid>
                    <Grid.Row columns={2}>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Location Name
                        </Grid.Column>
                        <Grid.Column width='10' textAlign='left'>
                            <Input
                                style={{ width: '100%', height: '100%' }}
                                name='locationId'
                                value={location.locationId ? location.locationId : ''}
                                onChange={e=>handleLocationInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={2}>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Address
                        </Grid.Column>
                        <Grid.Column width='10' textAlign='left'>
                            <Input
                                style={{ width: '100%', height: '100%' }}
                                name='address'
                                value={location.address ? location.address : ''}
                                onChange={e=>handleLocationInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={2}>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Postal Code
                        </Grid.Column>
                        <Grid.Column width='10' textAlign='left'>
                            <Input
                                style={{ width: '100%', height: '100%' }}
                                name='postalCode'
                                value={location.postalCode ? location.postalCode : ''}
                                onChange={e=>handleLocationInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={2}>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            State
                        </Grid.Column>
                        <Grid.Column width='10' textAlign='left'>
                            <Input
                                style={{ width: '100%', height: '100%' }}
                                name='state'
                                value={location.state ? location.state : ''}
                                onChange={e=>handleLocationInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={2}>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            City
                        </Grid.Column>
                        <Grid.Column width='10' textAlign='left'>
                            <Input
                                style={{ width: '100%', height: '100%' }}
                                name='city'
                                value={location.city ? location.city : ''}
                                onChange={e=>handleLocationInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row columns={2}>
                        <Grid.Column width='6' verticalAlign='middle' textAlign='left'>
                            Country Code
                        </Grid.Column>
                        <Grid.Column width='10' textAlign='left'>
                            <Input
                                style={{ width: '100%', height: '100%' }}
                                name='countryCode'
                                value={location.countryCode ? location.countryCode : ''}
                                onChange={e=>handleLocationInputChange(e)}
                            />
                        </Grid.Column>
                    </Grid.Row>
                    </Grid>
                </Grid.Column>
                <Grid.Column width='4' />
                </Grid>
                </Container>
                : ''}
            </Modal.Content>
            <Modal.Actions>
                <div>
                    <Button style={tbButton} onClick={onPrevious} disabled={step === 0}>
                        Previous
                    </Button>
                    <Button style={tbButton} onClick={onNext} disabled={locationId !== null || deviceId === null} >
                        {step === 2 || step === 3 ? 'Add Devices' : 'Next'}
                    </Button>
                    {step === 1 ? 
                    <Button style={tbButton} onClick={addDevices} disabled={locationId === null} >
                        Add to Location
                    </Button>
                    :'' }
                </div>
            </Modal.Actions>
        </Modal>
    );
}

const ChangeLocation = (props) => {
    const siteId = props.siteId;
    const getDevices = props.getDevices;
    
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;
    
    const [deviceLocation, setDeviceLocation] = useState({});
    const [availableLocations, setAvailableLocations] = useState({});
    const [selections, setSelections] = useState(null);

    const [selectedLocation ,setSelectedLocation] = useState(null);

    const [showModal, setShowModal] = useState(false);
    
    const closeModal = () => {
        setShowModal(false);
        setClearSelected(true);
    }

    const getAvailableLocations = () => {
        const deviceId = selections;
        NoaClient.get(
            "/api/site/" + siteId + "/device/" + deviceId + "/available-location",
            (response) => {
                setAvailableLocations(response.data);
        });
    }

    const getDeviceLocation = () => {
        const deviceId = selections;
        NoaClient.get(
            "/api/site/" + siteId + "/device/" + deviceId + "/location",
            (response) => {
                setDeviceLocation(response.data);
        });
    }

    const openModal = () => {
        setShowModal(true);
        getDeviceLocation();
        getAvailableLocations();
    }

    useEffect(() => {
        let deviceIds = Object.keys(selectedRows);
        setSelections(deviceIds[0]);
    },[selectedRows]);

    const handleChange = (event, data) => {
        const target = event.target;
        const value = target.value;
        const name = target.name;

        setDeviceLocation({
            ...deviceLocation,
            [name]: value
        });
    }

    const checkboxHandler = (data, index) => {
        if (data.checked) {
            setSelectedLocation(data.name);
        } else {
            setSelectedLocation(null);
        }
    }

    const handleAddNewLoc = () => {
        const locationsBody = [deviceLocation.locationId,selectedLocation];
        const deviceId = selections;
        NoaClient.post(
            "/api/site/" + siteId + "/device/" + deviceId + "/location",
            locationsBody,
            (response) => {
                noaNotification("success","Added to New Location");
                getDevices();
        });
        closeModal();
    }

    const handleUpdateLoc = () => {
        const locationId = deviceLocation.locationId;
        NoaClient.post(
            "/api/site/" + siteId + "/location/" + locationId,
            deviceLocation,
            (response) => {
                noaNotification("success","Updated Location");
                getDevices();
        });
        closeModal();
    }

    return (
        <Modal dimmer='inverted' open={showModal} onClose={closeModal}
            trigger={<Button style={tbButton} onClick={openModal}>Change Location</Button>}>
            <Modal.Header></Modal.Header>
            <Modal.Content>
                <Container style={{height: '500px'}}>
                <Grid>
                    <Grid.Row columns={3}>
                        <Grid.Column width={10}>
                            <Grid>
                                <Grid.Column>
                                <Grid.Row>
                                    <Grid.Column>
                                        <Header size='medium'>Current Location:</Header>
                                    </Grid.Column>
                                </Grid.Row>
                                <Divider style={dividerStyle}/>
                                <Grid.Row>
                                    <Grid columns={1}>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                                Device Id:
                                            </Grid.Column>
                                            <Grid.Column width={8}>
                                                <Form.Input type='text' 
                                                            name='deviceId'
                                                            fluid 
                                                            value={selections ? selections :''}
                                                            disabled
                                                >
                                                </Form.Input>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                                Location Name:
                                            </Grid.Column>
                                            <Grid.Column width={8}>
                                                <Form.Input type='text' 
                                                            name='locationId' 
                                                            fluid
                                                            disabled
                                                            value={deviceLocation.locationId}
                                                >
                                                </Form.Input>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                                Address:
                                            </Grid.Column>
                                            <Grid.Column width={8}>
                                                <Form.Input type='text' 
                                                            fluid
                                                            name='address' 
                                                            value={deviceLocation.address}
                                                            onChange={handleChange}
                                                >
                                                </Form.Input>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                                Postal Code:
                                            </Grid.Column>
                                            <Grid.Column width={8}>
                                                <Form.Input type='text' 
                                                            name='postalCode' 
                                                            fluid
                                                            value={deviceLocation.postalCode}
                                                            onChange={handleChange}
                                                >
                                                </Form.Input>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                                City:
                                            </Grid.Column>
                                            <Grid.Column width={8}>
                                                <Form.Input type='text' 
                                                            name='city' 
                                                            fluid
                                                            value={deviceLocation.city}
                                                            onChange={handleChange}
                                                >
                                                </Form.Input>
                                            </Grid.Column>
                                        </Grid.Row>
                                        <Grid.Row columns={2}>
                                            <Grid.Column width={8}>
                                                Country Code:
                                            </Grid.Column>
                                            <Grid.Column width={8}>
                                                <Form.Input type='text' 
                                                            name='countryCode'
                                                            fluid
                                                            value={deviceLocation.countryCode}
                                                            onChange={handleChange}
                                                >
                                                </Form.Input>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Row>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                        <Grid.Column width={1}>
                            <Divider vertical style={dividerStyle}/>
                        </Grid.Column>
                        <Grid.Column width={5}>
                            <Grid>
                                <Grid.Row>
                                    <Grid.Column>
                                        <Header size='medium'>Existing Locations:</Header>
                                    </Grid.Column>
                                </Grid.Row>
                                <Divider style={dividerStyle}/>
                                <Grid.Row>
                                {Array.isArray(availableLocations) ? availableLocations.length ?
                                availableLocations.map((availableLocation,index) => (
                                    <Grid.Row>
                                        <Grid.Column>
                                            <Grid.Row>
                                            <Grid.Column>
                                                <Checkbox
                                                    key={index}
                                                    label={availableLocation.locationId}
                                                    name={availableLocation.locationId}
                                                    disabled={selectedLocation === null ? 
                                                        false : selectedLocation !== availableLocation.locationId}
                                                    checked={selectedLocation === availableLocation.locationId}
                                                    onChange={
                                                        (e, data) => checkboxHandler(data, index)
                                                    }
                                                />
                                            </Grid.Column>
                                            </Grid.Row>
                                        </Grid.Column>
                                    </Grid.Row>
                                )) 
                                : <Grid.Row><Grid.Column>No Locations Found</Grid.Column></Grid.Row> 
                                : <Grid.Row><Grid.Column>Loading</Grid.Column></Grid.Row>}
                                </Grid.Row>
                            </Grid>
                        </Grid.Column>
                    </Grid.Row>
                    <Grid.Row>
                    <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                        <Segment style={noBoxShadow}>
                            <Grid columns={3} verticalAlign='middle'>
                                <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                                </Grid.Column>
                                <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                                </Grid.Column>
                                <Grid.Column width={6} textAlign='right' verticalAlign='middle'>
                                    <Fragment>
                                        <div>
                                            <Button style={tbButton} onClick={handleUpdateLoc} disabled={selectedLocation !=null ? true : false}>Save</Button>
                                            <Button style={tbButton} onClick={closeModal}>Cancel</Button>
                                            <Button style={tbButton} onClick={handleAddNewLoc}>Add to New Location</Button>
                                        </div>
							        </Fragment>
                                </Grid.Column>
                            </Grid>
                        </Segment>
                    </Grid.Column>
                    </Grid.Row>
                </Grid>
                </Container>
            </Modal.Content>
        </Modal>
    )
}

const RemoveSiteDevices = (props) => {
    const siteId = props.siteId;
    const deviceObjects = props.deviceObjects;
    const getDevices = props.getDevices;
    const selectedRows = props.selectedRows;
    const setClearSelected = props.setClearSelected;

    const [showModal, setShowModal] = useState(false);
    const [buttonStatus, setButtonStatus] = useState(true);
    const [toolTipMessage, setToolTipMessage] = useState("Select to Enable");


	const openModal = () => {
		setShowModal(true);
	}

	const closeModal = () => {
		setShowModal(false);
		setClearSelected(true);
	}

	/**
	 * Invokes a REST request to Remove the User selcted Devices.
	 * Also fetches the updated list of Devices.
	 * 
	*/
	const removeDevices = () => {
        const deviceLocationObjects= selectedRows;
		NoaClient.delete(
            "/api/site/"+siteId+"/device",
            deviceLocationObjects,
			(response) => {
				noaNotification('success', 'Devices Removed Successfully');
                getDevices();
            })
        closeModal();
    }
    
    useEffect(()=>{
        setButtonAndToolTipStatus();
    },[selectedRows]);

    const setButtonAndToolTipStatus = () => {
        const selectedRowsLength = Object.keys(selectedRows).length;
        if(selectedRowsLength < 1) {
            setButtonStatus(true);
            setToolTipMessage("Select to Enable");
        } else if (selectedRowsLength >= 1) {
            setButtonStatus(false);
            setToolTipMessage("Click to Delete");
        }
    }
 
	/**
	 * Renders a Button view to initiate Delete operation on selected Sites and 
	 * the Modal view to seek User confirmation.
	*/
    return (
        <Modal dimmer='inverted' open={showModal} onClose={closeModal}
            trigger={
                <Popup  content={toolTipMessage}
                    trigger={
                        <div style={{ display: "inline-block" }}>
                            <Button style={tbButton} 
                                    onClick={openModal}
                                    disabled={buttonStatus}
                            >
                                Remove
                            </Button>
                        </div>
                    }
                    inverted
                    size='mini'
                />
            }>
            <Modal.Header>Remove Devices from Site</Modal.Header>
            <Modal.Content>
                <Grid columns='equal'>
                <Grid.Row>
                    <p>Are you sure you want to remove these Devices</p>
                </Grid.Row>
                <Grid.Row></Grid.Row>
                <Grid.Row>
                    <Grid.Column>
                    </Grid.Column>
                    <Grid.Column>
                        <Button style={tbButton}
                            content='Yes'
                            labelPosition='left'
                            icon='checkmark'
                            floated='right'
                            onClick={removeDevices}
                        />
                        <Button style={tbButton} content='No'
                            labelPosition='right'
                            icon='x'
                            floated='right'
                            onClick={closeModal}
                        />
                    </Grid.Column>
                </Grid.Row>
                </Grid>
            </Modal.Content>
        </Modal>
    );
}

const IndeterminateCheckbox = React.forwardRef(
	({ indeterminate, ...rest }, ref) => {
		const defaultRef = React.useRef()
		const resolvedRef = ref || defaultRef

		React.useEffect(() => {
			resolvedRef.current.indeterminate = indeterminate
		}, [resolvedRef, indeterminate])

		return ( <Checkbox ref={resolvedRef} {...rest}/> )
	}
)

const DevicesTable = (props) => {
    const deviceObjects = props.deviceObjects;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;

    const [selectedRows, setSelectedRows] = useState({});

    useEffect(() => {
		setSelected(selectedRows);
	}, [selectedRows]);

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: '35px'
        },
        {
            label: "1",
            Header: "Device Id",
            accessor: "deviceId",
            filterable: true,
            hasAccordian: false,
            width: '70px'
        },
        {
            label: "2",
            Header: "Location Name",
            accessor: "locationId",
            filterable: true,
            hasAccordian: false,
            width: '70px'
        },
        {
            label: "3",
            Header: "Address",
            accessor: "address",
            filterable: true,
            hasAccordian: false,
            width: '70px'
        },
        {
            label: "4",
            Header: "Postal Code",
            accessor: "postalCode",
            filterable: true,
            hasAccordian: false,
            width: '70px'
        },
        {
            label: "5",
            Header: "City",
            accessor: "city",
            filterable: true,
            hasAccordian: false,
            width: '70px'
        },
        {
            label: "6",
            Header: "State",
            accessor: "state",
            filterable: false,
            hasAccordian: false,
            width: '70px'
        },
        {
            label: "7",
            Header: "Country Code",
            accessor: "countryCode",
            filterable: false,
            hasAccordian: false,
            width: '70px'
        }
    ]

    return(
        <Grid>
        <Grid.Row style={noBoxShadow}>
            <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                <NoaTable data={deviceObjects}
                    columns={columns}
                    selectedRows={selectedRows}
                    onSelectedRowsChange={setSelectedRows}
                    clearSelected={clearSelected}
                />
            </Grid.Column>
        </Grid.Row>
        </Grid>
    )
}

export default SiteDevices;