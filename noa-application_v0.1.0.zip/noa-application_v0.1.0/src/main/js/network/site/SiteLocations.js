import React, { Fragment, useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Modal,
    Button,
    Header,
    Container,
    Popup,
    Checkbox,
    Input,
    Dropdown,
    Divider,
    Tab,
    Card
} from 'semantic-ui-react';

import 'semantic-ui-css/semantic.min.css';

import { dividerStyle, gridScroll, noBoxShadow, tbButton } from '../../constants';

import NoaTable from '../Widgets/NoaTable';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';

function SiteLocations(props) {
    const siteId = props.siteId;
    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const [locations, setLocations] = useState([]);
    const [locRows, setLocRows] = useState([]);
    const [selectedRows, setSelectedRows] = useState([]);

    const getLocations = () => {
        NoaClient.get(
            "/api/site/"+ siteId +"/location",
            (response) => {
                setLocations(response.data);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getLocations();
    }, []);

    const onLocationsChange = () => {
        const rows = [...Array( Math.ceil(locations.length / 5) )];
        const locationRows = rows.map( (row, idx) => locations.slice(idx * 5, idx * 5 + 5) );
        setLocRows(locationRows);
    }

    useEffect(() => {
        onLocationsChange();
    },[locations]);

    const checkBoxHandler = (index) => {
        const locationId = locations[index].locationId;

        if(selectedRows.includes(locationId)) {
            setSelectedRows(
                selectedRows.filter(prevState => prevState !== locationId)
            );
        } else {
            setSelectedRows(prevState => [...prevState, locationId]);
        }
    }


    return(
        <Container>
            <Grid style={noBoxShadow} centered verticalAlign='middle'>
                <Grid.Row style={noBoxShadow}>
                    <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                        <Segment style={noBoxShadow}>
                            <Grid columns={3} verticalAlign='middle'>
                                <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                                </Grid.Column>
                                <Grid.Column width={5} verticalAlign='middle' textAlign='left'>
                                </Grid.Column>
                                <Grid.Column width={6} textAlign='right' verticalAlign='middle'>
                                    <Fragment>
                                        {/* <AddNodes
                                            networkId={networkId}
                                            getNodes={getNodes}
                                            setClearSelected={setClearSelected}
                                        />
                                        <DeleteNodes
                                            networkId={networkId}
                                            nodeIds={nodeIds}
                                            getNodes={getNodes}
                                            setClearSelected={setClearSelected}
                                        />
                                        <ViewNodes 
                                            nodeIds={nodeIds}
                                            initializeRedirect={initializeRedirect}
                                        /> */}
							        </Fragment>
                                </Grid.Column>
                            </Grid>
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
                <Divider style={dividerStyle}/>
                <Grid.Row style={noBoxShadow}>
                <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                    <Segment style={noBoxShadow}>
                        <Grid style={noBoxShadow}>
                            <Grid.Column style={noBoxShadow}>
                            <Grid>
                            {locRows.length ? locRows.map((row,index) => (
                                <Grid.Row columns={5} key={index}>
                                    {row.map((location,idx) => (
                                        <Grid.Column key={idx} verticalAlign='middle' textAlign='left'>
                                            <Card
                                                header= {
                                                    <Checkbox 
                                                        label={location.locationId}
                                                        checked={selectedRows.includes(location.locationId)}
                                                    />
                                                }
                                                onClick={() => checkBoxHandler(index*5 + idx)}
                                            />
                                        </Grid.Column>
                                    ))}
                                </Grid.Row>
                            )) : "No Locations"}
                            </Grid>
                            </Grid.Column>
                        </Grid>
                    </Segment>
                </Grid.Column>
                </Grid.Row>
            </Grid>
        </Container>
    )
}

export default SiteLocations