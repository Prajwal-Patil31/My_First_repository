import React, { Fragment, useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Modal,
    Button,
    Header,
    Container,
    Popup,
    Checkbox,
    Input,
    Dropdown,
    Divider,
    Tab
} from 'semantic-ui-react';

import { Link, useLocation } from "react-router-dom";

import 'semantic-ui-css/semantic.min.css';

import { gridScroll, noBoxShadow, tbButton } from '../../constants';

import NoaTable from '../Widgets/NoaTable';
import NoaClient from '../../utils/NoaClient';
import noaNotification from '../Widgets/NoaNotification';
import { GlobalSpinnerContext } from '../Widgets/GlobalSpinner';
import { RouteRediretContext } from '../Widgets/RouteRedirect';

function SiteL3Vpn(props) {
    const siteId = props.siteId;
    const [l3Vpns, setL3Vpns] = useState([]);
    const [selectedRows, setSelectedRows] = useState({});
    const [clearSelected, setClearSelected] = useState(false);

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);

    const setSelected = (items) => {
        let sel = Object.keys(items);

		if(sel.length === 0) {
			setClearSelected(false);
		}

		if (Array.isArray(sel)) {
            const selections = [];
			for (let i = 0; i < sel.length; i++) {
				let id = l3Vpns[sel[i]].vpnId;
				selections.push(id);
            }
            setSelectedRows(selections);
		}
    }

    const getL3Vpns = () => {
        NoaClient.get(
            "/api/site/"+siteId+"/l3-vpn",
            (response) => {
                setL3Vpns(response.data);
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getL3Vpns();
    }, []);

    return (
        <Container style={{height: '500px'}}>
            <L3VpnTable 
                l3Vpns={l3Vpns} 
                setSelected={setSelected}
                clearSelected={clearSelected}
            />
        </Container>
    )
}

const L3VpnTable = (props) => {
    const l3Vpns = props.l3Vpns;
    const setSelected = props.setSelected;
    const clearSelected = props.clearSelected;

    const [selectedRows, setSelectedRows] = useState({});

    useEffect(() => {
		setSelected(selectedRows);
	}, [selectedRows]);

    const columns = [
        {
            label: "1",
            Header: "Vpn Name",
            accessor: "vpnId",
            filterable: true,
            hasAccordian: false
        },
        {
            label: "2",
            Header: "Address Type",
            accessor: "addressType",
            filterable: true,
            hasAccordian: false
        },
        {
            label: "3",
            Header: "Apply Label Mode",
            accessor: "applyLabelMode",
            filterable: false,
            hasAccordian: false
        },
        {
            label: "4",
            Header: "Prefix Limit Number",
            accessor: "prefixLimitNumber",
            filterable: false,
            hasAccordian: false
        },
        {
            label: "5",
            Header: "Routing Table Limit Number",
            accessor: "routingTableLimitNumber",
            filterable: false,
            hasAccordian: false
        }
    ]

    return(
        <Grid.Row style={noBoxShadow}>
            <Grid.Column style={noBoxShadow} verticalAlign='middle'>
                <NoaTable data={l3Vpns}
                    columns={columns}
                    selectedRows={selectedRows}
                    onSelectedRowsChange={setSelectedRows}
                    clearSelected={clearSelected}
                />
            </Grid.Column>
        </Grid.Row>
    )
}

export default SiteL3Vpn