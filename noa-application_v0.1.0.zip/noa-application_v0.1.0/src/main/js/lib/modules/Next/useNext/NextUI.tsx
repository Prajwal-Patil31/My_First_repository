import React, { CSSProperties } from "react";
import ReactDOM from "react-dom";
import Script from "react-load-script";
import { Button, Grid } from "semantic-ui-react";

class NextUI extends React.Component<
  { style: CSSProperties; init: () => void; HeaderComponent: () => JSX.Element,FooterComponent: () => JSX.Element},
  {}
> {

  constructor(props) {
    super(props);

  }

  shouldComponentUpdate(nextProps) {
    if (nextProps.style !== this.props.style) return true;

    return false; // Never rerender/re-load the script unless div style changes
  }

  render() {
    const HeaderComponent = this.props.HeaderComponent;
    const FooterComponent = this.props.FooterComponent;
    const popUpContainer = document.getElementById("main-container");
    
    return (
      <>
{/*         <Script
          url="https://cdn.jsdelivr.net/gh/jcace/next-bower@1.0.1/js/next.js"
          onError={() =>
            console.error(
              "Error loading NEXT UI framework. Check your network connectivity."
            )
          }
          onLoad={this.props.init}
        /> */}
        <Grid>
          <Grid.Row columns={1}>
            <Grid.Column width={16}>
              <div id="nxContainer" style={this.props.style}>
              </div>
              
            </Grid.Column>
          </Grid.Row>
          {popUpContainer != null ? ReactDOM.createPortal(<HeaderComponent/>, popUpContainer) : null}
          {popUpContainer != null ? ReactDOM.createPortal(<FooterComponent/>, popUpContainer) : null}
        </Grid>
        
        
      </>
    );
  }
}

export default NextUI;
