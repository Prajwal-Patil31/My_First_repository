import React, { useEffect, useState } from "react";
import { NextContainerProps, NxTopology } from "./NextTypes";
import cloneDeep from "clone-deep";
import "../../../next/css/next.min.css";
import NextUI from "./NextUI";

// Define 'nx' on the window object so window.nx... calls don't give type errors
declare global {
  interface Window {
    nx: any;
  }
}



/**
 * NeXT UI React Hook
 * @param {topologyConfig, eventHandlers, topologyData, style, callback}
 * @returns { NextUI, nxApp } NextUI: component to render. Use {} syntax ie <>{NextUI}</>. nxApp:
 */
const useNextUi = ({
  topologyConfig,
  eventHandlers,
  topologyData,
  style,
  callback,
  headerComponent,
  footerComponent
}: NextContainerProps) => {
  const [nxApp, setNxApp] = useState<NxTopology>();
  
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "../../../../lib/d3.v6.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    }
  }, []);

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "../../../../lib/topojson.v3.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    }
  }, []);

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "../../../../lib/next/js/next.js";
    script.async = true;
    document.body.appendChild(script);
    script.onload = () => initializeNxLibrary();
    return () => {
      document.body.removeChild(script);
    }
  }, []);
  /**
   * Set topology data whenever it changes, or if nxApp is re-loaded for some reason.
   */
  useEffect(() => {
    if (!nxApp) return;

    nxApp.setData(cloneDeep(topologyData));
    mountEventHandlers();
  }, [topologyData, nxApp]);

  /**
   * Ensure eventHandlers are kept up to date if they change or their closure variables change
   */
  useEffect(() => {
    if (!nxApp) return;
    mountEventHandlers();
  }, [eventHandlers]);

  const mountEventHandlers = () => {
    if (!nxApp || !eventHandlers) return;

    Object.entries(eventHandlers).forEach(([event, eventHandler]) => {
      nxApp.off(event); // We need to remove all event handlers first, because ".on" adds a NEW one, it doesn't REPLACE an existing one.
      nxApp.on(event, eventHandler)!;
    });
  };

  const initializeNxLibrary = () => {
    const tempApp = new window.nx.ui.Application();
    tempApp.container(document.getElementById("nxContainer"));

    // Instantiate a new nx Topology
    const nxTopologyApp = new window.nx.graphic.Topology(topologyConfig);

    nxTopologyApp.attach(tempApp); // Attach topology to div and display
    nxTopologyApp.data(topologyData); // Set the initial topology data

    // Save the instance into state
    setNxApp(nxTopologyApp);
    mountEventHandlers();

    if (callback) {
      callback(nxTopologyApp);
    }
  };

  return {
    NextUI: <NextUI init={initializeNxLibrary} style={style} HeaderComponent={headerComponent} FooterComponent={footerComponent}/>,
    nxApp
  };
};

export default useNextUi;
