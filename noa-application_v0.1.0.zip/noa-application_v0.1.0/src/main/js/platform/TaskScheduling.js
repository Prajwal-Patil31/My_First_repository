import React, { useContext, useEffect } from 'react';
import { MenuContext } from '../utility/MenuContext';

const TaskScheduling = () => {
    const menuContext = useContext(MenuContext);
    useEffect(() => {
        menuContext.setDisplayText("Task Scheduling");
		menuContext.setHideMenu(true);
    },[]);

    return(
        <div></div>
    )
}
export default TaskScheduling;