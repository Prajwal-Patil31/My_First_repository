/**@module UserGroups */

import React, { useContext, useEffect, useState } from 'react';

import {
    Grid,
    Segment,
    Button,
    Checkbox,
    Icon,
    Accordion,
    Input
} from 'semantic-ui-react';

import { 
    cardLayout, titleText,noMarginLR, 
    noMarginTB, accordionTitle, applyButton, 
    cancelButton, completeWidth, fullHeight, 
    formParameter, inputBoxStyle 
} from '../../constants';

import 'semantic-ui-css/semantic.min.css';

import NoaTable from '../../widget/NoaTable';
import NoaClient from '../../utility/NoaClient';
import { GlobalSpinnerContext } from '../../utility/GlobalSpinner';
import { RouteRediretContext } from '../../utility/RouteRedirect';
import { NoaContainer } from '../../widget/NoaWidgets';
import { DropdownIcon } from '../../widget/NoaIcons';
import NoaFilter from '../../widget/NoaFilter';
import { useRouter } from '@uirouter/react';

const ConfigurationRecord = (props) => {
    const [rollbacks, setRollbacks] = useState([]);

    const [pageSize, setPageSize] = useState(5);
    const [totalPages, setTotalPages] = useState(0);
    const [totalEntries, setTotalEntries] = useState(0);
    const [columns, setColumns] = useState({});
    const [filters, setFilters] = useState({});

    const [indexesState, setIndexesState] = useState({ activeIndexes: [0] });

    const context = useContext(GlobalSpinnerContext);
    const redirectContext = useContext(RouteRediretContext);
    const router = useRouter();
    const [selectedRows, setSelectedRows] = useState([]);
    const [clearSelected, setClearSelected] = useState(false);

    const setSelected = (items) => {
        let sel = Object.keys(items);

        if (sel.length === 0) {
            setClearSelected(false);
        }

        if (Array.isArray(sel)) {
            const selections = [];
            for (let i = 0; i < sel.length; i++) {
                let id = rollbacks[sel[i]].rollbackId;
                selections.push(id);
            }
            setSelectedRows(selections);
        }
    }

    const getRollbacks = (filterObj) => {
        context.setRenderLocation(["configurational-record-list"]);
        NoaClient.post(
            "/api/platform/config/rollback",
            filterObj,
            (response) => {
                let responseData = response.data;
                let parsedConfigurations = [];
                responseData.data.map((item) => {
                    let resourceType = item["resource"];
                    item["resource"] = resourceType.replace('org.onap.aai.domain.yang.','')
                    parsedConfigurations.push(item)
                })
                setRollbacks(parsedConfigurations);
                setTotalPages(responseData.page.maxPages);
                setTotalEntries(responseData.page.totalEntries);
            }
        )
    }

    const getFilterCriteria = () => {
        NoaClient.get(
            "/api/platform/config/rollback/filter",
            (response) => {
                let responseData = response.data;
                if(responseData.columns !== null) {
                    setColumns(responseData.columns);
                }
                if(responseData.filters !== null) {
                    setFilters(responseData.filters);
                }
            }
        )
    }

    useEffect(() => {
        NoaClient(context, redirectContext);
        getFilterCriteria();
        router.stateService.go('default');
        let filterCriteria = {}

        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        filterCriteria["filters"] = {"rollback-unit":{}};
        filterCriteria["pagination"] = paginationObj;
        filterCriteria["sort"] = null;
        getRollbacks(filterCriteria);
    },[]);

    const handleClick = (e, titleProps) => {
        const { index } = titleProps;
        const activeIndexes = indexesState.activeIndexes;
        const newIndex = activeIndexes;
        const currentIndexPosition = activeIndexes.indexOf(index);
        if (currentIndexPosition > -1) {
          newIndex.splice(currentIndexPosition, 1);
        } else {
          newIndex.push(index);
        }
        setIndexesState(prevState => ({
            ...prevState,
            activeIndexes: newIndex
        }));
    }

    const activeIndex = indexesState.activeIndexes;

    return (
        <NoaContainer style={Object.assign({},fullHeight,completeWidth)}>
            <Grid style={fullHeight} stackable>
                <Grid.Row columns={1}>
                    <Grid.Column width={16}>
                        <Segment style={Object.assign({},cardLayout,fullHeight)}>
                            <Accordion>
                                <Accordion.Title
                                    active={activeIndex.includes(0)}
                                    index={0}
                                    onClick={handleClick}
                                    style={Object.assign({textAlign:'left'},accordionTitle)}
                                >
                                    <DropdownIcon />
                                    Archive Settings
                                </Accordion.Title>
                                <Accordion.Content active={activeIndex.includes(0)}>
                                    <ArchiveSettings />
                                </Accordion.Content>
                                <Accordion.Title
                                    active={activeIndex.includes(1)}
                                    index={1}
                                    onClick={handleClick}
                                    style={Object.assign({textAlign:'left'},accordionTitle)}
                                >
                                    <DropdownIcon />
                                    Change Records
                                </Accordion.Title>
                                <Accordion.Content active={activeIndex.includes(1)}>
                                    <RollbackRecordsTable rollbacks={rollbacks} getRollbacks={getRollbacks}
                                                            columns={columns}
                                                            filters={filters}
                                                            pageSize={pageSize}
                                                            totalPages={totalPages}
                                                            setPageSize={setPageSize}
                                                            totalEntries={totalEntries}
                                    />
                                </Accordion.Content>
                            </Accordion>
                        </Segment>
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const ArchiveSettings = () => {
    return(
        <Grid>
            <Grid.Row columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={3}>
                        <Grid.Column width={1}></Grid.Column>
                        <Grid.Column width={14}>
                            <Grid columns={3} stackable>
                                <Grid.Column computer={7} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid stackable columns={3}>
                                                    <Grid.Column width={6}></Grid.Column>
                                                    <Grid.Column width={8} textAlign='right'>
                                                        <p style={formParameter}>Enable Configuration Archive</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={2} textAlign='left'>
                                                        <Checkbox toggle={true} checked={true}/>
                                                    </Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                                <Grid.Column computer={2} tablet={16} mobile={16}></Grid.Column>
                                <Grid.Column computer={7} tablet={16} mobile={16}>
                                    <Grid>
                                        <Grid.Row columns={1}>
                                            <Grid.Column width={16}>
                                                <Grid stackable columns={3}>
                                                    <Grid.Column width={8} textAlign='left'>
                                                        <p style={formParameter}>Num of Records to Archive</p>
                                                    </Grid.Column>
                                                    <Grid.Column width={4} textAlign='left'>
                                                        <Input>
                                                            <input style={inputBoxStyle}></input>
                                                        </Input>
                                                    </Grid.Column>
                                                    <Grid.Column width={4}></Grid.Column>
                                                </Grid>
                                            </Grid.Column>
                                        </Grid.Row>
                                    </Grid>
                                </Grid.Column>
                            </Grid>
                        </Grid.Column>
                        <Grid.Column width={1}></Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
            <Grid.Row style={{paddingTop: "2em"}} columns={1}>
                <Grid.Column width={16}>
                    <Grid columns={2}>
                        <Grid.Column width={8} textAlign='right'>
                            <Button style={applyButton}>Update</Button>
                        </Grid.Column>
                        <Grid.Column width={8} textAlign='left'>
                            <Button style={cancelButton}>Cancel</Button>
                        </Grid.Column>
                    </Grid>
                </Grid.Column>
            </Grid.Row>
        </Grid>
    )
}

const IndeterminateCheckbox = React.forwardRef(
    ({ indeterminate, ...rest }, ref) => {
        const defaultRef = React.useRef()
        const resolvedRef = ref || defaultRef

        React.useEffect(() => {
            resolvedRef.current.indeterminate = indeterminate
        }, [resolvedRef, indeterminate])

        return (<Checkbox ref={resolvedRef} {...rest} />)
    }
)

const RollbackRecordsTable = (props) => {
    const rollbacks = props.rollbacks;
    const getRollbacks = props.getRollbacks;

    const pageSize = props.pageSize;
    const totalPages = props.totalPages;
    const setPageSize = props.setPageSize;
    const totalEntries = props.totalEntries;
    //const columns = props.columns;
    const filters = props.filters;

    const [selections,setSelections] = useState({});
    const [appliedFilters, setAppliedFilters] = useState({"rollback-unit" : {}});

    const columns = [
        {
            id: 'selection',
            Header: ({ getToggleAllPageRowsSelectedProps }) => (
                <IndeterminateCheckbox {...getToggleAllPageRowsSelectedProps()} />
            ),
            Cell: ({ row }) => (
                <IndeterminateCheckbox  {...row.getToggleRowSelectedProps()} />
            ),
            width: 1
        },
        {
            label: "1",
            Header: "Resource",
            accessor: "resource",
            width: 2
        },
        {
            label: "2",
            Header: "Resource Id",
            accessor: "resourceId",
            width: 2
        },
        {
            label: "3",
            Header: "Operation",
            accessor: "operation",
            width: 2
        },
        {
            label: "3",
            Header: "Description",
            accessor: "description",
            width: 4
        },
        {
            label: "7",
            Header: "Time Stamp",
            accessor: "timeStamp",
            width: 4
        },
        {
            label: "9",
            Header: "Status",
            Cell: ({row}) => (
                renderBoolean(row,"valid")
            ),
            width: 3
        }
    ]
    const [selectedRows, setSelectedRows] = useState([]);

    const handlePagination = (number) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = number

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;

        getRollbacks(filterObj)
    }

    const fetchFilteredData = (body) => {
        let paginationObj = {}
        paginationObj["size"] = pageSize
        paginationObj["number"] = 1
        
        body["pagination"] = paginationObj;

        if(body.filters == null) {
            let defaultFilter = {"rollback-unit" : {}}
            body["filters"] = defaultFilter
            setAppliedFilters(defaultFilter)
        }
        getRollbacks(body)
    }

    const handlePageSize = (value) => {
        setPageSize(value)
        let paginationObj = {}
        paginationObj["size"] = value
        paginationObj["number"] = 1

        let filterObj = {}
        filterObj["filters"] = appliedFilters;
        filterObj["pagination"] = paginationObj;
        filterObj["sort"] = null;
        getRollbacks(filterObj)
    }
    
    const fetchData = () => fetchFilteredData({"filters":null})

    return (
        <NoaContainer style={{ width: "100%", height: "100%", paddingLeft: "2em", paddingRight: "2em", paddingTop: "1em", paddingBottom: "1em" }}>
            <Grid style={Object.assign({ height: "100%" }, noMarginTB, noMarginLR)}>
                <Grid.Row>
                    <Grid.Column verticalAlign='middle'>
                        <Grid columns={2} verticalAlign='middle'>
                            <Grid.Column width={3} verticalAlign='bottom' textAlign='left'>
                                <p style={titleText}>Records List</p>
                            </Grid.Column>
                            <Grid.Column width={13} verticalAlign='bottom' textAlign='right'>
                                <NoaFilter filters={filters} getData={fetchFilteredData} setAppliedFilters={setAppliedFilters}/>
                            </Grid.Column>
                        </Grid>
                    </Grid.Column>
                </Grid.Row>
                <Grid.Row columns={1}>
                    <Grid.Column width={16} verticalAlign='middle'>
                        <NoaTable data={rollbacks}
                            columns={columns}
                            selectedRows={selectedRows}
                            onSelectedRowsChange={setSelectedRows}
                            selectedPageSize={pageSize}
                            handlePagination={handlePagination}
                            totalPages={totalPages}
                            handlePageSize={handlePageSize}
                            totalEntries={totalEntries}
                            resource="Configurational Records" 
                            fetchData={fetchData} 
                            location="configurational-record-list"
                        />
                    </Grid.Column>
                </Grid.Row>
            </Grid>
        </NoaContainer>
    )
}

const renderBoolean = (row,key) => {
    const enabledState = row.original[key];
    return (
       <>
        {enabledState == true ? 
            <Icon color={"green"} size='large' name='arrow alternate circle up outline' />
            : 
            <Icon color={"red"} size='large' name='arrow alternate circle down outline' />
        }
       </>
    )
}

export default ConfigurationRecord;