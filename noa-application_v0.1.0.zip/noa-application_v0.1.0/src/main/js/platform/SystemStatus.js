import React, { useContext, useEffect } from 'react';
import { MenuContext } from '../utility/MenuContext';

const SystemStatus = () => {
    const menuContext = useContext(MenuContext);
    useEffect(() => {
        menuContext.setDisplayText("System Status");
		menuContext.setHideMenu(true);
    },[]);
    return(
        <div></div>
    )
}
export default SystemStatus;