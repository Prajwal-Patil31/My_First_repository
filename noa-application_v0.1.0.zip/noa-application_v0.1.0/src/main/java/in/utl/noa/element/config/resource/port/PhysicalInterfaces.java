package in.utl.noa.element.config.resource.port;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.element.config.resource.port.model.InterfaceStats;
import in.utl.noa.element.config.resource.port.model.InterfaceStatsRepository;
import in.utl.noa.element.service.DeviceOperationService;
//import in.utl.noa.service.DeviceRepository;
import in.utl.noa.element.service.EdgeRouterService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;

import org.onap.aai.domain.yang.Attributes;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/interface")
public class PhysicalInterfaces {
    private static Logger logger = Logger.getLogger(PhysicalInterfaces.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    /*
     * @Autowired DeviceRepository deviceRepo;
     */

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    InterfaceStatsRepository interfaceStatsRepo;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<IetfInterface>> getInterfaces(@PathVariable("deviceId") String deviceId)
            throws JsonMappingException, JsonProcessingException, ParseException {

        List<IetfInterface> ietfInterfaces = new ArrayList<IetfInterface>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.IETF_INTERFACE))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            IetfInterface interfaceBody = mapper.readValue(interfaceObj.toString(), IetfInterface.class);
            ietfInterfaces.add(interfaceBody);
        }

        // deviceService.createVlanBaseEntry(deviceId);
        // deviceService.createIfEntry(deviceId);
        // deviceService.createStaticVlan(deviceId);
        // deviceService.deleteInterfaces(deviceId);

        return ResponseEntity.status(HttpStatus.OK).body(ietfInterfaces);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getInterfaceFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "ietf-interface");

        Map<String, Object> columns = new HashMap<>();
        columns.put("interfaceName", "Interface Name");
        columns.put("interfaceType", "Interface Type");
        columns.put("layer", "Layer");
        columns.put("ipAddress", "IP Address");
        columns.put("speed", "Speed");
        columns.put("adminStatus", "Admin Status");
        columns.put("enabled", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getInterfaceList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject interfaces = filterService.queryByFilter(requestBody, "ietf-interface");
        return ResponseEntity.status(HttpStatus.OK).body(interfaces);
    }

    @GetMapping(value = "/{interfaceId}")
    public ResponseEntity<IetfInterface> getInterfaceById(@PathVariable("deviceId") String deviceId,
            @PathVariable("interfaceId") String interfaceId) {

        IetfInterface ietfInterface = new IetfInterface();
        if (deviceId != null && interfaceId != null) {

            AAIResourceUri ietfInterfaceUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

            if (rClient.exists(ietfInterfaceUri)) {
                Optional<IetfInterface> fetchedIetfInterface = rClient.get(IetfInterface.class, ietfInterfaceUri);
                ietfInterface = fetchedIetfInterface.get();
                return ResponseEntity.status(HttpStatus.OK).body(ietfInterface);
            }

        }
        return ResponseEntity.status(HttpStatus.OK).body(ietfInterface);
    }

    @PutMapping()
    public ResponseEntity<String> addInterfaces(@PathVariable("deviceId") String deviceId,
            @RequestBody IetfInterface ietfInterface) throws BulkProcessFailed {

        Integer interfaceIndex = ietfInterface.getIfIndex();
        String interfaceId = String.valueOf(interfaceIndex);
        ietfInterface.setInterfaceId(interfaceId);
        ietfInterface.setDeviceId(deviceId);

        if (ietfInterface.getVlanPortType() == null) {
            ietfInterface.setVlanPortType("hybrid-port");
        }

        if (ietfInterface.isEnabled() == null) {
            ietfInterface.setEnabled(false);
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface",
                ietfInterface.getInterfaceId(), "Network Device", deviceId);

        ietfInterface.setIfAlias(ietfInterface.getInterfaceName());

        AAIResourceUri interfaceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

        if (!rClient.exists(interfaceUri)) {
            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(interfaceUri, ietfInterface);
            transactions.execute();
            description = ietfInterface.getInterfaceId() + " Interface has been Created.";

            JSONObject interfaceObj = rollbackHandler.getJsonObject(ietfInterface);

            List<Attributes> attributes = rollbackHandler.createAttributes(interfaceObj, null, null);
            String resourceUri = interfaceUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.IetfInterface", interfaceId,
                    resourceUri, deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.CREATED;
            addInterfaceStats(ietfInterface.getInterfaceId(), deviceId, ietfInterface.getIpAddress());
        } else {
            description = ietfInterface.getInterfaceId() + " Interface Already Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Interface",
                NoaEvents.CREATE_INTERFACE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    public void addInterfaceStats(String interfaceId, String deviceId, String ipAddress) {
        InterfaceStats statsBody = new InterfaceStats();
        String statsId = UUID.randomUUID().toString();
        statsBody.setStatsId(statsId);
        statsBody.setInterfaceId(interfaceId);
        statsBody.setDeviceId(deviceId);
        statsBody.setForwardingEnabled(true);
        statsBody.setSpeed("0mbps");
        statsBody.setPacketsReceived("0");
        statsBody.setPacketsTransferred("0");
        statsBody.setIpAddress(ipAddress);
        statsBody.setStatus(true);

        Date date = new Date();
        try {
            date = DATE_FORMAT.parse(DATE_FORMAT.format(date));
        } catch (java.text.ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        statsBody.setTimestamp(date);
        interfaceStatsRepo.save(statsBody);
    }

    @PostMapping(value = "/{interfaceId}")
    public ResponseEntity<String> updateInterface(@PathVariable("deviceId") String deviceId,
            @PathVariable("interfaceId") String interfaceId, @RequestBody IetfInterface interfaceBody)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface", interfaceId,
                "Network Device", deviceId);

        AAIResourceUri interfaceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

        AAITransactionalClient transactions;
        if (rClient.exists(interfaceUri)) {
            IetfInterface updInterface = rClient.get(IetfInterface.class, interfaceUri).get();
            transactions = rClient.beginTransaction().update(interfaceUri, interfaceBody);
            transactions.execute();
            description = interfaceBody.getInterfaceId() + " Interface has been Updated.";

            JSONObject interfaceObj = rollbackHandler.getJsonObject(updInterface);

            List<Attributes> attributes = rollbackHandler.createAttributes(interfaceObj, null, null);
            String resourceUri = interfaceUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.IetfInterface", interfaceId,
                    resourceUri, deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = interfaceBody.getInterfaceId() + " Interface Doesn't Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Interface",
                NoaEvents.MODIFY_INTERFACE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteInterface(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> interfaceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface", null, "Network Device",
                deviceId);

        if (deviceId != null) {
            for (String interfaceId : interfaceIds) {
                resourceMetadata.setResourceId(interfaceId);
                AAIResourceUri ietfInterfaceUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

                if (rClient.exists(ietfInterfaceUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(ietfInterfaceUri);
                    transactions.execute();
                    description = interfaceId + " Interface has been Deleted";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "Interface",
                            NoaEvents.DELETE_INTERFACE.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = interfaceId + " Interface Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "Interface",
                            NoaEvents.DELETE_INTERFACE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            }
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Removed Interfaces Successfully");
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Interface",
                NoaEvents.DELETE_INTERFACE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }
}
