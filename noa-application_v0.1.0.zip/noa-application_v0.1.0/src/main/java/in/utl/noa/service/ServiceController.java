package in.utl.noa.service;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.Endpoint;
import org.onap.aai.domain.yang.L2Vpn;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.NNode;
import org.onap.aai.domain.yang.L3Vpn;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.Path;
import org.onap.aai.domain.yang.Pathhop;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.VpnService;
import org.onap.aai.domain.yang.VpnServices;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;

import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.service.dto.ServiceDTO;
import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/service")
public class ServiceController {
    private static Logger logger = Logger.getLogger(ServiceController.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping(value = "/overview")
    public ResponseEntity<JSONObject> getServiceOverview() throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject activeServicesObj = (JSONObject) obj.get("active-services");

        return ResponseEntity.ok(activeServicesObj);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getServiceFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "vpn-service");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("serviceName", "Service Name");
        columns.put("serviceType", "Service Type");
        columns.put("subscriberName", "Subscriber Name");
        columns.put("serviceRate", "Service Rate");
        columns.put("endPoints", "Endpoints Count");
        columns.put("paths", "Paths Count");
        columns.put("adminStatus", "Admin Status");
        columns.put("enabled", "Service Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getServiceList(@RequestBody RequestBodyDTO requestBody)
            throws JsonProcessingException, ParseException {
        JSONObject services = filterService.queryByFilter(requestBody, "vpn-service");
        return ResponseEntity.status(HttpStatus.OK).body(services);
    }

    @GetMapping()
    public ResponseEntity<List<VpnService>> getServices() {
        List<VpnService> vpnServices = new ArrayList<VpnService>();

        AAISimplePluralUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnServices());

        if (rClient.exists(vpnServiceUri)) {

            VpnServices vpnServiceList = rClient.get(VpnServices.class, vpnServiceUri).get();

            vpnServices = vpnServiceList.getVpnService();

            return ResponseEntity.status(HttpStatus.OK).body(vpnServices);
        }
        return ResponseEntity.status(HttpStatus.OK).body(vpnServices);
    }

    @GetMapping(value = "/{serviceId}", produces = "application/json")
    public ResponseEntity<VpnService> getVpnServiceById(@PathVariable("serviceId") String serviceId) {

        VpnService vpnService = new VpnService();

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId)).depth(Depth.TWO);
        if (rClient.exists(vpnServiceUri)) {
            vpnService = rClient.get(VpnService.class, vpnServiceUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(vpnService);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(vpnService);
    }

    @PutMapping()
    public ResponseEntity<String> createVpnService(@RequestBody ServiceDTO vpnService) throws BulkProcessFailed {

        String serviceId = UUID.randomUUID().toString();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Service Template", serviceId, null,
                null);

        vpnService.setServiceStatus(true);
        vpnService.setEndpointsCount(0);
        vpnService.setPathsCount(0);
        vpnService.setAdminStatus(false);
        VpnService service = setServiceAttributes(vpnService);
        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        AAITransactionalClient transactions = null;
        if (service.getServiceType().equals("L3 VPN")) {

            L3Vpn l3vpn = new L3Vpn();
            l3vpn.setVpnId(serviceId);
            l3vpn.setAddressType(vpnService.getAddressType());
            l3vpn.setApplyLabelMode(vpnService.getApplyLabelMode());
            l3vpn.setPrefixLimitNumber(vpnService.getPrefixLimitNumber());
            l3vpn.setRoutingTableLimitNumber(vpnService.getRoutingTableLimitNumber());

            AAIResourceUri l3vpnUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.service().l3Vpn(serviceId));
            transactions = rClient.beginTransaction().create(vpnServiceUri, service).create(l3vpnUri, l3vpn)
                    .connect(vpnServiceUri, l3vpnUri);
            transactions.execute();

        } else {

            L2Vpn l2vpn = new L2Vpn();
            l2vpn.setVpnId(serviceId);
            l2vpn.setVpnName(service.getServiceName());
            l2vpn.setInstanceType(vpnService.getInstanceType());
            l2vpn.setServiceType(vpnService.getInstanceType());
            l2vpn.setDiscoveryType(vpnService.getDiscoveryType());
            l2vpn.setSignalingType(vpnService.getSignalingType());
            l2vpn.setMtu(vpnService.getMtu());
            l2vpn.setMacAgingTimer(vpnService.getMacAgingTimer());

            AAIResourceUri l2vpnUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.service().l2Vpn(serviceId));
            transactions = rClient.beginTransaction().create(vpnServiceUri, service).create(l2vpnUri, l2vpn)
                    .connect(vpnServiceUri, l2vpnUri);
            transactions.execute();

        }
        description = serviceId + " Service Created Successfully";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;

        auditLogger.addAuditLog(rClient, description, "Service Management", "Service Template",
                NoaEvents.CREATE_VPN_SERVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    private VpnService setServiceAttributes(ServiceDTO serviceDto) {
        VpnService service = new VpnService();

        service.setServiceId(serviceDto.getServiceId());
        service.setServiceName(serviceDto.getServiceName());
        service.setServiceType(serviceDto.getServiceType());
        service.setSubscriberName(serviceDto.getSubscriberName());
        service.setEndpointsCount(0);
        service.setPathsCount(0);
        service.setServiceRate(serviceDto.getServiceRate());
        service.setServiceStatus(serviceDto.isServiceStatus());
        service.setAdminStatus(serviceDto.isAdminStatus());
        return service;
    }

    @PostMapping(value = "/{serviceId}", produces = "application/json")
    public ResponseEntity<String> updateVpnService(@PathVariable("serviceId") String serviceId,
            @RequestBody VpnService updatedVpnService) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Service Template", serviceId, null,
                null);

        if (serviceId != null) {
            AAIResourceUri vpnServiceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));
            if (rClient.exists(vpnServiceUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().update(vpnServiceUri, updatedVpnService);

                transactions.execute();
                description = serviceId + " Service Template Updated Successfully";
                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = "Service Template with VPN Id " + serviceId + " Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null VPN Id.";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "Service Template",
                NoaEvents.MODIFY_VPN_SERVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteVpnServices(@RequestBody List<String> serviceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String serviceId : serviceIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Service Template", serviceId, null,
                    null);
            if (serviceId != null) {
                AAIResourceUri vpnServiceUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));
                if (rClient.exists(vpnServiceUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(vpnServiceUri);
                    transactions.execute();
                    description = "Service Template with VPN Id" + serviceId + "has been Deleted.";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "Service Template",
                            NoaEvents.DELETE_VPN_SERVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = "Service Template with VPN Id" + serviceId + "Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "Service Template",
                            NoaEvents.DELETE_VPN_SERVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null VPN Id.";
                auditLogger.addAuditLog(rClient, description, "Service Management", "Service Template",
                        NoaEvents.DELETE_VPN_SERVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Service Templates have been Deleted.");
    }

    @GetMapping(value = "/{serviceId}/overview")
    public ResponseEntity<JSONObject> getServiceOverview(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementDetailsObj = (JSONObject) obj.get("service-details");

        return ResponseEntity.ok(elementDetailsObj);
    }

    @GetMapping(value = "/{serviceId}/state")
    public ResponseEntity<List<JSONArray>> getServiceState(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("service-inventory");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{serviceId}/availability")
    public ResponseEntity<List<JSONObject>> getServiceAvailability(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("service-availability");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{serviceId}/device/availability")
    public ResponseEntity<List<JSONArray>> getServiceDeviceAvailability(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("service-device-availability");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{serviceId}/endpoint", produces = "application/json")
    public ResponseEntity<List<Endpoint>> getEndpoints(@PathVariable("serviceId") String serviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<Endpoint> endpoints = new ArrayList<Endpoint>();
        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.ENDPOINT))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject endpointObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Endpoint endpointBody = mapper.readValue(endpointObj.toString(), Endpoint.class);
            endpoints.add(endpointBody);
        }
        return ResponseEntity.status(HttpStatus.OK).body(endpoints);
    }

    @GetMapping(value = "/{serviceId}/endpoint/{endpointId}", produces = "application/json")
    public ResponseEntity<Endpoint> getEndpoint(@PathVariable("serviceId") String serviceId,
            @PathVariable("endpointId") String endpointId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.PATHHOP, __.key("endpoint-id", endpointId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        JSONObject endpointObj = (JSONObject) resultsArray.get(0).get("properties");
        mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
        Endpoint endpoint = mapper.readValue(endpointObj.toString(), Endpoint.class);

        return ResponseEntity.status(HttpStatus.OK).body(endpoint);
    }

    @PutMapping(value = "/{serviceId}/endpoint", produces = "application/json")
    public ResponseEntity<String> addEndpoints(@PathVariable("serviceId") String serviceId,
            @RequestBody List<String> elementIds) throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            for (String elementId : elementIds) {
                AAIResourceUri deviceUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(elementId));
                NetworkDevice device = rClient.get(NetworkDevice.class, deviceUri).get();
                Endpoint endpoint = new Endpoint();
                endpoint.setEndpointId(device.getDeviceId());
                endpoint.setEndpointName(device.getDeviceName());
                endpoint.setEndpointIp(device.getHost());
                endpoint.setEndpointStatus(device.isElementStatus());
                AAIResourceUri endpointUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.service().vpnService(serviceId).endpoint(endpoint.getEndpointId()));

                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(endpointUri, endpoint).connect(deviceUri, endpointUri);
                transactions.execute();
            }
            return ResponseEntity.status(HttpStatus.OK).body("Endpoints Added to Service");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @DeleteMapping(value = "/{serviceId}/endpoint", produces = "application/json")
    public ResponseEntity<String> removeEndpoints(@PathVariable("serviceId") String serviceId,
            @RequestBody List<String> endpointIds) throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            for (String endpointId : endpointIds) {
                AAIResourceUri endpointUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).endpoint(endpointId));

                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().delete(endpointUri);
                transactions.execute();
            }
            return ResponseEntity.status(HttpStatus.OK).body("Endpoints Added to Service");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @GetMapping(value = "/{serviceId}/link/availability")
    public ResponseEntity<List<JSONArray>> getServiceLinkAvailability(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("service-link-availability");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{serviceId}/ac/utilization")
    public ResponseEntity<List<JSONObject>> getServiceLinkUtilization(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("service-ac-utilization");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{serviceId}/path", produces = "application/json")
    public ResponseEntity<List<Path>> getPaths(@PathVariable("serviceId") String serviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<Path> paths = new ArrayList<Path>();

        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.PATH)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Path pathBody = mapper.readValue(interfaceObj.toString(), Path.class);
            paths.add(pathBody);
        }

        return ResponseEntity.status(HttpStatus.OK).body(paths);
    }

    @GetMapping(value = "/{serviceId}/path/filter")
    public ResponseEntity<ResponseDataDTO> getPathFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "path");

        Map<String, Object> columns = new HashMap<>();
        columns.put("pathName", "Path Name");
        columns.put("sourceElement", "Source Element");
        columns.put("sourceInterface", "Source Endpoint");
        columns.put("destinationElement", "Destination Element");
        columns.put("destinationInterface", "Destination Endpoint");
        columns.put("protocol", "Protocol");
        columns.put("hopsCount", "Hops Count");
        columns.put("pathRate", "Path Rate");
        columns.put("bandwidth", "Bandwidth");
        columns.put("latency", "Latency");
        columns.put("pathStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping(value = "/{serviceId}/path")
    public ResponseEntity<JSONObject> getPathList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject paths = filterService.queryByFilter(requestBody, "path");
        return ResponseEntity.status(HttpStatus.OK).body(paths);
    }

    @GetMapping(value = "/{serviceId}/path/{pathId}", produces = "application/json")
    public ResponseEntity<Path> getPath(@PathVariable("serviceId") String serviceId,
            @PathVariable("pathId") String pathId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        Path path = new Path();

        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.PATH, __.key("path-id", pathId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            path = mapper.readValue(interfaceObj.toString(), Path.class);
        }

        return ResponseEntity.status(HttpStatus.OK).body(path);
    }

    @PutMapping(value = "/{serviceId}/path", produces = "application/json")
    public ResponseEntity<String> addPaths(@PathVariable("serviceId") String serviceId, @RequestBody Path pathBody)
            throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            String pathId = UUID.randomUUID().toString();
            pathBody.setPathId(pathId);
            pathBody.setPathStatus(true);
            pathBody.setBandwidth("1Gbps");
            pathBody.setHopsCount(0);
            pathBody.setPathRate(200);
            pathBody.setLatency("25ms");

            if (pathBody.getPathName() == null) {
                String pathName = pathBody.getSourceInterface() + "@" + pathBody.getSourceElement() + ":"
                        + pathBody.getDestinationInterface() + "@" + pathBody.getDestinationElement();
                pathBody.setPathName(pathName);
            }
            AAIResourceUri pathUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).path(pathBody.getPathId()));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(pathUri, pathBody);
            transactions.execute();
            return ResponseEntity.status(HttpStatus.OK).body("Paths Added to Service");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @DeleteMapping(value = "/{serviceId}/path", produces = "application/json")
    public ResponseEntity<String> removePaths(@PathVariable("serviceId") String serviceId,
            @RequestBody List<String> pathIds) throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            for (String pathId : pathIds) {
                AAIResourceUri pathUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).path(pathId));

                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().delete(pathUri);
                transactions.execute();
            }
            return ResponseEntity.status(HttpStatus.OK).body("Paths Removed from Service");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @GetMapping(value = "/{serviceId}/path/{pathId}/pathhop", produces = "application/json")
    public ResponseEntity<List<Pathhop>> getPathhops(@PathVariable("serviceId") String serviceId,
            @PathVariable("pathId") String pathId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<Pathhop> pathhops = new ArrayList<Pathhop>();

        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.PATH, __.key("path-id", pathId))).to(__.node(Types.PATHHOP)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Pathhop pathhop = mapper.readValue(interfaceObj.toString(), Pathhop.class);
            pathhops.add(pathhop);
        }

        return ResponseEntity.status(HttpStatus.OK).body(pathhops);
    }

    @PutMapping(value = "/{serviceId}/path/{pathId}/pathhop", produces = "application/json")
    public ResponseEntity<String> addPathhop(@PathVariable("serviceId") String serviceId,
            @PathVariable("pathId") String pathId, @RequestBody Pathhop pathHopBody) throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            AAIResourceUri pathUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).path(pathId));

            if (rClient.exists(pathUri)) {
                String hopId = UUID.randomUUID().toString();
                pathHopBody.setHopId(hopId);
                pathHopBody.setHopStatus(true);

                if (pathHopBody.getHopName() == null) {
                    String hopName = pathHopBody.getSourceInterface() + "@" + pathHopBody.getSourceElement() + ":"
                            + pathHopBody.getDestinationInterface() + "@" + pathHopBody.getDestinationElement();
                    pathHopBody.setHopName(hopName);
                }

                AAIResourceUri hopUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.service().vpnService(serviceId).pathhop(pathHopBody.getHopId()));

                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(hopUri, pathHopBody).connect(hopUri, pathUri);
                transactions.execute();
                return ResponseEntity.status(HttpStatus.OK).body("Pathhops Added to a Path");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Path Doesn't Exists");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @DeleteMapping(value = "/{serviceId}/path/{pathId}/pathhop", produces = "application/json")
    public ResponseEntity<String> deletePathhop(@PathVariable("serviceId") String serviceId,
            @PathVariable("pathId") String pathId, @RequestBody List<String> hopIds) throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            AAIResourceUri pathUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).path(pathId));

            if (rClient.exists(pathUri)) {
                for (String hopId : hopIds) {
                    AAIResourceUri hopUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).pathhop(hopId));

                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(hopUri);
                    transactions.execute();
                }
                return ResponseEntity.status(HttpStatus.OK).body("Pathhops Remove from Path");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Path Doesn't Exists");
            }
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @GetMapping(value = "/{serviceId}/pathhop/{hopId}", produces = "application/json")
    public ResponseEntity<JSONObject> getPathhopDetails(@PathVariable("serviceId") String serviceId,
            @PathVariable("hopId") String hopId) throws ParseException, JsonMappingException, JsonProcessingException {

        JSONObject pathhopObj = new JSONObject();

        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.PATHHOP, __.key("hop-id", hopId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        Pathhop pathhop = new Pathhop();
        if (resultsArray.size() > 0) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(0).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            pathhop = mapper.readValue(interfaceObj.toString(), Pathhop.class);
        }
        pathhopObj.put("id", pathhop.getHopId());
        pathhopObj.put("name", pathhop.getHopName());
        pathhopObj.put("source", pathhop.getSourceElement());
        pathhopObj.put("sourceInterface", pathhop.getSourceInterface());
        pathhopObj.put("target", pathhop.getDestinationElement());
        pathhopObj.put("destinationInterface", pathhop.getDestinationInterface());
        pathhopObj.put("status", pathhop.isHopStatus());
        return ResponseEntity.status(HttpStatus.OK).body(pathhopObj);
    }

    @DeleteMapping(value = "/{serviceId}/pathhop", produces = "application/json")
    public ResponseEntity<String> removePathhops(@PathVariable("serviceId") String serviceId,
            @RequestBody List<String> hopIds) throws BulkProcessFailed {

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        if (rClient.exists(vpnServiceUri)) {
            for (String hopId : hopIds) {
                AAIResourceUri pathhopUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).pathhop(hopId));

                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().delete(pathhopUri);
                transactions.execute();
            }
            return ResponseEntity.status(HttpStatus.OK).body("PathHops Removed from Service");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Service Doesn't Exists");
        }
    }

    @GetMapping(value = "/{serviceId}/network", produces = "application/json")
    public ResponseEntity<List<IetfNetwork>> getProvisionedNetworks(@PathVariable("serviceId") String serviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();
        DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE, __.key("service-id", serviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.IETF_NETWORK))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject serviceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            networks.add(mapper.readValue(serviceObj.toString(), IetfNetwork.class));
        }
        return ResponseEntity.status(HttpStatus.OK).body(networks);
    }

    @PostMapping(value = "/{serviceId}/network", produces = "application/json")
    public ResponseEntity<Map<String, List<String>>> getProvisionedNetworkDetails(
            @PathVariable("serviceId") String serviceId, @RequestBody List<String> networkIds)
            throws ParseException, JsonMappingException, JsonProcessingException {

        Map<String, List<String>> networkObj = new HashMap<String, List<String>>();
        for (String networkId : networkIds) {
            IetfNetwork network = new IetfNetwork();
            AAIResourceUri networkUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

            network = rClient.get(IetfNetwork.class, networkUri).get();

            List<NNode> nodes = new ArrayList<NNode>();
            if (network.getNNodes() != null) {
                nodes = network.getNNodes().getNNode();
            }

            List<String> nodeNames = new ArrayList<String>();
            for (NNode node : nodes) {
                nodeNames.add(node.getNodeName());
            }
            networkObj.put(network.getNetworkName(), nodeNames);
        }
        return ResponseEntity.status(HttpStatus.OK).body(networkObj);
    }

    @GetMapping(value = "/{serviceId}/fault/overview")
    public ResponseEntity<JSONObject> getElementFaultOverview(@PathVariable("serviceId") String serviceId)
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject serviceFaultsObj = (JSONObject) obj.get("service-fault-overview");

        return ResponseEntity.ok(serviceFaultsObj);
    }
}
