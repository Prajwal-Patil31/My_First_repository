package in.utl.noa.util;

import javax.annotation.PostConstruct;

import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

@Service
public class RestClientManager implements ApplicationContextAware {
    private static ApplicationContext appContext;
    private AAIResourcesClient rClient;
    private AAIQueryClient qClient;
    private AAIDSLQueryClient dslClient;

    @Override
    public void setApplicationContext(ApplicationContext context) throws BeansException {
        appContext = context;
    }

    @PostConstruct
    public void init(){
        
        try {
            rClient = new AAIResourcesClient();
            qClient = new AAIQueryClient();
            dslClient = new AAIDSLQueryClient();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public AAIResourcesClient getRClient() {
        return rClient;
    }

    public AAIQueryClient getQClient() {
        return qClient;
    }

    public AAIDSLQueryClient getDSLQueryClient() {
		return dslClient;
	}
}
