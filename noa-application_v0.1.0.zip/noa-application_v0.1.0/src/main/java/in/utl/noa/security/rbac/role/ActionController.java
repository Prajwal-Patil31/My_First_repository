package in.utl.noa.security.rbac.role;

import org.apache.log4j.Logger;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aai.domain.yang.Action;
import org.onap.aai.domain.yang.Actions;
import org.onap.aai.domain.yang.Feature;
import org.onap.aai.domain.yang.Features;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.IetfNetworks;
import org.onap.aai.domain.yang.L2Vpn;
import org.onap.aai.domain.yang.L2Vpns;
import org.onap.aai.domain.yang.L3Vpn;
import org.onap.aai.domain.yang.L3Vpns;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.NetworkDevices;
import org.onap.aai.domain.yang.UrlMapping;
import org.onap.aai.domain.yang.UrlMappings;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;

import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/api/platform")
public class ActionController {
    private static Logger logger = Logger.getLogger(ActionController.class);

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    AuditLogger auditLogger = new AuditLogger();
    JSONParser parser = new JSONParser();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public ActionController() {
        super();
    }

    @GetMapping("/action")
    public ResponseEntity<Map<String, Map<String, List<Action>>>> getAllActionsByGroup() {
        Map<String, Map<String, List<Action>>> groupedActions = new HashMap<String, Map<String, List<Action>>>();
        List<Action> actionList = new ArrayList<Action>();

        List<Action> elementActions = new ArrayList<Action>();
        List<Action> networkActions = new ArrayList<Action>();
        List<Action> serviceActions = new ArrayList<Action>();
        List<Action> platformActions = new ArrayList<Action>();

        AAIPluralResourceUri actionsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().actions());

        Actions actions = rClient.get(Actions.class, actionsUri).get();
        actionList = actions.getAction();

        for (Action action : actionList) {
            String actionReference = action.getActionReference();
            String groupIdentifier = actionReference.substring(0, actionReference.indexOf("_"));
            switch (groupIdentifier) {
                case "EMT":
                    elementActions.add(action);
                    break;
                case "NET":
                    networkActions.add(action);
                    break;
                case "SVC":
                    serviceActions.add(action);
                    break;
                case "PLT":
                    platformActions.add(action);
                    break;
            }
        }

        Map<String, List<Action>> elementObj = divideByCategory(elementActions);
        Map<String, List<Action>> networkObj = divideByCategory(networkActions);
        Map<String, List<Action>> serviceObj = divideByCategory(serviceActions);
        Map<String, List<Action>> platformObj = divideByCategory(platformActions);

        groupedActions.put("Element Privileges", elementObj);
        groupedActions.put("Network Privileges", networkObj);
        groupedActions.put("Service Privileges", serviceObj);
        groupedActions.put("Platform Privileges", platformObj);

        return ResponseEntity.ok(groupedActions);
    }

    @PostMapping("/action")
    public ResponseEntity<Map<String, Map<String, List<Action>>>> getRelatedActionsByGroup(
            @RequestBody List<String> featureIds) throws JsonMappingException, JsonProcessingException {

        Map<String, Map<String, List<Action>>> groupedActions = new HashMap<String, Map<String, List<Action>>>();

        Map<String, List<JSONObject>> dropdownOptions = new HashMap<String, List<JSONObject>>();

        List<Action> actionList = new ArrayList<Action>();

        List<Action> elementActions = new ArrayList<Action>();
        List<Action> networkActions = new ArrayList<Action>();
        List<Action> serviceActions = new ArrayList<Action>();
        List<Action> platformActions = new ArrayList<Action>();

        for (String featureId : featureIds) {
            DSLStartNode startNode = new DSLStartNode(Types.FEATURE, __.key("feature-id", featureId));
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.ACTION))
                    .output();

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, Action>> resultsFromJson = mapper.readValue(results,
                    new TypeReference<Results<Map<String, Action>>>() {
                    });

            for (Map<String, Action> m : resultsFromJson.getResult()) {
                actionList.add(m.get("action"));
            }
        }

        for (Action action : actionList) {
            String relatedFeature = action.getRelatedFeature();
            switch (relatedFeature) {
                case "ElementManagement":
                    elementActions.add(action);
                    break;
                case "NetworkManagement":
                    networkActions.add(action);
                    break;
                case "ServiceManagement":
                    serviceActions.add(action);
                    break;
                default:
                    platformActions.add(action);
                    break;
            }
        }

        Map<String, List<Action>> elementObj = divideByCategory(elementActions);
        Map<String, List<Action>> networkObj = divideByCategory(networkActions);
        Map<String, List<Action>> serviceObj = divideByCategory(serviceActions);
        Map<String, List<Action>> platformObj = divideByCategory(platformActions);

        groupedActions.put("Element Privileges", elementObj);
        groupedActions.put("Network Privileges", networkObj);
        groupedActions.put("Service Privileges", serviceObj);
        groupedActions.put("Platform Privileges", platformObj);

        return ResponseEntity.ok(groupedActions);
    }

    public Map<String, List<Action>> divideByCategory(List<Action> actionsList) {
        Map<String, List<Action>> finalObj = new HashMap<String, List<Action>>();
        for (Action action : actionsList) {
            Set<String> actionObjKeys = finalObj.keySet();
            List<String> actionKeys = new ArrayList<String>();
            actionKeys.addAll(actionObjKeys);
            String category = action.getActionCategory();
            if (actionKeys.contains(category)) {
                List<Action> categoryActionList = finalObj.get(category);
                categoryActionList.add(action);
                finalObj.replace(category, categoryActionList);
            } else {
                List<Action> categoryActionList = new ArrayList<Action>();
                categoryActionList.add(action);
                finalObj.put(category, categoryActionList);
            }
        }

        return finalObj;
    }

    @PostMapping("/resource-action")
    public ResponseEntity<JSONObject> getActionsRequiringIdentifier(@RequestBody List<Action> actionsList)
            throws JsonMappingException, JsonProcessingException {

        Map<String, List<Action>> groupedActions = new HashMap<String, List<Action>>();
        Map<String, List<JSONObject>> dropdownOptions = new HashMap<String, List<JSONObject>>();

        List<Action> elementActions = new ArrayList<Action>();
        List<Action> networkActions = new ArrayList<Action>();
        List<Action> serviceActions = new ArrayList<Action>();
        List<Action> platformActions = new ArrayList<Action>();

        for (Action action : actionsList) {
            String actionReference = action.getActionReference();
            String groupIdentifier = actionReference.substring(0, actionReference.indexOf("_"));
            switch (groupIdentifier) {
                case "EMT":
                    elementActions.add(action);
                    break;
                case "NET":
                    networkActions.add(action);
                    break;
                case "SVC":
                    serviceActions.add(action);
                    break;
                case "PLT":
                    platformActions.add(action);
                    break;
            }
        }

        // Parsing for Element
        Map<String, List<Action>> elementObj = new HashMap<String, List<Action>>();
        Set<String> elementCategoryKeys = elementObj.keySet();

        List<String> elementCategoryList = new ArrayList<String>();
        elementCategoryList.addAll(elementCategoryKeys);

        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();
        AAISimplePluralUri devicesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevices());

        if (elementActions.size() > 0) {
            devices = rClient.get(NetworkDevices.class, devicesUri).get().getNetworkDevice();
        }

        List<JSONObject> devicesDropdownList = new ArrayList<JSONObject>();
        for (NetworkDevice device : devices) {
            JSONObject deviceDropdownObj = new JSONObject();
            deviceDropdownObj.put("key", device.getDeviceId());
            deviceDropdownObj.put("value", device.getDeviceId());
            deviceDropdownObj.put("text", device.getDeviceName());
            devicesDropdownList.add(deviceDropdownObj);
        }

        for (Action elementAction : elementActions) {
            String actionName = elementAction.getActionName();
            dropdownOptions.put(actionName, devicesDropdownList);
            String actionCategory = elementAction.getActionCategory();

            if (elementCategoryList.contains(actionCategory)) {
                List<Action> existingActions = elementObj.get(actionCategory);
                existingActions.add(elementAction);
            } else {
                List<Action> categoryActions = new ArrayList<Action>();
                categoryActions.add(elementAction);

                elementObj.put(actionCategory, categoryActions);
            }
        }

        // Parsing for Network
        Map<String, List<Action>> networkObj = new HashMap<String, List<Action>>();
        Set<String> networkCategoryKeys = networkObj.keySet();

        List<String> networkCategoryList = new ArrayList<String>();
        networkCategoryList.addAll(networkCategoryKeys);

        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();
        AAISimplePluralUri networksUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.network().ietfNetworks());

        if (networkActions.size() > 0) {
            networks = rClient.get(IetfNetworks.class, networksUri).get().getIetfNetwork();
        }

        List<JSONObject> networksDropdownList = new ArrayList<JSONObject>();
        for (IetfNetwork network : networks) {
            JSONObject networkDropdownObj = new JSONObject();
            networkDropdownObj.put("key", network.getNetworkId());
            networkDropdownObj.put("value", network.getNetworkId());
            networkDropdownObj.put("text", network.getNetworkName());
            networksDropdownList.add(networkDropdownObj);
        }

        for (Action networkAction : networkActions) {
            String actionName = networkAction.getActionName();
            dropdownOptions.put(actionName, networksDropdownList);
            String actionCategory = networkAction.getActionCategory();

            if (networkCategoryList.contains(actionCategory)) {
                List<Action> existingActions = networkObj.get(actionCategory);
                existingActions.add(networkAction);
            } else {
                List<Action> categoryActions = new ArrayList<Action>();
                categoryActions.add(networkAction);

                networkObj.put(actionCategory, categoryActions);
            }
        }

        // Parsing for Service
        Map<String, List<Action>> serviceObj = new HashMap<String, List<Action>>();
        Set<String> serviceCategoryKeys = serviceObj.keySet();

        List<String> serviceCategoryList = new ArrayList<String>();
        serviceCategoryList.addAll(serviceCategoryKeys);

        List<L2Vpn> l2vpnservices = new ArrayList<L2Vpn>();
        List<L3Vpn> l3vpnservices = new ArrayList<L3Vpn>();

        AAISimplePluralUri l2vpnServicesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.service().l2Vpns());

        AAISimplePluralUri l3vpnServicesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.service().l3Vpns());

        if (serviceActions.size() > 0) {
            Optional<L2Vpns> l2vpns = rClient.get(L2Vpns.class, l2vpnServicesUri);
            Optional<L3Vpns> l3vpns = rClient.get(L3Vpns.class, l3vpnServicesUri);

            if (l2vpns.isPresent()) {
                l2vpnservices = l2vpns.get().getL2Vpn();
            }
            if (l3vpns.isPresent()) {
                l3vpnservices = l3vpns.get().getL3Vpn();
            }
        }

        List<JSONObject> l2vpnServicesDropdownList = new ArrayList<JSONObject>();
        List<JSONObject> l3vpnServicesDropdownList = new ArrayList<JSONObject>();

        for (L2Vpn l2vpnservice : l2vpnservices) {
            JSONObject l2vpnDropdownObj = new JSONObject();
            l2vpnDropdownObj.put("key", l2vpnservice.getVpnId());
            l2vpnDropdownObj.put("value", l2vpnservice.getVpnId());
            l2vpnDropdownObj.put("text", l2vpnservice.getVpnId());
            l2vpnServicesDropdownList.add(l2vpnDropdownObj);
        }

        for (L3Vpn l3vpnservice : l3vpnservices) {
            JSONObject l3vpnDropdownObj = new JSONObject();
            l3vpnDropdownObj.put("key", l3vpnservice.getVpnId());
            l3vpnDropdownObj.put("value", l3vpnservice.getVpnId());
            l3vpnDropdownObj.put("text", l3vpnservice.getVpnId());
            l3vpnServicesDropdownList.add(l3vpnDropdownObj);
        }

        for (Action serviceAction : serviceActions) {
            String actionName = serviceAction.getActionName();
            if (serviceAction.getResourceName().equals("L2Vpn")) {
                dropdownOptions.put(actionName, l2vpnServicesDropdownList);
            } else {
                dropdownOptions.put(actionName, l3vpnServicesDropdownList);
            }

            String actionCategory = serviceAction.getActionCategory();

            if (serviceCategoryList.contains(actionCategory)) {
                List<Action> existingActions = serviceObj.get(actionCategory);
                existingActions.add(serviceAction);
            } else {
                List<Action> categoryActions = new ArrayList<Action>();
                categoryActions.add(serviceAction);

                serviceObj.put(actionCategory, categoryActions);
            }
        }

        groupedActions.put("Element Privileges", elementActions);
        groupedActions.put("Network Privileges", networkActions);
        groupedActions.put("Service Privileges", serviceActions);
        groupedActions.put("Platform Privileges", platformActions);

        JSONObject responseObj = new JSONObject();
        responseObj.put("actions", groupedActions);
        responseObj.put("dropdowndata", dropdownOptions);

        return ResponseEntity.ok(responseObj);
    }

    @GetMapping("/feature")
    public ResponseEntity<List<Feature>> getAllFeatures() {
        List<Feature> features = new ArrayList<>();
        AAIPluralResourceUri featuresUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().features());

        if (rClient.exists(featuresUri)) {
            Features featuresList = rClient.get(Features.class, featuresUri).get();
            features = featuresList.getFeature();
        }
        return new ResponseEntity<>(features, HttpStatus.OK);
    }

    @DeleteMapping("/delete-feature")
    public ResponseEntity<String> clearAllFeatures() {
        AAIPluralResourceUri featuresUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().features())
                .depth(Depth.TWO);

        if (rClient.exists(featuresUri)) {

            Features featuresList = rClient.get(Features.class, featuresUri).get();

            List<Feature> features = featuresList.getFeature();

            for (Feature feature : features) {
                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(feature.getFeatureId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(featureUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Features have been Deleted.");
    }

    @PutMapping("/create-feature")
    public ResponseEntity<String> createFeatures()
            throws FileNotFoundException, IOException, ParseException, BulkProcessFailed {
        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultData.json"));

        JSONObject featuresObject = (JSONObject) obj.get(0);
        List<JSONObject> featuresList = (List<JSONObject>) featuresObject.get("features");

        for (JSONObject feature : featuresList) {
            String defaultFeature = feature.toString();
            Feature featureObject = mapper.readValue(defaultFeature, Feature.class);
            String featureId = UUID.randomUUID().toString();
            featureObject.setFeatureId(featureId);

            AAIResourceUri featureUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));
            if (!rClient.exists(featureUri)) {
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(featureUri, featureObject);
                transactions.execute();
            }
        }

        return ResponseEntity.status(HttpStatus.CREATED).body("Features have been Created.");
    }

    @PutMapping("/create-action")
    public ResponseEntity<String> createActions() throws Exception {

        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultData.json"));
        JSONObject actionsObject = (JSONObject) obj.get(0);
        List<JSONObject> actionsList = (List<JSONObject>) actionsObject.get("actions");

        for (JSONObject action : actionsList) {
            String defaultAction = action.toString();
            Action actionObject = mapper.readValue(defaultAction, Action.class);
            String actionId = UUID.randomUUID().toString();
            actionObject.setActionId(actionId);

            AAIResourceUri actionUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.platform().action(actionId));
            if (!rClient.exists(actionUri)) {
                AAITransactionalClient transactions;
                String featureId = null;
                String featureName = actionObject.getRelatedFeature();

                DSLStartNode startNode = new DSLStartNode(Types.FEATURE, __.key("feature-name", featureName));
                DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

                String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

                JSONObject resultsJson = (JSONObject) parser.parse(results);
                List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

                for (int i = 0; i < resultsArray.size(); i++) {
                    JSONObject userObj = (JSONObject) resultsArray.get(i).get("properties");
                    mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
                    Feature feature = mapper.readValue(userObj.toString(), Feature.class);
                    featureId = feature.getFeatureId();
                }

                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));

                transactions = rClient.beginTransaction().create(actionUri, actionObject).connect(featureUri,
                        actionUri);
                transactions.execute();
            }
        }

        return ResponseEntity.status(HttpStatus.CREATED).body("Actions have been Created.");
    }

    @DeleteMapping("/delete-action")
    public ResponseEntity<String> clearAllActions() {
        AAIPluralResourceUri actionsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().actions())
                .depth(Depth.TWO);

        if (rClient.exists(actionsUri)) {

            Actions actionsList = rClient.get(Actions.class, actionsUri).get();

            List<Action> actions = actionsList.getAction();

            for (Action action : actions) {
                AAIResourceUri actionUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().action(action.getActionId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(actionUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Actions have been Deleted.");
    }

    @DeleteMapping("/url-mapping")
    public ResponseEntity<String> clearAllUrlMappings() {
        AAIPluralResourceUri urlMappingsUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.platform().urlMappings());

        if (rClient.exists(urlMappingsUri)) {

            UrlMappings urlMappingsList = rClient.get(UrlMappings.class, urlMappingsUri).get();

            List<UrlMapping> urlMappings = urlMappingsList.getUrlMapping();

            for (UrlMapping urlMapping : urlMappings) {
                AAIResourceUri urlMapUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().urlMapping(urlMapping.getMapId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(urlMapUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("URL to Feature Mappings have been Deleted.");
    }
}
