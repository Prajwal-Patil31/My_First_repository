package in.utl.noa.element.config.mpls.tunnel;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.onap.aai.domain.yang.MplsTunnel;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.element.service.DeviceOperationService;
import in.utl.noa.element.service.EdgeRouterService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

import org.onap.aai.domain.yang.Attributes;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/mpls/tunnel")
public class TunnelsManagement {
    private static Logger logger = Logger.getLogger(TunnelsManagement.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    /*
     * @Autowired DeviceRepository deviceRepo;
     */

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getTunnelFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "mpls-tunnel");

        Map<String, Object> columns = new HashMap<>();
        columns.put("tunnelName", "Tunnel Name");
        columns.put("ingressLsrId", "Ingress LSR Id");
        columns.put("egressLsrId", "Egress LSR Id");
        columns.put("tunnelRole", "Tunnel Role");
        columns.put("signalingProtocol", "Signalling Protocol");
        columns.put("tunnelInstance", "Tunnel Instance");
        columns.put("adminStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getTunnelList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject tunnels = filterService.queryByFilter(requestBody, "mpls-tunnel");
        return ResponseEntity.status(HttpStatus.OK).body(tunnels);
    }

    @GetMapping()
    public ResponseEntity<List<MplsTunnel>> getMplsTunnels(@PathVariable("deviceId") String deviceId) {

        List<MplsTunnel> mplsTunnels = new ArrayList<MplsTunnel>();
        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();

            if (device.getMplsTunnels() != null) {
                mplsTunnels = device.getMplsTunnels().getMplsTunnel();
            }
            return ResponseEntity.status(HttpStatus.OK).body(mplsTunnels);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mplsTunnels);
    }

    @GetMapping(value = "/{tunnelId}")
    public ResponseEntity<MplsTunnel> getMplsTunnel(@PathVariable("deviceId") String deviceId,
            @PathVariable("tunnelId") String tunnelId) {

        MplsTunnel mplsTunnel = new MplsTunnel();
        AAIResourceUri mplsTunnelUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).mplsTunnel(tunnelId));

        if (rClient.exists(mplsTunnelUri)) {
            mplsTunnel = rClient.get(MplsTunnel.class, mplsTunnelUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(mplsTunnel);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(mplsTunnel);
    }

    @PutMapping()
    public ResponseEntity<MplsTunnel> createMplsTunnel(@PathVariable("deviceId") String deviceId,
            @RequestBody MplsTunnel mplsTunnelBody) throws BulkProcessFailed {

        AAITransactionalClient transactions;

        String tunnelId = UUID.randomUUID().toString();

        mplsTunnelBody.setTunnelId(tunnelId);

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("MPLS Tunnel Instance", tunnelId,
                "Network Device", deviceId);

        mplsTunnelBody.setTunnelOwner("ldp");

        if (mplsTunnelBody.isIsInterface() == null) {
            mplsTunnelBody.setIsInterface(false);
        }
        AAIResourceUri mplsTunnelUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).mplsTunnel(mplsTunnelBody.getTunnelId()));

        // edgeRouterService.createMplsTunnel(deviceId, mplsTunnelBody);

        transactions = rClient.beginTransaction().create(mplsTunnelUri, mplsTunnelBody);

        transactions.execute();
        description = tunnelId + " Tunnel has been Created.";

        JSONObject tunnelObj = rollbackHandler.getJsonObject(mplsTunnelBody);

        List<Attributes> attributes = rollbackHandler.createAttributes(tunnelObj, null, null);
        String resourceUri = mplsTunnelUri.getObjectType().toString();
        rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.MplsTunnel", tunnelId, resourceUri,
                deviceId, attributes, null, 0, description, true);

        description = tunnelId + " Tunnel has been Created.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "MPLS Tunnel",
                NoaEvents.CREATE_MPLS_TUNNEL.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(mplsTunnelBody);
    }

    @PostMapping(value = "/{tunnelId}")
    public ResponseEntity<String> updateMplsTunnel(@PathVariable("deviceId") String deviceId,
            @PathVariable("tunnelId") String tunnelId, @RequestBody MplsTunnel mplsTunnelBody)
            throws BulkProcessFailed {

        AAITransactionalClient transactions;

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("MPLS Tunnel Instance", tunnelId,
                "Network Device", deviceId);

        AAIResourceUri mplsTunnelUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).mplsTunnel(mplsTunnelBody.getTunnelId()));

        if (rClient.exists(mplsTunnelUri)) {
            // edgeRouterService.createMplsTunnel(deviceId, mplsTunnelBody);
            MplsTunnel updMplsTunnel = rClient.get(MplsTunnel.class, mplsTunnelUri).get();
            transactions = rClient.beginTransaction().update(mplsTunnelUri, mplsTunnelBody);

            transactions.execute();
            description = tunnelId + " Tunnel has been Updated.";

            JSONObject tunnelObj = rollbackHandler.getJsonObject(updMplsTunnel);

            List<Attributes> attributes = rollbackHandler.createAttributes(tunnelObj, null, null);
            String resourceUri = mplsTunnelUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.MplsTunnel", tunnelId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = tunnelId + " Tunnel Doesn't Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "MPLS Tunnel",
                NoaEvents.MODIFY_MPLS_TUNNEL.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteMplsTunnels(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> tunnelIds) throws BulkProcessFailed {

        AAITransactionalClient transactions;

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("MPLS Tunnel Instance", null,
                "Network Device", deviceId);

        for (String tunnelId : tunnelIds) {
            resourceMetadata.setResourceId(tunnelId);
            AAIResourceUri mplsTunnelUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).mplsTunnel(tunnelId));

            if (rClient.exists(mplsTunnelUri)) {
                transactions = rClient.beginTransaction().delete(mplsTunnelUri);
                transactions.execute();
                description = tunnelId + " Tunnel has been Deleted";
                eventStatus = true;
                reqStatus = HttpStatus.NO_CONTENT;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "MPLS Tunnel",
                        NoaEvents.DELETE_MPLS_TUNNEL.getEvent(), eventStatus, null, resourceMetadata, auth);
            } else {
                description = tunnelId + " Tunnel Doesn't Exists.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "MPLS Tunnel",
                        NoaEvents.DELETE_MPLS_TUNNEL.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("MPLS Tunnel have been Deleted.");
    }
}
