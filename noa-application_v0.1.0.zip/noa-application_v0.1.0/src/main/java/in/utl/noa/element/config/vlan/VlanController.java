package in.utl.noa.element.config.vlan;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.Vlan;
import org.onap.aai.domain.yang.VlanInterface;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;

import org.onap.aai.domain.yang.Attributes;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/bridge/{bridgeId}/vlan")
public class VlanController {
    private static Logger logger = Logger.getLogger(VlanController.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    RestClientManager restClientManager;
    
    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<Vlan>> getVlans(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId) throws JsonMappingException, JsonProcessingException,ParseException {

        List<Vlan> vlans = new ArrayList<Vlan>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.BRIDGE_INSTANCE, __.key("bridge-id", bridgeId))).to(__.node(Types.VLAN)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject vlanObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Vlan vlanBody = mapper.readValue(vlanObj.toString(),Vlan.class);
            vlans.add(vlanBody);
        }
        return ResponseEntity.status(HttpStatus.OK).body(vlans);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getRoleFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();
        
        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "vlan");
        
        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("vlanName", "VLAN Name");
        columns.put("vlanType", "VLAN Type");
        columns.put("acCount", "AC Count");
        columns.put("hybridPorts", "Hybrid Ports");
        columns.put("untaggedPorts", "UnTagged Ports");
        columns.put("taggedPorts", "Tagged Ports");
        columns.put("vlanStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);
        
        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }
    
    @PostMapping()
    public ResponseEntity<JSONObject> getRoleList(@RequestBody RequestBodyDTO requestBody){
        JSONObject roles = filterService.queryByFilter(requestBody,"vlan");
        return ResponseEntity.status(HttpStatus.OK).body(roles);
    }
    
    @GetMapping(value = "/{vlanId}")
    public ResponseEntity<Vlan> getVlan(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @PathVariable("vlanId") String vlanId)
            throws JsonMappingException, JsonProcessingException,ParseException {

        Vlan vlan = new Vlan();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.BRIDGE_INSTANCE, __.key("bridge-id", bridgeId)))
                .to(__.node(Types.VLAN, __.key("vlan-id", vlanId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject vlanObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            vlan = mapper.readValue(vlanObj.toString(),Vlan.class);
            
        }
        return ResponseEntity.status(HttpStatus.OK).body(vlan);
    }

    @PutMapping()
    public ResponseEntity<Vlan> addVlan(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @RequestBody Vlan vlanInterfaces)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        Vlan vlan = new Vlan();

        String vlanId = UUID.randomUUID().toString();
        String vlanName = vlanInterfaces.getVlanName();
        String vlanType = vlanInterfaces.getVlanType();

        /* if (vlanType == null) {
            vlanType = vlanInterfaces.getIfMainType();
        }

        vlanInterfaces.setVlanStaticRowStatus(true);
        String tqGroupAddress = vlanInterfaces.getTqGroupAddress();
        if (tqGroupAddress == null) {
            tqGroupAddress = vlanInterfaces.getIfAlias();
        } */

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("VLAN", vlanId, "Network Device",
                deviceId);

        vlan.setVlanId(vlanId);
        vlan.setVlanName(vlanName);
        vlan.setVlanType(vlanType);
        vlan.setAcCount(0);
        vlan.setHybridPorts(0);
        vlan.setTaggedPorts(0);;
        vlan.setUntaggedPorts(0);
        vlan.setVlanStatus(true);

        // List<String> interfaceIds = vlanInterfaces.getInterfaceIds();

        // deviceService.createIfEntry(deviceId, vlanInterfaces);
        /*
         * deviceService.createIfMainEntry(deviceId, vlanInterfaces);
         * deviceService.createIpEntry(deviceId, vlanInterfaces);
         * deviceService.addTpGroupEntry(deviceId, vlanInterfaces);
         * if(vlanInterfaces.getIfMainType() != "l3ipvlan") {
         * deviceService.createStaticVlan(deviceId, vlanInterfaces); }
         */

        AAIResourceUri vlanUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

        AAIResourceUri bridgeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

        if (rClient.exists(bridgeUri)) {
            
            AAITransactionalClient transactions;

            transactions = rClient.beginTransaction().create(vlanUri, vlan).connect(bridgeUri, vlanUri);
            transactions.execute();
            description = vlanId + " VLAN has been Created";

            JSONObject vlanObj = rollbackHandler.getJsonObject(vlan);

            List<Attributes> attributes = rollbackHandler.createAttributes(vlanObj, null, null);
            String resourceUri = vlanUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.Vlan", vlanId, resourceUri,
                    null, attributes, null, 0, description, true);
            reqStatus = HttpStatus.CREATED;
            eventStatus = true;

        } else {
            description = "Bridge Doesn't Exists";
            reqStatus = HttpStatus.NOT_FOUND;
        }
        
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN", NoaEvents.CREATE_VLAN.getEvent(),
                eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(vlan);
    }

    @PostMapping(value = "/{vlanId}")
    public ResponseEntity<String> updateVlan(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @PathVariable("vlanId") String vlanId,
            @RequestBody Vlan updatedVlan) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("VLAN", vlanId, "Network Device",
                deviceId);

        if (vlanId != null) {
            AAIResourceUri vlanUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

            AAIResourceUri bridgeUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

            if (rClient.exists(bridgeUri)) {
                if (rClient.exists(vlanUri)) {
                    AAITransactionalClient transactions;
                    Vlan updVlan = rClient.get(Vlan.class, vlanUri).get();

                    transactions = rClient.beginTransaction().update(vlanUri, updatedVlan);
                    transactions.execute();
                    description = vlanId + " VLAN has been Updated";

                    JSONObject vlanObj = rollbackHandler.getJsonObject(updVlan);

                    List<Attributes> attributes = rollbackHandler.createAttributes(vlanObj, null, null);
                    String resourceUri = vlanUri.getObjectType().toString();
                    rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.Vlan", vlanId, resourceUri,
                            null, attributes, null, 0, description, true);

                    reqStatus = HttpStatus.OK;
                    eventStatus = true;
                } else {
                    description = vlanId + "VLAN Doesn't Exists.";
                }
            } else {
                description = "Bridge Doesn't Exists";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN", NoaEvents.MODIFY_VLAN.getEvent(),
                eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteVlans(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> vlanIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("VLAN", null, "Network Device",
                deviceId);

        for (String vlanId : vlanIds) {
            resourceMetadata.setResourceId(vlanId);
            if (vlanId != null) {
                AAIResourceUri vlanUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));
                if (rClient.exists(vlanUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(vlanUri);
                    transactions.execute();
                    description = vlanId + " VLAN has been Deleted";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.DELETE_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = vlanId + " VLAN Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.DELETE_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null VLAN Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                        NoaEvents.DELETE_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Vlans have been Deleted.");
    }

    @PostMapping(value = "/{vlanId}/interface")
    public ResponseEntity<String> addInterfacesToVlan(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @PathVariable("vlanId") String vlanId,
            @RequestBody Map<String,List<String>> interfaceObj) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface", null, "VLAN", null);

        AAIResourceUri vlanUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

        List<String> taggedPorts = interfaceObj.get("tagged");
        List<String> untaggedPorts = interfaceObj.get("untagged");
        List<String> hybridPorts = interfaceObj.get("hybrid");

        if (rClient.exists(vlanUri)) {
            for (String portId : taggedPorts) {

                resourceMetadata.setModuleId(vlanId);
                resourceMetadata.setResourceId(portId);

                if (portId != null) {

                    VlanInterface vlanInterface = new VlanInterface();
                    String tagId = UUID.randomUUID().toString();
                    vlanInterface.setTagId(tagId);

                    AAIResourceUri vlanInterfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlanInterface(tagId));
                    AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(portId));
                    IetfInterface ietfInterface = rClient.get(IetfInterface.class,interfaceUri).get();

                    vlanInterface.setVlanId(vlanId);
                    vlanInterface.setInterfaceName(ietfInterface.getInterfaceName());
                    vlanInterface.setTagType("tagged");
                    vlanInterface.setInterfaceId(portId);
                    
                    AAITransactionalClient transactions = null;
                    transactions = rClient.beginTransaction().create(vlanInterfaceUri,vlanInterface).connect(vlanUri, vlanInterfaceUri).connect(vlanInterfaceUri,interfaceUri);
                    transactions.execute();

                    description = ietfInterface.getInterfaceName() + " Interface has been Added to " + vlanId + " VLAN";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    
                } else {
                    description = "Received Null Interface Id";
                    reqStatus = HttpStatus.BAD_REQUEST;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            }

            for(String portId : untaggedPorts) {
                if (portId != null) {

                    VlanInterface vlanInterface = new VlanInterface();
                    String tagId = UUID.randomUUID().toString();
                    vlanInterface.setTagId(tagId);

                    AAIResourceUri vlanInterfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlanInterface(tagId));
                    AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(portId));
                    IetfInterface ietfInterface = rClient.get(IetfInterface.class,interfaceUri).get();

                    vlanInterface.setVlanId(vlanId);
                    vlanInterface.setInterfaceName(ietfInterface.getInterfaceName());
                    vlanInterface.setTagType("untagged");
                    vlanInterface.setInterfaceId(portId);
                    
                    AAITransactionalClient transactions = null;
                    transactions = rClient.beginTransaction().create(vlanInterfaceUri,vlanInterface).connect(vlanUri, vlanInterfaceUri).connect(vlanInterfaceUri,interfaceUri);
                    transactions.execute();

                    description = ietfInterface.getInterfaceName() + " Interface has been Added to " + vlanId + " VLAN";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    
                } else {
                    description = "Received Null Interface Id";
                    reqStatus = HttpStatus.BAD_REQUEST;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            }

            for(String portId : hybridPorts) {
                if (portId != null) {

                    VlanInterface vlanInterface = new VlanInterface();
                    String tagId = UUID.randomUUID().toString();
                    vlanInterface.setTagId(tagId);

                    AAIResourceUri vlanInterfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlanInterface(tagId));
                    AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(portId));
                    IetfInterface ietfInterface = rClient.get(IetfInterface.class,interfaceUri).get();

                    vlanInterface.setVlanId(vlanId);
                    vlanInterface.setInterfaceName(ietfInterface.getInterfaceName());
                    vlanInterface.setTagType("hybrid");
                    vlanInterface.setInterfaceId(portId);
                    
                    AAITransactionalClient transactions = null;
                    transactions = rClient.beginTransaction().create(vlanInterfaceUri,vlanInterface).connect(vlanUri, vlanInterfaceUri).connect(vlanInterfaceUri,interfaceUri);
                    transactions.execute();

                    description = ietfInterface.getInterfaceName() + " Interface has been Added to " + vlanId + " VLAN";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    
                } else {
                    description = "Received Null Interface Id";
                    reqStatus = HttpStatus.BAD_REQUEST;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body("Interfaces have been Added to Vlan.");
        } else {
            description = vlanId + " VLAN Doesn't Exists.";
            auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                    NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body(description);
        }
    }

    @DeleteMapping(value = "/{vlanId}/interface")
    public ResponseEntity<String> removeInterfacesToVlan(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @PathVariable("vlanId") String vlanId,
            @RequestBody List<String> interfaceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface", null, "VLAN", null);

        AAIResourceUri vlanUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

        if (rClient.exists(vlanUri)) {
            for (String interfaceId : interfaceIds) {

                resourceMetadata.setModuleId(vlanId);
                resourceMetadata.setResourceId(interfaceId);

                if (interfaceId != null) {

                    AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(
                            AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));
                            
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().disconnect(vlanUri, interfaceUri);
                    transactions.execute();
                    description = interfaceId + " Interface has been removed from " + vlanId + " VLAN";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                                NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);

                } else {
                    description = "Received Null Interface Id";
                    reqStatus = HttpStatus.BAD_REQUEST;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                            NoaEvents.REMOVE_PORTS_FROM_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body("Interfaces have been Added to Vlan.");
        } else {
            description = vlanId + " VLAN Doesn't Exists.";
            auditLogger.addAuditLog(rClient, description, "Device Configuration", "VLAN",
                    NoaEvents.ADD_PORTS_TO_VLAN.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body(description);
        }
    }

    @GetMapping(value = "/{vlanId}/interface")
    public ResponseEntity<Map<String, List<VlanInterface>>> getInterfacesOfVlan(
            @PathVariable("deviceId") String deviceId, @PathVariable("bridgeId") String bridgeId,
            @PathVariable("vlanId") String vlanId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException, ParseException {

        Map<String, List<VlanInterface>> vlanInterfaces = new HashMap<String, List<VlanInterface>>();

        List<VlanInterface> taggedPorts = new ArrayList<VlanInterface>();
        List<VlanInterface> untaggedPorts = new ArrayList<VlanInterface>();
        List<VlanInterface> hybridPorts = new ArrayList<VlanInterface>();

        DSLStartNode startNode = new DSLStartNode(Types.VLAN, __.key("vlan-id", vlanId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.VLAN_INTERFACE)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject networkObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            VlanInterface vlanInterface = mapper.readValue(networkObj.toString(),VlanInterface.class);
            switch(vlanInterface.getTagType()) {
                case "tagged":
                    taggedPorts.add(vlanInterface);
                    break;
                case "untagged":
                    untaggedPorts.add(vlanInterface);
                    break;
                case "hybrid":
                    hybridPorts.add(vlanInterface);
                    break;
            }
        }
        vlanInterfaces.put("tagged",taggedPorts);
        vlanInterfaces.put("untagged",untaggedPorts);
        vlanInterfaces.put("hybrid",hybridPorts);

        return new ResponseEntity<>(vlanInterfaces, HttpStatus.OK);
    }

    @GetMapping(value = "/{vlanId}/available-interface")
    public ResponseEntity<List<IetfInterface>> getAvailableInterfacesForVlan(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @PathVariable("vlanId") String vlanId)
            throws JsonMappingException, JsonProcessingException {

        List<IetfInterface> vlanInterfaces = new ArrayList<IetfInterface>();
        List<IetfInterface> allInterfaces = new ArrayList<IetfInterface>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.BRIDGE_INSTANCE, __.key("bridge-id", bridgeId)))
                .to(__.node(Types.VLAN, __.key("vlan-id", vlanId)))
                .to(__.node(Types.IETF_INTERFACE)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, IetfInterface>> interfaceResults = mapper.readValue(results,
                new TypeReference<Results<Map<String, IetfInterface>>>() {
                });

        for (Map<String, IetfInterface> m : interfaceResults.getResult()) {
            vlanInterfaces.add(m.get("ietf-interface"));
        }

        DSLQueryBuilder<Start, Node> queryBuilder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.BRIDGE_INSTANCE, __.key("bridge-id", bridgeId)))
                .to(__.node(Types.IETF_INTERFACE)).output();

        String allResults = dslClient.query(Format.RESOURCE, new DSLQuery(queryBuilder.build()));
        Results<Map<String, IetfInterface>> allInterfaceResults = mapper.readValue(allResults,
                new TypeReference<Results<Map<String, IetfInterface>>>() {
                });

        for (Map<String, IetfInterface> m : allInterfaceResults.getResult()) {
            allInterfaces.add(m.get("ietf-interface"));
        }

        if (vlanInterfaces.size() > 0) {
            for (int i = 0; i < allInterfaces.size(); i++) {
                IetfInterface interfaceObj = allInterfaces.get(i);
                String interfaceId = interfaceObj.getInterfaceId();
                IetfInterface existingInterface = vlanInterfaces.stream()
                        .filter(vlanInterface -> interfaceId.equals(vlanInterface.getInterfaceId())).findFirst().get();

                if (existingInterface != null) {
                    allInterfaces.remove(i);
                }
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(allInterfaces);
    }
}
