package in.utl.noa.controller;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aai.domain.yang.StpConfig;

import org.onap.aai.domain.yang.BgpInstance;
import org.onap.aai.domain.yang.BgpPeer;
import org.onap.aai.domain.yang.BridgeInstance;
import org.onap.aai.domain.yang.LdpEntity;
import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.L2VpnInstance;
import org.onap.aai.domain.yang.LdpPeer;
import org.onap.aai.domain.yang.L2Vpn;
import org.onap.aai.domain.yang.L3VpnInstance;
import org.onap.aai.domain.yang.MplsTunnel;
import org.onap.aai.domain.yang.NNode;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.VpnService;
import org.onap.aai.domain.yang.Path;
import org.onap.aai.domain.yang.Pathhop;
import org.onap.aai.domain.yang.Endpoint;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.Route;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.OspfInstance;
import org.onap.aai.domain.yang.OspfNeighbour;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/api/platform/default/")
public class DefaultDataController {
    private static Logger logger = Logger.getLogger(DefaultDataController.class);

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    AuditLogger auditLogger = new AuditLogger();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public NetworkDevice getDevice(String deviceId) {
        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        device = rClient.get(NetworkDevice.class, deviceUri).get();
        return device;
    }

    @PutMapping(value = "/device/{deviceId}")
    public ResponseEntity<String> handleDevice(@PathVariable("deviceId") String deviceId) throws BulkProcessFailed {

        NetworkDevice device = getDevice(deviceId);

        List<IetfInterface> ietfInterfaces = device.getIetfInterfaces().getIetfInterface();

        BridgeInstance bridge1 = createBridgeInstance(deviceId, "bridge0-3", true, false, "forward-all", 100, 50, 2, 2,
                true);
        BridgeInstance bridge2 = createBridgeInstance(deviceId, "bridge3-4", false, true, "forward-tagged-only", 60, 60,
                2, 1, false);
        BridgeInstance bridge3 = createBridgeInstance(deviceId, "bridge4-8", false, false, "forward-all", 90, 100, 1, 1,
                true);

        List<BridgeInstance> bridges = new ArrayList<BridgeInstance>();
        bridges.add(bridge1);
        bridges.add(bridge2);
        bridges.add(bridge3);

        for (BridgeInstance bridge : bridges) {
            AAIResourceUri bridgeUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridge.getBridgeId()));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(bridgeUri, bridge);
            transactions.execute();

            for (IetfInterface ietfInterface : ietfInterfaces) {
                AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                        .networkDevice(deviceId).ietfInterface(ietfInterface.getInterfaceId()));

                AAITransactionalClient interfaceTxns;
                interfaceTxns = rClient.beginTransaction().connect(bridgeUri, interfaceUri);
                interfaceTxns.execute();
            }
        }

        BgpInstance bgp1 = createBgpInstance("bgpInstance1", "150", 50, 60, 25, 50, 45, true);
        BgpInstance bgp2 = createBgpInstance("bgpInstance2", "350", 80, 100, 75, 80, 85, false);
        BgpInstance bgp3 = createBgpInstance("bgpInstance3", "165", 100, 170, 50, 80, 75, true);

        List<BgpInstance> bgpInstances = new ArrayList<BgpInstance>();
        bgpInstances.add(bgp1);
        bgpInstances.add(bgp2);
        bgpInstances.add(bgp3);

        for (BgpInstance bgpInstance : bgpInstances) {
            AAIResourceUri bgpUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpInstance(bgpInstance.getBgpId()));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(bgpUri, bgpInstance);
            transactions.execute();

            BgpPeer peer1 = constructPeer("192.168.1.110", "HYD-PE-146", 22, "ipv4", "192.168.1.101", 22);
            BgpPeer peer2 = constructPeer("192.168.1.111", "DEL-CE-130", 22, "ipv4", "192.168.1.102", 22);
            BgpPeer peer3 = constructPeer("192.168.1.112", "BOM-PE-240", 22, "ipv4", "192.168.1.103", 22);

            List<BgpPeer> peers = new ArrayList<BgpPeer>();
            peers.add(peer1);
            peers.add(peer2);
            peers.add(peer3);

            AAITransactionalClient peerTransactions = null;
            for (BgpPeer peer : peers) {
                AAIResourceUri bgpPeerUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpPeer(peer.getPeerId()));

                peerTransactions = rClient.beginTransaction().create(bgpPeerUri, peer).connect(bgpPeerUri, bgpUri);
                peerTransactions.execute();
            }
        }

        OspfInstance ospf1 = createOspfInstance("ospfInstance1", "25", "4000ms", "enabled", "enabled", "enabled", true);
        OspfInstance ospf2 = createOspfInstance("ospfInstance2", "45", "5000ms", "enabled", "enabled", "disabled",
                false);
        OspfInstance ospf3 = createOspfInstance("ospfInstance3", "10", "4500ms", "enabled", "enabled", "disabled",
                false);

        List<OspfInstance> ospfInstances = new ArrayList<OspfInstance>();
        ospfInstances.add(ospf1);
        ospfInstances.add(ospf2);
        ospfInstances.add(ospf3);

        for (OspfInstance ospfInstance : ospfInstances) {
            AAIResourceUri ospfUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfInstance(ospfInstance.getOspfId()));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(ospfUri, ospfInstance);
            transactions.execute();

            OspfNeighbour neighbour1 = constructNeighbour("HYD-PE-068", "192.168.1.101", 0, "Unplanned Restart",
                    "Unknown", true);
            OspfNeighbour neighbour2 = constructNeighbour("BOM-CE-258", "192.168.1.102", 0, "Planned Restart",
                    "Software Restart", true);
            OspfNeighbour neighbour3 = constructNeighbour("DEL-PE-659", "192.168.1.103", 0, "Planned Restart",
                    "Software Restart", true);

            List<OspfNeighbour> neighbours = new ArrayList<OspfNeighbour>();
            neighbours.add(neighbour1);
            neighbours.add(neighbour2);
            neighbours.add(neighbour3);

            AAITransactionalClient neighbourTransactions = null;

            for (OspfNeighbour neighbour : neighbours) {
                AAIResourceUri neighbourUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                        .networkDevice(deviceId).ospfNeighbour(neighbour.getNeighbourId()));

                neighbourTransactions = rClient.beginTransaction().create(neighbourUri, neighbour).connect(neighbourUri,
                        ospfUri);
                neighbourTransactions.execute();

            }
        }

        LdpEntity entity1 = createLdpEntity(deviceId, 1, "downstreamOnDemand", "conservative", 830, 145, 30,
                "192.168.1.104", true);
        LdpEntity entity2 = createLdpEntity(deviceId, 2, "downstreamUnsolicited", "liberal", 580, 226, 650,
                "192.168.1.115", false);
        LdpEntity entity3 = createLdpEntity(deviceId, 3, "downstreamUnsolicited", "liberal", 450, 124, 85,
                "192.168.1.120", true);

        List<LdpEntity> ldpEntities = new ArrayList<LdpEntity>();
        ldpEntities.add(entity1);
        ldpEntities.add(entity2);
        ldpEntities.add(entity3);

        for (LdpEntity ldpEntity : ldpEntities) {
            AAIResourceUri entityUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpEntity(ldpEntity.getEntityId()));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(entityUri, ldpEntity);
            transactions.execute();

            LdpPeer peer1 = constructLdpPeer(ldpEntity.getEntityId(), "192.168.1.110", "down stream on demand");
            LdpPeer peer2 = constructLdpPeer(ldpEntity.getEntityId(), "192.168.1.110", "down stream Unsolicited");
            LdpPeer peer3 = constructLdpPeer(ldpEntity.getEntityId(), "192.168.1.110", "down stream on demand");

            List<LdpPeer> peers = new ArrayList<LdpPeer>();
            peers.add(peer1);
            peers.add(peer2);
            peers.add(peer3);

            AAITransactionalClient peerTransactions = null;
            for (LdpPeer peer : peers) {
                AAIResourceUri ldpPeerUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpPeer(peer.getPeerId()));

                peerTransactions = rClient.beginTransaction().create(ldpPeerUri, peer);
                peerTransactions.execute();
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body("Resources Created");
    }

    @PutMapping(value = "/network/{networkId}")
    public ResponseEntity<String> handleNetwork(@PathVariable("networkId") String networkId) throws BulkProcessFailed {

        IetfNetwork network = new IetfNetwork();
        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

        network = rClient.get(IetfNetwork.class, networkUri).get();
        String networkType = network.getNetworkType();

        List<NNode> nodes = network.getNNodes().getNNode();
        for (int i = 0; i < nodes.size(); i++) {
            NNode srcNode = nodes.get(i);
            NetworkDevice srcDevice = getDevice(srcNode.getNodeId());
            IetfInterface srcInterface = srcDevice.getIetfInterfaces().getIetfInterface().get(1);
            String localAddress = srcInterface.getIpAddress();

            for (int j = i + 1; j < nodes.size(); j++) {
                NNode destNode = nodes.get(j);
                NetworkDevice destDevice = getDevice(destNode.getNodeId());
                IetfInterface destInterface = destDevice.getIetfInterfaces().getIetfInterface().get(0);
                String nexthopAddress = destInterface.getIpAddress();
                switch (networkType) {
                    case "L1 Network":
                        createLink(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(),
                                destDevice.getDeviceName(), destInterface.getInterfaceName(), "L1 Link", "50Gbps",
                                "25ms");
                        break;
                    case "L2 Network":
                        createLink(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(),
                                destDevice.getDeviceName(), destInterface.getInterfaceName(), "L2 Link", "50Gbps",
                                "25ms");
                        break;
                    case "L2.5 Network":
                        createLsp(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(),
                                destDevice.getDeviceName(), destInterface.getInterfaceName());
                        break;
                    case "L3 Network":
                        createRoute(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(), localAddress,
                                destDevice.getDeviceName(), destInterface.getInterfaceName(), nexthopAddress);
                        break;
                    default:
                        break;
                }
            }

        }
        return ResponseEntity.status(HttpStatus.OK).body("Network Resources Created");
    }

    @PutMapping(value = "/service/{serviceId}")
    public ResponseEntity<String> handleService(@PathVariable("serviceId") String serviceId,
            @RequestBody List<String> endpointIds)
            throws BulkProcessFailed, ParseException, JsonMappingException, JsonProcessingException {

        VpnService service = new VpnService();
        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId));

        service = rClient.get(VpnService.class, vpnServiceUri).get();
        String serviceType = service.getServiceType();

        String networkType = null;
        switch (serviceType) {
            case "L2 VPN":
                networkType = "L2.5 Network";
                break;
            case "L3 VPN":
                networkType = "L3 Network";
                break;
            default:
                break;
        }

        List<Endpoint> endpoints = new ArrayList<Endpoint>();

        for (String endpointId : endpointIds) {
            AAIResourceUri deviceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(endpointId)).depth(Depth.TWO);

            NetworkDevice device = getDevice(endpointId);
            List<IetfInterface> interfaces = device.getIetfInterfaces().getIetfInterface();

            Endpoint endpoint = new Endpoint();
            endpoint.setEndpointId(device.getDeviceId());
            endpoint.setEndpointName(device.getDeviceName());
            endpoint.setEndpointIp(device.getHost());
            endpoint.setEndpointRole(interfaces.get(0).getInterfaceName());
            endpoint.setEndpointStatus(device.isElementStatus());
            AAIResourceUri endpointUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.service().vpnService(serviceId).endpoint(endpoint.getEndpointId()));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(endpointUri, endpoint).connect(deviceUri, endpointUri);
            transactions.execute();

            createVpnInstance(service, device);

            List<IetfNetwork> networks = new ArrayList<IetfNetwork>();

            if (networkType != null) {
                DSLStartNode startNode = new DSLStartNode(Types.N_NODE, __.key("node-id", device.getDeviceId()));
                DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                        .to(__.node(Types.IETF_NETWORK, __.key("network-type", networkType))).output();

                String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

                JSONParser parser = new JSONParser();
                JSONObject resultsJson = (JSONObject) parser.parse(results);
                List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

                for (int i = 0; i < resultsArray.size(); i++) {
                    JSONObject networkObj = (JSONObject) resultsArray.get(i).get("properties");
                    mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
                    IetfNetwork network = mapper.readValue(networkObj.toString(), IetfNetwork.class);
                    networks.add(network);
                }
            }
            for (IetfNetwork network : networks) {
                String networkId = network.getNetworkId();
                AAIResourceUri networkUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

                AAITransactionalClient networkTxns;
                networkTxns = rClient.beginTransaction().connect(vpnServiceUri, networkUri);
                networkTxns.execute();
            }
            endpoints.add(endpoint);
        }

        for (int i = 0; i < endpoints.size(); i++) {
            for (int j = endpoints.size() - 1; j > i; j--) {
                Endpoint srcEndpoint = endpoints.get(i);
                Endpoint destEndpoint = endpoints.get(j);

                String srcElement = srcEndpoint.getEndpointName();
                String srcInterface = srcEndpoint.getEndpointRole();
                String destElement = destEndpoint.getEndpointName();
                String destInterface = destEndpoint.getEndpointRole();
                String pathId = UUID.randomUUID().toString();
                String pathName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;

                Path path = new Path();
                path.setPathId(pathId);
                path.setPathName(pathName);
                path.setSourceElement(srcElement);
                path.setSourceInterface(srcInterface);
                path.setDestinationElement(destElement);
                path.setDestinationInterface(destInterface);
                path.setProtocol("BGP");
                path.setPathRate(j - i);
                path.setHopsCount(j - i);
                path.setBandwidth("10Gbps");
                path.setLatency("50ms");
                path.setPathStatus(true);

                AAIResourceUri pathUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId).path(path.getPathId()));

                AAITransactionalClient pathTxns;
                pathTxns = rClient.beginTransaction().create(pathUri, path);
                pathTxns.execute();

                List<Integer> hops = new ArrayList<Integer>();
                for (int small = i; j >= small; small++) {
                    hops.add(small);
                }

                for (int hop = 0; hop < hops.size() - 1; hop++) {

                    Endpoint srcHop = endpoints.get(hop);
                    Endpoint destHop = endpoints.get(hop + 1);

                    String srcHopElement = srcHop.getEndpointName();
                    String srcHopInterface = srcHop.getEndpointRole();
                    String destHopElement = destHop.getEndpointName();
                    String destHopInterface = destHop.getEndpointRole();

                    String hopId = UUID.randomUUID().toString();
                    String hopName = srcHopInterface + "@" + srcHopElement + ":" + destHopInterface + "@"
                            + destHopElement;

                    Pathhop pathhop = new Pathhop();
                    pathhop.setHopId(hopId);
                    pathhop.setHopName(hopName);
                    pathhop.setSourceElement(srcHopElement);
                    pathhop.setSourceInterface(srcHopInterface);
                    pathhop.setDestinationElement(destHopElement);
                    pathhop.setDestinationInterface(destHopInterface);
                    pathhop.setProtocol("BGP");
                    pathhop.setOrder(hop + 1);
                    pathhop.setCost(1);
                    pathhop.setBandwidth("10Gbps");
                    pathhop.setLatency(hop + 2 + "0ms");
                    pathhop.setHopStatus(true);

                    AAIResourceUri hopUri = AAIUriFactory.createResourceUri(
                            AAIFluentTypeBuilder.service().vpnService(serviceId).pathhop(pathhop.getHopId()));

                    AAITransactionalClient hopTxns;
                    hopTxns = rClient.beginTransaction().create(hopUri, pathhop).connect(hopUri, pathUri);
                    hopTxns.execute();

                }
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body("Service Resources Created");
    }

    private void createVpnInstance(VpnService service, NetworkDevice device) throws BulkProcessFailed {
        String serviceType = service.getServiceType();
        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(service.getServiceId()));

        AAITransactionalClient transactions;

        switch (serviceType) {
            case "L2 VPN":
                L2VpnInstance vpnInstance = new L2VpnInstance();
                String vpnInstanceId = UUID.randomUUID().toString();
                vpnInstance.setL2VpnInstanceId(vpnInstanceId);
                vpnInstance.setVplsName(service.getServiceName());
                vpnInstance.setVpnId(service.getServiceId());

                L2Vpn l2vpn = new L2Vpn();
                DSLStartNode startNode = new DSLStartNode(Types.VPN_SERVICE,
                        __.key("service-id", service.getServiceId()));
                DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.L2_VPN))
                        .output();

                String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));
                JSONParser parser = new JSONParser();
                JSONObject resultsJson = new JSONObject();

                try {
                    resultsJson = (JSONObject) parser.parse(results);
                } catch (ParseException e1) {
                    e1.printStackTrace();
                }
                List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

                JSONObject vpnObj = (JSONObject) resultsArray.get(0).get("properties");
                mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
                try {
                    l2vpn = mapper.readValue(vpnObj.toString(), L2Vpn.class);
                } catch (JsonProcessingException e) {
                    e.printStackTrace();
                }
                vpnInstance.setMtu(Integer.parseInt(l2vpn.getMtu()));
                vpnInstance.setSignalingType(l2vpn.getSignalingType());
                vpnInstance.setControlWord(true);
                vpnInstance.setOperationalStatus(true);

                AAIResourceUri l2vpnInstanceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                        .networkDevice(device.getDeviceId()).l2VpnInstance(vpnInstance.getL2VpnInstanceId()));

                transactions = rClient.beginTransaction().create(l2vpnInstanceUri, vpnInstance)
                        .connect(l2vpnInstanceUri, vpnServiceUri);
                transactions.execute();

                break;
            case "L3 VPN":
                L3VpnInstance l3vpnInstance = new L3VpnInstance();
                String l3vpnInstanceId = UUID.randomUUID().toString();
                l3vpnInstance.setL3VpnInstanceId(l3vpnInstanceId);
                l3vpnInstance.setVrfName(service.getServiceName());
                l3vpnInstance.setVpnId(service.getServiceId());
                l3vpnInstance.setRouteDistinguisher(String.valueOf((int) (Math.random() * (200 - 40 + 1) + 40)));
                l3vpnInstance.setMaxRoutes((int) (Math.random() * (500 - 200 + 1) + 200));
                l3vpnInstance.setMidRouteThreshold((int) (Math.random() * (500 - 200 + 1) + 200));
                l3vpnInstance.setHighRouteThreshold((int) (Math.random() * (500 - 200 + 1) + 200));
                l3vpnInstance.setAdminStatus("up");

                AAIResourceUri l3vpnInstanceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                        .networkDevice(device.getDeviceId()).l3VpnInstance(l3vpnInstance.getL3VpnInstanceId()));

                transactions = rClient.beginTransaction().create(l3vpnInstanceUri, l3vpnInstance)
                        .connect(l3vpnInstanceUri, vpnServiceUri);
                transactions.execute();

                break;
            default:
                break;
        }
    }

    private void createLink(String networkId, String srcElement, String srcInterface, String destElement,
            String destInterface, String linkType, String linkRate, String linkLatency) {
        Link link = new Link();
        String linkId = UUID.randomUUID().toString();
        String linkName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;
        link.setLinkId(linkId);
        link.setLinkName(linkName);
        link.setLinkType(linkType);
        link.setSourceNode(srcElement);
        link.setSourceEndpoint(srcInterface);
        link.setDestinationNode(destElement);
        link.setDestinationEndpoint(destInterface);
        link.setLinkRate(linkRate);
        link.setLinkLatency(linkLatency);
        link.setDelay("3000ms");
        link.setAutoNegotiation(true);
        link.setDuplexMode("full");
        link.setAdminStatus(true);
        link.setLinkStatus(true);

        AAIResourceUri linkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).link(link.getLinkId()));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(linkUri, link);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    private void createLsp(String networkId, String srcElement, String srcInterface, String destElement,
            String destInterface) {
        Lsp lsp = new Lsp();
        String lspId = UUID.randomUUID().toString();
        String lspName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;

        lsp.setLspId(lspId);
        lsp.setLspName(lspName);

        lsp.setSourceElement(srcElement);
        lsp.setSourceInterface(srcInterface);
        lsp.setDestinationElement(destElement);
        lsp.setDestinationInterface(destInterface);
        lsp.setLspStatus(true);
        lsp.setAdminStatus(true);

        AAIResourceUri lspUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).lsp(lsp.getLspId()));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(lspUri, lsp);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    private void createRoute(String networkId, String srcElement, String srcInterface, String localAddress,
            String destElement, String destInterface, String nexthopAddress) {

        Route route = new Route();
        String routeId = UUID.randomUUID().toString();
        String routeName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;
        route.setRouteId(routeId);
        route.setRouteName(routeName);
        route.setSourceElement(srcElement);
        route.setLocalAddress(srcInterface);
        route.setDestinationElement(destElement);
        route.setNexthopAddress(nexthopAddress);
        route.setProtocol("BGP");
        route.setRouteStatus(true);
        route.setAdminStatus(true);

        AAIResourceUri routeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).route(route.getRouteId()));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(routeUri, route);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    private BridgeInstance createBridgeInstance(String deviceId, String bridgeName, Boolean gmrpStatus,
            Boolean gvrpStatus, String trafficClass, Integer maxVlanId, Integer maxSupportedVlans, Integer numOfVlans,
            Integer activeVlans, Boolean bridgeState) {

        BridgeInstance bridge = new BridgeInstance();
        String bridgeId = UUID.randomUUID().toString();

        bridge.setBridgeId(bridgeId);
        bridge.setBridgeName(bridgeName);
        bridge.setGmrpStatus(gmrpStatus);
        bridge.setGvrpStatus(gvrpStatus);
        bridge.setTrafficClass(trafficClass);
        bridge.setMaxVlanId(maxVlanId);
        bridge.setMaxSupportedVlans(maxSupportedVlans);
        bridge.setNumOfVlans(numOfVlans);
        bridge.setActiveVlans(activeVlans);
        bridge.setBridgeState(bridgeState);

        StpConfig stpConfig = new StpConfig();
        stpConfig.setConfigId(bridgeId);
        stpConfig.setEnableStp(true);
        stpConfig.setDeviceId(deviceId);
        stpConfig.setDesignatedRootBridge("bridge1");
        stpConfig.setBridgeRootCost("4");
        stpConfig.setTransmitHoldCount(400);
        stpConfig.setMaxAge(600);
        stpConfig.setHelloTime(6000);
        stpConfig.setForwardDelay(4000);
        stpConfig.setTopologyChanges(6);
        stpConfig.setLastTopologyChange(new Date().toString());

        bridge.getStpConfig().add(stpConfig);
        return bridge;
    }

    private BgpInstance createBgpInstance(String identifierName, String localAsNumber, Integer maxRoutes,
            Integer maxPeers, Integer maxIbgpPaths, Integer maxEbgpPaths, Integer maxEibgpPaths, Boolean operStatus) {

        BgpInstance bgp = new BgpInstance();
        String bgpId = UUID.randomUUID().toString();

        bgp.setBgpId(bgpId);
        bgp.setBgpInstanceName(identifierName);
        bgp.setLocalAsNumber(localAsNumber);
        bgp.setAdvtNonBgpRoutes(true);
        bgp.setEnableSnmpNotifications(true);
        bgp.setMaxRoutes(maxRoutes);
        bgp.setMaxPeers(maxPeers);
        bgp.setCurrentPeers(0);
        bgp.setMaxIbgpPaths(maxIbgpPaths);
        bgp.setMaxEbgpPaths(maxEbgpPaths);
        bgp.setMaxEibgpPaths(maxEibgpPaths);
        bgp.setInstanceStatus(operStatus);

        return bgp;
    }

    private BgpPeer constructPeer(String localAddress, String peerName, Integer localPort, String remoteAddressType,
            String remoteAddress, Integer remotePort) {
        BgpPeer peer = new BgpPeer();
        String peerId = UUID.randomUUID().toString();
        peer.setPeerId(peerId);
        peer.setPeerName(peerName);
        peer.setLocalAddress(localAddress);
        peer.setLocalPort(localPort);
        peer.setRemoteAddressType(remoteAddressType);
        peer.setRemoteAddress(remoteAddress);
        peer.setRemotePort(remotePort);
        peer.setPeerState("suppressed");
        peer.setAdminStatus("enabled");
        peer.setNegotiatedVersion(1);
        peer.setRemoteAsNumber(1);
        peer.setConnectRetryInterval(10);
        peer.setHoldTimeConfigured(10);
        peer.setKeepAliveConfigured(10);
        peer.setMinAsOriginationInterval(10);
        peer.setMinRouteAdvertisementInterval(10);
        peer.setRestartMode("receiving");
        peer.setRestartTimeInterval(10);
        peer.setAllowAutomaticStart("enable");
        peer.setIdleHoldTimeConfigured(60);
        peer.setDelayOpen("enable");
        peer.setDelayOpenTimeConfigured(0);
        peer.setPrefixUpperLimit(5000);
        peer.setTcpConnectRetryCount(5);
        peer.setIsPeerDamped("enable");
        peer.setBfdStatus(true);
        peer.setConnectionStatus(true);
        return peer;
    }

    private OspfInstance createOspfInstance(String instanceName, String globalTraceLevel, String spfComputeInterval,
            String staggeringStatus, String internalState, String tosSupport, Boolean operStatus) {

        OspfInstance ospf = new OspfInstance();
        String ospfId = UUID.randomUUID().toString();

        ospf.setOspfId(ospfId);
        ospf.setOspfInstanceName(instanceName);
        ospf.setGlobalTraceLevel(globalTraceLevel);
        ospf.setSpfComputeInterval(spfComputeInterval);
        ospf.setStaggeringStatus(staggeringStatus);
        ospf.setInternalState(internalState);
        ospf.setTosSupport(tosSupport);
        ospf.setInstanceStatus(operStatus);

        return ospf;
    }

    private OspfNeighbour constructNeighbour(String neighbourName, String ipAddress, Integer addressLessIndex,
            String grStatus, String grReason, Boolean state) {
        OspfNeighbour neighbour = new OspfNeighbour();
        String neighbourId = UUID.randomUUID().toString();
        neighbour.setNeighbourId(neighbourId);
        neighbour.setNeighbourName(neighbourName);
        neighbour.setIpAddress(ipAddress);
        neighbour.setAddressLessIndex(addressLessIndex);
        neighbour.setBfdState(true);
        neighbour.setGracefulRestartStatus(grStatus);
        neighbour.setGracefulRestartReason(grStatus);
        neighbour.setNeighbourState(state);
        return neighbour;
    }

    private LdpEntity createLdpEntity(String ldpId, Integer entityIndex, String labelDistMethod,
            String labelRetentionMode, Integer tcpPort, Integer udpDescPort, Integer pduLength, String ipAddress,
            Boolean operStatus) {

        LdpEntity entity = new LdpEntity();
        String entityId = UUID.randomUUID().toString();

        entity.setEntityId(entityId);
        entity.setEntityIndex(entityIndex);
        entity.setEntityLdpId(ldpId);
        entity.setLabelDistMethod(labelDistMethod);
        entity.setLabelRetentionMode(labelRetentionMode);
        entity.setTcpPort(tcpPort);
        entity.setUdpDescPort(udpDescPort);
        entity.setMaxPduLength(pduLength);
        entity.setOperStatus(true);
        entity.setTargetPeerAddrType("ipv4");
        entity.setTargetPeerAddr(ipAddress);
        entity.setProtocolVersion(1);
        entity.setInitSessionThreshold(8);
        entity.setKeepAliveHoldTimer(40);

        return entity;
    }

    public LdpPeer constructLdpPeer(String peerLdpId, String ipAddress, String labelDistMethod) {
        LdpPeer peer = new LdpPeer();
        String peerId = UUID.randomUUID().toString();

        peer.setPeerId(peerId);
        peer.setPeerLdpId(peerLdpId);
        peer.setPeerLabelDistMethod(labelDistMethod);
        peer.setPeerPathVectorLimit(50);
        peer.setPeerTransportAddrType("IPv4");
        peer.setPeerTransportAddr(ipAddress);

        return peer;
    }

    private MplsTunnel createTunnel(Integer tunnelIndex, String tunnelName, String ingressLsr, String egressLsr,
            String signalingProtocol, Integer setupPriority, Integer holdingPriority, Integer instancePriority,
            String pathInUse) {

        MplsTunnel tunnel = new MplsTunnel();
        String tunnelId = UUID.randomUUID().toString();

        tunnel.setTunnelId(tunnelId);
        tunnel.setTunnelIndex(tunnelIndex);
        tunnel.setTunnelName(tunnelName);
        tunnel.setIngressLsrId(ingressLsr);
        tunnel.setEgressLsrId(egressLsr);
        tunnel.setSignalingProtocol(signalingProtocol);
        tunnel.setAdminStatus(true);
        tunnel.setOperStatus(true);

        tunnel.setSetUpPriority(setupPriority);
        tunnel.setHoldingPriority(holdingPriority);
        tunnel.setPrimaryInstance(1);
        tunnel.setInstancePriority(instancePriority);
        tunnel.setPathInUse(pathInUse);
        return tunnel;
    }
}