package in.utl.noa.element.config.resource.port.model;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "interfacestats")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "statsId")
public class InterfaceStats implements Serializable {

	private static final long serialVersionUID = 2166767574384150667L;
	
	@Id
	@Column(name = "statsid")
	private String statsId;

	@Column(name = "interfaceid")
	private String interfaceId;

	@Column(name = "ipaddress")
	private String ipAddress;
    
    @Column(name = "deviceid")
    private String deviceId;

    @Column(name = "speed")
    private String speed;
    
    @Column(name = "forwardingenabled")
    private Boolean forwardingEnabled;

    @Column(name = "packetsreceived")
    private String packetsReceived;

    @Column(name = "packetstransferred")
    private String packetsTransferred;

    @Column(name = "status")
    private Boolean status;
    
    @Column(name = "timestamp")
    private Date timestamp;
    
	public InterfaceStats() {
        super();
    }

    public InterfaceStats(final String interfaceId) {
        super();
        this.interfaceId = interfaceId;
	}
	
	public String getStatsId() {
        return statsId;
    }

    public void setStatsId(String statsId) {
        this.statsId = statsId;
    }

    public String getInterfaceId() {
        return interfaceId;
    }

    public void setInterfaceId(String interfaceId) {
        this.interfaceId = interfaceId;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public String getSpeed() {
        return speed;
    }

    public void setSpeed(String speed) {
        this.speed = speed;
    }

    public Boolean getForwardingEnabled() {
        return forwardingEnabled;
    }

    public void setForwardingEnabled(Boolean forwardingEnabled) {
        this.forwardingEnabled = forwardingEnabled;
    }

    public String getPacketsReceived() {
        return packetsReceived;
    }

    public void setPacketsReceived(String packetsReceived) {
        this.packetsReceived = packetsReceived;
    }

    public String getPacketsTransferred() {
        return packetsTransferred;
    }

    public void setPacketsTransferred(String packetsTransferred) {
        this.packetsTransferred = packetsTransferred;
    }
    
    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
}
