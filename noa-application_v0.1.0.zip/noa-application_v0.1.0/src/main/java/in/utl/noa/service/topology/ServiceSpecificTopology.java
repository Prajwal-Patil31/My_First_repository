package in.utl.noa.service.topology;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.onap.aai.domain.yang.Endpoint;
import org.onap.aai.domain.yang.Path;
import org.onap.aai.domain.yang.Pathhop;
import org.onap.aai.domain.yang.VpnService;

import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;

@RestController
@RequestMapping(value = "/api/service/{serviceId}/topology")
public class ServiceSpecificTopology {

    private static Logger logger = Logger.getLogger(ServiceSpecificTopology.class);

    JSONParser parser = new JSONParser();

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<Map<String, List<JSONObject>>> getNetworkSpecificTopology(
            @PathVariable("serviceId") String serviceId) {

        VpnService service = new VpnService();
        AAIResourceUri serviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId)).depth(Depth.TWO);

        Map<String, List<JSONObject>> topologyObject = new HashMap<String, List<JSONObject>>();
        service = rClient.get(VpnService.class, serviceUri).get();
        String serviceType = service.getServiceType();

        List<Endpoint> serviceEndpoints = new ArrayList<Endpoint>();
        List<Path> servicePaths = new ArrayList<Path>();

        List<Pathhop> serviceLinks = new ArrayList<Pathhop>();

        if (service.getEndpoints() != null) {
            serviceEndpoints = service.getEndpoints().getEndpoint();
        }

        if (service.getPaths() != null) {
            servicePaths = service.getPaths().getPath();
        }

        if (service.getPathhops() != null) {
            serviceLinks = service.getPathhops().getPathhop();
        }

        List<JSONObject> nodes = new ArrayList<JSONObject>();
        List<JSONObject> links = new ArrayList<JSONObject>();

        for (Endpoint serviceEndpoint : serviceEndpoints) {
            JSONObject node = new JSONObject();
            node.put("id", serviceEndpoint.getEndpointId());
            node.put("name", serviceEndpoint.getEndpointName());
            if (serviceEndpoint.isEndpointStatus() == null || serviceEndpoint.isEndpointStatus() == true) {
                node.put("color", "#0how00");
            } else {
                node.put("color", "#FF0000");
            }
            node.put("role", "node");
            node.put("iconType", "router");
            nodes.add(node);
        }

        topologyObject.put("nodes", nodes);

        for (Pathhop serviceLink : serviceLinks) {
            JSONObject link = new JSONObject();
            link.put("id", serviceLink.getHopId());
            link.put("label", serviceLink.getHopName());
            link.put("source", serviceLink.getSourceElement());
            link.put("target", serviceLink.getDestinationElement());

            if (!links.stream().anyMatch(o -> o.get("label").toString().equals(serviceLink.getHopName()))) {
                links.add(link);
            }
        }

        topologyObject.put("links", links);
        return ResponseEntity.status(HttpStatus.OK).body(topologyObject);
    }
}
