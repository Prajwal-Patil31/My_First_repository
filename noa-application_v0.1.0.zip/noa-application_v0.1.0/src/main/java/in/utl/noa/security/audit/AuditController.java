package in.utl.noa.security.audit;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.onap.aai.domain.yang.AccessMetadata;
import org.onap.aai.domain.yang.AuditLog;
import org.onap.aai.domain.yang.AuditLogs;
import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;

import org.onap.aaiclient.client.graphinventory.entities.DSLNodeKey;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Output;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

@RestController
@RequestMapping(value = "/api/platform/security/audit")
public class AuditController {

    private static Logger logger = Logger.getLogger(AuditController.class);
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getAuditLogFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "audit-log");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("category", "Category");
        columns.put("subCategory", "Sub Category");
        columns.put("event", "Event");
        columns.put("description", "Description");
        columns.put("accountId", "User Account");
        columns.put("timeStamp", "Time Stamp");
        columns.put("status", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getAuditLogList(@RequestBody RequestBodyDTO requestBody)
            throws JsonProcessingException {
        JSONObject auditLogs = filterService.queryByFilter(requestBody, "audit-log");
        return ResponseEntity.status(HttpStatus.OK).body(auditLogs);
    }

    @GetMapping()
    public ResponseEntity<List<AuditLog>> getAllLogs() {
        List<AuditLog> auditLogs = new ArrayList<AuditLog>();

        AAIPluralResourceUri auditLogsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().auditLogs())
                .depth(Depth.TWO);

        if (rClient.exists(auditLogsUri)) {

            AuditLogs logsList = rClient.get(AuditLogs.class, auditLogsUri).get();

            auditLogs = logsList.getAuditLog();
        }
        return ResponseEntity.status(HttpStatus.OK).body(auditLogs);
    }

    @PostMapping(value = "/filter", produces = "application/json")
    public ResponseEntity<List<AuditLog>> getLogsByCategory(@RequestBody Map<String, List<String>> filterValues)
            throws JsonMappingException, JsonProcessingException, UnsupportedEncodingException {

        List<AuditLog> auditLogs = new ArrayList<AuditLog>();
        List<AccessMetadata> accessMetadataList = new ArrayList<AccessMetadata>();
        List<ResourceMetadata> resourceMetadataList = new ArrayList<ResourceMetadata>();

        List<String> categories = new ArrayList<String>();
        if (filterValues.get("category").size() != 0) {
            categories = filterValues.get("category");
        }

        List<String> subCategories = new ArrayList<String>();
        if (filterValues.get("sub-category").size() != 0) {
            subCategories = filterValues.get("sub-category");
        }

        List<String> events = new ArrayList<String>();
        if (filterValues.get("event").size() != 0) {
            List<String> eventKeys = filterValues.get("event");
            for (String eventKey : eventKeys) {
                events.add(NoaEvents.valueOf(eventKey).getEvent());
            }
        }

        List<String> users = new ArrayList<String>();
        if (filterValues.get("account-id").size() != 0) {
            users = filterValues.get("account-id");
        }

        String[] usersArray = users.toArray(new String[0]);
        String[] categoriesArray = categories.toArray(new String[0]);
        String[] subCategoriesArray = subCategories.toArray(new String[0]);
        String[] eventsArray = events.toArray(new String[0]);

        List<DSLNodeKey> categoriesFilter = new ArrayList<DSLNodeKey>();
        List<DSLNodeKey> subCategoriesFilter = new ArrayList<DSLNodeKey>();
        List<DSLNodeKey> eventsFilter = new ArrayList<DSLNodeKey>();
        List<DSLNodeKey> usersFilter = new ArrayList<DSLNodeKey>();

        List<DSLQueryBuilder<DSLStartNode, Node>> queryList = new ArrayList<DSLQueryBuilder<DSLStartNode, Node>>();

        if (categoriesArray.length > 0) {
            if (usersArray.length > 0) {
                categoriesFilter.add(__.key("account-id", usersArray));
            }
            categoriesFilter.add(__.key("category", categoriesArray));
            queryList.add(__.node(Types.AUDIT_LOG, categoriesFilter.toArray(new DSLNodeKey[0])).output());
        }

        if (subCategoriesArray.length > 0) {
            if (usersArray.length > 0) {
                subCategoriesFilter.add(__.key("account-id", usersArray));
            }
            subCategoriesFilter.add(__.key("sub-category", subCategoriesArray));
            queryList.add(__.node(Types.AUDIT_LOG, subCategoriesFilter.toArray(new DSLNodeKey[0])).output());
        }

        if (eventsArray.length > 0) {
            if (usersArray.length > 0) {
                eventsFilter.add(__.key("account-id", usersArray));
            }
            eventsFilter.add(__.key("event", eventsArray));
            queryList.add(__.node(Types.AUDIT_LOG, eventsFilter.toArray(new DSLNodeKey[0])).output());
        }

        List<DSLNodeKey> resourceFilter = new ArrayList<DSLNodeKey>();
        if (filterValues.get("resource-id").size() != 0) {
            String[] resourceIds = filterValues.get("resource-id").toArray(new String[0]);
            resourceFilter.add(__.key("resource-id", resourceIds));
        } else {
            resourceFilter.add(__.key("audit-id", "", "null").not());
        }

        if (categoriesArray.length == 0 && subCategoriesArray.length == 0 && eventsArray.length == 0
                && usersArray.length > 0) {
            usersFilter.add(__.key("account-id", usersArray));
            queryList.add(__.node(Types.AUDIT_LOG, usersFilter.toArray(new DSLNodeKey[0])).output());
        }

        if (filterValues.get("resource-id").size() == 0) {
            DSLStartNode accessStartNode = new DSLStartNode(Types.ACCESS_METADATA,
                    __.key("audit-id", "", "null").not());

            DSLQueryBuilder<Output, Output> accessBuilder = TraversalBuilder.traversal(accessStartNode.output());

            if (queryList.size() > 0) {
                accessBuilder.union(queryList.toArray(new DSLQueryBuilder[0]));
            }

            String accessResults = dslClient.query(Format.RESOURCE, new DSLQuery(accessBuilder.build()));

            Results<Map<String, AuditLog>> accessAuditResults = mapper.readValue(accessResults,
                    new TypeReference<Results<Map<String, AuditLog>>>() {
                    });

            Results<Map<String, AccessMetadata>> accessResultsFromJson = mapper.readValue(accessResults,
                    new TypeReference<Results<Map<String, AccessMetadata>>>() {
                    });

            for (Map<String, AuditLog> m : accessAuditResults.getResult()) {
                if (m.get("audit-log") != null) {
                    auditLogs.add(m.get("audit-log"));
                }
            }
            for (Map<String, AccessMetadata> m : accessResultsFromJson.getResult()) {
                if (m.get("access-metadata") != null) {
                    accessMetadataList.add(m.get("access-metadata"));
                }
            }
        }

        DSLStartNode resourceStartNode = new DSLStartNode(Types.RESOURCE_METADATA,
                resourceFilter.toArray(new DSLNodeKey[0]));

        DSLQueryBuilder<Output, Output> resourceBuilder = TraversalBuilder.traversal(resourceStartNode.output());

        if (queryList.size() > 0) {
            resourceBuilder.union(queryList.toArray(new DSLQueryBuilder[0]));
        } else {
            resourceBuilder.to(__.node(Types.AUDIT_LOG).output());
        }

        String resourceResults = dslClient.query(Format.RESOURCE, new DSLQuery(resourceBuilder.build()));

        Results<Map<String, AuditLog>> resourceAuditResults = mapper.readValue(resourceResults,
                new TypeReference<Results<Map<String, AuditLog>>>() {
                });

        Results<Map<String, ResourceMetadata>> resourceResultsFromJson = mapper.readValue(resourceResults,
                new TypeReference<Results<Map<String, ResourceMetadata>>>() {
                });

        for (Map<String, AuditLog> m : resourceAuditResults.getResult()) {
            if (m.get("audit-log") != null) {
                auditLogs.add(m.get("audit-log"));
            }
        }
        for (Map<String, ResourceMetadata> m : resourceResultsFromJson.getResult()) {
            if (m.get("resource-metadata") != null) {
                resourceMetadataList.add(m.get("resource-metadata"));
            }
        }

        for (AuditLog auditLog : auditLogs) {
            String auditId = auditLog.getAuditId();
            AccessMetadata accessMetadata = accessMetadataList.stream()
                    .filter(metadata -> metadata.getAuditId().equals(auditId)).findFirst().orElse(null);

            ResourceMetadata resourceMetadata = resourceMetadataList.stream()
                    .filter(metadata -> metadata.getAuditId().equals(auditId)).findFirst().orElse(null);

            if (accessMetadata != null) {
                auditLog.getAccessMetadata().add(accessMetadata);
            }
            if (resourceMetadata != null) {
                auditLog.getResourceMetadata().add(resourceMetadata);
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body(auditLogs);
    }

    @DeleteMapping()
    public ResponseEntity<String> clearAllLogs() {
        AAIPluralResourceUri auditLogsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().auditLogs())
                .depth(Depth.TWO);

        if (rClient.exists(auditLogsUri)) {

            AuditLogs logsList = rClient.get(AuditLogs.class, auditLogsUri).get();

            List<AuditLog> auditLogs = logsList.getAuditLog();

            for (AuditLog auditLog : auditLogs) {
                AAIResourceUri auditLogUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().auditLog(auditLog.getAuditId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(auditLogUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Audit Logs have been Deleted.");
    }
}
