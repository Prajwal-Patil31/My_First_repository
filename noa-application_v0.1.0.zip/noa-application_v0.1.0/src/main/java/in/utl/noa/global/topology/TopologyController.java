package in.utl.noa.global.topology;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.VpnService;
import org.onap.aai.domain.yang.Endpoint;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.Route;
import org.onap.aai.domain.yang.NNode;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.global.topology.service.TopologyService;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.platform.config.service.RollbackHandler;

@RestController
@RequestMapping(value = "/api/global/topology")
public class TopologyController {
    private static Logger logger = Logger.getLogger(TopologyController.class);
    private static Map<String, JSONObject> filters;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    TopologyService topologyService;

    AuditLogger auditLogger = new AuditLogger();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    private JSONParser parser = new JSONParser();
    private ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getTopologyFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();
		
        String filterModules[] = new String[] { "ietf-network", "n-node", "link","lsp","route"};

        filters = filterService.getFilterCriteria("topology", filterModules);

        responseData.setFilters(filters);
        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @DeleteMapping()
    public ResponseEntity<String> clearAllFilters() {
        filterService.deleteFilters();
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Filters Deleted.");
    }

    @GetMapping("/{networkType}/link/{linkId}")
    public ResponseEntity<JSONObject> getLinkById(@PathVariable("linkId") String linkId,@PathVariable("networkType") String networkType) throws ParseException {
        JSONObject linkDetail = new JSONObject();
        
        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", "","null").not());
        
        DSLQueryBuilder<Start, Node> builder = null;
        JSONParser parser = new JSONParser();
        String results = null;
        JSONObject resultsJson = new JSONObject();

        List<JSONObject> resultsArray = new ArrayList<JSONObject>();
        JSONObject link = new JSONObject();

        switch(networkType) {
            case "L1 Network":
                builder = TraversalBuilder.fragment(startNode).to(__.node(Types.LINK)).output();
                results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));
                resultsJson = (JSONObject) parser.parse(results);
                resultsArray = (List<JSONObject>) resultsJson.get("results");
                linkDetail = (JSONObject) resultsArray.get(0).get("properties");

                link.put("id",linkDetail.get("link-id").toString());
                link.put("type",linkDetail.get("link-type").toString());
                link.put("name",linkDetail.get("link-name").toString());
                link.put("source",linkDetail.get("source-node").toString());
                link.put("sourceInterface",linkDetail.get("source-endpoint").toString());
                link.put("target",linkDetail.get("destination-node").toString());
                link.put("destinationInterface",linkDetail.get("destination-endpoint").toString());
                link.put("status",linkDetail.get("link-status").toString());
                break;
            case "L2 Network":
                builder = TraversalBuilder.fragment(startNode).to(__.node(Types.LINK)).output();
                results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));
                resultsJson = (JSONObject) parser.parse(results);
                resultsArray = (List<JSONObject>) resultsJson.get("results");
                linkDetail = (JSONObject) resultsArray.get(0).get("properties");

                link.put("id",linkDetail.get("link-id").toString());
                link.put("type",linkDetail.get("link-type").toString());
                link.put("name",linkDetail.get("link-name").toString());
                link.put("source",linkDetail.get("source-node").toString());
                link.put("sourceInterface",linkDetail.get("source-endpoint").toString());
                link.put("target",linkDetail.get("destination-node").toString());
                link.put("destinationInterface",linkDetail.get("destination-endpoint").toString());
                link.put("status",linkDetail.get("link-status").toString());
                break;
            case "L2.5 Network":
                builder = TraversalBuilder.fragment(startNode).to(__.node(Types.LSP)).output();
                results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));
                resultsJson = (JSONObject) parser.parse(results);
                resultsArray = (List<JSONObject>) resultsJson.get("results");
                linkDetail = (JSONObject) resultsArray.get(0).get("properties");

                link.put("id",linkDetail.get("lsp-id").toString());
                link.put("type","LSP");
                link.put("name",linkDetail.get("lsp-name").toString());
                link.put("source",linkDetail.get("source-element").toString());
                link.put("sourceInterface",linkDetail.get("source-interface").toString());
                link.put("target",linkDetail.get("destination-element").toString());
                link.put("destinationInterface",linkDetail.get("destination-interface").toString());
                link.put("status",linkDetail.get("lsp-status").toString());
                break;
            case "L3 Network":
                builder = TraversalBuilder.fragment(startNode).to(__.node(Types.ROUTE)).output();
                results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));
                resultsJson = (JSONObject) parser.parse(results);
                resultsArray = (List<JSONObject>) resultsJson.get("results");
                linkDetail = (JSONObject) resultsArray.get(0).get("properties");

                link.put("id",linkDetail.get("route-id").toString());
                link.put("type","Route");
                link.put("name",linkDetail.get("route-name").toString());
                link.put("source",linkDetail.get("source-element").toString());
                link.put("sourceInterface",linkDetail.get("local-address").toString());
                link.put("target",linkDetail.get("destination-element").toString());
                link.put("destinationInterface",linkDetail.get("nexthop-address").toString());
                link.put("status",linkDetail.get("route-status").toString());
                break;
        }
        return ResponseEntity.status(HttpStatus.OK).body(link);
    }

    @GetMapping("/{networkType}")
    public ResponseEntity<Map<String, List<JSONObject>>> getGlobalTopology(@PathVariable("networkType") String networkType) 
        throws ParseException, JsonMappingException, JsonProcessingException {

        Map<String, List<JSONObject>> topologyObject = new HashMap<String,List<JSONObject>>();
		List<IetfNetwork> networks = new ArrayList<IetfNetwork>();
        List<String> networkIds = new ArrayList<String>();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-type", networkType));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject networkObj = (JSONObject) resultsArray.get(i).get("properties");
            String networkId = networkObj.get("network-id").toString();
            networkIds.add(networkId);
        }
        
        for(String networkId : networkIds) {
            IetfNetwork network = new IetfNetwork();
            AAIResourceUri networkUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

            network = rClient.get(IetfNetwork.class, networkUri).get();                
            networks.add(network);
        }

        List<NNode> networkNodes = new ArrayList<NNode>();
        List<Link> networkLinks = new ArrayList<Link>();
        List<Lsp> networkLsps = new ArrayList<Lsp>();
        List<Route> networkRoutes = new ArrayList<Route>();

        List<JSONObject> nodes = new ArrayList<JSONObject>();
        List<JSONObject> links = new ArrayList<JSONObject>();
        List<JSONObject> nodeSets = new ArrayList<JSONObject>();

        for(IetfNetwork network : networks) {
            List<String> nodesList = new ArrayList<String>();
            if(network.getNNodes() != null) {
                networkNodes.addAll(network.getNNodes().getNNode());
            }
            
            switch(networkType) {
                case "L1 Network":
                    if(network.getLinks() != null) {
                        networkLinks.addAll(network.getLinks().getLink());
                    }
                    break;
                case "L2 Network":
                    if(network.getLinks() != null) {
                        networkLinks.addAll(network.getLinks().getLink());
                    }
                    break;
                case "L2.5 Network":
                    if(network.getLsps() != null) {
                        networkLsps.addAll(network.getLsps().getLsp());
                    }
                    break;
                case "L3 Network":
                    if(network.getRoutes() != null) {
                        networkRoutes.addAll(network.getRoutes().getRoute());
                    }
                    break;
                default:
                    break;
            }

            JSONObject networkObj = new JSONObject();

            for(NNode networkNode : networkNodes) {
                nodesList.add(networkNode.getNodeName());
            }
            networkObj.put("id", network.getNetworkId());
            networkObj.put("type", "nodeSet");
            networkObj.put("name", network.getNetworkName());
            networkObj.put("nodes", nodesList);
            if (network.isNetworkStatus() == null || network.isNetworkStatus() == true) {
                networkObj.put("color", "#0how00");
            } else {
                networkObj.put("color", "#FF0000");
            }
            nodeSets.add(networkObj);
        }

        for (NNode networkNode : networkNodes) {
            JSONObject node = new JSONObject();
            node.put("id", networkNode.getNodeId());
            node.put("name", networkNode.getNodeName());
            if (networkNode.isNodeStatus() == null || networkNode.isNodeStatus() == true) {
                node.put("color", "#0how00");
            } else {
                node.put("color", "#FF0000");
            }
            node.put("role", "node");
            node.put("iconType", "router");
            nodes.add(node);
        }

        topologyObject.put("nodes", nodes);

        for (Link networkLink : networkLinks) {
            JSONObject link = new JSONObject();
            link.put("id", networkLink.getLinkId());
            link.put("label", networkLink.getLinkName());
            link.put("source", networkLink.getSourceNode());
            link.put("type","link");
            link.put("sourceInt",networkLink.getSourceEndpoint());
            link.put("destinationInt",networkLink.getDestinationEndpoint());
            link.put("target", networkLink.getDestinationNode());
            links.add(link);
        }

        for (Lsp networkLsp : networkLsps) {
            JSONObject lsp = new JSONObject();
            lsp.put("id", networkLsp.getLspId());
            lsp.put("label", networkLsp.getLspName());
            lsp.put("source", networkLsp.getSourceElement());
            lsp.put("type","route");
            lsp.put("sourceIp",networkLsp.getSourceInterface());
            lsp.put("destinationIp",networkLsp.getDestinationInterface());
            lsp.put("target", networkLsp.getDestinationElement());
            links.add(lsp);
        }

        for (Route networkRoute : networkRoutes) {
            JSONObject route = new JSONObject();
            route.put("id", networkRoute.getRouteId());
            route.put("label", networkRoute.getRouteName());
            route.put("source", networkRoute.getSourceElement());
            route.put("type","route");
            route.put("sourceIp",networkRoute.getLocalAddress());
            route.put("destinationIp",networkRoute.getNexthopAddress());
            route.put("target", networkRoute.getDestinationElement());
            links.add(route);
        }
        topologyObject.put("links", links);
        topologyObject.put("nodeSets", nodeSets);

        return ResponseEntity.status(HttpStatus.OK).body(topologyObject);
    }

    @PostMapping()
    public ResponseEntity<Map<String, List<JSONObject>>> getTopology(@RequestBody RequestBodyDTO requestBody) {

        List<String> networkTypeValues = new ArrayList<>();
        networkTypeValues.add("L3 Network");

        JSONObject networkTypeFilter = new JSONObject();
        networkTypeFilter.put("network-type", networkTypeValues);

        Map<String, JSONObject> networkObject = new HashMap<>();
        networkObject.put("topology:ietf-network", networkTypeFilter);
        
        if(requestBody.getFilters() == null) {
            requestBody.setFilters(networkObject);
        } else if(requestBody.getFilters().keySet().size() == 0) {
            requestBody.setFilters(networkObject);
        } else {
            int filterCount = 0;
            for(var key : requestBody.getFilters().keySet()) {
                if(requestBody.getFilters().get(key) != null) {
                    if(requestBody.getFilters().get(key).keySet().size() != 0) {
                        for(var filterKey : requestBody.getFilters().get(key).keySet()) {
                            Object filterValue = requestBody.getFilters().get(key).get(filterKey);
                            if(filterValue instanceof List) {
                                filterCount++;
                            }
                        }
                    }
                }
            }
            if(filterCount == 0) {
                requestBody.setFilters(networkObject);
            }
        }
                
        List<Object> topologyResults = filterService.performQueryClientFilter(requestBody);

        Map<String, List<JSONObject>> topologyObject = topologyService.convertResultsToTopologyData(topologyResults, requestBody, "topology:ietf-network");

        return ResponseEntity.status(HttpStatus.OK).body(topologyObject);
    }

    @PostMapping(value = "/service")
    public ResponseEntity<Map<String,List<String>>> getDeployedService(@RequestBody List<String> serviceIds)
        throws ParseException, JsonMappingException, JsonProcessingException {

        Map<String,List<String>> serviceObj = new HashMap<String,List<String>>();
        for(String serviceId : serviceIds) {
            VpnService service = new VpnService();
            AAIResourceUri serviceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId)).depth(Depth.TWO);

            service = rClient.get(VpnService.class,serviceUri).get();
            
            List<Endpoint> endpoints = new ArrayList<Endpoint>();
            if(service.getEndpoints() != null) {
                endpoints = service.getEndpoints().getEndpoint();
            }

            List<String> endpointNames = new ArrayList<String>();
            for(Endpoint endpoint : endpoints) {
                endpointNames.add(endpoint.getEndpointName());
            }
            serviceObj.put(service.getServiceName(),endpointNames);
        }
        return ResponseEntity.status(HttpStatus.OK).body(serviceObj);
    }

    @PostMapping(value = "/network")
    public ResponseEntity<Map<String,List<String>>> getProvisionedNetworkDetails(@RequestBody List<String> networkIds) 
        throws ParseException, JsonMappingException, JsonProcessingException{
                
        Map<String,List<String>> networkObj = new HashMap<String,List<String>>();
        for(String networkId : networkIds) {
            IetfNetwork network = new IetfNetwork();
            AAIResourceUri networkUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

            network = rClient.get(IetfNetwork.class,networkUri).get();
            
            List<NNode> nodes = new ArrayList<NNode>();
            if(network.getNNodes() != null) {
                nodes = network.getNNodes().getNNode();
            }
    
            List<String> nodeNames = new ArrayList<String>();
            for(NNode node : nodes) {
                nodeNames.add(node.getNodeName());
            }
            networkObj.put(network.getNetworkName(),nodeNames);
        }
        return ResponseEntity.status(HttpStatus.OK).body(networkObj);
    }
}
