package in.utl.noa.global.event.controller;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.Event;
import org.onap.aai.domain.yang.Events;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.account.user.model.User;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

@RestController
@RequestMapping(value = "/api/global/event")
public class NotificationEventsController {

    private static Logger logger = Logger.getLogger(NotificationEventsController.class);
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    JSONParser parser = new JSONParser();

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    @GetMapping("/new")
    public ResponseEntity<List<Event>> getNotifications() throws JsonMappingException, JsonProcessingException {
        List<Event> events = new ArrayList<Event>();

        DSLStartNode startNode = new DSLStartNode(Types.EVENT, __.key("event-status", false));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Event>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Event>>>() {
                });

        for (Map<String, Event> m : resultsFromJson.getResult()) {
            events.add(m.get("event"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(events);
    }

    @GetMapping()
    public ResponseEntity<List<Event>> getAllNotifications() throws JsonMappingException, JsonProcessingException {
        List<Event> events = new ArrayList<Event>();

        AAIPluralResourceUri eventsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().events());

        if (rClient.exists(eventsUri)) {
            Optional<Events> userAccounts = rClient.get(Events.class, eventsUri);
            events = userAccounts.get().getEvent();
        }
        return ResponseEntity.status(HttpStatus.OK).body(events);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getEventFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "event");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("eventType", "Event Type");
        columns.put("resource", "Resource");
        columns.put("resourceId", "Resource Identifier");
        columns.put("description", "Description");
        columns.put("timestamp", "Timestamp");
        columns.put("ackUser", "Acknowledged User");
        columns.put("ackTimestamp", "Ack Timestamp");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getEventList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject events = filterService.queryByFilter(requestBody, "event");
        return ResponseEntity.status(HttpStatus.OK).body(events);
    }

    @PostMapping(value = "/create")
    public ResponseEntity<String> createEvents()
            throws BulkProcessFailed, FileNotFoundException, IOException, ParseException {

        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultEvents.json"));
        JSONObject faultsObj = (JSONObject) obj.get(0);
        List<JSONObject> eventList = (List<JSONObject>) faultsObj.get("events");

        for (JSONObject event : eventList) {
            String defaultEvent = event.toString();
            Event eventObj = mapper.readValue(defaultEvent, Event.class);
            String eventId = UUID.randomUUID().toString();

            AAIResourceUri eventUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().event(eventId));
            eventObj.setEventId(eventId);

            rClient.create(eventUri, eventObj);

        }
        return ResponseEntity.status(HttpStatus.OK).body("Events Added");
    }

    @PostMapping(value = "/{eventId}")
    public ResponseEntity<String> updateEvent(@PathVariable("eventId") String eventId, @RequestBody Event eventObj)
            throws BulkProcessFailed {

        AAIResourceUri eventUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().event(eventId));
        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().update(eventUri, eventObj);
        transactions.execute();
        return ResponseEntity.status(HttpStatus.OK).body("Event Updated");
    }

    @PostMapping(value = "/{eventId}/ack")
    public ResponseEntity<String> acknowledgeEvent(@RequestBody List<Event> events) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        in.utl.noa.account.user.model.UserAccount user = (in.utl.noa.account.user.model.UserAccount) auth
                .getPrincipal();
        String accountId = user.getUsername();

        Date date = Calendar.getInstance().getTime();
        String timeStamp = DATE_FORMAT.format(date);

        for (Event event : events) {
            String eventId = event.getEventId();
            // event.setAcknowledgedUser(accountId);
            // event.setAcknowledgedTimeStamp(timeStamp)
            event.setEventStatus(true);
            AAIResourceUri eventUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().event(eventId));
            AAITransactionalClient transactions = rClient.beginTransaction();
            transactions.update(eventUri, event);
            try {
                transactions.execute();
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body("Notifications have been Acknowledged");
    }

    @DeleteMapping()
    public ResponseEntity<String> clearEvents(@RequestBody List<String> eventIds) {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        User user = (User) auth.getPrincipal();
        String accountId = user.getAccountId();

        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));

        if (rClient.exists(userUri)) {
            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String eventId : eventIds) {
                AAIResourceUri eventUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().event(eventId));
                transactions.disconnect(userUri, eventUri);
            }
            try {
                transactions.execute();
            } catch (Exception e) {
                logger.info(e);
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body("Notifications have been Cleared.");
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteAllEvents() {
        AAIPluralResourceUri eventsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().events())
                .depth(Depth.TWO);

        Events eventsList = rClient.get(Events.class, eventsUri).get();

        List<Event> events = eventsList.getEvent();

        for (Event event : events) {
            AAIResourceUri eventUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.platform().event(event.getEventId()));

            if (rClient.exists(eventUri)) {
                AAITransactionalClient transactions = rClient.beginTransaction().delete(eventUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Notification Events have been Deleted.");
    }
}
