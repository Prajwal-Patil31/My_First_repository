package in.utl.noa.element.config.mpls;

import java.util.List;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.onap.aai.domain.yang.MplsConfig;
import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;

import in.utl.noa.global.event.NoaEvents;

import in.utl.noa.platform.config.service.RollbackHandler;
import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/mpls")
public class MplsGeneralConfiguration {
    private static Logger logger = Logger.getLogger(MplsGeneralConfiguration.class);

    static ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<MplsConfig> getMplsConfiguration(@PathVariable("deviceId") String deviceId) {

        MplsConfig mplsConfig = new MplsConfig();
        AAIResourceUri mplsConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).mplsConfig(deviceId));

        if (rClient.exists(mplsConfigUri)) {
            mplsConfig = rClient.get(MplsConfig.class, mplsConfigUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(mplsConfig);
    }

    @PostMapping()
    public ResponseEntity<String> updateMplsConfiguration(@PathVariable("deviceId") String deviceId,
            @RequestBody MplsConfig mplsConfig) throws BulkProcessFailed {

        AAITransactionalClient transactions;
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("MPLS Config", deviceId,
                "Network Device", deviceId);

        if (deviceId != null) {
            AAIResourceUri mplsConfigUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).mplsConfig(deviceId));

            MplsConfig actMplsConfig = new MplsConfig();
            if (mplsConfig.getConfigId() == null) {
                mplsConfig.setConfigId(deviceId);
            }

            if (rClient.exists(mplsConfigUri)) {
                actMplsConfig = rClient.get(MplsConfig.class, mplsConfigUri).get();
                transactions = rClient.beginTransaction().update(mplsConfigUri, mplsConfig);
                transactions.execute();
            } else {
                transactions = rClient.beginTransaction().create(mplsConfigUri, mplsConfig);
                transactions.execute();
                actMplsConfig = rClient.get(MplsConfig.class, mplsConfigUri).get();
            }

            description = "MPLS Configuration has been Updated in " + deviceId + " Device";

            JSONObject mplsConfigObj = rollbackHandler.getJsonObject(actMplsConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(mplsConfigObj, null, null);
            String resourceUri = mplsConfigUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.MplsConfig", deviceId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "MPLS",
                NoaEvents.MODIFY_MPLS_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }
}
