package in.utl.noa.global.fault.util;

import in.utl.noa.global.fault.dto.FaultDTO;
import org.springframework.messaging.Message;

import org.apache.log4j.Logger;

public class FaultMessageCorrelator {
    private static Logger logger = Logger.getLogger(FaultMessageCorrelator.class);

    public FaultMessageCorrelator() {
        super();
    }

    @SuppressWarnings("unused")
    public int getFaultCode(Message<?> message) {
        logger.info("getFaultCode:: " + ((FaultDTO) message.getPayload()).getFaultCode());
        return Integer.parseInt(((FaultDTO) message.getPayload()).getFaultCode());
    }  
}