package in.utl.noa.mdsal.toaster;

import org.eclipse.jdt.annotation.NonNull;
import org.opendaylight.mdsal.dom.api.DOMNotification;
import org.opendaylight.mdsal.dom.api.DOMNotificationListener;
import org.opendaylight.yang.gen.v1.http.netconfcentral.org.ns.toaster.rev091120.ToasterListener;
import org.opendaylight.yang.gen.v1.http.netconfcentral.org.ns.toaster.rev091120.ToasterOutOfBread;
import org.opendaylight.yang.gen.v1.http.netconfcentral.org.ns.toaster.rev091120.ToasterRestocked;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingNotificationListener implements ToasterListener {

    private static final Logger LOG = LoggerFactory.getLogger(LoggingNotificationListener.class);

    @Override
    public void onToasterOutOfBread(ToasterOutOfBread arg0) {
        LOG.info("onToasterOutOfBread Notification received");
    }

    @Override
    public void onToasterRestocked(ToasterRestocked notification) {
        LOG.info("Notification {} received {}", ToasterRestocked.QNAME, notification);
        // Read Notification Data Using 'notification' Object notification.*()
    }

}