package in.utl.noa.network.l1;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/api/network/{networkId}/link")
public class LinksManagement {
    private static Logger logger = Logger.getLogger(LinksManagement.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    @GetMapping(value = "/filter")
    public ResponseEntity<ResponseDataDTO> getNetworkLinkFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "link");

        Map<String, Object> columns = new HashMap<>();
        columns.put("linkName", "Link Name");
        columns.put("sourceNode", "Source Node");
        columns.put("sourceEndpoint", "Source Endpoint");
        columns.put("destinationNode", "Destination Element");
        columns.put("destinationEndpoint", "Destination Interface");
        columns.put("linkRate", "Link Rate");
        columns.put("latency", "Latency");
        columns.put("linkStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getLinkList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject links = filterService.queryByFilter(requestBody, "link");
        return ResponseEntity.status(HttpStatus.OK).body(links);
    }

    @GetMapping()
    public ResponseEntity<List<Link>> getLinks(@PathVariable("networkId") String networkId) {

        List<Link> links = new ArrayList<Link>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);
        if (rClient.exists(networkUri)) {
            IetfNetwork network = new IetfNetwork();
            network = rClient.get(IetfNetwork.class, networkUri).get();
            if (network.getLinks() != null) {
                links = network.getLinks().getLink();
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(links);
    }

    @GetMapping(value = "/{linkId}")
    public ResponseEntity<Link> getLink(@PathVariable("networkId") String networkId,
            @PathVariable("linkId") String linkId) {

        Link link = new Link();
        AAIResourceUri linkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).link(linkId));
        if (rClient.exists(linkUri)) {
            link = rClient.get(Link.class, linkUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(link);
    }

    @PostMapping("/exists")
    public ResponseEntity<Boolean> checkLinkExistence(@PathVariable("networkId") String networkId,
            @RequestBody JSONObject srcDest) throws ParseException {

        String srcNode = srcDest.get("sourceNode").toString();
        String srcEndpoint = srcDest.get("sourceEndpoint").toString();
        String destNode = srcDest.get("destinationNode").toString();
        String destEndpoint = srcDest.get("destinationEndpoint").toString();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.LINK, __.key("source-node", srcNode), __.key("source-endpoint", srcEndpoint),
                        __.key("destination-node", destNode), __.key("destination-endpoint", destEndpoint)))
                .output();

        String results = dslClient.query(Format.COUNT, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        JSONObject countObj = (JSONObject) resultsArray.get(0).get("link");

        Boolean exists = false;
        if (countObj != null) {
            exists = true;
        }

        return ResponseEntity.status(HttpStatus.OK).body(exists);
    }

    @PutMapping()
    public ResponseEntity<String> addLinksToNetwork(@PathVariable("networkId") String networkId,
            @RequestBody Link linkBody) throws BulkProcessFailed, JsonProcessingException {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String linkId = UUID.randomUUID().toString();
        linkBody.setLinkId(linkId);
        linkBody.setLinkType("L1 Link");
        linkBody.setLinkStatus(true);
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));
        if (rClient.exists(networkUri)) {
            AAIResourceUri linkUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).link(linkId));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(linkUri, linkBody);

            transactions.execute();
        }
        description = linkBody.getLinkName() + " Link has been Created.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.ADD_LINK_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> removeLinksFromNetwork(@PathVariable("networkId") String networkId,
            @RequestBody List<String> linkIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        for (String linkId : linkIds) {
            resourceMetadata.setResourceId(linkId);
            if (networkId != null && linkId != null) {
                AAIResourceUri linkuri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).link(linkId));
                if (rClient.exists(linkuri)) {
                    AAITransactionalClient transactions = rClient.beginTransaction().delete(linkuri);
                    transactions.execute();
                    description = linkId + " Link has been Removed from " + networkId + " Network";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_LINK_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = linkId + "Link Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_LINK_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Link Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.REMOVE_LINK_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Links have been Removed.");
    }

    @PostMapping(value = "/{linkId}")
    public ResponseEntity<String> updateLink(@PathVariable("networkId") String networkId,
            @PathVariable("linkId") String linkId, @RequestBody Link linkBody) throws BulkProcessFailed {

        AAIResourceUri linkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).link(linkId));
        if (rClient.exists(linkUri)) {
            AAITransactionalClient transactions = rClient.beginTransaction().update(linkUri, linkBody);
            transactions.execute();
            return ResponseEntity.status(HttpStatus.OK).body("Link has been Updated");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Link Doesn't Exists");
        }
    }
}
