package in.utl.noa.security.rbac.authentication;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Service;

import in.utl.noa.account.user.model.User;
import in.utl.noa.util.RestClientManager;

@Service("GDBUserDetails")
public class GDBUserDetails implements UserDetailsService {

	private static Logger logger = Logger.getLogger(GDBUserDetails.class);
	public static final PasswordEncoder encoder = new BCryptPasswordEncoder();

	@Autowired
	RestClientManager restClientManager;

	private AAIResourcesClient rClient;
	private AAIDSLQueryClient dslClient;

	static ObjectMapper mapper = new ObjectMapper();

	@PostConstruct
	public void init() {
		rClient = restClientManager.getRClient();
		dslClient = restClientManager.getDSLQueryClient();
	}

	@Override
	public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {

		try {
			User user = findByUserName(name);
			logger.info("GDB UserDetails : loadUserByUsername");
			if (user == null) {
				throw new UsernameNotFoundException("exception: User not found");
			} else {
				user.setAuthorities(getAuthorities(user.getRoleName()));
				return new UserPrincipal(user);
			}
		} catch (final Exception e) {
			throw new RuntimeException(e);
		}
	}

	public User findByUserName(String name) throws ParseException, JsonMappingException, JsonProcessingException {

		User userAccount = null;
		logger.info("GDB UserDetails : findByUsername");
		DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT, __.key("user-name", name));
		DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

		String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

		JSONParser parser = new JSONParser();
		JSONObject resultsJson = (JSONObject) parser.parse(results);
		List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");
		if (resultsArray.size() > 0) {
			JSONObject userObj = (JSONObject) resultsArray.get(0).get("properties");
			mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
			userAccount = mapper.readValue(userObj.toString(), User.class);
		}
		return userAccount;
	}

	private final List<GrantedAuthority> getAuthorities(final String roleName) {
		return getGrantedAuthorities(getRoleAuthorities(roleName));
	}

	private final List<String> getRoleAuthorities(final String roleName) {

		List<String> featureNames = new ArrayList<String>();

		DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-name", roleName));
		DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.FEATURE)).output();

		String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

		JSONParser parser = new JSONParser();
		JSONObject resultsJson = null;
		try {
			resultsJson = (JSONObject) parser.parse(results);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

		for (int i = 0; i < resultsArray.size(); i++) {
			JSONObject featureObj = (JSONObject) resultsArray.get(i).get("properties");
			String featureName = (String) featureObj.get("feature-name");
			featureNames.add(featureName);
		}
		featureNames.add("SecurityManagement");
		return featureNames;
	}

	private final List<GrantedAuthority> getGrantedAuthorities(final List<String> actions) {
		final List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();

		for (final String action : actions) {
			authorities.add(new SimpleGrantedAuthority(action));
		}
		return authorities;
	}
}
