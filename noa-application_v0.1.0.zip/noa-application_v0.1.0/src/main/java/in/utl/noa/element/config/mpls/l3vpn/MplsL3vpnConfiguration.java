package in.utl.noa.element.config.mpls.l3vpn;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.L3VpnConfig;
import org.onap.aai.domain.yang.L3VpnInstance;
import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;

import in.utl.noa.security.audit.AuditLogger;

import in.utl.noa.global.event.NoaEvents;

import in.utl.noa.platform.config.service.RollbackHandler;

import org.onap.aai.domain.yang.Attributes;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/mpls/service/l3vpn")
public class MplsL3vpnConfiguration {
    private static Logger logger = Logger.getLogger(MplsL3vpnConfiguration.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping(value = "/config")
    public ResponseEntity<L3VpnConfig> getMplsL3VpnConfiguration(@PathVariable("deviceId") String deviceId) {

        L3VpnConfig mplsL3VpnConfig = new L3VpnConfig();
        AAIResourceUri mplsL3VpnConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).l3VpnConfig(deviceId));

        if (rClient.exists(mplsL3VpnConfigUri)) {
            mplsL3VpnConfig = rClient.get(L3VpnConfig.class, mplsL3VpnConfigUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(mplsL3VpnConfig);
    }

    @PostMapping(value = "/config")
    public ResponseEntity<String> updateMplsL3VpnConfiguration(@PathVariable("deviceId") String deviceId,
            @RequestBody L3VpnConfig mplsL3VpnConfig) throws BulkProcessFailed {

        AAITransactionalClient transactions;

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("L3VPN Config", deviceId,
                "Network Device", deviceId);

        if (deviceId != null) {
            if (mplsL3VpnConfig.getConfigId() == null) {
                mplsL3VpnConfig.setConfigId(deviceId);
            }
            AAIResourceUri mplsL3VpnConfigUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).l3VpnConfig(deviceId));

            // edgeRouterService.configureL3Vpn(deviceId, routerConfigDTO);
            L3VpnConfig updMplsL3vpnConfig = new L3VpnConfig();
            if (rClient.exists(mplsL3VpnConfigUri)) {
                updMplsL3vpnConfig = rClient.get(L3VpnConfig.class, mplsL3VpnConfigUri).get();
                transactions = rClient.beginTransaction().update(mplsL3VpnConfigUri, mplsL3VpnConfig);
                transactions.execute();
            } else {
                transactions = rClient.beginTransaction().create(mplsL3VpnConfigUri, mplsL3VpnConfig);
                transactions.execute();
                updMplsL3vpnConfig = rClient.get(L3VpnConfig.class, mplsL3VpnConfigUri).get();
            }
            description = "L3 VPN Configuration has been Updated in " + deviceId + " Device";

            JSONObject mplsL3vpnObj = rollbackHandler.getJsonObject(updMplsL3vpnConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(mplsL3vpnObj, null, null);
            String resourceUri = mplsL3VpnConfigUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.L3VpnConfig", deviceId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.CREATED;
        } else {
            description = "Received Null Router Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "L3VPN",
                NoaEvents.MODIFY_MPLS_L3VPN_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping()
    public ResponseEntity<List<L3VpnInstance>> getL2vpnInstance(@PathVariable("deviceId") String deviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<L3VpnInstance> l3vpnInstances = new ArrayList<L3VpnInstance>();
        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.L3_VPN_INSTANCE))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject object = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            L3VpnInstance l3vpnInstance = mapper.readValue(object.toString(), L3VpnInstance.class);
            l3vpnInstances.add(l3vpnInstance);
        }
        return ResponseEntity.status(HttpStatus.OK).body(l3vpnInstances);
    }

    @PutMapping()
    public ResponseEntity<String> createL3vpnInstance(@PathVariable("deviceId") String deviceId,
            @RequestBody L3VpnInstance instanceBody) throws BulkProcessFailed {

        AAITransactionalClient transactions;

        String l3vpnInstanceId = UUID.randomUUID().toString();
        instanceBody.setL3VpnInstanceId(l3vpnInstanceId);
        instanceBody.setCreationTime(new Date().toString());
        AAIResourceUri l3vpnInstanceUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).l3VpnInstance(instanceBody.getL3VpnInstanceId()));

        transactions = rClient.beginTransaction().create(l3vpnInstanceUri, instanceBody);
        transactions.execute();
        return ResponseEntity.status(HttpStatus.OK).body("Created L3vpn Instance");
    }
}
