package in.utl.noa.mdsal;

import org.eclipse.jdt.annotation.NonNull;
import org.opendaylight.mdsal.binding.api.DataObjectModification;
import org.opendaylight.mdsal.binding.api.DataTreeChangeListener;
import org.opendaylight.mdsal.binding.api.DataTreeModification;
import org.opendaylight.mdsal.dom.api.DOMMountPointService;
import org.opendaylight.mdsal.dom.api.DOMNotificationListener;
import org.opendaylight.mdsal.dom.api.DOMNotificationService;
import org.opendaylight.mdsal.dom.api.DOMDataTreeChangeListener;
import org.opendaylight.mdsal.dom.api.DOMMountPoint;
import org.opendaylight.mdsal.binding.api.NotificationService;
import org.opendaylight.yang.gen.v1.http.netconfcentral.org.ns.toaster.rev091120.ToasterRestocked;
import org.opendaylight.yangtools.concepts.ListenerRegistration;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier;
import org.opendaylight.yangtools.yang.data.api.schema.tree.DataTreeCandidate;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NetworkTopology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NodeId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TopologyId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.TopologyKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Node;
import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.network.topology.topology.topology.types.TopologyNetconf;
import org.opendaylight.yangtools.yang.model.api.SchemaPath;
import org.opendaylight.yangtools.yang.model.api.stmt.SchemaNodeIdentifier;
import org.opendaylight.yangtools.yang.model.api.stmt.SchemaNodeIdentifier.Absolute;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import in.utl.noa.mdsal.toaster.LoggingNotificationListener;

import java.util.Collection;
import java.util.Optional;

import io.lighty.core.controller.api.LightyServices;

public class DeviceDOMDataTreeChangeListener implements DOMDataTreeChangeListener {
    private static final Logger LOG = LoggerFactory.getLogger(DeviceDOMDataTreeChangeListener.class);

    /* @java.lang.Override
    public void onDataTreeChanged(final java.util.Collection<DataTreeModification<Node>> changes) {
        if (LOG.isTraceEnabled()) {
            for (DataTreeModification<Node> change : changes) {
                outputChanges(change);
            }
        }
    } */

    private static void outputChanges(final DataTreeCandidate change) {
        LOG.info("OnDataChange, change: {}", change);
    }

    public void registerToasterListener(LightyServices lightyServices, final NodeId nodeId) {
        DOMMountPointService mountPointService = lightyServices.getDOMMountPointService();
        /* DOMNotificationService notificationService = lightyServices.getDOMNotificationService(); */

        QName TOASTER_QNAME = QName.create("http://netconfcentral.org/ns/toaster", "2009-11-20", "toaster");
        Optional<DOMMountPoint> mountPoint;

        YangInstanceIdentifier NETCONF_TOPO_NODE_YIID = YangInstanceIdentifier.builder()
                    .node(NetworkTopology.QNAME).node(Topology.QNAME)
                    .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(), TopologyNetconf.QNAME.getLocalName())
                    .node(Node.QNAME)
                    .nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), "toaster")
                    .build();

        try {
            mountPoint = mountPointService.getMountPoint(NETCONF_TOPO_NODE_YIID);
            final DOMMountPoint mount = mountPoint.get();
        } catch (Exception e) {
            throw new IllegalArgumentException(e);
        }

        final LoggingNotificationListener listener = new LoggingNotificationListener();
        DOMNotificationListener lit;
        final Optional<DOMNotificationService> notificationService = mountPoint.get().getService(DOMNotificationService.class);
        Collection<Absolute> types = null;
        types.add(Absolute.of(ToasterRestocked.QNAME));

        /* final ListenerRegistration<ToasterListener> listenerReg = notificationService.registerNotificationListener(listener, types); */
    }

    @Override
    public void onDataTreeChanged(@NonNull Collection<DataTreeCandidate> changes) {
        for (DataTreeCandidate change : changes) {
             outputChanges(change);
        }
    }
}
