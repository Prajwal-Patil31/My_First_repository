package in.utl.noa;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.AccessRole;
import org.onap.aai.domain.yang.Action;
import org.onap.aai.domain.yang.BridgeInstance;
import org.onap.aai.domain.yang.FaultConfig;
import org.onap.aai.domain.yang.FaultProcessingPolicy;
import org.onap.aai.domain.yang.Feature;
import org.onap.aai.domain.yang.Filter;
import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.IetfInterfaces;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.NNodes;
import org.onap.aai.domain.yang.NNode;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.LdpPeer;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.LdpEntity;
import org.onap.aai.domain.yang.OspfInstance;
import org.onap.aai.domain.yang.BgpInstance;
import org.onap.aai.domain.yang.BgpPeer;
import org.onap.aai.domain.yang.OspfNeighbour;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.PasswordHistory;
import org.onap.aai.domain.yang.Route;
import org.onap.aai.domain.yang.StpConfig;
import org.onap.aai.domain.yang.UrlMapping;
import org.onap.aai.domain.yang.PasswordPolicy;
import org.onap.aai.domain.yang.UserGroup;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.stereotype.Component;

import org.springframework.transaction.annotation.Transactional;

import in.utl.noa.util.RestClientManager;

@Component
public class DefaultDataLoader implements ApplicationListener<ContextRefreshedEvent> {

    private static Logger logger = Logger.getLogger(DefaultDataLoader.class);

    private boolean setup = false;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    private static final PasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();
    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    JSONParser parser = new JSONParser();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public DefaultDataLoader() {
        super();
    }

    List<NetworkDevice> devicesList = new ArrayList<NetworkDevice>();

    @Override
    @Transactional
    public void onApplicationEvent(final ContextRefreshedEvent event) {

        if (setup) {
            return;
        }

        // Default Features:

        /* try {
            createDefaultFeatures();
        } catch (IOException | ParseException | BulkProcessFailed e) {
            e.printStackTrace();
        } */

        // Default Actions:

        /* try {
            createDefaultActions();
        } catch (IOException | ParseException | BulkProcessFailed e) {
            e.printStackTrace();
        } */

        // Default Roles

        /* AccessRole adminRole = createDefaultRoleGDB("Administrator", "ADMIN1001", 3, 4, 8);
        AccessRole networksAdminRole = createDefaultRoleGDB("NetworksAdministrator", "ADMIN1002", 5, 2, 10);
        AccessRole sysAdminRole = createDefaultRoleGDB("SystemAdministrator", "ADMIN1004", 2, 4, 8);
        AccessRole userRole = createDefaultRoleGDB("DefaultRole", "USER1001", 1, 1, 8); */

        // Default Password Policies

        /* PasswordPolicy defaultPolicy = createDefaultPasswordPolicyGDB("DefaultPolicy", 2, 4, 8, 1);
        PasswordPolicy weeklyExpire = createDefaultPasswordPolicyGDB("WeeklyExpire", 3, 5, 10, 1); */

        // Default User Groups

        /* UserGroup adminGroup = createDefaultUserGroupGDB("AdministratorsGroup", "Administrator", 2,
                adminRole.getRoleId());
        UserGroup userGroup = createDefaultUserGroupGDB("UsersGroup", "DefaultRole", 1, userRole.getRoleId()); */

        // Default Users

        /* createDefaultUserGDB("admin", "NOA", "Administrator", "pass", true, "7864593211", "admin@gmail.com", "admin",
                "Administrator", "DefaultPolicy", 1, adminRole.getRoleId(), defaultPolicy.getPolicyId(),
                adminGroup.getUserGroupId());
        createDefaultUserGDB("user", "NOA", "DefaultUser", "pass", true, "7564983224", "user@gmail.com", "User", "user",
                "DefaultPolicy", 1, userRole.getRoleId(), defaultPolicy.getPolicyId(), userGroup.getUserGroupId());
        createDefaultUserGDB("noaadmin", "NOA", "Administrator", "pass", true, "9865547474", "noaadmin@gmail.com",
                "admin", "NetworksAdministrator", "WeeklyExpire", 1, networksAdminRole.getRoleId(),
                weeklyExpire.getPolicyId(), adminGroup.getUserGroupId());

        createDefaultUserGDB("noauser", "NOA", "User", "pass", true, "7548946321", "noausergmail.com", "admin",
                "SystemAdministrator", "WeeklyExpire", 1, sysAdminRole.getRoleId(), weeklyExpire.getPolicyId(),
                adminGroup.getUserGroupId());

        createDefaultUserGDB("utladmin", "UTL", "Administrator", "pass", true, "8475963512", "utladmin@gmail.com",
                "admin", "NetworksAdministrator", "WeeklyExpire", 1, networksAdminRole.getRoleId(),
                weeklyExpire.getPolicyId(), adminGroup.getUserGroupId()); */

        // Default Devices

        /* NetworkDevice device1 = new NetworkDevice();
        NetworkDevice device2 = new NetworkDevice();
        NetworkDevice device3 = new NetworkDevice();
        NetworkDevice device4 = new NetworkDevice();
        NetworkDevice device5 = new NetworkDevice();
        
        NetworkDevice device6 = new NetworkDevice();
        
        NetworkDevice device7 = new NetworkDevice();
        NetworkDevice device8 = new NetworkDevice();
        NetworkDevice device9 = new NetworkDevice();
        NetworkDevice device10 = new NetworkDevice();
        NetworkDevice device11 = new NetworkDevice();
        NetworkDevice device12 = new NetworkDevice();
        try {
            device1 = createDefaultDeviceGDB("vja-pe-700", "pe-router", "192.168.1.1", 831, "Juniper ACX 700",
                    "Junos 21.4R1.12", "Juniper");
            device2 = createDefaultDeviceGDB("hyd-pe-560", "pe-router", "192.168.1.2", 832, "Juniper ACX 700",
                    "Junos 21.4R1.12", "Juniper");
            device3 = createDefaultDeviceGDB("bom-pe-250", "pe-router", "192.168.1.3", 833, "Juniper ACX 700",
                    "Junos 21.4R1.12", "Juniper");
            device4 = createDefaultDeviceGDB("del-pe-640", "pe-router", "10.0.0.1", 1001, "Juniper ACX 700",
                    "Junos 21.4R1.12", "Juniper");
            device5 = createDefaultDeviceGDB("vja-ce-100", "ce-router", "10.0.0.2", 1002, "Juniper ACX 550",
                    "Junos 21.4R1.12", "Juniper");
            device6 = createDefaultDeviceGDB("pjb-ce-264", "ce-router", "10.0.0.3", 1003, "Juniper ACX 550",
                    "Junos 21.4R1.12", "Juniper");
            device7 = createDefaultDeviceGDB("kol-ce-450", "ce-router", "10.0.0.4", 1004, "Juniper ACX 550",
                    "Junos 21.4R1.12", "Juniper");
            device8 = createDefaultDeviceGDB("bom-p-352", "p-router", "10.0.0.5", 1005, "Juniper ACX 400",
                    "Junos 21.4R1.12", "Juniper");
            device9 = createDefaultDeviceGDB("chn-p-102", "p-router", "10.0.0.6", 1006, "Juniper ACX 400",
                    "Junos 21.4R1.12", "Juniper");
            device10 = createDefaultDeviceGDB("del-p-468", "p-router", "10.0.0.7", 1007, "Juniper ACX 400",
                    "Junos 21.4R1.12", "Juniper");
            device11 = createDefaultDeviceGDB("del-pe-845", "pe-router", "10.0.0.8", 1008, "Juniper ACX 700",
                    "Junos 21.4R1.12", "Juniper");
            device12 = createDefaultDeviceGDB("hyd-ce-197", "ce-router", "10.0.0.9", 1009, "Juniper ACX 550",
                    "Junos 21.4R1.12", "Juniper");
        } catch (BulkProcessFailed e1) { // TODO Auto-generated catch block
            e1.printStackTrace();
        }

        devicesList.addAll(Arrays.asList(device1, device2, device3, device4, device5, device6, device7, device8,
                device9, device10, device11, device12)); */

        // Default Filters

        /* createDefaultFilterGDB("fault-config", "severity", "Severity", new String[] { "1", "2", "3", "4", "5" });
        createDefaultFilterGDB("fault-config", "policy-type", "Policy Type",
                new String[] { "auto-acknowledge", "auto-escalate" });

        createDefaultFilterGDB("fault-processing-policy", "policy-type", "Policy Type",
                new String[] { "auto-acknowledge", "auto-escalate" });
        createDefaultFilterGDB("fault-processing-policy", "severity", "Severity",
                new String[] { "1", "2", "3", "4", "5" });

        createDefaultFilterGDB("network-device", "device-type", "Device Type",
                new String[] { "ce-router", "pe-router", "p-router" });
        createDefaultFilterGDB("network-device", "vendor", "Vendor", new String[] { "Cisco", "Altran", "Juniper" });
        createDefaultFilterGDB("network-device", "element-status", "Status", new String[] { "true", "false" });

        createDefaultFilterGDB("ietf-interface", "interface-type", "Interface Type",
                new String[] { "ethernetCsmacd", "iso88023Csmacd", "regular1822", "hdh1822" });
        createDefaultFilterGDB("ietf-interface", "enabled", "Interface Status", new String[] { "true", "false" });
        createDefaultFilterGDB("ietf-interface", "admin-status", "Admin Status", new String[] { "up", "down" });

        createDefaultFilterGDB("bridge-instance", "gvrp-status", "GVRP Status", new String[] { "true", "false" });
        createDefaultFilterGDB("bridge-instance", "gmrp-status", "GMRP Status", new String[] { "true", "false" });
        createDefaultFilterGDB("bridge-instance", "traffic-class", "Traffic Class",
                new String[] { "forward-all", "forward-tagged-only", "forward-untagged-only" });
        createDefaultFilterGDB("bridge-instance", "bridge-state", "Bridge Status", new String[] { "true", "false" });

        createDefaultFilterGDB("bgp-instance", "instanceStatus", "BGP Instance Status",
                new String[] { "true", "false" });

        createDefaultFilterGDB("ospf-instance", "instance-status", "OSPF Instance Status",
                new String[] { "true", "false" });
        createDefaultFilterGDB("ospf-instance", "tos-support", "OSPF Instance Status",
                new String[] { "true", "false" });
        createDefaultFilterGDB("ospf-instance", "staggering-status", "OSPF Instance Status",
                new String[] { "true", "false" });

        createDefaultFilterGDB("ldp-entity", "label-dist-method", "Label Dist Method",
                new String[] { "downstreamOnDemand", "downstreamUnsolicited" });
        createDefaultFilterGDB("ldp-entity", "label-retention-mode", "Label Retention Mode",
                new String[] { "conservative", "liberal" });
        createDefaultFilterGDB("ldp-entity", "oper-status", "Operational Status", new String[] { "true", "false" });

        createDefaultFilterGDB("ldp-peer", "peer-label-dist-method", "Peer Label Dist Method",
                new String[] { "downstreamOnDemand", "downstreamUnsolicited" });
        createDefaultFilterGDB("ldp-peer", "peer-status", "Peer Status", new String[] { "true", "false" });

        createDefaultFilterGDB("mpls-tunnel", "signaling-protocol", "Signaling Protocol",
                new String[] { "BGP", "OSPF" });
        createDefaultFilterGDB("mpls-tunnel", "admin-status", "Admin Status", new String[] { "true", "false" });
        createDefaultFilterGDB("mpls-tunnel", "control-word", "Control Word", new String[] { "true", "false" });

        createDefaultFilterGDB("ietf-network", "network-type", "Network Type",
                new String[] { "L1 Network", "L2 Network", "L3 Network" });
        createDefaultFilterGDB("ietf-network", "network-status", "Network Status", new String[] { "true", "false" });
        createDefaultFilterGDB("ietf-network", "link-type", "Link Type", new String[] { "Link", "LSP", "Route" });

        createDefaultFilterGDB("link", "link-status", "Link Status", new String[] { "true", "false" });
        createDefaultFilterGDB("link", "duplex-mode", "Duplex Mode", new String[] { "full", "half" });

        createDefaultFilterGDB("route", "protocol", "Protocol", new String[] { "BGP", "OSPF" });
        createDefaultFilterGDB("route", "route-status", "Route Status", new String[] { "true", "false" });

        createDefaultFilterGDB("lsp", "lsp-status", "LSP Status", new String[] { "true", "false" });

        createDefaultFilterGDB("vpn-service", "service-type", "Service Type", new String[] { "L2 VPN", "L3 VPN" });
        createDefaultFilterGDB("vpn-service", "service-status", "Service Status", new String[] { "true", "false" });

        createDefaultFilterGDB("path", "protocol", "Protocol", new String[] { "BGP", "OSPF" });
        createDefaultFilterGDB("path", "path-status", "Path Status", new String[] { "true", "false" });

        createDefaultFilterGDB("endpoint", "endpoint-status", "Endpoint Status", new String[] { "true", "false" });

        createDefaultFilterGDB("user-account", "account-type", "Account Type", new String[] { "tenant", "user" });
        createDefaultFilterGDB("user-account", "account-status", "Account Status", new String[] { "true", "false" });

        createDefaultFilterGDB("topology:ietf-network", "network-status", "Network Status",
                new String[] { "true", "false" });
        createDefaultFilterGDB("topology:ietf-network", "link-type", "Link Type",
                new String[] { "Link", "LSP", "Route" });
        createDefaultFilterGDB("topology:n-node", "node-type", "Element Type",
                new String[] { "ce-router", "pe-outer", "p-router" });
        createDefaultFilterGDB("topology:n-node", "node-status", "Element Status", new String[] { "true", "false" });

        createDefaultFilterGDB("topology:link", "link-status", "Link Status", new String[] { "true", "false" });
        createDefaultFilterGDB("topology:link", "duplex-mode", "Duplex Mode", new String[] { "half", "full" });
        createDefaultFilterGDB("topology:lsp", "lsp-status", "LSP Status", new String[] { "true", "false" });
        createDefaultFilterGDB("topology:route", "route-status", "Route Status", new String[] { "true", "false" });
        createDefaultFilterGDB("topology:route", "protocol", "Protocol", new String[] { "BGP", "OSPF" });

        createDefaultFilterGDB("l2-vpn", "service-type", "Service Type",
                new String[] { "L2 VPN VPLS Service", "L2 VPN VPWS Service" });
        createDefaultFilterGDB("l2-vpn", "discovery-type", "Discovery Type", new String[] { "BGP", "LDP", "Mixed" });
        createDefaultFilterGDB("l2-vpn", "signaling-type", "Signaling Type", new String[] { "BGP", "LDP", "Mixed" });
        createDefaultFilterGDB("l2-vpn", "status", "Service Status", new String[] { "true", "false" });

        createDefaultFilterGDB("l3-vpn", "service-type", "Service Type", new String[] { "L3 VPN Service" });
        createDefaultFilterGDB("l3-vpn", "routing-protocol", "Routing Protocol", new String[] { "BGP", "OSPF" });
        createDefaultFilterGDB("l3-vpn", "apply-label-mode", "Label Mode",
                new String[] { "Per-Route", "Per-Instance" });
        createDefaultFilterGDB("l3-vpn", "status", "Service Status", new String[] { "true", "false" });

        createDefaultFilterGDB("topology:l2-vpn", "service-type", "Service Type",
                new String[] { "L2 VPN VPLS Service", "L2 VPN VPWS Service" });
        createDefaultFilterGDB("topology:l2-vpn", "status", "Service Status", new String[] { "Active", "InActive" });

        createDefaultFilterGDB("topology:l3-vpn", "service-type", "Service Type", new String[] { "L3 VPN Service" });
        createDefaultFilterGDB("topology:l3-vpn", "routing-protocol", "Routing Protocol",
                new String[] { "BGP", "OSPF" });
        createDefaultFilterGDB("topology:l3-vpn", "status", "Service Status", new String[] { "Active", "InActive" }); */

        // Default Fault Policies

        /* createDefaultFaultProcessingPolicy("AckPolicy", "auto-acknowledge", 1, 0, 7, 12, 10);
        createDefaultFaultProcessingPolicy("EscPolicy", "auto-escalate", 3, 4, 7, 10, 15); */

        // Default Fault Configurations

        /* try {
            createDefaultFaultConfigurations(1101, 5, 1003, 56, "auto-acknowledge", "AckPolicy");
            createDefaultFaultConfigurations(1102, 3, 1015, 152, "auto-acknowledge", "AckPolicy");
            createDefaultFaultConfigurations(1003, 1, 1101, 43, "auto-escalate", "EscPolicy");
            createDefaultFaultConfigurations(1004, 1, 1003, 12, "auto-escalate", "EscPolicy");
        } catch (BulkProcessFailed e) { // TODO Auto-generated catch block
            e.printStackTrace();
        } */

        // Default Networks

        /* try {
            createDefaultNetwork("RajL1Network", "L1 Network", "Link", "1Gbps", 5, 4, true);
            createDefaultNetwork("MhL1Network", "L1 Network", "Link", "2.5Gbps", 2, 10, true);
            createDefaultNetwork("ChnL1Network", "L1 Network", "Link", "1Gbps", 6, 14, true);
            createDefaultNetwork("BomL2Network", "L2 Network", "Link", "1Gbps", 5, 4, false);
            createDefaultNetwork("VjaL2Network", "L2 Network", "Link", "10Gbps", 1, 2, true);
            createDefaultNetwork("BngL2.5Network", "L2.5 Network", "Lsp", "20Gbps", 15, 1, true);
            createDefaultNetwork("KrlL2.5Network", "L2.5 Network", "Lsp", "2Gbps", 6, 8, false);
            createDefaultNetwork("ChnL2.5Network", "L2.5 Network", "Lsp", "5Gbps", 4, 10, true);
            createDefaultNetwork("VjaL3Network", "L3 Network", "Route", "1Gbps", 1, 2, true);
            createDefaultNetwork("HydL3Network", "L3 Network", "Route", "2.5Gbps", 9, 6, true);
            createDefaultNetwork("BomL3Network", "L3 Network", "Route", "10Gbps", 4, 4, true);
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        } */

        setup = true;
    }

    @Transactional
    private void createDefaultFeatures() throws FileNotFoundException, IOException, ParseException, BulkProcessFailed {

        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultData.json"));

        JSONObject featuresObject = (JSONObject) obj.get(0);
        List<JSONObject> featuresList = (List<JSONObject>) featuresObject.get("features");

        for (JSONObject feature : featuresList) {
            String defaultFeature = feature.toString();
            Feature featureObject = mapper.readValue(defaultFeature, Feature.class);
            String featureId = UUID.randomUUID().toString();
            featureObject.setFeatureId(featureId);

            AAIResourceUri featureUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));
            if (!rClient.exists(featureUri)) {
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(featureUri, featureObject);
                transactions.execute();
            }
        }
    }

    @Transactional
    public void createDefaultActions() throws FileNotFoundException, IOException, ParseException, BulkProcessFailed {
        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultData.json"));
        JSONObject actionsObject = (JSONObject) obj.get(0);
        List<JSONObject> actionsList = (List<JSONObject>) actionsObject.get("actions");

        for (JSONObject action : actionsList) {
            String defaultAction = action.toString();
            Action actionObject = mapper.readValue(defaultAction, Action.class);
            String actionId = UUID.randomUUID().toString();
            actionObject.setActionId(actionId);

            AAIResourceUri actionUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.platform().action(actionId));
            if (!rClient.exists(actionUri)) {
                AAITransactionalClient transactions;
                String featureId = null;
                String featureName = actionObject.getRelatedFeature();

                DSLStartNode startNode = new DSLStartNode(Types.FEATURE, __.key("feature-name", featureName));
                DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

                String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

                JSONObject resultsJson = (JSONObject) parser.parse(results);
                List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

                for (int i = 0; i < resultsArray.size(); i++) {
                    JSONObject userObj = (JSONObject) resultsArray.get(i).get("properties");
                    mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
                    Feature feature = mapper.readValue(userObj.toString(), Feature.class);
                    featureId = feature.getFeatureId();
                }

                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));

                transactions = rClient.beginTransaction().create(actionUri, actionObject).connect(featureUri,
                        actionUri);
                transactions.execute();
            }
        }
    }

    @Transactional
    private void createDefaultUrlMappings()
            throws FileNotFoundException, IOException, ParseException, BulkProcessFailed {

        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultData.json"));

        JSONObject urlMappingobj = (JSONObject) obj.get(0);
        List<JSONObject> urlMappingsList = (List<JSONObject>) urlMappingobj.get("urlMappings");

        for (JSONObject urlMapping : urlMappingsList) {
            String defaultUrlMapping = urlMapping.toString();
            UrlMapping urlMappingObject = mapper.readValue(defaultUrlMapping, UrlMapping.class);
            String mapId = UUID.randomUUID().toString();
            urlMappingObject.setMapId(mapId);

            AAIResourceUri urlMapUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.platform().urlMapping(mapId));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(urlMapUri, urlMappingObject);
            transactions.execute();
        }
    }

    @Transactional
    private AccessRole createDefaultRoleGDB(final String roleName, final String roleCode, final Integer assignedUsers,
            final Integer assignedGroups, final Integer featuresEnabled) {
        String roleId = UUID.randomUUID().toString();
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        AccessRole defaultRole = new AccessRole();
        defaultRole.setRoleId(roleId);
        defaultRole.setRoleName(roleName);
        defaultRole.setRoleCode(roleCode);
        defaultRole.setAssignedUsers(assignedUsers);
        defaultRole.setAssignedGroups(assignedGroups);
        defaultRole.setFeaturesEnabled(featuresEnabled);
        defaultRole.setAdminStatus(true);
        rClient.create(roleUri, defaultRole);

        return defaultRole;
    }

    @Transactional
    private PasswordPolicy createDefaultPasswordPolicyGDB(final String passwordPolicyName, final Integer minDigits,
            final Integer maxFailAttempts, final Integer minLength, final Integer minSplChar) {
        String policyId = UUID.randomUUID().toString();

        AAIResourceUri passwordPolicyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));

        PasswordPolicy defaultPolicy = new PasswordPolicy();
        defaultPolicy.setPolicyId(policyId);
        defaultPolicy.setPolicyName(passwordPolicyName);
        defaultPolicy.setMaxFailAttempt(maxFailAttempts);
        defaultPolicy.setMinDigits(minDigits);
        defaultPolicy.setMinLength(minLength);
        defaultPolicy.setMinLowChar(2);
        defaultPolicy.setMinReuseDays(5);
        defaultPolicy.setMinSplChar(minSplChar);
        defaultPolicy.setMinUpperChar(1);
        defaultPolicy.setNumMultipleLogin(1);
        defaultPolicy.setNumOldPassword(5);
        defaultPolicy.setPassExpDays(2);

        rClient.create(passwordPolicyUri, defaultPolicy);

        return defaultPolicy;
    }

    @Transactional
    private UserGroup createDefaultUserGroupGDB(final String userGroupName, final String roleName,
            final Integer userCount, final String roleId) {
        String userGroupId = UUID.randomUUID().toString();

        AAIResourceUri userGroupUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

        UserGroup defaultUserGroup = new UserGroup();
        defaultUserGroup.setUserGroupId(userGroupId);
        defaultUserGroup.setUserGroupName(userGroupName);
        defaultUserGroup.setUserGroupCode("1001");
        defaultUserGroup.setRoleName(roleName);
        defaultUserGroup.setUserCount(userCount);

        AAITransactionalClient transactions;
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        transactions = rClient.beginTransaction().create(userGroupUri, defaultUserGroup).connect(userGroupUri, roleUri);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
        return defaultUserGroup;
    }

    @Transactional
    private final void createDefaultUserGDB(final String userName, final String firstName, final String lastName,
            final String password, final boolean accountStatus, final String mobileNumber, final String emailId,
            final String userType, final String roleName, final String policyName, final Integer groupCount,
            final String roleId, final String policyId, final String userGroupId) {

        String accountId = UUID.randomUUID().toString();
        org.onap.aai.domain.yang.UserAccount userAccount = new org.onap.aai.domain.yang.UserAccount();

        AAIResourceUri userUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId))
                .depth(Depth.TWO);

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        AAIResourceUri policyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));

        AAIResourceUri groupUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

        String encodedPassword = PASSWORD_ENCODER.encode(password);
        Date date = Calendar.getInstance().getTime();
        String timeStamp = DATE_FORMAT.format(date);

        userAccount.setAccountId(accountId);
        userAccount.setUserName(userName);
        userAccount.setFirstName(firstName);
        userAccount.setLastName(lastName);
        userAccount.setPassword(encodedPassword);
        userAccount.setAccountStatus(accountStatus);
        userAccount.setMobileNumber(mobileNumber);
        userAccount.setEmailId(emailId);
        userAccount.setUserType(userType);
        userAccount.setLatestPasswordTimeStamp(timeStamp);
        userAccount.setFailedAttempts(0);
        userAccount.setRoleName(roleName);
        userAccount.setPolicyName(policyName);
        userAccount.setAssignedGroups(groupCount);

        PasswordHistory passwordHistory = new PasswordHistory();
        passwordHistory.setOldPassword(encodedPassword);
        passwordHistory.setPosition(0);

        userAccount.getPasswordHistory().add(passwordHistory);

        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().create(userUri, userAccount)
                .connect(userUri, roleUri).connect(userUri, policyUri).connect(userUri, groupUri);

        try {
            transactionClient.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    @Transactional
    public void createDefaultFaultConfigurations(final Integer errorCode, final Integer severity,
            final Integer relatedErrorCode, final Integer trapCategory, final String policyType,
            final String policyName) throws BulkProcessFailed {

        String configId = UUID.randomUUID().toString();
        FaultConfig faultConfig = new FaultConfig();
        faultConfig.setErrorCode(errorCode);
        faultConfig.setSeverity(severity);
        faultConfig.setRelatedErrorCode(relatedErrorCode);
        faultConfig.setTrapCategory(trapCategory);
        faultConfig.setPolicyType(policyType);
        faultConfig.setPolicyName(policyName);

        AAIResourceUri faultConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));

        String policyId = null;
        DSLStartNode startNode = new DSLStartNode(Types.FAULT_PROCESSING_POLICY, __.key("policy-name", policyName));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = new JSONObject();

        try {
            resultsJson = (JSONObject) parser.parse(results);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject roleObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            FaultProcessingPolicy policy = new FaultProcessingPolicy();
            try {
                policy = mapper.readValue(roleObj.toString(), FaultProcessingPolicy.class);
            } catch (JsonProcessingException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            policyId = policy.getPolicyId();
        }

        AAITransactionalClient transactions = rClient.beginTransaction();
        transactions.create(faultConfigUri, faultConfig);

        if (policyId != null) {
            AAIResourceUri faultPolicyUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));

            transactions.connect(faultPolicyUri, faultConfigUri);
        }
        transactions.execute();
    }

    @Transactional
    public void createDefaultFaultProcessingPolicy(final String policyName, final String policyType,
            final Integer severity, final Integer toSeverity, final Integer numDaysOlder, final Integer numHoursOlder,
            final Integer retainMinFaults) {

        FaultProcessingPolicy faultPolicy = new FaultProcessingPolicy();
        String policyId = UUID.randomUUID().toString();

        faultPolicy.setPolicyId(policyId);
        faultPolicy.setPolicyName(policyName);
        faultPolicy.setPolicyType(policyType);
        faultPolicy.setSeverity(severity);
        faultPolicy.setToSeverity(toSeverity);
        faultPolicy.setNumOfDaysOlder(numDaysOlder);
        faultPolicy.setNumOfHoursOlder(numHoursOlder);
        faultPolicy.setRetainMinFaults(retainMinFaults);

        AAIResourceUri faultPolicyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));

        AAITransactionalClient transactionClient = rClient.beginTransaction();
        transactionClient.create(faultPolicyUri, faultPolicy);

        try {
            transactionClient.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    @Transactional
    private NetworkDevice createDefaultDeviceGDB(final String deviceName, final String deviceType, final String host,
            final Integer port, final String hardware, final String software, final String vendor)
            throws BulkProcessFailed {

        String deviceId = UUID.randomUUID().toString();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        NetworkDevice defaultDevice = new NetworkDevice();
        defaultDevice.setDeviceId(deviceId);
        defaultDevice.setDeviceName(deviceName);
        defaultDevice.setDeviceType(deviceType);
        defaultDevice.setHost(host);
        defaultDevice.setPort(port);
        defaultDevice.setHardwareVersion(hardware);
        defaultDevice.setSoftwareVersion(software);
        defaultDevice.setVendor(vendor);
        defaultDevice.setElementStatus(true);

        IetfInterfaces interfaces = new IetfInterfaces();
        List<IetfInterface> interfaceList = new ArrayList<IetfInterface>();

        for (int i = 0; i <= 9; i++) {
            IetfInterface ethernet = new IetfInterface();
            ethernet.setInterfaceName("ethernet" + i);
            ethernet.setInterfaceId(ethernet.getInterfaceName() + "@" + deviceName);
            ethernet.setLayer("L1");
            ethernet.setSpeed("1Gbps");
            ethernet.setAdminStatus("up");
            ethernet.setEnabled(true);
            ethernet.setIfIndex(i);
            ethernet.setIfAlias(ethernet.getInterfaceName() + "@" + deviceName);
            ethernet.setInterfaceType("ethernetCsmacd");
            ethernet.setBridgePortType("customerBridgePort");
            ethernet.setVlanPortType("hybrid-port");
            ethernet.setDeviceId(deviceId);
            ethernet.setIpAddress(host + i);

            interfaceList.add(ethernet);
        }

        interfaces.getIetfInterface().addAll(interfaceList);

        defaultDevice.setIetfInterfaces(interfaces);

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(deviceUri, defaultDevice);
        transactions.execute();

        List<IetfInterface> ietfInterfaces = defaultDevice.getIetfInterfaces().getIetfInterface();

        BridgeInstance bridge1 = createBridgeInstance(deviceId, "bridge0-3", true, false, "forward-all", 100, 50, 2, 2,
                true);
        BridgeInstance bridge2 = createBridgeInstance(deviceId, "bridge3-4", false, true, "forward-tagged-only", 60, 60,
                2, 1, false);
        BridgeInstance bridge3 = createBridgeInstance(deviceId, "bridge4-8", false, false, "forward-all", 90, 100, 1, 1,
                true);

        List<BridgeInstance> bridges = new ArrayList<BridgeInstance>();
        bridges.add(bridge1);
        bridges.add(bridge2);
        bridges.add(bridge3);

        for (BridgeInstance bridge : bridges) {
            AAIResourceUri bridgeUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridge.getBridgeId()));

            AAITransactionalClient bridgeTransactions;
            bridgeTransactions = rClient.beginTransaction().create(bridgeUri, bridge);
            bridgeTransactions.execute();

            for (IetfInterface ietfInterface : ietfInterfaces) {
                AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                        .networkDevice(deviceId).ietfInterface(ietfInterface.getInterfaceId()));

                AAITransactionalClient interfaceTxns;
                interfaceTxns = rClient.beginTransaction().connect(bridgeUri, interfaceUri);
                interfaceTxns.execute();
            }
        }

        BgpInstance bgp1 = createBgpInstance("bgpInstance1", "150", 50, 60, 25, 50, 45, true);
        BgpInstance bgp2 = createBgpInstance("bgpInstance2", "350", 80, 100, 75, 80, 85, false);
        BgpInstance bgp3 = createBgpInstance("bgpInstance3", "165", 100, 170, 50, 80, 75, true);

        List<BgpInstance> bgpInstances = new ArrayList<BgpInstance>();
        bgpInstances.add(bgp1);
        bgpInstances.add(bgp2);
        bgpInstances.add(bgp3);

        for (BgpInstance bgpInstance : bgpInstances) {
            AAIResourceUri bgpUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpInstance(bgpInstance.getBgpId()));

            AAITransactionalClient bgpTransactions;
            bgpTransactions = rClient.beginTransaction().create(bgpUri, bgpInstance);
            bgpTransactions.execute();

            BgpPeer peer1 = constructPeer("192.168.1.110", "HYD-PE-146", 22, "ipv4", "192.168.1.101", 22);
            BgpPeer peer2 = constructPeer("192.168.1.111", "DEL-CE-130", 22, "ipv4", "192.168.1.102", 22);
            BgpPeer peer3 = constructPeer("192.168.1.112", "BOM-PE-240", 22, "ipv4", "192.168.1.103", 22);

            List<BgpPeer> peers = new ArrayList<BgpPeer>();
            peers.add(peer1);
            peers.add(peer2);
            peers.add(peer3);

            AAITransactionalClient peerTransactions = null;
            for (BgpPeer peer : peers) {
                AAIResourceUri bgpPeerUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpPeer(peer.getPeerId()));

                peerTransactions = rClient.beginTransaction().create(bgpPeerUri, peer).connect(bgpPeerUri, bgpUri);
                peerTransactions.execute();
            }
        }

        OspfInstance ospf1 = createOspfInstance("ospfInstance1", "25", "4000ms", "enabled", "enabled", "enabled", true);
        OspfInstance ospf2 = createOspfInstance("ospfInstance2", "45", "5000ms", "enabled", "enabled", "disabled",
                false);
        OspfInstance ospf3 = createOspfInstance("ospfInstance3", "10", "4500ms", "enabled", "enabled", "disabled",
                false);

        List<OspfInstance> ospfInstances = new ArrayList<OspfInstance>();
        ospfInstances.add(ospf1);
        ospfInstances.add(ospf2);
        ospfInstances.add(ospf3);

        for (OspfInstance ospfInstance : ospfInstances) {
            AAIResourceUri ospfUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfInstance(ospfInstance.getOspfId()));

            AAITransactionalClient ospfTransactions;
            ospfTransactions = rClient.beginTransaction().create(ospfUri, ospfInstance);
            ospfTransactions.execute();

            OspfNeighbour neighbour1 = constructNeighbour("HYD-PE-068", "192.168.1.101", 0, "Unplanned Restart",
                    "Unknown", true);
            OspfNeighbour neighbour2 = constructNeighbour("BOM-CE-258", "192.168.1.102", 0, "Planned Restart",
                    "Software Restart", true);
            OspfNeighbour neighbour3 = constructNeighbour("DEL-PE-659", "192.168.1.103", 0, "Planned Restart",
                    "Software Restart", true);

            List<OspfNeighbour> neighbours = new ArrayList<OspfNeighbour>();
            neighbours.add(neighbour1);
            neighbours.add(neighbour2);
            neighbours.add(neighbour3);

            AAITransactionalClient neighbourTransactions = null;

            for (OspfNeighbour neighbour : neighbours) {
                AAIResourceUri neighbourUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                        .networkDevice(deviceId).ospfNeighbour(neighbour.getNeighbourId()));

                neighbourTransactions = rClient.beginTransaction().create(neighbourUri, neighbour).connect(neighbourUri,
                        ospfUri);
                neighbourTransactions.execute();

            }
        }

        LdpEntity entity1 = createLdpEntity(deviceId, 1, "downstreamOnDemand", "conservative", 830, 145, 30,
                "192.168.1.104", true);
        LdpEntity entity2 = createLdpEntity(deviceId, 2, "downstreamUnsolicited", "liberal", 580, 226, 650,
                "192.168.1.115", false);
        LdpEntity entity3 = createLdpEntity(deviceId, 3, "downstreamUnsolicited", "liberal", 450, 124, 85,
                "192.168.1.120", true);

        List<LdpEntity> ldpEntities = new ArrayList<LdpEntity>();
        ldpEntities.add(entity1);
        ldpEntities.add(entity2);
        ldpEntities.add(entity3);

        for (LdpEntity ldpEntity : ldpEntities) {
            AAIResourceUri entityUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpEntity(ldpEntity.getEntityId()));

            AAITransactionalClient entityTransactions;
            entityTransactions = rClient.beginTransaction().create(entityUri, ldpEntity);
            entityTransactions.execute();

            LdpPeer peer1 = constructLdpPeer(ldpEntity.getEntityId(), "192.168.1.110", "down stream on demand");
            LdpPeer peer2 = constructLdpPeer(ldpEntity.getEntityId(), "192.168.1.110", "down stream Unsolicited");
            LdpPeer peer3 = constructLdpPeer(ldpEntity.getEntityId(), "192.168.1.110", "down stream on demand");

            List<LdpPeer> peers = new ArrayList<LdpPeer>();
            peers.add(peer1);
            peers.add(peer2);
            peers.add(peer3);

            AAITransactionalClient peerTransactions = null;
            for (LdpPeer peer : peers) {
                AAIResourceUri ldpPeerUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpPeer(peer.getPeerId()));

                peerTransactions = rClient.beginTransaction().create(ldpPeerUri, peer);
                peerTransactions.execute();
            }
        }
        return defaultDevice;
    }

    @Transactional
    private void createDefaultNetwork(final String networkName, final String networkType, final String linkType,
            final String linkRate, final Integer externalNetworks, final Integer sharedNetworks,
            final Boolean networkStatus) throws BulkProcessFailed {

        String networkId = UUID.randomUUID().toString();

        IetfNetwork network = new IetfNetwork();
        network.setNetworkId(networkId);
        network.setNetworkName(networkName);
        network.setNetworkType(networkType);
        network.setLinkType(linkType);
        network.setLinkRate(linkRate);
        network.setExternal(externalNetworks);
        network.setShared(sharedNetworks);
        network.setAdminStatus(true);
        network.setNetworkStatus(networkStatus);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

        NNodes nodes = new NNodes();
        List<NNode> nodesList = new ArrayList<NNode>();

        List<Integer> elementList = new ArrayList<Integer>();

        switch (networkType) {
            case "L1 Network":
                elementList = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11);
                break;
            case "L2 Network":
                elementList = Arrays.asList(0, 2, 4, 6, 8, 10);
                break;
            case "L2.5 Network":
                elementList = Arrays.asList(0, 2, 4, 6, 8, 10);
                break;
            case "L3 Network":
                elementList = Arrays.asList(1, 3, 5, 7, 9, 11);
                break;
            default:
                break;
        }

        if (devicesList.size() > 0) {
            for (Integer elementItem : elementList) {
                NetworkDevice device = devicesList.get(elementItem);
                NNode node = new NNode();
                node.setNodeId(device.getDeviceId());
                node.setNodeName(device.getDeviceName());
                node.setNodeType(device.getDeviceType());
                node.setNodeStatus(device.isElementStatus());
                node.setIpAddress(device.getHost());
                nodesList.add(node);
            }
        }

        nodes.getNNode().addAll(nodesList);
        network.setNNodes(nodes);

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(networkUri, network);
        transactions.execute();

        for (int i = 0; i < nodesList.size(); i++) {
            NNode srcNode = nodesList.get(i);
            NetworkDevice srcDevice = getDevice(srcNode.getNodeId());
            IetfInterface srcInterface = srcDevice.getIetfInterfaces().getIetfInterface().get(1);
            String localAddress = srcInterface.getIpAddress();

            for (int j = i + 1; j < nodesList.size(); j++) {
                NNode destNode = nodesList.get(j);
                NetworkDevice destDevice = getDevice(destNode.getNodeId());
                IetfInterface destInterface = destDevice.getIetfInterfaces().getIetfInterface().get(0);
                String nexthopAddress = destInterface.getIpAddress();
                switch (networkType) {
                    case "L1 Network":
                        createLink(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(),
                                destDevice.getDeviceName(), destInterface.getInterfaceName(), "L1 Link", "50Gbps",
                                "25ms");
                        break;
                    case "L2 Network":
                        createLink(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(),
                                destDevice.getDeviceName(), destInterface.getInterfaceName(), "L2 Link", "50Gbps",
                                "25ms");
                        break;
                    case "L2.5 Network":
                        createLsp(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(),
                                destDevice.getDeviceName(), destInterface.getInterfaceName());
                        break;
                    case "L3 Network":
                        createRoute(networkId, srcDevice.getDeviceName(), srcInterface.getInterfaceName(), localAddress,
                                destDevice.getDeviceName(), destInterface.getInterfaceName(), nexthopAddress);
                        break;
                    default:
                        break;
                }
            }

        }
    }

    @Transactional
    private final void createDefaultFilterGDB(String module, String filterCategory, String filterName,
            String... filterValues) {
        AAITransactionalClient transactions = rClient.beginTransaction();
        Integer transactionsCount = 0;
        for (String filterValue : filterValues) {
            String uuid = UUID.randomUUID().toString();
            AAIResourceUri filterUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().filter(uuid));
            Filter filter = new Filter();
            filter.setModule(module);
            filter.setFilterCategory(filterCategory);
            filter.setFilterName(filterName);
            filter.setFilterValue(filterValue);

            transactions.create(filterUri, filter);
            transactionsCount++;
        }
        if (transactionsCount > 0) {
            try {
                transactions.execute();
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        }
    }

    private BridgeInstance createBridgeInstance(String deviceId, String bridgeName, Boolean gmrpStatus,
            Boolean gvrpStatus, String trafficClass, Integer maxVlanId, Integer maxSupportedVlans, Integer numOfVlans,
            Integer activeVlans, Boolean bridgeState) {

        BridgeInstance bridge = new BridgeInstance();
        String bridgeId = UUID.randomUUID().toString();

        bridge.setBridgeId(bridgeId);
        bridge.setBridgeName(bridgeName);
        bridge.setGmrpStatus(gmrpStatus);
        bridge.setGvrpStatus(gvrpStatus);
        bridge.setTrafficClass(trafficClass);
        bridge.setMaxVlanId(maxVlanId);
        bridge.setMaxSupportedVlans(maxSupportedVlans);
        bridge.setNumOfVlans(numOfVlans);
        bridge.setActiveVlans(activeVlans);
        bridge.setBridgeState(bridgeState);

        StpConfig stpConfig = new StpConfig();
        stpConfig.setConfigId(bridgeId);
        stpConfig.setEnableStp(true);
        stpConfig.setDeviceId(deviceId);
        stpConfig.setDesignatedRootBridge("bridge1");
        stpConfig.setBridgeRootCost("4");
        stpConfig.setTransmitHoldCount(400);
        stpConfig.setMaxAge(600);
        stpConfig.setHelloTime(6000);
        stpConfig.setForwardDelay(4000);
        stpConfig.setTopologyChanges(6);
        stpConfig.setLastTopologyChange(new Date().toString());

        bridge.getStpConfig().add(stpConfig);
        return bridge;
    }

    private BgpInstance createBgpInstance(String identifierName, String localAsNumber, Integer maxRoutes,
            Integer maxPeers, Integer maxIbgpPaths, Integer maxEbgpPaths, Integer maxEibgpPaths, Boolean operStatus) {

        BgpInstance bgp = new BgpInstance();
        String bgpId = UUID.randomUUID().toString();

        bgp.setBgpId(bgpId);
        bgp.setBgpInstanceName(identifierName);
        bgp.setLocalAsNumber(localAsNumber);
        bgp.setAdvtNonBgpRoutes(true);
        bgp.setEnableSnmpNotifications(true);
        bgp.setMaxRoutes(maxRoutes);
        bgp.setMaxPeers(maxPeers);
        bgp.setCurrentPeers(0);
        bgp.setMaxIbgpPaths(maxIbgpPaths);
        bgp.setMaxEbgpPaths(maxEbgpPaths);
        bgp.setMaxEibgpPaths(maxEibgpPaths);
        bgp.setInstanceStatus(operStatus);

        return bgp;
    }

    private BgpPeer constructPeer(String localAddress, String peerName, Integer localPort, String remoteAddressType,
            String remoteAddress, Integer remotePort) {
        BgpPeer peer = new BgpPeer();
        String peerId = UUID.randomUUID().toString();
        peer.setPeerId(peerId);
        peer.setPeerName(peerName);
        peer.setLocalAddress(localAddress);
        peer.setLocalPort(localPort);
        peer.setRemoteAddressType(remoteAddressType);
        peer.setRemoteAddress(remoteAddress);
        peer.setRemotePort(remotePort);
        peer.setPeerState("suppressed");
        peer.setAdminStatus("enabled");
        peer.setNegotiatedVersion(1);
        peer.setRemoteAsNumber(1);
        peer.setConnectRetryInterval(10);
        peer.setHoldTimeConfigured(10);
        peer.setKeepAliveConfigured(10);
        peer.setMinAsOriginationInterval(10);
        peer.setMinRouteAdvertisementInterval(10);
        peer.setRestartMode("receiving");
        peer.setRestartTimeInterval(10);
        peer.setAllowAutomaticStart("enable");
        peer.setIdleHoldTimeConfigured(60);
        peer.setDelayOpen("enable");
        peer.setDelayOpenTimeConfigured(0);
        peer.setPrefixUpperLimit(5000);
        peer.setTcpConnectRetryCount(5);
        peer.setIsPeerDamped("enable");
        peer.setBfdStatus(true);
        peer.setConnectionStatus(true);
        return peer;
    }

    private OspfInstance createOspfInstance(String instanceName, String globalTraceLevel, String spfComputeInterval,
            String staggeringStatus, String internalState, String tosSupport, Boolean operStatus) {

        OspfInstance ospf = new OspfInstance();
        String ospfId = UUID.randomUUID().toString();

        ospf.setOspfId(ospfId);
        ospf.setOspfInstanceName(instanceName);
        ospf.setGlobalTraceLevel(globalTraceLevel);
        ospf.setSpfComputeInterval(spfComputeInterval);
        ospf.setStaggeringStatus(staggeringStatus);
        ospf.setInternalState(internalState);
        ospf.setTosSupport(tosSupport);
        ospf.setInstanceStatus(operStatus);

        return ospf;
    }

    private OspfNeighbour constructNeighbour(String neighbourName, String ipAddress, Integer addressLessIndex,
            String grStatus, String grReason, Boolean state) {
        OspfNeighbour neighbour = new OspfNeighbour();
        String neighbourId = UUID.randomUUID().toString();
        neighbour.setNeighbourId(neighbourId);
        neighbour.setNeighbourName(neighbourName);
        neighbour.setIpAddress(ipAddress);
        neighbour.setAddressLessIndex(addressLessIndex);
        neighbour.setBfdState(true);
        neighbour.setGracefulRestartStatus(grStatus);
        neighbour.setGracefulRestartReason(grStatus);
        neighbour.setNeighbourState(state);
        return neighbour;
    }

    private LdpEntity createLdpEntity(String ldpId, Integer entityIndex, String labelDistMethod,
            String labelRetentionMode, Integer tcpPort, Integer udpDescPort, Integer pduLength, String ipAddress,
            Boolean operStatus) {

        LdpEntity entity = new LdpEntity();
        String entityId = UUID.randomUUID().toString();

        entity.setEntityId(entityId);
        entity.setEntityIndex(entityIndex);
        entity.setEntityLdpId(ldpId);
        entity.setLabelDistMethod(labelDistMethod);
        entity.setLabelRetentionMode(labelRetentionMode);
        entity.setTcpPort(tcpPort);
        entity.setUdpDescPort(udpDescPort);
        entity.setMaxPduLength(pduLength);
        entity.setOperStatus(true);
        entity.setTargetPeerAddrType("ipv4");
        entity.setTargetPeerAddr(ipAddress);
        entity.setProtocolVersion(1);
        entity.setInitSessionThreshold(8);
        entity.setKeepAliveHoldTimer(40);

        return entity;
    }

    public LdpPeer constructLdpPeer(String peerLdpId, String ipAddress, String labelDistMethod) {
        LdpPeer peer = new LdpPeer();
        String peerId = UUID.randomUUID().toString();

        peer.setPeerId(peerId);
        peer.setPeerLdpId(peerLdpId);
        peer.setPeerLabelDistMethod(labelDistMethod);
        peer.setPeerPathVectorLimit(50);
        peer.setPeerTransportAddrType("IPv4");
        peer.setPeerTransportAddr(ipAddress);

        return peer;
    }

    public NetworkDevice getDevice(String deviceId) {
        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        device = rClient.get(NetworkDevice.class, deviceUri).get();
        return device;
    }

    private void createLink(String networkId, String srcElement, String srcInterface, String destElement,
            String destInterface, String linkType, String linkRate, String linkLatency) {
        Link link = new Link();
        String linkId = UUID.randomUUID().toString();
        String linkName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;
        link.setLinkId(linkId);
        link.setLinkName(linkName);
        link.setLinkType(linkType);
        link.setSourceNode(srcElement);
        link.setSourceEndpoint(srcInterface);
        link.setDestinationNode(destElement);
        link.setDestinationEndpoint(destInterface);
        link.setLinkRate(linkRate);
        link.setLinkLatency(linkLatency);
        link.setDelay("3000ms");
        link.setAutoNegotiation(true);
        link.setDuplexMode("full");
        link.setAdminStatus(true);
        link.setLinkStatus(true);

        AAIResourceUri linkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).link(link.getLinkId()));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(linkUri, link);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    private void createLsp(String networkId, String srcElement, String srcInterface, String destElement,
            String destInterface) {
        Lsp lsp = new Lsp();
        String lspId = UUID.randomUUID().toString();
        String lspName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;

        lsp.setLspId(lspId);
        lsp.setLspName(lspName);

        lsp.setSourceElement(srcElement);
        lsp.setSourceInterface(srcInterface);
        lsp.setDestinationElement(destElement);
        lsp.setDestinationInterface(destInterface);
        lsp.setLspStatus(true);
        lsp.setAdminStatus(true);

        AAIResourceUri lspUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).lsp(lsp.getLspId()));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(lspUri, lsp);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    private void createRoute(String networkId, String srcElement, String srcInterface, String localAddress,
            String destElement, String destInterface, String nexthopAddress) {

        Route route = new Route();
        String routeId = UUID.randomUUID().toString();
        String routeName = srcInterface + "@" + srcElement + ":" + destInterface + "@" + destElement;
        route.setRouteId(routeId);
        route.setRouteName(routeName);
        route.setSourceElement(srcElement);
        route.setLocalAddress(srcInterface);
        route.setDestinationElement(destElement);
        route.setNexthopAddress(nexthopAddress);
        route.setProtocol("BGP");
        route.setRouteStatus(true);
        route.setAdminStatus(true);

        AAIResourceUri routeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).route(route.getRouteId()));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(routeUri, route);
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }
}