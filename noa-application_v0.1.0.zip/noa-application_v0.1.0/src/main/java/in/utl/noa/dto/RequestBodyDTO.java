package in.utl.noa.dto;

import java.util.Map;

import org.json.simple.JSONObject;

public class RequestBodyDTO {
    private Map<String, JSONObject> filters;
    private JSONObject pagination;
    private Map<String, String> sortDetails;

    public RequestBodyDTO() {
    }

    public Map<String, JSONObject> getFilters() {
        return this.filters;
    }

    public void setFilters(Map<String, JSONObject> filters) {
        this.filters = filters;
    }

    public JSONObject getPagination() {
        return this.pagination;
    }

    public void setPagination(JSONObject pagination) {
        this.pagination = pagination;
    }

    public Map<String, String> getSortDetails() {
        return this.sortDetails;
    }

    public void setSortDetails(Map<String, String> sortDetails) {
        this.sortDetails = sortDetails;
    }

}
