package in.utl.noa.platform.config.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.onap.aai.domain.yang.RollbackRecords;
import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.RollbackUnit;

import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.platform.config.service.RollbackHandler;

@RestController
@RequestMapping(value = "/api/platform/config/rollback")
public class RollbackController {
    private static Logger logger = Logger.getLogger(RollbackController.class);

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @Autowired
    GDBFilterService filterService;

    @Autowired
    RollbackHandler rollbackHandler;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<List<RollbackUnit>> getRollbackUnits() {
        List<RollbackUnit> rollbackUnits = rollbackHandler.getRollbackUnits();

        return ResponseEntity.status(HttpStatus.OK).body(rollbackUnits);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getRoleFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "access-role");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("resource", "Resource");
        columns.put("resourceId", "Resource Id");
        columns.put("operation", "Operation");
        columns.put("description", "Description");
        columns.put("timestamp", "Timestamp");
        columns.put("status", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getRoleList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject roles = filterService.queryByFilter(requestBody, "rollback-unit");
        return ResponseEntity.status(HttpStatus.OK).body(roles);
    }

    @GetMapping(value = "/{rollbackId}/attribute")
    public ResponseEntity<List<Attributes>> getAttributes(@PathVariable("rollbackId") String rollbackId)
            throws BulkProcessFailed, IllegalArgumentException, ClassNotFoundException {
        List<Attributes> attributes = new ArrayList<Attributes>();
        if (rollbackId != null) {
            AAIResourceUri rollbackUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackId)).depth(Depth.TWO);
            if (rClient.exists(rollbackUri)) {
                RollbackUnit rollbackUnit = rClient.get(RollbackUnit.class, rollbackUri).get();
                attributes.addAll(rollbackUnit.getAttributes());
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(attributes);
    }

    @PostMapping(value = "/{rollbackId}")
    public ResponseEntity<String> rollbackTansaction(@PathVariable("rollbackId") String rollbackId)
            throws BulkProcessFailed, IllegalArgumentException, ClassNotFoundException {

        if (rollbackId != null) {
            AAIResourceUri rollbackUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackId)).depth(Depth.TWO);
            if (rClient.exists(rollbackUri)) {
                rollbackHandler.revertConfiguration(rollbackUri);
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body("Reverted Successfully");
    }

    @DeleteMapping(value = "/{rollbackId}")
    public ResponseEntity<String> deleteRb(@PathVariable("rollbackId") String rollbackId) throws BulkProcessFailed {
        AAIResourceUri rollbackUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackId)).depth(Depth.TWO);

        AAITransactionalClient transactions = rClient.beginTransaction();
        transactions.delete(rollbackUri);
        transactions.execute();
        return ResponseEntity.status(HttpStatus.OK).body("Deleted");
    }

    @DeleteMapping()
    public ResponseEntity<String> clearAllLogs() {
        AAIPluralResourceUri rollbackRecordsUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackRecords()).depth(Depth.TWO);

        RollbackRecords recordsList = rClient.get(RollbackRecords.class, rollbackRecordsUri).get();

        List<RollbackUnit> rollbacks = recordsList.getRollbackUnit();

        for (RollbackUnit rollback : rollbacks) {
            AAIResourceUri rollbackUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollback.getRollbackId()));

            if (rClient.exists(rollbackUri)) {
                AAITransactionalClient transactions = rClient.beginTransaction().delete(rollbackUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Rollback Records have been Deleted.");
    }
}
