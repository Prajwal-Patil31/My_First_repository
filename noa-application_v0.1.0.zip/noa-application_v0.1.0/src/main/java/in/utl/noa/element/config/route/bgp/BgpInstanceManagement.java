package in.utl.noa.element.config.route.bgp;

import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.onap.aai.domain.yang.BgpInstance;
import org.onap.aai.domain.yang.BgpPeer;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.element.service.DeviceOperationService;
//import in.utl.noa.service.DeviceRepository;
import in.utl.noa.element.service.EdgeRouterService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;

import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.RollbackUnit;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/router/bgp")
public class BgpInstanceManagement {
    private static Logger logger = Logger.getLogger(BgpInstanceManagement.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    /* @Autowired
    DeviceRepository deviceRepo; */

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;
    
    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<BgpInstance>> getBgpInstances(@PathVariable("deviceId") String deviceId) {

        List<BgpInstance> bgpInstances = new ArrayList<BgpInstance>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {

            device = rClient.get(NetworkDevice.class, deviceUri).get();

            if (device.getBgpInstances() != null) {
                bgpInstances = device.getBgpInstances().getBgpInstance();
            }
            return ResponseEntity.status(HttpStatus.OK).body(bgpInstances);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(bgpInstances);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getBgpInstanceFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();
        
        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "bgp-instance");

        Map<String, Object> columns = new HashMap<>();
        columns.put("bgpInstanceName", "Instance Name");
        columns.put("localAsNumber", "Local AS Number");
        columns.put("maxPeers", "Max Peers");
        columns.put("currentPeers", "Current Peers");
        columns.put("maxRoutes", "Max Routes");
        columns.put("maxIbgpPaths", "Max IBGP Paths");
        columns.put("maxEbgpPaths", "Max EBGP Paths");
        columns.put("maxEibgpPaths", "Max EIBGP Paths");
        columns.put("instanceStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getBgpInstanceList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject bgpInstances = filterService.queryByFilter(requestBody,"bgp-instance");
        return ResponseEntity.status(HttpStatus.OK).body(bgpInstances);
    }

    @GetMapping(value = "/{instanceId}")
    public ResponseEntity<BgpInstance> getBgpInstance(@PathVariable("deviceId") String deviceId,
        @PathVariable("instanceId") String instanceId) {

        BgpInstance bgpInstance = new BgpInstance();

        AAIResourceUri bgpInstanceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpInstance(instanceId));

        if (rClient.exists(bgpInstanceUri)) {

            bgpInstance = rClient.get(BgpInstance.class, bgpInstanceUri).get();

            return ResponseEntity.status(HttpStatus.OK).body(bgpInstance);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(bgpInstance);
    }

    @PutMapping()
    public ResponseEntity<BgpInstance> createBgpInstance(@PathVariable("deviceId") String deviceId,
            @RequestBody BgpInstance bgpInstanceBody) throws BulkProcessFailed {

        String bgpId = UUID.randomUUID().toString();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("BGP Instance", bgpId,
                "Network Device", deviceId);

        AAIResourceUri bgpUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpInstance(bgpId));

        bgpInstanceBody.setBgpId(bgpId);
        bgpInstanceBody.setCurrentPeers(3);
        bgpInstanceBody.setGrStatus("Complete");
        bgpInstanceBody.setGrReason("Software Restart");
        bgpInstanceBody.setEnableGracefulRestart(true);
        bgpInstanceBody.setGrStatus("Planned Restart");

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(bgpUri, bgpInstanceBody);
        transactions.execute();
        description = "BGP Instance has been Created in " + deviceId;

        JSONObject bgpInstanceObj = rollbackHandler.getJsonObject(bgpInstanceBody);

        List<Attributes> attributes = rollbackHandler.createAttributes(bgpInstanceObj, null, null);
        String resourceUri = bgpUri.getObjectType().toString();
        rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.BgpInstance", bgpId, resourceUri,
                deviceId, attributes, null, 0, description, true);

        eventStatus = true;
        reqStatus = HttpStatus.OK;
        
        BgpPeer peer1 = constructPeer("192.168.1.110", "HYD-PE-146",22, "ipv4", "192.168.1.101", 22);
        BgpPeer peer2 = constructPeer("192.168.1.111", "DEL-CE-130",22, "ipv4", "192.168.1.102", 22);
        BgpPeer peer3 = constructPeer("192.168.1.112","BOM-PE-240", 22, "ipv4", "192.168.1.103", 22);

        List<BgpPeer> peers = new ArrayList<BgpPeer>();
        peers.add(peer1);
        peers.add(peer2);
        peers.add(peer3);

        AAITransactionalClient peerTransactions = null;
        for (BgpPeer peer : peers) {
            AAIResourceUri bgpPeerUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpPeer(peer.getPeerId()));

            if (!rClient.exists(bgpPeerUri)) {
                peerTransactions = rClient.beginTransaction().create(bgpPeerUri, peer).connect(bgpPeerUri, bgpUri);
                peerTransactions.execute();
            }
        }

        auditLogger.addAuditLog(rClient, description, "Device Configuration", "BgpInstance",
                NoaEvents.CREATE_BGP_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(bgpInstanceBody);
    }

    private BgpPeer constructPeer(String localAddress,String peerName, Integer localPort, String remoteAddressType,
            String remoteAddress, Integer remotePort) {
        BgpPeer peer = new BgpPeer();
        String peerId = UUID.randomUUID().toString();
        peer.setPeerId(peerId);
        peer.setPeerName(peerName);
        peer.setLocalAddress(localAddress);
        peer.setLocalPort(localPort);
        peer.setRemoteAddressType(remoteAddressType);
        peer.setRemoteAddress(remoteAddress);
        peer.setRemotePort(remotePort);
        peer.setPeerState("suppressed");
        peer.setAdminStatus("enabled");
        peer.setNegotiatedVersion(1);
        peer.setRemoteAsNumber(1);
        peer.setConnectRetryInterval(10);
        peer.setHoldTimeConfigured(10);
        peer.setKeepAliveConfigured(10);
        peer.setMinAsOriginationInterval(10);
        peer.setMinRouteAdvertisementInterval(10);
        peer.setRestartMode("receiving");
        peer.setRestartTimeInterval(10);
        peer.setAllowAutomaticStart("enable");
        peer.setIdleHoldTimeConfigured(60);
        peer.setDelayOpen("enable");
        peer.setDelayOpenTimeConfigured(0);
        peer.setPrefixUpperLimit(5000);
        peer.setTcpConnectRetryCount(5);
        peer.setIsPeerDamped("enable");
        peer.setBfdStatus(true);
        peer.setConnectionStatus(true);
        return peer;
    }

    @PostMapping(value = "/{instanceId}")
    public ResponseEntity<String> updateBgpConfiguration(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId,
            @RequestBody BgpInstance updatedBgpInstance) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Bgp Instance", instanceId,
                "Network Device", deviceId);

        AAIResourceUri bgpUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpInstance(instanceId));

        if (rClient.exists(bgpUri)) {
            AAITransactionalClient transactions;
            BgpInstance updBgpConfig = rClient.get(BgpInstance.class, bgpUri).get();
            transactions = rClient.beginTransaction().update(bgpUri, updatedBgpInstance);
            transactions.execute();
            description = "BGP Instance has been Updated in " + deviceId + " Device";

            JSONObject bgpInstanceObj = rollbackHandler.getJsonObject(updBgpConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(bgpInstanceObj, null, null);
            String resourceUri = bgpUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.BgpInstance", instanceId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = instanceId + " BGP Instance Doesn't Exists";
            reqStatus = HttpStatus.NOT_FOUND;
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "BGP Instance",
                NoaEvents.UPDATE_BGP_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteBgpInstances(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> bgpInstanceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("BGP Instance", null,
                "Network Device", deviceId);

        for (String bgpInstanceId : bgpInstanceIds) {
            resourceMetadata.setResourceId(bgpInstanceId);
            if (bgpInstanceId != null) {
                AAIResourceUri bgpUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bgpInstance(bgpInstanceId));
                if (rClient.exists(bgpUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(bgpUri);
                    transactions.execute();
                    description = bgpInstanceId + " BGP Instance has been Deleted";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "BgpInstance",
                            NoaEvents.DELETE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = bgpInstanceId + " BGP Instance Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "BgpInstance",
                            NoaEvents.DELETE_BGP_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Instance Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "BgpInstance",
                        NoaEvents.DELETE_BGP_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/{instanceId}/peer")
    public ResponseEntity<List<BgpPeer>> getBgpPeers(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId) throws JsonMappingException, JsonProcessingException, ParseException {

        List<BgpPeer> bgpPeers = new ArrayList<BgpPeer>();
        
        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                                        .to(__.node(Types.BGP_INSTANCE, __.key("bgp-id", instanceId)))
                                        .to(__.node(Types.BGP_PEER)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject peerObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            BgpPeer peerBody = mapper.readValue(peerObj.toString(),BgpPeer.class);
            bgpPeers.add(peerBody);
        }
        return ResponseEntity.status(HttpStatus.OK).body(bgpPeers);
    }

    @GetMapping(value = "/{instanceId}/peer/{peerId}")
    public ResponseEntity<BgpPeer> getBgpPeerById(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId, @PathVariable("peerId") String peerId) 
            throws JsonMappingException, JsonProcessingException, ParseException {

        BgpPeer bgpPeer = new BgpPeer();
        
        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                                        .to(__.node(Types.BGP_INSTANCE, __.key("bgp-id", instanceId)))
                                        .to(__.node(Types.BGP_PEER, __.key("peer-id", peerId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject peerObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            bgpPeer = mapper.readValue(peerObj.toString(),BgpPeer.class);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(bgpPeer);
    }
}
