package in.utl.noa.element;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.AttachmentCircuit;
import org.onap.aai.domain.yang.AuditConfig;
import org.onap.aai.domain.yang.DeviceConfig;
import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.IetfInterfaces;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.IpAuthorizationManager;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.Route;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.NetworkDevices;
import org.onap.aai.domain.yang.PerformanceConfig;
import org.onap.aai.domain.yang.PortControlEntry;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.Vlan;
import org.onap.aai.domain.yang.VpnService;
import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.RollbackUnit;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;

import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

import in.utl.noa.element.service.DeviceOperationService;
import in.utl.noa.element.service.EdgeRouterService;

import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.element.config.resource.port.model.InterfaceStats;
import in.utl.noa.element.config.resource.port.model.InterfaceStatsRepository;
import in.utl.noa.platform.config.service.RollbackHandler;

@RestController
@RequestMapping(value = "/api/element")
public class DeviceController {

    private static Logger logger = Logger.getLogger(DeviceController.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    InterfaceStatsRepository interfaceStatsRepo;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping("/overview")
    public ResponseEntity<JSONObject> getNetworkOverview() throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementOverviewObj = (JSONObject) obj.get("element-overview");

        return ResponseEntity.ok(elementOverviewObj);
    }

    @GetMapping("/status")
    public ResponseEntity<List<JSONArray>> getInventoryOverview()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStatusObj = (List<JSONArray>) obj.get("element-status");
        return ResponseEntity.ok(elementStatusObj);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getNetworkDeviceFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "network-device");

        Map<String, Object> columns = new HashMap<>();
        columns.put("deviceName", "Device Name");
        columns.put("deviceType", "Device Type");
        columns.put("host", "Host Address");
        columns.put("model", "Model");
        columns.put("status", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getDevices(@RequestBody RequestBodyDTO requestBody) {
        JSONObject elements = filterService.queryByFilter(requestBody, "network-device");
        return ResponseEntity.status(HttpStatus.OK).body(elements);
    }

    @GetMapping()
    public ResponseEntity<List<NetworkDevice>> getDevicesList() {
        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();

        AAISimplePluralUri deviceUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevices());

        if (rClient.exists(deviceUri)) {

            NetworkDevices devicesList = rClient.get(NetworkDevices.class, deviceUri).get();

            devices = devicesList.getNetworkDevice();

            return ResponseEntity.status(HttpStatus.OK).body(devices);
        }
        return ResponseEntity.status(HttpStatus.OK).body(devices);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> clearAllDevices() {
        AAIPluralResourceUri devicesUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevices()).depth(Depth.TWO);

        if (rClient.exists(devicesUri)) {

            NetworkDevices devicesList = rClient.get(NetworkDevices.class, devicesUri).get();

            List<NetworkDevice> devices = devicesList.getNetworkDevice();

            for (NetworkDevice device : devices) {
                AAIResourceUri deviceUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(device.getDeviceId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(deviceUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Devices have been Deleted.");
    }

    @GetMapping(value = "/{deviceId}", produces = "application/json")
    public ResponseEntity<NetworkDevice> getDeviceById(@PathVariable("deviceId") String deviceId) {

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(device);
    }

    @PutMapping()
    public ResponseEntity<NetworkDevice> addDevice(@RequestBody NetworkDevice newDevice) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String deviceId = UUID.randomUUID().toString();
        newDevice.setDeviceId(deviceId);

        String deviceType = newDevice.getDeviceType();
        switch (deviceType) {
            case "pe-router":
                newDevice.setHardwareVersion("Juniper ACX 700");
                break;
            case "ce-router":
                newDevice.setHardwareVersion("Juniper ACX 550");
                break;
            case "p-router":
                newDevice.setHardwareVersion("Juniper ACX 500");
                break;
        }
        newDevice.setSoftwareVersion("Junos 21.4R1.12");
        if (newDevice.isElementStatus() == null) {
            newDevice.setElementStatus(false);
        }

        IetfInterfaces interfaces = new IetfInterfaces();
        List<IetfInterface> interfaceList = new ArrayList<IetfInterface>();

        for (int i = 0; i <= 9; i++) {
            IetfInterface ethernet = new IetfInterface();
            Random r = new Random();

            ethernet.setInterfaceName("ethernet" + i);
            ethernet.setInterfaceId(UUID.randomUUID().toString());
            ethernet.setLayer("L1");
            ethernet.setSpeed("1Gbps");
            ethernet.setAdminStatus("up");
            ethernet.setEnabled(true);
            ethernet.setIfIndex(i);
            ethernet.setIfAlias(ethernet.getInterfaceName());
            ethernet.setInterfaceType("ethernetCsmacd");
            ethernet.setBridgePortType("customerBridgePort");
            ethernet.setVlanPortType("hybrid-port");
            ethernet.setDeviceId(deviceId);
            ethernet.setIpAddress(r.nextInt(255) + "." + r.nextInt(255) + "." + r.nextInt(255) + "." + r.nextInt(255));

            interfaceList.add(ethernet);
        }

        interfaces.getIetfInterface().addAll(interfaceList);

        newDevice.setIetfInterfaces(interfaces);

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", deviceId, null, null);

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(deviceUri, newDevice);
        transactions.execute();

        description = deviceId + " Device Attached Successfully.";

        JSONObject deviceObj = rollbackHandler.getJsonObject(newDevice);
        deviceObj.remove("ietf-interfaces");
        deviceObj.remove("bridge");
        List<Attributes> attributes = rollbackHandler.createAttributes(deviceObj, null, null);
        String resourceUri = deviceUri.getObjectType().toString();

        rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.NetworkDevice", deviceId, resourceUri, null,
                attributes, null, 0, description, true);

        description = deviceId + " Device Attached Successfully.";
        reqStatus = HttpStatus.CREATED;
        eventStatus = true;
        auditLogger.addAuditLog(rClient, description, "Device Management", "Inventory Management",
                NoaEvents.ATTACH_DEVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(newDevice);
    }

    @PatchMapping(value = "/{deviceId}")
    public ResponseEntity<String> updateDevice(@PathVariable("deviceId") String deviceId,
            @RequestBody NetworkDevice newDevice) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", deviceId, null, null);

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        newDevice.setRestart(false);
        if (deviceId != null) {
            if (rClient.exists(deviceUri)) {
                NetworkDevice updDevice = rClient.get(NetworkDevice.class, deviceUri).get();
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().create(deviceUri, newDevice);

                transactions.execute();
                description = deviceId + " Device Updated Successfully.";

                JSONObject deviceObj = rollbackHandler.getJsonObject(updDevice);
                List<Attributes> attributes = rollbackHandler.createAttributes(deviceObj, null, null);
                String resourceUri = deviceUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.NetworkDevice", deviceId,
                        resourceUri, null, attributes, null, 0, description, true);
                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = deviceId + " Device Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Management", "Inventory Management",
                NoaEvents.UPDATE_DEVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteDevices(@RequestBody List<String> deviceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", null, null, null);

        for (String deviceId : deviceIds) {
            resourceMetadata.setResourceId(deviceId);
            if (deviceId != null) {
                AAIResourceUri deviceUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));
                if (rClient.exists(deviceUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(deviceUri);
                    transactions.execute();
                    description = deviceId + " Device Detached Successfully.";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Device Management", "Inventory Management",
                            NoaEvents.DETACH_DEVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    // deviceService.detachDevice(deviceId);
                } else {
                    description = deviceId + " Device Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Device Management", "Inventory Management",
                            NoaEvents.DETACH_DEVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Device Id";
                auditLogger.addAuditLog(rClient, description, "Device Management", "Inventory Management",
                        NoaEvents.DETACH_DEVICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(reqStatus).body("Devices have been Deleted.");
    }

    @GetMapping(value = "/{deviceId}/overview")
    public ResponseEntity<JSONObject> getDeviceOverview(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementDetailsObj = (JSONObject) obj.get("device-details");

        return ResponseEntity.ok(elementDetailsObj);
    }

    @GetMapping(value = "/{deviceId}/state")
    public ResponseEntity<List<JSONArray>> getDeviceState(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("device-state");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{deviceId}/resource/overview")
    public ResponseEntity<JSONObject> getDeviceResourcesOverview(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementStateObj = (JSONObject) obj.get("device-resources");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{deviceId}/interface/in")
    public ResponseEntity<List<JSONObject>> getDeviceInterfaceUtilizationIn(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("interface-utilization-in");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{deviceId}/interface/out")
    public ResponseEntity<List<JSONObject>> getDeviceInterfaceUtilizationOut(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("interface-utilization-out");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{deviceId}/fault/overview")
    public ResponseEntity<JSONObject> getElementFaultOverview()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementStatusObj = (JSONObject) obj.get("element-fault-overview");

        return ResponseEntity.ok(elementStatusObj);
    }

    @GetMapping(value = "/{deviceId}/network")
    public ResponseEntity<List<IetfNetwork>> getNetworks(@PathVariable("deviceId") String deviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();

        DSLStartNode startNode = new DSLStartNode(Types.N_NODE, __.key("node-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.IETF_NETWORK))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject networkObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            IetfNetwork network = mapper.readValue(networkObj.toString(), IetfNetwork.class);
            networks.add(network);
        }
        return ResponseEntity.status(HttpStatus.OK).body(networks);
    }

    @GetMapping(value = "/{deviceId}/network/overview")
    public ResponseEntity<JSONObject> getNetworkOverview(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementNetworksObj = (JSONObject) obj.get("element-connectivity-network");

        return ResponseEntity.ok(elementNetworksObj);
    }

    @GetMapping(value = "/{deviceId}/service")
    public ResponseEntity<List<VpnService>> getServices(@PathVariable("deviceId") String deviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<VpnService> services = new ArrayList<VpnService>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.ENDPOINT))
                .to(__.node(Types.VPN_SERVICE)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject serviceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            VpnService serviceBody = mapper.readValue(serviceObj.toString(), VpnService.class);
            services.add(serviceBody);
        }

        return ResponseEntity.status(HttpStatus.OK).body(services);
    }

    @GetMapping(value = "/{deviceId}/service/overview")
    public ResponseEntity<JSONObject> getServiceOverview(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementServicesObj = (JSONObject) obj.get("element-connectivity-service");

        return ResponseEntity.ok(elementServicesObj);
    }

    @GetMapping(value = "/{deviceId}/service/throughput")
    public ResponseEntity<List<JSONObject>> getDeviceServiceThroughput(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("device-service-throughput");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{deviceId}/connection/overview")
    public ResponseEntity<JSONObject> getConnectionOverview(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementConnectionObj = (JSONObject) obj.get("element-connectivity-path");

        return ResponseEntity.ok(elementConnectionObj);
    }

    @GetMapping(value = "/{deviceId}/link")
    public ResponseEntity<List<Link>> getRelatedLinks(@PathVariable("deviceId") String deviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<Link> links = new ArrayList<Link>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        device = rClient.get(NetworkDevice.class, deviceUri).get();
        String deviceName = device.getDeviceName();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", "", "null").not());
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).union(
                __.node(Types.LINK, __.key("source-node", deviceName)).output(),
                __.node(Types.LINK, __.key("destination-node", deviceName)).output());

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject serviceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Link serviceBody = mapper.readValue(serviceObj.toString(), Link.class);
            links.add(serviceBody);
        }

        return ResponseEntity.status(HttpStatus.OK).body(links);
    }

    @GetMapping(value = "/{deviceId}/link/latency")
    public ResponseEntity<List<JSONObject>> getDeviceLinkLatencyDeviation(@PathVariable("deviceId") String deviceId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("device-link-latency");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{deviceId}/lsp")
    public ResponseEntity<List<Lsp>> getRelatedLsps(@PathVariable("deviceId") String deviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<Lsp> lsps = new ArrayList<Lsp>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        device = rClient.get(NetworkDevice.class, deviceUri).get();
        String deviceName = device.getDeviceName();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", "", "null").not());
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).union(
                __.node(Types.LSP, __.key("source-element", deviceName)).output(),
                __.node(Types.LSP, __.key("destination-element", deviceName)).output());

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject serviceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Lsp serviceBody = mapper.readValue(serviceObj.toString(), Lsp.class);
            lsps.add(serviceBody);
        }

        return ResponseEntity.status(HttpStatus.OK).body(lsps);
    }

    @GetMapping(value = "/{deviceId}/route")
    public ResponseEntity<List<Route>> getRelatedRoutes(@PathVariable("deviceId") String deviceId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<Route> routes = new ArrayList<Route>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        device = rClient.get(NetworkDevice.class, deviceUri).get();
        String deviceName = device.getDeviceName();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", "", "null").not());
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).union(
                __.node(Types.ROUTE, __.key("source-element", deviceName)).output(),
                __.node(Types.ROUTE, __.key("destination-element", deviceName)).output());

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject routeObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Route route = mapper.readValue(routeObj.toString(), Route.class);
            routes.add(route);
        }

        return ResponseEntity.status(HttpStatus.OK).body(routes);
    }

    @GetMapping(value = "/{deviceId}/altranRequest")
    public void getInterfacesFromDevice(@PathVariable("deviceId") String deviceId) {
        deviceService.getInterfaces(deviceId);
    }

    @PostMapping(value = "/{deviceId}/interface-stats/{interfaceId}")
    public ResponseEntity<List<InterfaceStats>> getInterfaceStats(@PathVariable("deviceId") String deviceId,
            @PathVariable("interfaceId") String interfaceId, @RequestBody JSONObject durationObj)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        Integer minutes = 0;
        Integer hours = 0;
        Integer days = 0;

        if (durationObj.get("minutes") != null) {
            minutes = Integer.parseInt(durationObj.get("minutes").toString());
        }

        if (durationObj.get("hours") != null) {
            hours = Integer.parseInt(durationObj.get("hours").toString());
        }

        if (durationObj.get("days") != null) {
            days = Integer.parseInt(durationObj.get("days").toString());
        }

        List<InterfaceStats> interfaceStats = interfaceStatsRepo.findByDuration(interfaceId + "@" + deviceId, minutes,
                hours, days);

        return ResponseEntity.status(HttpStatus.OK).body(interfaceStats);
    }

    @GetMapping(value = "/{deviceId}/attachment-circuit")
    public ResponseEntity<List<AttachmentCircuit>> getAttachmentCircuits(@PathVariable("deviceId") String deviceId)
            throws JsonMappingException, JsonProcessingException {

        List<AttachmentCircuit> attachmentCircuits = new ArrayList<AttachmentCircuit>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            if (device.getAttachmentCircuits() != null) {
                attachmentCircuits.addAll(device.getAttachmentCircuits().getAttachmentCircuit());
            }
            return ResponseEntity.status(HttpStatus.OK).body(attachmentCircuits);
        }
        return ResponseEntity.status(HttpStatus.OK).body(attachmentCircuits);
    }

    @GetMapping(value = "/{deviceId}/attachment-circuit/{acId}")
    public ResponseEntity<AttachmentCircuit> getAttachmentCircuit(@PathVariable("deviceId") String deviceId,
            @PathVariable("acId") String acId) throws JsonMappingException, JsonProcessingException {

        AttachmentCircuit attachmentCircuit = new AttachmentCircuit();

        AAIResourceUri attachmentCircuitUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).attachmentCircuit(acId));

        if (rClient.exists(attachmentCircuitUri)) {
            attachmentCircuit = rClient.get(AttachmentCircuit.class, attachmentCircuitUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(attachmentCircuit);
        }
        return ResponseEntity.status(HttpStatus.OK).body(attachmentCircuit);
    }

    @PutMapping(value = "/{deviceId}/attachment-circuit")
    public ResponseEntity<String> createAttachmentCircuit(@PathVariable("deviceId") String deviceId,
            @RequestBody AttachmentCircuit attachmentCircuitBody) throws BulkProcessFailed {

        if (attachmentCircuitBody.getAcId() == null) {
            attachmentCircuitBody.setAcId(attachmentCircuitBody.getAcName());
        }
        String vlanId = attachmentCircuitBody.getAcCustomerVlan();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Attachment Circuit",
                attachmentCircuitBody.getAcId(), "Network Device", deviceId);

        if (deviceId != null) {
            AAIResourceUri attachmentCircuitUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                    .networkDevice(deviceId).attachmentCircuit(attachmentCircuitBody.getAcId()));

            AAIResourceUri vlanUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

            if (!rClient.exists(attachmentCircuitUri)) {
                // edgeRouterService.createAttachmentCircuit(deviceId, attachmentCircuitBody);

                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(attachmentCircuitUri, attachmentCircuitBody)
                        .connect(attachmentCircuitUri, vlanUri);
                transactions.execute();
                description = attachmentCircuitBody.getAcId() + " Attachment Circuit Already Exists";

                JSONObject acObj = rollbackHandler.getJsonObject(attachmentCircuitBody);

                List<Attributes> attributes = rollbackHandler.createAttributes(acObj, null, null);
                String resourceUri = attachmentCircuitUri.getObjectType().toString();
                RollbackUnit rollbackUnit = rollbackHandler.addRollbackUnit("Create",
                        "org.onap.aai.domain.yang.AttachmentCircuit", attachmentCircuitBody.getAcId(), resourceUri,
                        deviceId, attributes, null, 0, description, true);

                AAIResourceUri rollbackUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackUnit.getRollbackId()));

                JSONObject vlanObj = new JSONObject();
                vlanObj.put("vlan", vlanId);

                String vlanAttributeUri = vlanUri.getObjectType().toString();

                List<Attributes> vlanAttributes = rollbackHandler.createAttributes(vlanObj, vlanAttributeUri, null);
                rollbackHandler.addRollbackUnit("Connect", "org.onap.aai.domain.yang.AttachmentCircuit",
                        attachmentCircuitBody.getAcId(), resourceUri, deviceId, vlanAttributes, rollbackUri, 1,
                        description, false);

                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = attachmentCircuitBody.getAcId() + " Attachment Circuit Already Exists";
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Attachment Circuit",
                NoaEvents.CREATE_ATTACHMENT_CIRCUIT.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping(value = "/{deviceId}/attachment-circuit/{acId}")
    public ResponseEntity<String> updateAttachmentCircuit(@PathVariable("deviceId") String deviceId,
            @PathVariable("acId") String acId, @RequestBody AttachmentCircuit attachmentCircuitBody)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Attachment Circuit",
                attachmentCircuitBody.getAcId(), "Network Device", deviceId);

        if (deviceId != null && acId != null) {
            AAIResourceUri attachmentCircuitUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).attachmentCircuit(acId));

            if (rClient.exists(attachmentCircuitUri)) {
                // edgeRouterService.createAttachmentCircuit(deviceId, attachmentCircuitBody);
                AttachmentCircuit updac = rClient.get(AttachmentCircuit.class, attachmentCircuitUri).get();
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().update(attachmentCircuitUri, attachmentCircuitBody);
                transactions.execute();
                description = attachmentCircuitBody.getAcId() + " Attachment Circuit Already Exists";

                JSONObject acObj = rollbackHandler.getJsonObject(updac);

                List<Attributes> attributes = rollbackHandler.createAttributes(acObj, null, null);
                String resourceUri = attachmentCircuitUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.AttachmentCircuit",
                        attachmentCircuitBody.getAcId(), resourceUri, deviceId, attributes, null, 0, description, true);

                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = attachmentCircuitBody.getAcId() + " Attachment Circuit Already Exists";
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Attachment Circuit",
                NoaEvents.MODIFY_ATTACHMENT_CIRCUIT.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{deviceId}/attachment-circuit")
    public ResponseEntity<String> deleteAttachmentCircuits(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> acIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Attachment Circuit", null,
                "Network Device", deviceId);

        for (String acId : acIds) {
            if (acId != null) {
                resourceMetadata.setResourceId(acId);
                AAIResourceUri attachmentCircuitUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).attachmentCircuit(acId));
                if (rClient.exists(attachmentCircuitUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(attachmentCircuitUri);
                    transactions.execute();
                    description = acId + " Attachment Circuit has been Deleted.";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "Attachment Circuit",
                            NoaEvents.DELETE_ATTACHMENT_CIRCUIT.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = acId + " Attachment Circuit Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "Attachment Circuit",
                            NoaEvents.DELETE_ATTACHMENT_CIRCUIT.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Attachment Circuit Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "Attachment Circuit",
                        NoaEvents.DELETE_ATTACHMENT_CIRCUIT.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Attachment Circuits have been Deleted.");
    }

    @GetMapping(value = "/customer-device")
    public ResponseEntity<List<NetworkDevice>> getCustomerDevices()
            throws JsonMappingException, JsonProcessingException {

        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-type", "edge-router").not());
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, NetworkDevice>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, NetworkDevice>>>() {
                });

        for (Map<String, NetworkDevice> m : resultsFromJson.getResult()) {
            devices.add(m.get("network-device"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(devices);
    }

    @GetMapping("/{deviceId}/device-config")
    public ResponseEntity<DeviceConfig> getDeviceConfig(@PathVariable("deviceId") String deviceId) {

        DeviceConfig deviceConfig = new DeviceConfig();
        AAIResourceUri deviceConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).deviceConfig(deviceId));
        if (rClient.exists(deviceConfigUri)) {
            deviceConfig = rClient.get(DeviceConfig.class, deviceConfigUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(deviceConfig);
    }

    @PostMapping(value = "/{deviceId}/device-config")
    public ResponseEntity<String> updateDeviceConfig(@PathVariable("deviceId") String deviceId,
            @RequestBody DeviceConfig deviceConfig) throws BulkProcessFailed {

        String configId = deviceConfig.getConfigId();
        if (configId == null) {
            configId = deviceId;
            deviceConfig.setConfigId(configId);
        }
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Device Config",
                deviceConfig.getConfigId(), "Network Device", deviceId);

        deviceConfig.setInitiateConfigSave(false);
        ;
        deviceConfig.setInitiateConfigRestore(false);
        deviceConfig.setClearConfig(false);

        AAIResourceUri deviceConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).deviceConfig(configId));

        AAITransactionalClient transactions;
        if (deviceId != null) {
            DeviceConfig updDeviceConfig = new DeviceConfig();
            if (rClient.exists(deviceConfigUri)) {
                updDeviceConfig = rClient.get(DeviceConfig.class, deviceConfigUri).get();
                transactions = rClient.beginTransaction().update(deviceConfigUri, deviceConfig);
                transactions.execute();
            } else {
                transactions = rClient.beginTransaction().create(deviceConfigUri, deviceConfig);
                transactions.execute();
                updDeviceConfig = rClient.get(DeviceConfig.class, deviceConfigUri).get();
            }
            description = "Device Configuration has been Updated in " + deviceId + " Device";

            JSONObject deviceConfigObj = rollbackHandler.getJsonObject(updDeviceConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(deviceConfigObj, null, null);
            String resourceUri = deviceConfigUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.DeviceConfig", configId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Device Config",
                NoaEvents.CHANGE_DEVICE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{deviceId}/audit-config")
    public ResponseEntity<AuditConfig> getAuditConfig(@PathVariable("deviceId") String deviceId) {

        AuditConfig auditConfig = new AuditConfig();
        AAIResourceUri auditConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).auditConfig(deviceId));
        if (rClient.exists(auditConfigUri)) {
            auditConfig = rClient.get(AuditConfig.class, auditConfigUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(auditConfig);
    }

    @PostMapping(value = "/{deviceId}/audit-config")
    public ResponseEntity<String> updateAuditConfig(@PathVariable("deviceId") String deviceId,
            @RequestBody AuditConfig auditConfig) throws BulkProcessFailed {

        String configId = auditConfig.getConfigId();
        if (configId == null) {
            configId = deviceId;
            auditConfig.setConfigId(configId);
        }

        auditConfig.setAuditLogReset(false);
        auditConfig.setAuditLogInitiateTransfer(false);

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Audit Config",
                auditConfig.getConfigId(), "Network Device", deviceId);

        AAIResourceUri auditConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).auditConfig(configId));

        AAITransactionalClient transactions;
        if (deviceId != null) {
            AuditConfig updAuditConfig = new AuditConfig();
            if (rClient.exists(auditConfigUri)) {
                updAuditConfig = rClient.get(AuditConfig.class, auditConfigUri).get();
                transactions = rClient.beginTransaction().update(auditConfigUri, auditConfig);
                transactions.execute();
            } else {
                transactions = rClient.beginTransaction().create(auditConfigUri, auditConfig);
                transactions.execute();
                updAuditConfig = rClient.get(AuditConfig.class, auditConfigUri).get();
            }
            description = "Audit Configuration has been Updated in " + deviceId + " Device";

            JSONObject auditConfigObj = rollbackHandler.getJsonObject(updAuditConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(auditConfigObj, null, null);
            String resourceUri = auditConfigUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.AuditConfig", configId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Audit Config",
                NoaEvents.CHANGE_AUDIT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{deviceId}/performance-config")
    public ResponseEntity<PerformanceConfig> getPerformanceConfig(@PathVariable("deviceId") String deviceId) {

        PerformanceConfig performanceConfig = new PerformanceConfig();
        AAIResourceUri performanceConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).performanceConfig(deviceId));
        if (rClient.exists(performanceConfigUri)) {
            performanceConfig = rClient.get(PerformanceConfig.class, performanceConfigUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(performanceConfig);
    }

    @PostMapping(value = "/{deviceId}/performance-config")
    public ResponseEntity<String> updatePerformanceConfig(@PathVariable("deviceId") String deviceId,
            @RequestBody PerformanceConfig performanceConfig) throws BulkProcessFailed {

        String configId = performanceConfig.getConfigId();
        if (configId == null) {
            configId = deviceId;
            performanceConfig.setConfigId(configId);
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Performance Config",
                performanceConfig.getConfigId(), "Network Device", deviceId);

        AAIResourceUri performanceConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).performanceConfig(configId));

        AAITransactionalClient transactions;
        if (deviceId != null) {
            PerformanceConfig updPerformanceConfig = new PerformanceConfig();
            if (rClient.exists(performanceConfigUri)) {
                updPerformanceConfig = rClient.get(PerformanceConfig.class, performanceConfigUri).get();
                transactions = rClient.beginTransaction().update(performanceConfigUri, performanceConfig);
                transactions.execute();
            } else {
                transactions = rClient.beginTransaction().create(performanceConfigUri, performanceConfig);
                transactions.execute();
                updPerformanceConfig = rClient.get(PerformanceConfig.class, performanceConfigUri).get();
            }

            description = "Performance Configuration has been Updated in " + deviceId + " Device";

            JSONObject performanceConfigObj = rollbackHandler.getJsonObject(updPerformanceConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(performanceConfigObj, null, null);
            String resourceUri = performanceConfigUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.PerformanceConfig", configId,
                    resourceUri, deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Performance Config",
                NoaEvents.CHANGE_PERFORMANCE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/{deviceId}/port-control")
    public ResponseEntity<List<PortControlEntry>> getPortControls(@PathVariable("deviceId") String deviceId)
            throws JsonMappingException, JsonProcessingException {

        List<PortControlEntry> portControls = new ArrayList<PortControlEntry>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            if (device.getPortControl() != null) {
                portControls = device.getPortControl().getPortControlEntry();
            }
            return ResponseEntity.status(HttpStatus.OK).body(portControls);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(portControls);
    }

    @GetMapping(value = "/{deviceId}/port-control/{portControlId}")
    public ResponseEntity<PortControlEntry> getPortControl(@PathVariable("deviceId") String deviceId,
            @PathVariable("portControlId") String portControlId) throws JsonMappingException, JsonProcessingException {

        PortControlEntry portControl = new PortControlEntry();

        AAIResourceUri portControlUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).portControlEntry(portControlId));

        if (rClient.exists(portControlUri)) {
            portControl = rClient.get(PortControlEntry.class, portControlUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(portControl);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(portControl);
    }

    @PutMapping(value = "/{deviceId}/port-control")
    public ResponseEntity<String> createPortControl(@PathVariable("deviceId") String deviceId,
            @RequestBody PortControlEntry portControlBody) throws BulkProcessFailed {

        Integer portControlIndex = portControlBody.getPortControlIndex();

        if (portControlBody.getPortControlId() == null) {
            portControlBody.setPortControlId(portControlIndex + "@" + deviceId);
        } else {
            String portControlId = portControlBody.getPortControlId();
            portControlBody.setPortControlId(portControlId + "@" + deviceId);
        }

        String holBlockPrevention = portControlBody.getHolBlockPrevention();

        if (holBlockPrevention.equals("false") || holBlockPrevention == null) {
            portControlBody.setHolBlockPrevention("Disabled");
        } else {
            portControlBody.setHolBlockPrevention("Enabled");
        }

        if (portControlBody.isRenegotiate() == null) {
            portControlBody.setRenegotiate(false);
        }

        String cpuControlledLearning = portControlBody.getCpuControlledLearning();

        if (cpuControlledLearning.equals("false") || cpuControlledLearning == null) {
            portControlBody.setCpuControlledLearning("Disabled");
        } else {
            portControlBody.setCpuControlledLearning("Enabled");
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Port Control",
                portControlBody.getPortControlId(), "Network Device", deviceId);

        if (deviceId != null) {
            AAIResourceUri portControlUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                    .networkDevice(deviceId).portControlEntry(portControlBody.getPortControlId()));

            if (!rClient.exists(portControlUri)) {
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(portControlUri, portControlBody);
                transactions.execute();
                description = portControlBody.getPortControlId() + " Port Control has been Created.";

                JSONObject portControlObj = rollbackHandler.getJsonObject(portControlBody);

                List<Attributes> attributes = rollbackHandler.createAttributes(portControlObj, null, null);
                String resourceUri = portControlUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.PortControl",
                        portControlBody.getPortControlId(), resourceUri, deviceId, attributes, null, 0, description,
                        true);

                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = portControlBody.getPortControlId() + " Port Control Already Exists";
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Port Control",
                NoaEvents.CHANGE_PORT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping(value = "/{deviceId}/port-control/{portControlId}")
    public ResponseEntity<String> updatePortControl(@PathVariable("deviceId") String deviceId,
            @PathVariable("portControlId") String portControlId, @RequestBody PortControlEntry portControlBody)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Port Control",
                portControlBody.getPortControlId(), "Network Device", deviceId);

        if (deviceId != null) {
            AAIResourceUri portControlUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).portControlEntry(portControlId));

            if (rClient.exists(portControlUri)) {
                PortControlEntry updPortControl = rClient.get(PortControlEntry.class, portControlUri).get();
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().update(portControlUri, portControlBody);
                transactions.execute();
                description = portControlBody.getPortControlId() + " Port Control has been Updated.";

                JSONObject portControlObj = rollbackHandler.getJsonObject(updPortControl);

                List<Attributes> attributes = rollbackHandler.createAttributes(portControlObj, null, null);
                String resourceUri = portControlUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.PortControl", portControlId,
                        resourceUri, deviceId, attributes, null, 0, description, true);

                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = portControlBody.getPortControlId() + " Port Control Doesn't Exists";
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Port Control",
                NoaEvents.CHANGE_PORT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{deviceId}/port-control")
    public ResponseEntity<String> deletePortControls(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> portControlIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Port Control", null, "Network Device",
                deviceId);

        for (String portControlId : portControlIds) {
            resourceMetadata.setResourceId(portControlId);
            if (portControlId != null) {
                AAIResourceUri portControlUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).portControlEntry(portControlId));
                if (rClient.exists(portControlUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(portControlUri);
                    transactions.execute();
                    description = portControlId + " Port Control has been Deleted.";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "Port Control",
                            NoaEvents.CHANGE_PORT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = portControlId + " Port Control Doesn't Exists";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "Port Control",
                            NoaEvents.CHANGE_PORT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Device Id";
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "Port Control",
                        NoaEvents.CHANGE_PORT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Port Control have been Deleted.");
    }

    @GetMapping(value = "/{deviceId}/authorization-manager")
    public ResponseEntity<List<IpAuthorizationManager>> getAuthorizationManagers(
            @PathVariable("deviceId") String deviceId) throws JsonMappingException, JsonProcessingException {

        List<IpAuthorizationManager> ipAuthorizationManagers = new ArrayList<IpAuthorizationManager>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            if (device.getIpAuthorizationManagers() != null) {
                ipAuthorizationManagers = device.getIpAuthorizationManagers().getIpAuthorizationManager();
            }
            return ResponseEntity.status(HttpStatus.OK).body(ipAuthorizationManagers);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ipAuthorizationManagers);
    }

    @GetMapping(value = "/{deviceId}/authorization-manager/{managerId}")
    public ResponseEntity<IpAuthorizationManager> getAuthorizationManager(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId) {

        IpAuthorizationManager ipAuthorizationManager = new IpAuthorizationManager();

        AAIResourceUri authorizationManagerUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));

        if (rClient.exists(authorizationManagerUri)) {
            ipAuthorizationManager = rClient.get(IpAuthorizationManager.class, authorizationManagerUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(ipAuthorizationManager);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ipAuthorizationManager);
    }

    @PutMapping(value = "/{deviceId}/authorization-manager")
    public ResponseEntity<String> createAuthorizationManager(@PathVariable("deviceId") String deviceId,
            @RequestBody IpAuthorizationManager athrManagerBody) throws BulkProcessFailed {

        String managerId = athrManagerBody.getManagerId();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("IP Authorization Manager", null,
                "Network Device", deviceId);

        if (deviceId != null) {
            athrManagerBody.setManagerId(managerId + "@" + deviceId);
            resourceMetadata.setResourceId(athrManagerBody.getManagerId());
            AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device()
                    .networkDevice(deviceId).ipAuthorizationManager(athrManagerBody.getManagerId()));

            if (!rClient.exists(athrManagerUri)) {
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(athrManagerUri, athrManagerBody);
                transactions.execute();
                description = athrManagerBody.getManagerId() + "IP Authorization Manager has been Created.";

                JSONObject athrManagerObj = rollbackHandler.getJsonObject(athrManagerBody);

                List<Attributes> attributes = rollbackHandler.createAttributes(athrManagerObj, null, null);
                String resourceUri = athrManagerUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.IpAuthorizationManager",
                        athrManagerBody.getManagerId(), resourceUri, deviceId, attributes, null, 0, description, true);

                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = athrManagerBody.getManagerId() + " IP Authorization Manager Already Exists";
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                NoaEvents.CREATE_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping(value = "/{deviceId}/authorization-manager/{managerId}")
    public ResponseEntity<String> updateAuthorizationManager(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId, @RequestBody IpAuthorizationManager athrManagerBody)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("IP Authorization Manager", managerId,
                "Network Device", deviceId);

        if (deviceId != null) {
            AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));

            if (rClient.exists(athrManagerUri)) {
                AAITransactionalClient transactions;
                IpAuthorizationManager updManager = rClient.get(IpAuthorizationManager.class, athrManagerUri).get();
                transactions = rClient.beginTransaction().update(athrManagerUri, athrManagerBody);
                transactions.execute();
                description = managerId + "IP Authorization Manager has been Updated.";

                JSONObject athrManagerObj = rollbackHandler.getJsonObject(updManager);

                List<Attributes> attributes = rollbackHandler.createAttributes(athrManagerObj, null, null);
                String resourceUri = athrManagerUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.IpAuthorizationManager",
                        athrManagerBody.getManagerId(), resourceUri, deviceId, attributes, null, 0, description, true);

                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = managerId + " IP Authorization Manager Doesn't Exists";
            }
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                NoaEvents.MODIFY_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{deviceId}/authorization-manager")
    public ResponseEntity<String> deleteAuthorizationManagers(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> managerIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("IP Authorization Manager", null,
                "Network Device", deviceId);

        for (String managerId : managerIds) {
            resourceMetadata.setResourceId(managerId);
            if (managerId != null) {
                AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));
                if (rClient.exists(athrManagerUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(athrManagerUri);
                    transactions.execute();
                    description = managerId + " IP Authorization Manager has been Created";
                    eventStatus = true;
                    reqStatus = HttpStatus.CREATED;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                            NoaEvents.DELETE_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                } else {
                    description = managerId + " IP Authorization Manager Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                            NoaEvents.DELETE_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Manager Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                        NoaEvents.DELETE_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata,
                        auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Authorization Managers have been Deleted.");
    }

    @PostMapping(value = "/{deviceId}/authorization-manager/{managerId}/interface")
    public ResponseEntity<String> connectInterfacesToAthrManager(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId, @RequestBody List<String> interfaceIds)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface", null,
                "IP Authorization Manager", managerId);

        AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));

        if (managerId != null) {
            if (rClient.exists(athrManagerUri)) {
                for (String interfaceId : interfaceIds) {
                    resourceMetadata.setResourceId(interfaceId);

                    AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(
                            AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

                    if (rClient.exists(interfaceUri)) {
                        AAITransactionalClient transactions;
                        transactions = rClient.beginTransaction().connect(athrManagerUri, interfaceUri);
                        transactions.execute();
                        description = interfaceId + " Interface has been Added to " + managerId
                                + " IP Authorization Manager";
                        eventStatus = true;
                        reqStatus = HttpStatus.OK;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager",
                                NoaEvents.ADD_INTERFACE_TO_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                                resourceMetadata, auth);
                    } else {
                        description = interfaceId + " Interface Doesn't Exists.";
                        eventStatus = false;
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager",
                                NoaEvents.ADD_INTERFACE_TO_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                                resourceMetadata, auth);
                        return ResponseEntity.status(reqStatus).body(description);
                    }
                }
                return ResponseEntity.status(HttpStatus.OK).body("Connected Interfaces Successfully.");
            } else {
                description = managerId + " IP Authorization Manager Doesn't Exists.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Manager Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                NoaEvents.ADD_INTERFACE_TO_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata,
                auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping(value = "/{deviceId}/authorization-manager/{managerId}/vlan")
    public ResponseEntity<String> connectVlansToAthrManager(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId, @RequestBody List<String> vlanIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("VLAN", null, "IP Authorization Manager",
                managerId);

        if (managerId != null) {
            AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));
            if (rClient.exists(athrManagerUri)) {
                for (String vlanId : vlanIds) {
                    resourceMetadata.setResourceId(vlanId);
                    AAIResourceUri vlanUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

                    if (rClient.exists(vlanUri)) {
                        AAITransactionalClient transactions;
                        transactions = rClient.beginTransaction().connect(athrManagerUri, vlanUri);
                        transactions.execute();
                        description = vlanId + " VLAN has been Added to " + managerId + " IP Authorization Manager";
                        eventStatus = true;
                        reqStatus = HttpStatus.OK;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager", NoaEvents.ADD_VLAN_TO_IP_AUTHORIZATION_MANAGER.getEvent(),
                                eventStatus, null, resourceMetadata, auth);
                    } else {
                        description = vlanId + " VLAN Doesn't Exists.";
                        eventStatus = false;
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager", NoaEvents.ADD_VLAN_TO_IP_AUTHORIZATION_MANAGER.getEvent(),
                                eventStatus, null, resourceMetadata, auth);
                        return ResponseEntity.status(reqStatus).body(description);
                    }
                }
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("VLANs Removed from IP Authorization Manager");
            } else {
                description = managerId + " IP Authorization Manager Doesn't Exists.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                        NoaEvents.ADD_VLAN_TO_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata,
                        auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        } else {
            description = "Received Null Manager Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                NoaEvents.ADD_VLAN_TO_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{deviceId}/authorization-manager/{managerId}/interface")
    public ResponseEntity<String> disconnectInterfacesFromAthrManager(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId, @RequestBody List<String> interfaceIds)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Interface", null,
                "IP Authorization Manager", managerId);

        AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));

        if (managerId != null) {
            if (rClient.exists(athrManagerUri)) {
                for (String interfaceId : interfaceIds) {
                    resourceMetadata.setResourceId(interfaceId);

                    AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(
                            AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

                    if (rClient.exists(interfaceUri)) {
                        AAITransactionalClient transactions;
                        transactions = rClient.beginTransaction().connect(athrManagerUri, interfaceUri);
                        transactions.execute();
                        description = interfaceId + " Interface has been Removed from " + managerId
                                + " IP Authorization Manager";

                        eventStatus = true;
                        reqStatus = HttpStatus.OK;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager",
                                NoaEvents.REMOVE_INTERFACE_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                                resourceMetadata, auth);
                    } else {
                        description = interfaceId + " Interface Doesn't Exists.";
                        eventStatus = false;
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager",
                                NoaEvents.REMOVE_INTERFACE_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                                resourceMetadata, auth);
                        return ResponseEntity.status(reqStatus).body(description);
                    }
                }
                return ResponseEntity.status(HttpStatus.OK).body("Removed Interfaces Successfully.");
            } else {
                description = managerId + " IP Authorization Manager Doesn't Exists.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                        NoaEvents.REMOVE_INTERFACE_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                        resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        } else {
            description = "Received Null Manager Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                NoaEvents.REMOVE_INTERFACE_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{deviceId}/authorization-manager/{managerId}/vlan")
    public ResponseEntity<String> disconnectVlansFromAthrManager(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId, @RequestBody List<String> vlanIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("VLAN", null, "IP Authorization Manager",
                managerId);

        if (managerId != null) {
            AAIResourceUri athrManagerUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ipAuthorizationManager(managerId));
            if (rClient.exists(athrManagerUri)) {
                for (String vlanId : vlanIds) {
                    resourceMetadata.setResourceId(vlanId);
                    AAIResourceUri vlanUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).vlan(vlanId));

                    if (rClient.exists(vlanUri)) {
                        AAITransactionalClient transactions;
                        transactions = rClient.beginTransaction().disconnect(athrManagerUri, vlanUri);
                        transactions.execute();
                        description = vlanId + " VLAN has been Removed from " + managerId + " IP Authorization Manager";

                        eventStatus = true;
                        reqStatus = HttpStatus.OK;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager",
                                NoaEvents.REMOVE_VLAN_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                                resourceMetadata, auth);
                    } else {
                        description = vlanId + " VLAN Doesn't Exists.";
                        eventStatus = false;
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Device Configuration",
                                "IP Authorization Manager",
                                NoaEvents.REMOVE_VLAN_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                                resourceMetadata, auth);
                        return ResponseEntity.status(reqStatus).body(description);
                    }
                }
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("VLANs Removed from IP Authorization Manager");
            } else {
                description = managerId + " IP Authorization Manager Doesn't Exists.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                        NoaEvents.REMOVE_VLAN_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null,
                        resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        } else {
            description = "Received Null Manager Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "IP Authorization Manager",
                NoaEvents.REMOVE_VLAN_FROM_IP_AUTHORIZATION_MANAGER.getEvent(), eventStatus, null, resourceMetadata,
                auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/{deviceId}/authorization-manager/{managerId}/interface")
    public ResponseEntity<List<IetfInterface>> getAccessibleInterfaces(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId) throws JsonMappingException, JsonProcessingException {

        List<IetfInterface> interfaces = new ArrayList<IetfInterface>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.IP_AUTHORIZATION_MANAGER, __.key("manager-id", managerId)))
                .to(__.node(Types.IETF_INTERFACE)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, IetfInterface>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, IetfInterface>>>() {
                });

        for (Map<String, IetfInterface> m : resultsFromJson.getResult()) {
            interfaces.add(m.get("ietf-interface"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(interfaces);
    }

    @GetMapping(value = "/{deviceId}/authorization-manager/{managerId}/vlan")
    public ResponseEntity<List<Vlan>> getAccessibleVlans(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId) throws JsonMappingException, JsonProcessingException {

        List<Vlan> vlans = new ArrayList<Vlan>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.IP_AUTHORIZATION_MANAGER, __.key("manager-id", managerId))).to(__.node(Types.VLAN))
                .output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Vlan>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Vlan>>>() {
                });

        for (Map<String, Vlan> m : resultsFromJson.getResult()) {
            vlans.add(m.get("vlan"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(vlans);
    }

    @GetMapping(value = "/{deviceId}/authorization-manager/{managerId}/available-interface")
    public ResponseEntity<List<IetfInterface>> getAvailableInterfacesForAthr(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId) throws JsonMappingException, JsonProcessingException {

        NetworkDevice device = new NetworkDevice();
        List<IetfInterface> allInterfaces = new ArrayList<IetfInterface>();

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);
        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            if (device.getIetfInterfaces() != null) {
                allInterfaces.addAll(device.getIetfInterfaces().getIetfInterface());
            }
        }

        List<String> interfaceIds = new ArrayList<String>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.IP_AUTHORIZATION_MANAGER, __.key("manager-id", managerId)))
                .to(__.node(Types.IETF_INTERFACE)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, IetfInterface>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, IetfInterface>>>() {
                });

        for (Map<String, IetfInterface> m : resultsFromJson.getResult()) {
            interfaceIds.add(m.get("ietf-interface").getInterfaceId());
        }

        if (interfaceIds.size() > 0) {
            List<IetfInterface> diffInterfaces = allInterfaces.stream()
                    .filter(ietfInterface -> interfaceIds.contains(ietfInterface.getInterfaceId()))
                    .collect(Collectors.toList());

            allInterfaces.removeAll(diffInterfaces);
        }
        return ResponseEntity.status(HttpStatus.OK).body(allInterfaces);
    }

    @GetMapping(value = "/{deviceId}/authorization-manager/{managerId}/available-vlan")
    public ResponseEntity<List<Vlan>> getAvailableVlanForAthr(@PathVariable("deviceId") String deviceId,
            @PathVariable("managerId") String managerId) throws JsonMappingException, JsonProcessingException {

        List<String> vlanIds = new ArrayList<String>();

        List<Vlan> allVlans = new ArrayList<Vlan>();

        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.BRIDGE_INSTANCE, __.key("bridge-id", "1"))).to(__.node(Types.VLAN)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Vlan>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Vlan>>>() {
                });

        for (Map<String, Vlan> m : resultsFromJson.getResult()) {
            allVlans.add(m.get("vlan"));
        }

        DSLQueryBuilder<Start, Node> queryBuilder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.IP_AUTHORIZATION_MANAGER, __.key("manager-id", managerId))).to(__.node(Types.VLAN))
                .output();
        String queryResults = dslClient.query(Format.RESOURCE, new DSLQuery(queryBuilder.build()));

        Results<Map<String, Vlan>> vlanResults = mapper.readValue(queryResults,
                new TypeReference<Results<Map<String, Vlan>>>() {
                });

        for (Map<String, Vlan> m : vlanResults.getResult()) {
            vlanIds.add(m.get("vlan").getVlanId());
        }

        if (vlanIds.size() > 0) {
            List<Vlan> diffVlans = allVlans.stream().filter(vlan -> vlanIds.contains(vlan.getVlanId()))
                    .collect(Collectors.toList());

            allVlans.removeAll(diffVlans);
        }
        return ResponseEntity.status(HttpStatus.OK).body(allVlans);
    }

}
