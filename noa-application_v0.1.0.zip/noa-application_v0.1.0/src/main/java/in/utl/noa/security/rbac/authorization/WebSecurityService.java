package in.utl.noa.security.rbac.authorization;

import java.util.Collection;
import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.springframework.stereotype.Service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import org.springframework.jdbc.core.JdbcTemplate;

import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.account.user.model.User;
import in.utl.noa.global.event.NoaEvents;

@Service("WebSecurityService")
public class WebSecurityService {

    private static Logger logger = Logger.getLogger(WebSecurityService.class);

    String qryUri = "SELECT FEATURE_ID FROM URI_FEATURE WHERE URI_PATH = ?";
    String qryFeature = "SELECT FEATURE_NAME FROM FEATURE_INFO WHERE FEATURE_ID = ?";

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @Autowired
    private JdbcTemplate jdbcTemplate;

    AuditLogger auditLogger = new AuditLogger();

    public boolean check(Authentication auth, HttpServletRequest req) {
        /* UserAccount user = (UserAccount)auth.getPrincipal(); */
        User user = null;
        String userName = null;
        if (auth.getPrincipal() instanceof User) {
            user = (User) auth.getPrincipal();
            userName = user.getUserName();
        } else {
            userName = auth.getName();
        }

        String description = null;
        Boolean eventStatus = false;
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", userName, null, null);

        if (auth.isAuthenticated()) {
            Collection<? extends GrantedAuthority> access = auth.getAuthorities();
            String reqUri = req.getRequestURI();
            String[] pathSegs = reqUri.split("/");
            String privilege = "";
            String uri = "";

            uri = pathSegs.length > 2 ? pathSegs[2] : pathSegs[1];

            if (uri.equals("api"))
                return true;

            if (uri != "") {
                int featureId = jdbcTemplate.queryForObject(qryUri, new Object[] { uri }, Integer.class);
                privilege = jdbcTemplate.queryForObject(qryFeature, new Object[] { featureId }, String.class);
            }

            if (privilege != "") {
                GrantedAuthority gam = new SimpleGrantedAuthority(privilege);
                GrantedAuthority gav = new SimpleGrantedAuthority(privilege + "ViewOnly");
                boolean voaccess = access.contains(gav);

                if (access.contains(gam) || voaccess) {
                    if (voaccess && (req.getMethod() != "GET")) {
                        description = userName + " Made Forbidden Request.";
                        auditLogger.addAuditLog(rClient, description, "Security", "Access Authorization",
                                NoaEvents.FORBIDDEN_ACCESS.getEvent(), eventStatus, null, resourceMetadata, auth);
                        return false;
                    }
                    return true;
                }
            }
            return false;
        } else {
            description = userName + " Made Un-Authorized Request.";
            auditLogger.addAuditLog(rClient, description, "Security", "Access Authorization",
                    NoaEvents.UNAUTHORIZED_ACCESS.getEvent(), eventStatus, null, resourceMetadata, auth);
            return false;
        }
    }
}