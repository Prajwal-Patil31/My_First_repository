package in.utl.noa.security.rbac.authentication.controller;

import java.text.SimpleDateFormat;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.Callable;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.AccessMetadata;
import org.onap.aai.domain.yang.UserAccount;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.account.user.model.User;
import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/login", produces = "application/json")
public class BasicAuthLoginController {

    private static Logger logger = Logger.getLogger(BasicAuthLoginController.class);

    AuditLogger auditLogger = new AuditLogger();
    JSONParser parser = new JSONParser();
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public BasicAuthLoginController() {
        super();
    }

    @GetMapping()
    public ResponseEntity<String> login(final Authentication auth) throws ParseException, java.text.ParseException, JsonMappingException, JsonProcessingException {
        
        User user = (User) auth.getPrincipal();
        String userName = user.getUserName();
        logger.info("Basic Auth Login Controller");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                
        DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT, __.key("user-name", userName));
        
        int passExpDays = 0;
        long differenceInDays = 0;

        /* if (userName != null) {
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.PASSWORD_POLICY).output());
            String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));
            
            JSONObject resultsJson = (JSONObject) parser.parse(results);
            List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

            

            if (resultsArray.size() > 0) {
                JSONObject securityPolicyObject = (JSONObject) resultsArray.get(0).get("properties");
                Object newobj = securityPolicyObject.get("pass-exp-days");
                passExpDays = Integer.parseInt(newobj.toString());
            }

            String changedDate = userac.getLatestPasswordTimeStamp();
            Date passwordChangedDate = dateFormat.parse(changedDate);
            Date presentDate = Calendar.getInstance().getTime();

            long differenceInTime = presentDate.getTime() - passwordChangedDate.getTime();
            
            differenceInDays = (differenceInTime/ (1000 * 60 * 60 * 24))% 365;
        } */

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;

        AccessMetadata accessMetadata = auditLogger.createAccessMetadata("10.0.0.115");
        
        if (/* differenceInDays >= passExpDays */ false) {
            return new ResponseEntity<String>("PASSWORD EXPIRED", HttpStatus.BAD_REQUEST);
        } else {
            
           /*  String fname = userac.getFirstName();
            String lname = userac.getLastName();
 */
            JSONObject resp = new JSONObject();
            /* resp.put("accountId", userac.getAccountId());
            resp.put("FirstName", fname);
            resp.put("LastName", lname); */
            resp.put("UserName", userName); 
            return new ResponseEntity<String>(resp.toString(), HttpStatus.OK);
        }
    }
}
