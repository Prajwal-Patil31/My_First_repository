package in.utl.noa.element.config.route.ospf;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.OspfInstance;
import org.onap.aai.domain.yang.OspfNeighbour;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.RrdRouteConfig;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.element.service.DeviceOperationService;
//import in.utl.noa.service.DeviceRepository;
import in.utl.noa.element.service.EdgeRouterService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.RollbackUnit;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/router/ospf")
public class OspfInstanceManagement {
    private static Logger logger = Logger.getLogger(OspfInstanceManagement.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    /* @Autowired
    DeviceRepository deviceRepo; */

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;
    
    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getOspfInstanceFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();
        
        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "ospf-instance");

        Map<String, Object> columns = new HashMap<>();
        columns.put("ospfInstanceName", "Instance Name");
        columns.put("globalTraceLevel", "Global Trace Level");
        columns.put("spfComputeInterval", "SPF Compute Interval");
        columns.put("staggeringStatus", "Staggering Status");
        columns.put("internalState", "Internal State");
        columns.put("tosSupport", "TOS Support");
        columns.put("instanceStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getOspfInstanceList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject ospfInstances = filterService.queryByFilter(requestBody,"ospf-instance");
        return ResponseEntity.status(HttpStatus.OK).body(ospfInstances);
    }

    @GetMapping()
    public ResponseEntity<List<OspfInstance>> getOspfInstances(@PathVariable("deviceId") String deviceId) {

        List<OspfInstance> ospfInstances = new ArrayList<OspfInstance>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {

            device = rClient.get(NetworkDevice.class, deviceUri).get();

            if (device.getOspfInstances() != null) {
                ospfInstances = device.getOspfInstances().getOspfInstance();
            }
            return ResponseEntity.status(HttpStatus.OK).body(ospfInstances);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ospfInstances);
    }

    @GetMapping(value = "/{instanceId}")
    public ResponseEntity<OspfInstance> getOspfInstance(@PathVariable("deviceId") String deviceId,
        @PathVariable("instanceId") String instanceId) {

        OspfInstance ospfInstance = new OspfInstance();

        AAIResourceUri ospfInstanceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfInstance(instanceId));

        if (rClient.exists(ospfInstanceUri)) {

            ospfInstance = rClient.get(OspfInstance.class, ospfInstanceUri).get();

            return ResponseEntity.status(HttpStatus.OK).body(ospfInstance);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ospfInstance);
    }

    @PutMapping()
    public ResponseEntity<OspfInstance> createOspfInstance(@PathVariable("deviceId") String deviceId,
            @RequestBody OspfInstance ospfInstanceBody) throws BulkProcessFailed {

        String ospfId = UUID.randomUUID().toString();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("OSPF Instance", ospfId,
                "Network Device", deviceId);

        AAIResourceUri ospfUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfInstance(ospfId));

        ospfInstanceBody.setOspfId(ospfId);
        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(ospfUri, ospfInstanceBody);
        transactions.execute();
        description = "OSPF Instance has been Created in " + deviceId;

        JSONObject ospfInstanceObj = rollbackHandler.getJsonObject(ospfInstanceBody);

        List<Attributes> attributes = rollbackHandler.createAttributes(ospfInstanceObj, null, null);
        String resourceUri = ospfUri.getObjectType().toString();
        rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.OspfInstance", ospfId, resourceUri,
                deviceId, attributes, null, 0, description, true);

        eventStatus = true;
        reqStatus = HttpStatus.OK;
        
        OspfNeighbour neighbour1 = constructNeighbour("HYD-PE-068", "192.168.1.101", 0,"Unplanned Restart","Unknown",true);
        OspfNeighbour neighbour2 = constructNeighbour("BOM-CE-258", "192.168.1.102", 0,"Planned Restart","Software Restart",true);
        OspfNeighbour neighbour3 = constructNeighbour("DEL-PE-659", "192.168.1.103", 0,"Planned Restart","Software Restart",true);

        List<OspfNeighbour> neighbours = new ArrayList<OspfNeighbour>();
        neighbours.add(neighbour1);
        neighbours.add(neighbour2);
        neighbours.add(neighbour3);

        AAITransactionalClient neighbourTransactions = null;

        for (OspfNeighbour neighbour : neighbours) {
            AAIResourceUri neighbourUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfNeighbour(neighbour.getNeighbourId()));

            if (!rClient.exists(neighbourUri)) {
                neighbourTransactions = rClient.beginTransaction().create(neighbourUri, neighbour).connect(neighbourUri,ospfUri);
                neighbourTransactions.execute();
            }
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "OspfInstance",
                NoaEvents.CREATE_OSPF_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(ospfInstanceBody);
    }

    private OspfNeighbour constructNeighbour(String neighbourName, String ipAddress,
            Integer addressLessIndex,String grStatus,String grReason, Boolean state) {
        OspfNeighbour neighbour = new OspfNeighbour();
        String neighbourId = UUID.randomUUID().toString();
        neighbour.setNeighbourId(neighbourId);
        neighbour.setNeighbourName(neighbourName);
        neighbour.setIpAddress(ipAddress);
        neighbour.setAddressLessIndex(addressLessIndex);
        neighbour.setBfdState(true);
        neighbour.setGracefulRestartStatus(grStatus);
        neighbour.setGracefulRestartReason(grStatus);
        neighbour.setNeighbourState(state);
        return neighbour;
    }

    @PostMapping(value = "/{instanceId}")
    public ResponseEntity<String> updateOspfConfiguration(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId,
            @RequestBody OspfInstance updatedOspfInstance) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Ospf Instance", instanceId,
                "Network Device", deviceId);

        AAIResourceUri ospfUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfInstance(instanceId));

        if (rClient.exists(ospfUri)) {
            AAITransactionalClient transactions;
            OspfInstance updOspfConfig = rClient.get(OspfInstance.class, ospfUri).get();
            transactions = rClient.beginTransaction().update(ospfUri, updatedOspfInstance);
            transactions.execute();
            description = "OSPF Instance has been Updated in " + deviceId + " Device";

            JSONObject ospfInstanceObj = rollbackHandler.getJsonObject(updOspfConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(ospfInstanceObj, null, null);
            String resourceUri = ospfUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.OspfInstance", instanceId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = instanceId + " OSPF Instance Doesn't Exists";
            reqStatus = HttpStatus.NOT_FOUND;
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "OSPF Instance",
                NoaEvents.UPDATE_OSPF_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteOspfInstances(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> ospfInstanceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("OSPF Instance", null,
                "Network Device", deviceId);

        for (String ospfInstanceId : ospfInstanceIds) {
            resourceMetadata.setResourceId(ospfInstanceId);
            if (ospfInstanceId != null) {
                AAIResourceUri bgpUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ospfInstance(ospfInstanceId));
                if (rClient.exists(bgpUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(bgpUri);
                    transactions.execute();
                    description = ospfInstanceId + " OSPF Instance has been Deleted";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "OspfInstance",
                            NoaEvents.DELETE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = ospfInstanceId + " OSPF Instance Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "OspfInstance",
                            NoaEvents.DELETE_BGP_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Instance Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "OspfInstance",
                        NoaEvents.DELETE_OSPF_INSTANCE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/{instanceId}/neighbour")
    public ResponseEntity<List<OspfNeighbour>> getOspfNeighbours(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId) throws JsonMappingException, JsonProcessingException, ParseException {

        List<OspfNeighbour> ospfNeighbours = new ArrayList<OspfNeighbour>();
        
        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                                        .to(__.node(Types.OSPF_INSTANCE, __.key("ospf-id", instanceId)))
                                        .to(__.node(Types.OSPF_NEIGHBOUR)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject neighbourObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            OspfNeighbour neighbour = mapper.readValue(neighbourObj.toString(),OspfNeighbour.class);
            ospfNeighbours.add(neighbour);
        }
        return ResponseEntity.status(HttpStatus.OK).body(ospfNeighbours);
    }

    @GetMapping(value = "/{instanceId}/neighbour/{neighbourId}")
    public ResponseEntity<OspfNeighbour> getOspfNeighbour(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId, @PathVariable("neighbourId") String neighbourId) 
            throws JsonMappingException, JsonProcessingException, ParseException {

        OspfNeighbour ospfNeighbour = new OspfNeighbour();
        
        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                                        .to(__.node(Types.OSPF_INSTANCE, __.key("ospf-id", instanceId)))
                                        .to(__.node(Types.OSPF_NEIGHBOUR, __.key("neighbour-id", neighbourId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject neighbourObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            ospfNeighbour = mapper.readValue(neighbourObj.toString(),OspfNeighbour.class);
        }
        return ResponseEntity.status(HttpStatus.OK).body(ospfNeighbour);
    }

    @GetMapping(value = "/{instanceId}/redist")
    public ResponseEntity<List<RrdRouteConfig>> getOspfRrdConfigurations(@PathVariable("deviceId") String deviceId,
            @PathVariable("instanceId") String instanceId) throws JsonMappingException, JsonProcessingException, ParseException {

        List<RrdRouteConfig> rrdConfigurations = new ArrayList<RrdRouteConfig>();
        
        DSLStartNode startNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                                        .to(__.node(Types.OSPF_INSTANCE, __.key("ospf-id", instanceId)))
                                        .to(__.node(Types.RRD_ROUTE_CONFIG)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject neighbourObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            RrdRouteConfig routeConfig = mapper.readValue(neighbourObj.toString(),RrdRouteConfig.class);
            rrdConfigurations.add(routeConfig);
        }
        return ResponseEntity.status(HttpStatus.OK).body(rrdConfigurations);
    }
}
