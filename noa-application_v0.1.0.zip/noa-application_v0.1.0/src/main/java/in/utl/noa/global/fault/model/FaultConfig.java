package in.utl.noa.global.fault.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.SequenceGenerator;

@Entity
@Table(name = "FAULT_CONFIG")
public class FaultConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "SEQ")
    @SequenceGenerator(name = "SEQ", sequenceName = "fault_config_fault_id_seq", initialValue = 1, allocationSize = 1)
    @Column(name = "FAULT_ID")
    private int faultId;

    @Column(name = "FAULT_CODE")
    private int faultCode;

    @Column(name = "SEVERITY")
    private int severity;

    @Column(name = "RELATED_FAULT_CODE")
    private int relatedFaultCode;

    @Column(name = "TRAP_CATEGORY")
    private int trapCategory;

    public int getFaultId() {
        return faultId;
    }

    public void setAlamId(int faultId) {
        this.faultId = faultId;
    }

    public int getFaultCode() {
        return faultCode;
    }

    public void setFaultCode(int faultCode) {
        this.faultCode = faultCode;
    }

    public int getRelatedFaultCode() {
        return relatedFaultCode;
    }

    public void setRelatedFaultCode(int relatedFaultCode) {
        this.relatedFaultCode = relatedFaultCode;
    }

    public int getSeverity() {
        return severity;
    }

    public void setSeverity(int severity) {
        this.severity = severity;
    }

    public int getTrapCategory() {
        return trapCategory;
    }

    public void setTrapCategory(int trapCategory) {
        this.trapCategory = trapCategory;
    }
}