package in.utl.noa.account.user.profile.dto;

import java.util.List;

import org.onap.aai.domain.yang.AccessRole;
import org.onap.aai.domain.yang.PasswordPolicy;
import org.onap.aai.domain.yang.UserGroup;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class UserProfile {

	private String accountId;
	private String userName;
	private String password;
	private String firstName;
	private String middleInitial;
	private String lastName;
	private String mobileNumber;
	private String emailId;
	private Boolean accountStatus;
	private String userType;
	private String roleName;
	private String policyName;
	private AccessRole role;
	private PasswordPolicy policy;
	private String timeZone;
	private java.util.Date lastLoginTime;
	private List<UserGroup> groups;
	private String latestPasswordTimeStamp;

	public static final PasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();

	public AccessRole getRole() {
		return role;
	}

	public void setRole(final AccessRole role) {
		this.role = role;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public List<UserGroup> getGroups() {
		return groups;
	}

	public void setGroups(List<UserGroup> groups) {
		this.groups = groups;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleInitial() {
		return middleInitial;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public java.util.Date getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(java.util.Date lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public PasswordPolicy getPolicy() {
		return policy;
	}

	public void setPolicy(PasswordPolicy policy) {
		this.policy = policy;
	}

	public String getLatestPasswordTimeStamp() {
		return latestPasswordTimeStamp;
	}

	public void setLatestPasswordTimeStamp(String latestPasswordTimeStamp) {
		this.latestPasswordTimeStamp = latestPasswordTimeStamp;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public Boolean getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(Boolean accountStatus) {
		this.accountStatus = accountStatus;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
}