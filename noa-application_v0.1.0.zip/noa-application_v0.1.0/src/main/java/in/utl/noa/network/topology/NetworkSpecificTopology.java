package in.utl.noa.network.topology;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.NNode;
import org.onap.aai.domain.yang.Route;

import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.global.topology.service.TopologyService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

@RestController
@RequestMapping(value = "/api/network/{networkId}/topology")
public class NetworkSpecificTopology {
    private static Logger logger = Logger.getLogger(NetworkSpecificTopology.class);

    JSONParser parser = new JSONParser();

    @Autowired
    TopologyService topologyService;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<Map<String, List<JSONObject>>> getNetworkSpecificTopology(
            @PathVariable("networkId") String networkId) {

        IetfNetwork network = new IetfNetwork();
        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

        Map<String, List<JSONObject>> topologyObject = new HashMap<String, List<JSONObject>>();
        network = rClient.get(IetfNetwork.class, networkUri).get();
        String networkType = network.getNetworkType();

        List<NNode> networkNodes = new ArrayList<NNode>();
        List<Link> networkLinks = new ArrayList<Link>();
        List<Lsp> networkLsps = new ArrayList<Lsp>();
        List<Route> networkRoutes = new ArrayList<Route>();

        if (network.getNNodes() != null) {
            networkNodes = network.getNNodes().getNNode();
        }

        if (network.getLinks() != null) {
            networkLinks = network.getLinks().getLink();
        }

        if (network.getLsps() != null) {
            networkLsps = network.getLsps().getLsp();
        }

        if (network.getRoutes() != null) {
            networkRoutes = network.getRoutes().getRoute();
        }

        List<JSONObject> nodes = new ArrayList<JSONObject>();
        List<JSONObject> links = new ArrayList<JSONObject>();

        for (NNode networkNode : networkNodes) {
            JSONObject node = new JSONObject();
            node.put("id", networkNode.getNodeId());
            node.put("name", networkNode.getNodeName());
            if (networkNode.isNodeStatus() == null || networkNode.isNodeStatus() == true) {
                node.put("color", "#0how00");
            } else {
                node.put("color", "#FF0000");
            }
            node.put("role", "node");
            node.put("iconType", "router");
            nodes.add(node);
        }

        topologyObject.put("nodes", nodes);

        switch (networkType) {
            case "L1 Network":
                for (Link networkLink : networkLinks) {
                    JSONObject link = new JSONObject();
                    link.put("id", networkLink.getLinkId());
                    link.put("label", networkLink.getLinkName());
                    link.put("source", networkLink.getSourceNode());
                    link.put("target", networkLink.getDestinationNode());
                    links.add(link);
                }
                break;
            case "L2 Network":
                for (Link networkLink : networkLinks) {
                    JSONObject link = new JSONObject();
                    link.put("id", networkLink.getLinkId());
                    link.put("label", networkLink.getLinkName());
                    link.put("source", networkLink.getSourceNode());
                    link.put("target", networkLink.getDestinationNode());
                    links.add(link);
                }
                break;
            case "L2.5 Network":
                for (Lsp networkLsp : networkLsps) {
                    JSONObject lsp = new JSONObject();
                    lsp.put("id", networkLsp.getLspId());
                    lsp.put("label", networkLsp.getLspName());
                    lsp.put("source", networkLsp.getSourceElement());
                    lsp.put("target", networkLsp.getDestinationElement());
                    links.add(lsp);
                }
                break;
            case "L3 Network":
                for (Route networkRoute : networkRoutes) {
                    JSONObject route = new JSONObject();
                    route.put("id", networkRoute.getRouteId());
                    route.put("label", networkRoute.getRouteName());
                    route.put("source", networkRoute.getSourceElement());
                    route.put("target", networkRoute.getDestinationElement());
                    links.add(route);
                }
                break;
            default:
                break;
        }
        topologyObject.put("links", links);
        return ResponseEntity.status(HttpStatus.OK).body(topologyObject);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getNetworkTopologyFilters(@PathVariable("networkId") String networkId) {
        ResponseDataDTO responseData = new ResponseDataDTO();

        String filterModules[] = new String[] { "ietf-network", "n-node" };

        Map<String, JSONObject> filters = new HashMap<>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

        if (rClient.exists(networkUri)) {
            IetfNetwork network = rClient.get(IetfNetwork.class, networkUri).get();
            String networkType = network.getNetworkType();
            switch (networkType) {
                case "L1 Network":
                    filters = filterService.getFilterCriteria("l1-topology", filterModules);
                    break;
                case "L2 Network":
                    filters = filterService.getFilterCriteria("l2-topology", filterModules);
                    break;
                case "L3 Network":
                    filters = filterService.getFilterCriteria("l3-topology", filterModules);
                    break;
                default:
                    break;
            }
            responseData.setFilters(filters);
        }
        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<Map<String, List<JSONObject>>> getTopology(@PathVariable("networkId") String networkId,
            @RequestBody RequestBodyDTO requestBody) {

        List<String> filterValues = new ArrayList<>();
        filterValues.add(networkId);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

        Map<String, List<JSONObject>> topologyObject = new HashMap<>();

        String vertexName = null;
        if (rClient.exists(networkUri)) {
            IetfNetwork network = rClient.get(IetfNetwork.class, networkUri).get();
            String networkType = network.getNetworkType();
            switch (networkType) {
                case "L1 Network":
                    vertexName = "l1-topology:ietf-network";
                    break;
                case "L2 Network":
                    vertexName = "l2-topology:ietf-network";
                    break;
                case "L3 Network":
                    vertexName = "l3-topology:ietf-network";
                    break;

                default:
                    break;
            }

            requestBody.getFilters().get(vertexName).put("network-id", filterValues);
            requestBody.getFilters().get(vertexName).put("network-type",
                    new ArrayList<String>(Arrays.asList(networkType)));

            List<Object> networkResults = filterService.performQueryClientFilter(requestBody);
            topologyObject = topologyService.convertResultsToTopologyData(networkResults, requestBody, vertexName);
        }

        return ResponseEntity.status(HttpStatus.OK).body(topologyObject);
    }
}