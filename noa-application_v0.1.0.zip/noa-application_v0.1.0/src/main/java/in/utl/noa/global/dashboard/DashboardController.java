package in.utl.noa.global.dashboard;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.VpnService;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.Site;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.aai.entities.AAIResultWrapper;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.Format;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.global.fault.model.Fault;
import in.utl.noa.global.fault.repository.FaultRepository;
import in.utl.noa.util.RestClientManager;

@RestController
@RequestMapping(value = "/api/global/dashboard")
public class DashboardController {
    private static Logger logger = Logger.getLogger(DashboardController.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @Autowired
    FaultRepository faultRepo;

    @Autowired
    RestClientManager restClientManager;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping("/network-overview")
    public ResponseEntity<List<JSONArray>> getNetworkOverview()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> networkOverviewObj = (List<JSONArray>) obj.get("network-overview");

        return ResponseEntity.ok(networkOverviewObj);
    }

    @GetMapping("/inventory-overview")
    public ResponseEntity<JSONObject> getInventoryOverview() throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject inventoryOverviewObj = (JSONObject) obj.get("inventory-overview");

        return ResponseEntity.ok(inventoryOverviewObj);
    }

    @GetMapping("/network-status")
    public ResponseEntity<JSONObject> getNetworkStatus() throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject networkStatusObj = (JSONObject) obj.get("network-status");

        return ResponseEntity.ok(networkStatusObj);
    }

    @GetMapping("/alarm-summary")
    public ResponseEntity<JSONObject> getAlarmEventsSummary()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject alarmSummaryObj = (JSONObject) obj.get("alarm-event-summary");

        return ResponseEntity.ok(alarmSummaryObj);
    }

    @GetMapping("/alarm-distribution")
    public ResponseEntity<JSONObject> getAlarmEventsDistribution()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject alarmDistributionObj = (JSONObject) obj.get("alarm-event-distribution");

        return ResponseEntity.ok(alarmDistributionObj);
    }

    @GetMapping("/top-performance")
    public ResponseEntity<JSONObject> getTopPerformances() throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject topPerformancesObj = (JSONObject) obj.get("top-performance");

        return ResponseEntity.ok(topPerformancesObj);
    }

    private List<JSONArray> getOverviewStats() throws ParseException, JsonMappingException, JsonProcessingException {
        JSONParser parser = new JSONParser();
        // Sites
        List<Site> siteList = new ArrayList<Site>();
        AAISimplePluralUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().sites());
        siteUri.format(Format.RAW);

        AAIResultWrapper siteWrapper = rClient.get(siteUri);
        String siteResults = siteWrapper.getJson();

        JSONObject siteResultsJson = (JSONObject) parser.parse(siteResults);
        List<JSONObject> siteResultsArray = new ArrayList<JSONObject>();
        if (siteResultsJson != null) {
            siteResultsArray = (List<JSONObject>) siteResultsJson.get("results");
        }

        for (int i = 0; i < siteResultsArray.size(); i++) {
            JSONObject policyObj = (JSONObject) siteResultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            siteList.add(mapper.readValue(policyObj.toString(), Site.class));
        }
        JSONObject siteObj = new JSONObject();
        siteObj.put("name", "sites");
        siteObj.put("value", 16);
        siteObj.put("maxValue", 100);
        Integer value = 0;

        for (Site site : siteList) {

        }
        JSONArray siteArray = new JSONArray();
        siteArray.add(siteObj);

        // Networks
        List<IetfNetwork> networksList = new ArrayList<IetfNetwork>();
        AAISimplePluralUri networksUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.network().ietfNetworks());
        networksUri.format(Format.RAW);

        AAIResultWrapper networkWrapper = rClient.get(networksUri);
        String networkResults = networkWrapper.getJson();

        JSONObject networkResultsJson = (JSONObject) parser.parse(networkResults);
        List<JSONObject> networkResultsArray = (List<JSONObject>) networkResultsJson.get("results");

        for (int i = 0; i < networkResultsArray.size(); i++) {
            JSONObject policyObj = (JSONObject) networkResultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            networksList.add(mapper.readValue(policyObj.toString(), IetfNetwork.class));
        }

        JSONObject networkObj = new JSONObject();
        networkObj.put("name", "networks");
        networkObj.put("maxValue", networksList.size());

        Integer activeNetworks = 0;
        for (IetfNetwork network : networksList) {
            if (network.isNetworkStatus()) {
                activeNetworks = activeNetworks + 1;
            }
        }
        networkObj.put("value", activeNetworks);

        JSONArray networkArray = new JSONArray();
        networkArray.add(networkObj);

        // Services
        List<VpnService> servicesList = new ArrayList<VpnService>();
        AAISimplePluralUri servicesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.service().vpnServices());
        servicesUri.format(Format.RAW);

        AAIResultWrapper servicesWrapper = rClient.get(servicesUri);
        String serviceResults = servicesWrapper.getJson();

        JSONObject serviceResultsJson = (JSONObject) parser.parse(serviceResults);
        List<JSONObject> serviceResultsArray = (List<JSONObject>) serviceResultsJson.get("results");

        for (int i = 0; i < serviceResultsArray.size(); i++) {
            JSONObject policyObj = (JSONObject) serviceResultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            servicesList.add(mapper.readValue(policyObj.toString(), VpnService.class));
        }

        JSONObject serviceObj = new JSONObject();
        serviceObj.put("name", "services");
        serviceObj.put("maxValue", servicesList.size());

        Integer activeServices = 0;
        for (VpnService service : servicesList) {
            if (service.isServiceStatus()) {
                activeServices = activeServices + 1;
            }
        }
        serviceObj.put("value", activeServices);

        JSONArray serviceArray = new JSONArray();
        serviceArray.add(serviceObj);

        // Elements
        List<NetworkDevice> devicesList = new ArrayList<NetworkDevice>();
        AAISimplePluralUri devicesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().networkDevices());
        devicesUri.format(Format.RAW);

        AAIResultWrapper devicesWrapper = rClient.get(devicesUri);
        String deviceResults = devicesWrapper.getJson();

        JSONObject deviceResultsJson = (JSONObject) parser.parse(deviceResults);
        List<JSONObject> deviceResultsArray = (List<JSONObject>) deviceResultsJson.get("results");

        for (int i = 0; i < deviceResultsArray.size(); i++) {
            JSONObject policyObj = (JSONObject) deviceResultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            devicesList.add(mapper.readValue(policyObj.toString(), NetworkDevice.class));
        }

        JSONObject deviceObj = new JSONObject();
        deviceObj.put("name", "elements");
        deviceObj.put("maxValue", devicesList.size());

        Integer activeDevices = 0;
        for (NetworkDevice device : devicesList) {
            if (device.isElementStatus()) {
                activeDevices = activeDevices + 1;
            }
        }
        deviceObj.put("value", activeDevices);

        JSONArray deviceArray = new JSONArray();
        deviceArray.add(deviceObj);

        List<JSONArray> overviewObj = new ArrayList<JSONArray>();
        overviewObj.add(siteArray);
        overviewObj.add(networkArray);
        overviewObj.add(serviceArray);
        overviewObj.add(deviceArray);
        return overviewObj;
    }

    public JSONObject getFaultOverview() {
        List<Fault> faults = faultRepo.findAll();
        Integer infoCount = 0;
        Integer warningCount = 0;
        Integer minorCount = 0;
        Integer majorCount = 0;
        Integer criticalCount = 0;

        for (Fault fault : faults) {
            switch (fault.getSeverity()) {
                case 1:
                    infoCount = infoCount + 1;
                    break;
                case 2:
                    warningCount = warningCount + 1;
                    break;
                case 3:
                    minorCount = minorCount + 1;
                    break;
                case 4:
                    majorCount = majorCount + 1;
                    break;
                case 5:
                    criticalCount = criticalCount + 1;
                    break;
            }
        }

        JSONObject alarmSummary = new JSONObject();
        JSONObject eventSummary = new JSONObject();

        JSONObject alarmObj = new JSONObject();
        alarmObj.put("critical", criticalCount);
        alarmObj.put("major", majorCount);
        alarmObj.put("minor", minorCount);
        alarmObj.put("warning", warningCount);
        alarmObj.put("information", infoCount);

        JSONObject eventObj = new JSONObject();
        eventObj.put("device", 59);
        eventObj.put("link/route", 25);
        eventObj.put("network", 14);
        eventObj.put("service", 9);

        alarmSummary.put("alarms-summary", alarmObj);
        alarmSummary.put("events-summary", eventObj);
        return alarmSummary;
    }
}
