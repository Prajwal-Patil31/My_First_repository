package in.utl.noa.util;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.commons.text.CaseUtils;
import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.onap.aai.domain.yang.Filter;
import org.onap.aai.domain.yang.FilterCriteria;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.CustomQuery;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.GraphInventoryObjectName;
import org.onap.aaiclient.client.graphinventory.entities.DSLNodeKey;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Output;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.utl.noa.dto.RequestBodyDTO;

@Service
public class GDBFilterService {
    private static Logger logger = Logger.getLogger(GDBFilterService.class);

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    private ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    private JSONParser parser = new JSONParser();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    public <T> JSONObject queryByFilter(RequestBodyDTO requestBody, String className) {
        List<Object> filteredList = new ArrayList<Object>();
        List<Object> completeList = new ArrayList<Object>();

        Map<String, JSONObject> filters = requestBody.getFilters();
        JSONObject paginationObj = requestBody.getPagination();

        Integer pageSize = 10;
        Integer pageIndex = 1;

        if (paginationObj != null) {
            pageSize = paginationObj.get("size") != null ? Integer.parseInt(paginationObj.get("size").toString()) : 10;
            pageIndex = paginationObj.get("number") != null ? Integer.parseInt(paginationObj.get("number").toString())
                    : 1;
        }

        Integer startRange = pageSize * (pageIndex - 1);
        Integer endRange = pageSize * pageIndex;

        String vertexLabels[] = new String[filters.keySet().size()];
        vertexLabels = filters.keySet().toArray(vertexLabels);

        String basicQuery = "g.V()";
        StringBuilder stringBuilder = new StringBuilder(basicQuery);
        StringBuilder rootChildrenBuilder = new StringBuilder();

        for (int i = 0; i < vertexLabels.length; i++) {
            String vertexLabel = vertexLabels[i];
            String label;
            String labelSplit[] = vertexLabel.split(":");

            if (labelSplit.length > 1) {
                label = labelSplit[1];
            } else {
                label = vertexLabel;
            }

            String vertexQuery = ".hasLabel('" + label + "')";

            StringBuilder vertexStringBuilder = new StringBuilder(vertexQuery);
            JSONObject vertexFilters = filters.get(vertexLabel);

            buildFilterAttributes(stringBuilder, vertexStringBuilder, rootChildrenBuilder, vertexFilters, i, false);
        }
        stringBuilder.append(".store('x')" + rootChildrenBuilder.toString() + ".cap('x').unfold().dedup()");
        String finalQuery = stringBuilder.toString();
        String results = null;
        String countResults = null;

        try {
            countResults = qClient.query(Format.COUNT, new CustomQuery(finalQuery));
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        stringBuilder.append(".range(" + startRange + "," + endRange + ")");

        finalQuery = stringBuilder.toString();

        try {
            results = qClient.query(Format.RESOURCE, new CustomQuery(finalQuery));
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        filteredList = convertJsonToPojo(results, filteredList, className);

        JSONObject countResultsJson = null;
        try {
            countResultsJson = (JSONObject) parser.parse(countResults);
        } catch (ParseException e1) {
            e1.printStackTrace();
        }

        List<JSONObject> countResultsArray = (List<JSONObject>) countResultsJson.get("results");
        Integer totalEntries = 0;
        if (countResultsArray.size() > 0) {
            if (countResultsArray.get(0).get(className) != null) {
                totalEntries = Integer.parseInt(countResultsArray.get(0).get(className).toString());
            }
        }

        Integer maxPages = 0;
        if (totalEntries % pageSize != 0) {
            maxPages = totalEntries / pageSize + 1;
        } else {
            maxPages = totalEntries / pageSize;
        }
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", filteredList);

        JSONObject pageObj = new JSONObject();
        pageObj.put("maxPages", maxPages);
        pageObj.put("totalEntries", totalEntries);
        jsonObject.put("page", pageObj);

        return jsonObject;
    }

    public <T> List<Object> performQueryClientFilter(RequestBodyDTO requestBody) {
        List<Object> filteredList = new ArrayList<Object>();

        Map<String, JSONObject> filters = requestBody.getFilters();

        String vertexLabels[] = new String[filters.keySet().size()];
        vertexLabels = filters.keySet().toArray(vertexLabels);

        String basicQuery = "g.V()";
        StringBuilder stringBuilder = new StringBuilder(basicQuery);
        StringBuilder rootChildrenBuilder = new StringBuilder();

        for (int i = 0; i < vertexLabels.length; i++) {
            String vertexLabel = vertexLabels[i];
            String label;
            String labelSplit[] = vertexLabel.split(":");

            if (labelSplit.length > 1) {
                label = labelSplit[1];
            } else {
                label = vertexLabel;
            }

            String vertexQuery = ".hasLabel('" + label + "')";

            StringBuilder vertexStringBuilder = new StringBuilder(vertexQuery);
            JSONObject vertexFilters = filters.get(vertexLabel);

            buildFilterAttributes(stringBuilder, vertexStringBuilder, rootChildrenBuilder, vertexFilters, i, false);
        }

        stringBuilder.append(".store('x')" + rootChildrenBuilder.toString() + ".cap('x').unfold().dedup()");

        String finalQuery = stringBuilder.toString();

        String results = null;
        try {
            results = qClient.query(Format.RESOURCE, new CustomQuery(finalQuery));
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }

        filteredList = convertJson(results, filteredList);

        return filteredList;
    }

    public Map<String, JSONObject> getFilterCriteria(String component, String... vertexLabels) {
        List<Filter> filters = new ArrayList<Filter>();

        List<String> vertexLabelsCC = new ArrayList<String>();
        List<String> componentVertexLabels = new ArrayList<String>();

        if (component != null) {
            for (int i = 0; i < vertexLabels.length; i++) {
                componentVertexLabels.add(i, component + ":" + vertexLabels[i]);
            }
        }

        for (int i = 0; i < vertexLabels.length; i++) {
            String vertexLabel = vertexLabels[i];
            vertexLabelsCC.add(i, CaseUtils.toCamelCase(vertexLabel, true, '-'));
        }

        Map<String, List<String>> parentChildMap = new HashMap<String, List<String>>();

        for (int i = 0; i < vertexLabelsCC.size(); i++) {
            String vertexLabelCC = vertexLabelsCC.get(i);
            List<String> childLabels = new ArrayList<String>();

            getChildLabels(component, vertexLabelCC, vertexLabels, childLabels);

            if (component != null) {
                parentChildMap.put(componentVertexLabels.get(i), childLabels);
            } else {
                parentChildMap.put(vertexLabels[i], childLabels);
            }
        }

        List<String> allChildren = parentChildMap.values().stream().flatMap(List::stream).collect(Collectors.toList());

        Map<String, List<String>> filteredParentChildMap = new HashMap<String, List<String>>();
        for (var parent : parentChildMap.keySet()) {
            if (!allChildren.contains(parent)) {
                filteredParentChildMap.put(parent, parentChildMap.get(parent));
            }
        }

        String[] filterKeys = null;

        if (component != null) {
            filterKeys = componentVertexLabels.toArray(new String[0]);
        } else {
            filterKeys = vertexLabels;
        }

        DSLStartNode filterStartNode = new DSLStartNode(Types.FILTER, __.key("module", filterKeys));
        DSLQueryBuilder<Output, Output> filterBuilder = TraversalBuilder.traversal(filterStartNode.output());
        String filterResults = dslClient.query(Format.RESOURCE, new DSLQuery(filterBuilder.build()));

        Results<Map<String, Filter>> filterResultsFromJson;
        try {
            filterResultsFromJson = mapper.readValue(filterResults, new TypeReference<Results<Map<String, Filter>>>() {
            });

            for (Map<String, Filter> m : filterResultsFromJson.getResult()) {
                filters.add(m.get("filter"));
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        Map<String, JSONObject> responseDataFilters = new HashMap<String, JSONObject>();

        for (var parentLabel : filteredParentChildMap.keySet()) {
            List<String> childLabels = filteredParentChildMap.get(parentLabel);
            List<Filter> parentFilters = filters.stream().filter(filter -> filter.getModule().equals(parentLabel))
                    .collect(Collectors.toList());

            JSONObject filterObject = new JSONObject();
            List<JSONObject> parentFilterObjects = new ArrayList<JSONObject>();
            List<JSONObject> childFilterObjects = new ArrayList<JSONObject>();

            parentFilters.forEach((Filter filter) -> {
                // String filterName = filter.getFilterName();
                String filterCategory = filter.getFilterCategory();
                String filterValue = filter.getFilterValue();
                Boolean exists = false;
                for (JSONObject dataFilter : parentFilterObjects) {
                    if (dataFilter.get("filterCategory").equals(filterCategory)) {
                        dataFilter.put("filterName", filterCategory);
                        List<String> filterValues = (List<String>) dataFilter.get("filterValue");
                        filterValues.add(filterValue);
                        dataFilter.put("filterValue", filterValues);
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("filterCategory", filterCategory);
                    jsonObject.put("filterName", filterCategory);
                    List<String> filterValues = new ArrayList<String>();
                    filterValues.add(filterValue);
                    jsonObject.put("filterValue", filterValues);
                    parentFilterObjects.add(jsonObject);
                }
            });

            childLabels.forEach((String childLabel) -> {
                List<Filter> childFilters = filters.stream().filter(filter -> filter.getModule().equals(childLabel))
                        .collect(Collectors.toList());

                childFilters.forEach((Filter filter) -> {
                    // String filterName = filter.getFilterName();
                    String filterCategory = filter.getFilterCategory();
                    String filterValue = filter.getFilterValue();
                    Boolean exists = false;
                    for (JSONObject dataFilter : childFilterObjects) {
                        if (dataFilter.get("filterCategory").equals(filterCategory)) {
                            dataFilter.put("filterName", filterCategory);
                            List<String> filterValues = (List<String>) dataFilter.get("filterValue");
                            filterValues.add(filterValue);
                            dataFilter.put("filterValue", filterValues);
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("filterCategory", filterCategory);
                        jsonObject.put("filterName", filterCategory);
                        jsonObject.put("childName", childLabel);
                        List<String> filterValues = new ArrayList<String>();
                        filterValues.add(filterValue);
                        jsonObject.put("filterValue", filterValues);
                        childFilterObjects.add(jsonObject);
                    }
                });
            });

            filterObject.put("filterCriteria", parentFilterObjects);
            filterObject.put("childCriteria", childFilterObjects);

            responseDataFilters.put(parentLabel, filterObject);
        }

        return responseDataFilters;
    }

    public void deleteFilters() {
        AAIPluralResourceUri filtersUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.platform().filterCriteria());

        if (rClient.exists(filtersUri)) {

            FilterCriteria logsList = rClient.get(FilterCriteria.class, filtersUri).get();

            List<Filter> filters = logsList.getFilter();

            for (Filter filter : filters) {
                AAIResourceUri filterUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().filter(filter.getCriteriaId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(filterUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void buildFilterAttributes(StringBuilder stringBuilder, StringBuilder vertexStringBuilder,
            StringBuilder rootChildrenBuilder, JSONObject vertexFilters, int i, Boolean child) {

        JSONObject childFilterObjects = new JSONObject();

        for (var filterKey : vertexFilters.keySet()) {

            if (vertexFilters.get(filterKey) instanceof List<?>) {
                vertexStringBuilder.append(".has('" + filterKey + "', within(");
                List<String> filterValues = (List<String>) vertexFilters.get(filterKey);
                for (String value : filterValues) {
                    vertexStringBuilder.append("'" + value + "',");
                }
                vertexStringBuilder.deleteCharAt(vertexStringBuilder.length() - 1);
                vertexStringBuilder.append("))");
            } else {
                String childFilterKey;
                String keySplit[] = ((String) filterKey).split(":");

                if (keySplit.length > 1) {
                    childFilterKey = keySplit[1];
                } else {
                    childFilterKey = (String) filterKey;
                }
                childFilterObjects.put(childFilterKey, vertexFilters.get(filterKey));

            }
        }

        String childKeys[] = new String[childFilterObjects.keySet().size()];
        childKeys = (String[]) childFilterObjects.keySet().toArray(childKeys);

        StringBuilder childStringBuilder = new StringBuilder();

        for (int j = 0; j < childKeys.length; j++) {
            String childKey = childKeys[j];
            Map<String, List<String>> childFilterObject = (Map<String, List<String>>) childFilterObjects.get(childKey);

            if (j == 0) {
                childStringBuilder.append(".union(__.both().hasLabel('" + childKey + "')");
            } else {
                childStringBuilder.append(".store('x'), __.both().hasLabel('" + childKey + "')");
            }

            buildFilterAttributes(vertexStringBuilder, childStringBuilder, rootChildrenBuilder,
                    new JSONObject(childFilterObject), j, true);

            if (j == childKeys.length - 1) {
                childStringBuilder.append(".store('x'))");
            }
        }

        if (!child) {
            if (i == 0) {
                stringBuilder.append(vertexStringBuilder.toString());
                rootChildrenBuilder.append(childStringBuilder.toString());
            } else {
                vertexStringBuilder.append(childStringBuilder.toString());
                stringBuilder.append(".where(__.both()" + vertexStringBuilder.toString() + ".store('x'))");
            }
        }

    }

    public <T> List<T> convertJsonToPojo(String results, List<T> filteredList, String vertexLabel) {

        JSONObject resultsJson = null;
        try {
            resultsJson = (JSONObject) parser.parse(results);
        } catch (ParseException e1) {
            e1.printStackTrace();
        }

        List<JSONObject> resultsList = (List<JSONObject>) resultsJson.get("results");
        Map<String, Class<?>> classNamesMap = new HashMap<>();

        for (JSONObject resultsObject : resultsList) {
            /* String[] vertexLabels = new String[1];
            String vertexLabel = resultsObject.get("node-type").toString();

            String vertexLabelCC = CaseUtils.toCamelCase(vertexLabel, true, '-');
            try {
                filteredList.add((T) mapper.readValue(resultsObject.get("properties").toString(),
                        Class.forName("org.onap.aai.domain.yang." + vertexLabelCC)));

            } catch (Exception e) {
                e.printStackTrace();
            }

            String[] vertexLabels = new String[1];
            String vertexLabel = (String) resultsObject.keySet().toArray(vertexLabels)[0];*/

            String vertexLabelCC = CaseUtils.toCamelCase(vertexLabel, true, '-'); 

            try {
                Map<String, T> resultsPojo = mapper.readValue(resultsObject.toString(),
                        mapper.getTypeFactory().constructMapType(Map.class, String.class,
                                Class.forName("org.onap.aai.domain.yang." + vertexLabelCC)));

                if (resultsPojo.get(vertexLabel) != null) {
                    filteredList.add(resultsPojo.get(vertexLabel));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return filteredList;
    }

    public <T> List<T> convertJson(String results, List<T> filteredList) {

        JSONObject resultsJson = null;
        try {
            resultsJson = (JSONObject) parser.parse(results);
        } catch (ParseException e1) {
            e1.printStackTrace();
        }

        List<JSONObject> resultsList = (List<JSONObject>) resultsJson.get("results");
        Map<String, Class<?>> classNamesMap = new HashMap<>();

        for (JSONObject resultsObject : resultsList) {

            String[] vertexLabels = new String[1];
            String vertexLabel = (String) resultsObject.keySet().toArray(vertexLabels)[0];

            String vertexLabelCC = CaseUtils.toCamelCase(vertexLabel, true, '-');

            try {
                Map<String, T> resultsPojo = mapper.readValue(resultsObject.toString(),
                        mapper.getTypeFactory().constructMapType(Map.class, String.class,
                                Class.forName("org.onap.aai.domain.yang." + vertexLabelCC)));

                if (resultsPojo.get(vertexLabel) != null) {
                    filteredList.add(resultsPojo.get(vertexLabel));
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return filteredList;
    }

    public void getChildLabels(String component, String vertexLabelCC, String[] vertexLabels,
            List<String> childLabels) {
        try {
            Class<?> vertexClass = Class.forName("org.onap.aai.domain.yang." + vertexLabelCC);
            List<Field> fields = Arrays.asList(vertexClass.getDeclaredFields());

            for (Field field : fields) {
                String fieldName = field.getName();
                String fieldTypeName = field.getType().getSimpleName();

                switch (fieldTypeName) {
                    case "String":
                    case "Integer":
                    case "Boolean":
                    case "RelationshipList":
                    case "long":
                        break;
                    case "List":
                        String filedNameParsed = fieldName.replaceAll("([^^])([A-Z][a-z])", "$1-$2").toLowerCase();
                        if (Arrays.asList(vertexLabels).contains(filedNameParsed)) {
                            if (component != null) {
                                childLabels.add(component + ":" + filedNameParsed);
                            } else {
                                childLabels.add(filedNameParsed);
                            }
                        }
                        break;
                    default:
                        getChildLabels(component, fieldTypeName, vertexLabels, childLabels);
                        break;
                }
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
