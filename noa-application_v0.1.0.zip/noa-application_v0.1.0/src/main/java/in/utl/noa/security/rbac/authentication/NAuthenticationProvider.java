package in.utl.noa.security.rbac.authentication;

import com.fasterxml.jackson.core.JsonProcessingException;

import org.apache.log4j.Logger;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;

import in.utl.noa.account.user.model.UserAccountRepository;
import in.utl.noa.account.user.model.User;

public class NAuthenticationProvider extends DaoAuthenticationProvider {

    private static Logger logger = Logger.getLogger(NAuthenticationProvider.class);

    @Autowired
    private UserAccountRepository userRepository;

    @Autowired
    private GDBUserDetails userDetails;

    // ToDo: Complete User Object is being stored as Principal in Spring Session
    // Table instead of Username
    @Override
    public Authentication authenticate(Authentication auth) throws AuthenticationException {
        User user = null;
        try {
            user = userDetails.findByUserName(auth.getName());
            logger.info("NAuthProvider");
        } catch (JsonProcessingException | ParseException e) {
            e.printStackTrace();
        }

        if ((user == null)) {
            throw new BadCredentialsException("Invalid username or password");
        }

        final Authentication result = super.authenticate(auth);
        return new UsernamePasswordAuthenticationToken(user, result.getCredentials(), result.getAuthorities());
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return authentication.equals(UsernamePasswordAuthenticationToken.class);
    }
}
