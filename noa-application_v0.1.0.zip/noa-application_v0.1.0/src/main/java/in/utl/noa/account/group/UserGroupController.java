package in.utl.noa.account.group;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.core.JsonProcessingException;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.modelmapper.ModelMapper;

import org.onap.aai.domain.yang.AccessRole;
import org.onap.aai.domain.yang.Action;
import org.onap.aai.domain.yang.GroupPrivilege;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.UserAccount;
import org.onap.aai.domain.yang.UserGroup;
import org.onap.aai.domain.yang.UserGroups;

import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.AAIResultWrapper;
import org.onap.aaiclient.client.aai.entities.Relationships;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

@RestController
@RequestMapping(value = "/api/platform/security/rbac/group")
public class UserGroupController {
    private static Logger logger = Logger.getLogger(UserGroupController.class);

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    AuditLogger auditLogger = new AuditLogger();
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    GDBFilterService filterService;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<UserGroup>> getUserGroups() throws ParseException {
        List<UserGroup> userGroupsList = new ArrayList<UserGroup>();
        AAIPluralResourceUri groupsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().userGroups());
        if (rClient.exists(groupsUri)) {
            Optional<UserGroups> userGroups = rClient.get(UserGroups.class, groupsUri);
            userGroupsList = userGroups.get().getUserGroup();
        }

        return ResponseEntity.status(HttpStatus.OK).body(userGroupsList);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getUserGroupFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "user-group");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("userGroupName", "Group Name");
        columns.put("userGroupCode", "Group Code");
        columns.put("userCount", "User Count");
        columns.put("roleName", "Role");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getUserGroupList(@RequestBody RequestBodyDTO requestBody)
            throws JsonProcessingException, ParseException {
        JSONObject groups = filterService.queryByFilter(requestBody, "user-group");
        return ResponseEntity.status(HttpStatus.OK).body(groups);
    }

    @GetMapping(value = "/{userGroupId}")
    public ResponseEntity<Optional<UserGroup>> getUserGroupById(@PathVariable("userGroupId") String userGroupId) {
        Optional<UserGroup> userGroup = null;

        if (userGroupId != null) {
            AAIResourceUri groupsUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));
            if (rClient.exists(groupsUri)) {
                userGroup = rClient.get(UserGroup.class, groupsUri);
            }
            return ResponseEntity.status(HttpStatus.OK).body(userGroup);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(userGroup);
    }

    @PutMapping()
    public ResponseEntity<UserGroup> addUserGroup(@RequestBody UserGroup newUserGroup) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String userGroupId = UUID.randomUUID().toString();
        newUserGroup.setUserGroupId(userGroupId);

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Group", userGroupId, null, null);

        AAIResourceUri groupsUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

        if (!rClient.exists(groupsUri)) {
            AAITransactionalClient transactions;

            transactions = rClient.beginTransaction().create(groupsUri, newUserGroup);

            transactions.execute();
            description = userGroupId + " User Group Created Successfully";
            eventStatus = true;
            reqStatus = HttpStatus.CREATED;
        } else {
            description = userGroupId + " User Group Already Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                NoaEvents.CREATE_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(newUserGroup);
    }

    @PostMapping(value = "/{userGroupId}")
    public ResponseEntity<String> updateUserGroup(@PathVariable("userGroupId") String userGroupId,
            @RequestBody UserGroup newuserGroup) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Group", userGroupId, null, null);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (userGroupId != null) {
            AAIResourceUri groupsUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

            if (rClient.exists(groupsUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().update(groupsUri, newuserGroup);

                transactions.execute();
                description = userGroupId + " User Group Updated Successfully.";
                reqStatus = HttpStatus.OK;
                eventStatus = true;
            } else {
                description = userGroupId + " User Group Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null User Group Id";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                NoaEvents.MODIFY_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteUserGroups(@RequestBody List<String> userGroupIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String userGroupId : userGroupIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Group", userGroupId, null,
                    null);
            if (userGroupId != null) {
                AAIResourceUri groupsUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

                if (rClient.exists(groupsUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(groupsUri);
                    transactions.execute();
                    description = userGroupId + " User Group Deleted Successfully.";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                            NoaEvents.DELETE_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = userGroupId + " User Group Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                            NoaEvents.DELETE_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null User Group Id";
                auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                        NoaEvents.DELETE_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("User Groups Deleted.");
    }

    @GetMapping("/{userGroupId}/user")
    public ResponseEntity<List<UserAccount>> getUsers(@PathVariable("userGroupId") String userGroupId)
            throws ParseException, JsonMappingException, JsonProcessingException {
        List<UserAccount> userAccounts = new ArrayList<UserAccount>();

        DSLStartNode startNode = new DSLStartNode(Types.USER_GROUP, __.key("user-group-id", userGroupId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.USER_ACCOUNT))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject userObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            UserAccount userBody = mapper.readValue(userObj.toString(), UserAccount.class);
            userAccounts.add(userBody);
        }
        return ResponseEntity.status(HttpStatus.OK).body(userAccounts);
    }

    @PostMapping("/{userGroupId}/user")
    public ResponseEntity<String> addUsers(@PathVariable("userGroupId") String userGroupId,
            @RequestBody List<String> userAccountsId) throws BulkProcessFailed {

        AAIResourceUri userGroupUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata(null, null, "User Group", userGroupId);

        if (rClient.exists(userGroupUri)) {
            for (String useraccountId : userAccountsId) {
                resourceMetadata.setResourceType("User Account");
                resourceMetadata.setResourceId(useraccountId);

                AAIResourceUri userUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().userAccount(useraccountId));
                if (rClient.exists(userUri)) {
                    transactionClient.connect(userGroupUri, userUri);
                    transactionClient.execute();
                    description = useraccountId + " User Account Added to " + userGroupId + " User Group";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                            NoaEvents.ADD_USER_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = useraccountId + " User Account Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                            NoaEvents.ADD_USER_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            }
        } else {
            description = userGroupId + " User Group Doesn't Exists.";
            reqStatus = HttpStatus.NOT_FOUND;
            auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                    NoaEvents.ADD_USER_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body(description);
        }
        return ResponseEntity.status(HttpStatus.OK).body("User Added to Group");
    }

    @DeleteMapping("/{userGroupId}/user")
    public ResponseEntity<String> removeUsers(@PathVariable("userGroupId") String userGroupId,
            @RequestBody List<String> accountIds) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        AAIResourceUri userGroupUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata(null, null, "User Group", userGroupId);

        if (rClient.exists(userGroupUri)) {
            for (String accountId : accountIds) {
                resourceMetadata.setResourceType("User Account");
                resourceMetadata.setResourceId(accountId);

                AAIResourceUri userUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
                transactionClient.disconnect(userGroupUri, userUri);
                try {
                    transactionClient.execute();
                    description = "User Account " + accountId + " Removed from " + userGroupId + " User Group";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                            NoaEvents.REMOVE_USER_FROM_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        } else {
            description = userGroupId + " User Group Doesn't Exists.";
            reqStatus = HttpStatus.NOT_FOUND;
            auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                    NoaEvents.REMOVE_USER_FROM_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body(description);
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{userGroupId}/role")
    public ResponseEntity<Optional<AccessRole>> getRole(@PathVariable("userGroupId") String userGroupId) {

        Optional<AccessRole> accessRole = null;
        AAIResourceUri userGroupUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

        if (rClient.exists(userGroupUri)) {
            AAIResultWrapper resultWrapper = rClient.get(userGroupUri);
            if (resultWrapper.hasRelationshipsTo(Types.ACCESS_ROLE)) {
                Relationships relationships = resultWrapper.getRelationships().get();
                List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.ACCESS_ROLE);
                AAIResourceUri roleUri = allRelatedNodes.get(0);
                accessRole = rClient.get(AccessRole.class, roleUri);
                return ResponseEntity.status(HttpStatus.OK).body(accessRole);
            }
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(accessRole);
        } else
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(accessRole);
    }

    @PostMapping("/{userGroupId}/role/{roleId}")
    public ResponseEntity<String> assignRole(@PathVariable("userGroupId") String userGroupId,
            @PathVariable("roleId") String roleId, @RequestBody Map<String, List<String>> resourcesObj)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException, ParseException {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata(null, null, "User Group", userGroupId);

        AAIResourceUri userGroupUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        AAITransactionalClient transactions;
        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

        if (rClient.exists(roleUri)) {
            AAIResultWrapper resultWrapper = rClient.get(userGroupUri);
            if (resultWrapper.hasRelationshipsTo(Types.ACCESS_ROLE)) {
                Relationships relationships = resultWrapper.getRelationships().get();
                List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.ACCESS_ROLE);
                for (int i = 0; i < allRelatedNodes.size(); i++) {
                    AAIResourceUri roleUriOld = allRelatedNodes.get(i);
                    transactionClient.disconnect(userGroupUri, roleUriOld);
                    transactionClient.execute();
                }
            }
            if (rClient.exists(userGroupUri)) {
                resourceMetadata.setResourceType("Access Role");
                resourceMetadata.setResourceId(roleId);

                List<Action> actions = new ArrayList<Action>();

                DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
                DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                        .to(__.node(Types.ACTION, __.key("per-instance", true))).output();

                String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

                JSONParser parser = new JSONParser();
                JSONObject resultsJson = (JSONObject) parser.parse(results);
                List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

                for (int i = 0; i < resultsArray.size(); i++) {
                    JSONObject actionObj = (JSONObject) resultsArray.get(i).get("properties");
                    mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
                    Action actionBody = mapper.readValue(actionObj.toString(), Action.class);
                    actions.add(actionBody);
                }

                List<GroupPrivilege> groupPrivileges = new ArrayList<GroupPrivilege>();

                if (resourcesObj != null) {
                    List<String> elementIds = resourcesObj.get("element");
                    List<String> serviceIds = resourcesObj.get("service");
                    List<String> networkIds = resourcesObj.get("network");

                    if (elementIds != null && elementIds.size() > 0) {
                        List<Action> elementActions = actions.stream()
                                .filter(action -> action.getRelatedFeature().equals("ElementManagement"))
                                .collect(Collectors.toList());

                        for (String elementId : elementIds) {
                            for (Action elementAction : elementActions) {
                                GroupPrivilege groupPrivilege = new GroupPrivilege();
                                String grpPrivilegeId = UUID.randomUUID().toString();
                                groupPrivilege.setPrivilegeId(grpPrivilegeId);
                                groupPrivilege.setActionName(elementAction.getActionName());
                                groupPrivilege.setActionCode(elementAction.getActionReference());
                                groupPrivilege.setPrivilegeType("ElementManagement");
                                groupPrivilege.setResource(elementAction.getResourceName());
                                groupPrivilege.setResourceId(elementId);
                                groupPrivileges.add(groupPrivilege);
                            }
                        }
                    }

                    if (serviceIds != null && serviceIds.size() > 0) {
                        List<Action> serviceActions = actions.stream()
                                .filter(action -> action.getRelatedFeature().equals("ServiceManagement"))
                                .collect(Collectors.toList());

                        for (String serviceId : serviceIds) {
                            for (Action serviceAction : serviceActions) {
                                GroupPrivilege groupPrivilege = new GroupPrivilege();
                                String grpPrivilegeId = UUID.randomUUID().toString();
                                groupPrivilege.setPrivilegeId(grpPrivilegeId);
                                groupPrivilege.setActionName(serviceAction.getActionName());
                                groupPrivilege.setActionCode(serviceAction.getActionReference());
                                groupPrivilege.setPrivilegeType("ServiceManagement");
                                groupPrivilege.setResource(serviceAction.getResourceName());
                                groupPrivilege.setResourceId(serviceId);
                                groupPrivileges.add(groupPrivilege);
                            }
                        }
                    }

                    if (networkIds != null && networkIds.size() > 0) {
                        List<Action> networkActions = actions.stream()
                                .filter(action -> action.getRelatedFeature().equals("NetworkManagement"))
                                .collect(Collectors.toList());

                        for (String networkId : networkIds) {
                            for (Action networkAction : networkActions) {
                                GroupPrivilege groupPrivilege = new GroupPrivilege();
                                String grpPrivilegeId = UUID.randomUUID().toString();
                                groupPrivilege.setPrivilegeId(grpPrivilegeId);
                                groupPrivilege.setActionName(networkAction.getActionName());
                                groupPrivilege.setActionCode(networkAction.getActionReference());
                                groupPrivilege.setPrivilegeType("NetworkManagement");
                                groupPrivilege.setResource(networkAction.getResourceName());
                                groupPrivilege.setResourceId(networkId);
                                groupPrivileges.add(groupPrivilege);
                            }
                        }
                    }
                }

                transactions = rClient.beginTransaction().connect(userGroupUri, roleUri);
                for (GroupPrivilege privilege : groupPrivileges) {
                    AAIResourceUri groupPrivilegeUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business()
                            .userGroup(userGroupId).groupPrivilege(privilege.getPrivilegeId()));

                    transactions.create(groupPrivilegeUri, privilege);
                }

                transactions.execute();
                description = roleId + " Role Assigned to " + userGroupId + " User Group";
                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = userGroupId + " User Group Doesn't Exists";
            }
        } else {
            description = roleId + " Role Doesn't Exists";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "User Group Management",
                NoaEvents.ASSIGN_ROLE_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }
}
