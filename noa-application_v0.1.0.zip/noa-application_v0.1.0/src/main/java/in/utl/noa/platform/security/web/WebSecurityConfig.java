package in.utl.noa.platform.security.web;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.authentication.AuthenticationEventPublisher;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.DefaultAuthenticationEventPublisher;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;

import org.springframework.security.web.AuthenticationEntryPoint;

import org.springframework.security.web.authentication.session.ConcurrentSessionControlAuthenticationStrategy;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;

import in.utl.noa.account.user.UserController;

import in.utl.noa.security.rbac.authentication.CustomAuthenticationEntryPoint;
import in.utl.noa.security.rbac.authentication.GDBUserDetails;
import in.utl.noa.security.rbac.authentication.NAuthenticationProvider;
import in.utl.noa.security.rbac.authentication.NUserDetails;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    /* @Autowired
    private NUserDetails userDetails; */
    
    @Autowired 
    private GDBUserDetails userDetails;
    

    public WebSecurityConfig() {
        super();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    @Autowired
    public void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.authenticationProvider(authProvider());
    }

    @Override
    public void configure(final WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/resources/**");
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        AuthenticationEntryPoint entryPoint = new CustomAuthenticationEntryPoint();
        httpSecurity
                // .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                .authorizeRequests()
                .antMatchers("/", "/index", "/error", "/built/**", "/*.css", "/images/**", "/lib/**").permitAll()
                .antMatchers("/logout").permitAll().antMatchers("/api/swagger-ui.html").permitAll()
                .antMatchers("/api/swagger-ui/**").permitAll().antMatchers("/api/resource/**").permitAll()
                .antMatchers("/api/profile/**").authenticated().antMatchers("/api/**")
                .access("@WebSecurityService.check(authentication, request)").anyRequest().authenticated().and()
                .httpBasic().authenticationEntryPoint(entryPoint).and()
                
                /*
                 * TODO: Replace this with Dedicated Controller/Handler for Logout
                 * (BasicAuthLogoutController)
                 */
                .logout(logout -> logout.permitAll().logoutSuccessHandler((request, response, authentication) -> {
                    response.setStatus(HttpServletResponse.SC_OK);
                })).csrf().disable().sessionManagement().maximumSessions(-1).sessionRegistry(sessionRegistry()).and()
                .sessionFixation().none();
    }

    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    @Bean
    public RegisterSessionAuthenticationStrategy registerSessionAuthStr() {
        return new RegisterSessionAuthenticationStrategy(sessionRegistry());
    }

    /* @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    } */

    @Bean
    public AuthenticationEventPublisher authenticationEventPublisher
            (ApplicationEventPublisher applicationEventPublisher) {
        return new DefaultAuthenticationEventPublisher(applicationEventPublisher);
    }

    @Bean
    public SessionAuthenticationStrategy sessionAuthenticationStrategy() {
        ConcurrentSessionControlAuthenticationStrategy sessionAuthenticationStrategy = new ConcurrentSessionControlAuthenticationStrategy(
                sessionRegistry());
        sessionAuthenticationStrategy.setMaximumSessions(1);
        sessionAuthenticationStrategy.setExceptionIfMaximumExceeded(true);
        return sessionAuthenticationStrategy;
    }

    @Bean
    public DaoAuthenticationProvider authProvider() {
        final NAuthenticationProvider authProvider = new NAuthenticationProvider();
        authProvider.setUserDetailsService(userDetails);
        authProvider.setPasswordEncoder(UserController.PASSWORD_ENCODER);
        return authProvider;
    }
}