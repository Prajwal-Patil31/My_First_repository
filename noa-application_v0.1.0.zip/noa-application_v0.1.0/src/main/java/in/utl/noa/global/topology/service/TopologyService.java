package in.utl.noa.global.topology.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;

import org.springframework.http.ResponseEntity;

import in.utl.noa.dto.RequestBodyDTO;

public interface TopologyService {
    public Map<String, List<JSONObject>> convertResultsToTopologyData(List<Object> topologyResults,
            RequestBodyDTO requestBody, String vertexName);
}
