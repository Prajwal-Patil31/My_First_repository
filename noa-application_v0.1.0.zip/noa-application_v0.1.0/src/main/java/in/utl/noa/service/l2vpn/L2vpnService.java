package in.utl.noa.service.l2vpn;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;
import org.json.simple.parser.JSONParser;

import org.onap.aai.domain.yang.VpnService;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.onap.aaiclient.client.aai.AAIDSLQueryClient;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/api/service/l2vpn/{serviceId}")
public class L2vpnService {
    private static Logger logger = Logger.getLogger(L2vpnService.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<VpnService> getL2VpnServiceById(@PathVariable("serviceId") String serviceId) {

        VpnService vpnService = new VpnService();

        AAIResourceUri vpnServiceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId)).depth(Depth.TWO);
        if (rClient.exists(vpnServiceUri)) {
            vpnService = rClient.get(VpnService.class, vpnServiceUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(vpnService);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(vpnService);
    }
}
