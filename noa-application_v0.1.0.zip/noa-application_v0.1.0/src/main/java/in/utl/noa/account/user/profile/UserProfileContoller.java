package in.utl.noa.account.user.profile;

import in.utl.noa.account.user.model.User;
import in.utl.noa.account.user.model.UserAccountRepository;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.account.user.password.service.CustomPasswordValidator;
import in.utl.noa.account.user.profile.dto.UserProfile;

import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import org.modelmapper.ModelMapper;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aai.domain.yang.PasswordHistory;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.PasswordPolicy;
import org.onap.aai.domain.yang.UserGroup;
import org.onap.aai.domain.yang.UserAccount;

import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.security.core.context.SecurityContextHolder;

@RestController
@RequestMapping(value = "/api/profile")
public class UserProfileContoller {

    private static Logger logger = Logger.getLogger(UserProfileContoller.class);

    @Autowired
    private UserAccountRepository userRepository;

    AuditLogger auditLogger = new AuditLogger();

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    CustomPasswordValidator passwordValidator = new CustomPasswordValidator();

    private static final PasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public UserProfileContoller() {
        super();
    }

    @GetMapping()
    public ResponseEntity<UserProfile> getProfile(final Authentication auth)
            throws ParseException, JsonMappingException, JsonProcessingException {

        User user = (User) auth.getPrincipal();
        String username = user.getUserName();

        UserAccount userAccount = new UserAccount();
        DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT, __.key("user-name", username));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        if (resultsArray.size() > 0) {
            JSONObject actionObj = (JSONObject) resultsArray.get(0).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            userAccount = mapper.readValue(actionObj.toString(), UserAccount.class);
        }

        UserProfile profile = modelMapper.map(userAccount, UserProfile.class);

        List<UserGroup> userGroups = new ArrayList<UserGroup>();

        DSLQueryBuilder<Start, Node> queryBuilder = TraversalBuilder.fragment(startNode).to(__.node(Types.USER_GROUP))
                .output();

        String queryResults = dslClient.query(Format.SIMPLE, new DSLQuery(queryBuilder.build()));

        JSONObject queryResultsJson = (JSONObject) parser.parse(queryResults);
        List<JSONObject> queryResultsArray = (List<JSONObject>) queryResultsJson.get("results");

        for (int i = 0; i < queryResultsArray.size(); i++) {
            JSONObject actionObj = (JSONObject) queryResultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            UserGroup userGroup = mapper.readValue(actionObj.toString(), UserGroup.class);
            userGroups.add(userGroup);
        }

        profile.setGroups(userGroups);

        return ResponseEntity.ok(profile);
    }

    @PostMapping()
    public ResponseEntity<UserProfile> updateProfile(@RequestBody UserProfile profile) throws BulkProcessFailed {
        UserAccount userAccount = modelMapper.map(profile, UserAccount.class);
        String accountId = userAccount.getAccountId();
        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
        if (rClient.exists(userUri)) {
            UserAccount userAccountOld = rClient.get(UserAccount.class, userUri).get();
            userAccount.setResourceVersion(userAccountOld.getResourceVersion());
            AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().update(userUri,
                    userAccount);
            transactionClient.execute();
            return ResponseEntity.ok(profile);
        }
        return new ResponseEntity<>(profile, HttpStatus.NOT_FOUND);
    }

    @PostMapping("/change-password")
    public ResponseEntity<String> changePassword(@RequestBody JSONObject profile)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException, ParseException {

        String accountId = profile.get("accountId").toString();
        String prevPassword = profile.get("oldPassword").toString();
        String password = profile.get("password").toString();

        PasswordPolicy policy = new PasswordPolicy();

        DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT, __.key("account-id", accountId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.PASSWORD_POLICY))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject policyObj = (JSONObject) resultsArray.get(i).get("properties");
            policy = mapper.readValue(policyObj.toString(), PasswordPolicy.class);
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null, null);

        AAIResourceUri userUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId))
                .depth(Depth.TWO);

        if (rClient.exists(userUri) && policy != null) {

            UserAccount userAccount = rClient.get(UserAccount.class, userUri).get();
            UserAccount userAccountCopy = userAccount;

            String encodedPassword = PASSWORD_ENCODER.encode(password);

            Boolean isPasswordValid = passwordValidator.checkPassword(policy, password);
            if (PASSWORD_ENCODER.matches(prevPassword, userAccount.getPassword())) {
                if (isPasswordValid) {

                    Date date = Calendar.getInstance().getTime();
                    String timeStamp = DATE_FORMAT.format(date);

                    AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

                    final List<PasswordHistory> passwordHistoryList = userAccountCopy.getPasswordHistory();

                    for (PasswordHistory oldPassword : passwordHistoryList) {
                        if (PASSWORD_ENCODER.matches(password, oldPassword.getOldPassword())) {
                            return new ResponseEntity<>("Cannot use Old Password", HttpStatus.BAD_REQUEST);
                        }
                    }

                    int limit = policy.getNumOldPassword();

                    Collections.sort(passwordHistoryList, new Comparator<PasswordHistory>() {
                        @Override
                        public int compare(PasswordHistory a, PasswordHistory b) {
                            Integer position1 = a.getPosition();
                            Integer position2 = b.getPosition();
                            return position1.compareTo(position2);
                        }
                    });

                    userAccount.getPasswordHistory().clear();
                    userAccount.getPasswordHistory().addAll(passwordHistoryList);

                    if (passwordHistoryList.size() == limit) {
                        String oldPassword = passwordHistoryList.get(0).getOldPassword();
                        AAIResourceUri oldPasswordUri = AAIUriFactory.createResourceUri(
                                AAIFluentTypeBuilder.business().userAccount(accountId).passwordHistory(oldPassword));

                        transactionClient.delete(oldPasswordUri);
                        passwordHistoryList.remove(0);
                        userAccount.getPasswordHistory().remove(0);
                    }

                    for (int i = 0; i < passwordHistoryList.size(); i++) {
                        PasswordHistory passwordHistory = passwordHistoryList.get(i);
                        passwordHistory.setPosition(i);
                    }

                    PasswordHistory passwordHistory = new PasswordHistory();
                    passwordHistory.setOldPassword(encodedPassword);
                    passwordHistory.setPosition(passwordHistoryList.size());

                    userAccount.setPassword(encodedPassword);
                    userAccount.setLatestPasswordTimeStamp(timeStamp);
                    userAccount.getPasswordHistory().add(passwordHistoryList.size(), passwordHistory);

                    transactionClient.create(userUri, userAccount);
                    transactionClient.execute();

                    description = userAccount.getUserName() + " has Changed Password";
                    reqStatus = HttpStatus.OK;
                    eventStatus = true;
                } else {
                    description = "Password Not Adhering to Assigned Policy";
                }
            } else {
                description = "Incorrect Old Password";
                reqStatus = HttpStatus.BAD_REQUEST;
                eventStatus = false;
            }

        } else {
            description = "User Not Found";
            reqStatus = HttpStatus.NOT_FOUND;
        }
        auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                NoaEvents.CHANGE_PASSWORD.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }
}