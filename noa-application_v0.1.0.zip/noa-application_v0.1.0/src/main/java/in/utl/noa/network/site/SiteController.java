package in.utl.noa.network.site;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.onap.aai.domain.yang.Site;
import org.onap.aai.domain.yang.Sites;
import org.onap.aai.domain.yang.Location;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.NetworkDevices;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/site")
public class SiteController {
    private static Logger logger = Logger.getLogger(SiteController.class);

    @Autowired
    RestClientManager restClientManager;

    AuditLogger auditLogger = new AuditLogger();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    private ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public SiteController() {
        super();
    }

    @GetMapping()
    public ResponseEntity<List<Site>> getSites() {
        List<Site> sitesList = new ArrayList<Site>();
        AAIPluralResourceUri sitesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().sites())
                .depth(Depth.THREE);

        if (rClient.exists(sitesUri)) {
            Sites sites = rClient.get(Sites.class, sitesUri).get();
            sitesList = sites.getSite();
        }
        return ResponseEntity.ok(sitesList);
    }

    @GetMapping("/{siteId}")
    public ResponseEntity<Site> getSite(@PathVariable("siteId") String siteId) {
        Site site = new Site();
        if (siteId != null) {
            AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId))
                    .depth(Depth.THREE);
            if (rClient.exists(siteUri)) {
                site = rClient.get(Site.class, siteUri).get();
            }
            return ResponseEntity.ok(site);
        }
        return new ResponseEntity<>(site, HttpStatus.BAD_REQUEST);
    }

    @PutMapping()
    public ResponseEntity<Site> addSite(@RequestBody Site site) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String siteId = site.getSiteId();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Site", siteId, null, null);

        if (siteId != null) {
            AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId));
            if (!rClient.exists(siteUri)) {
                site.setActualSiteStart((new Date()).toString());
                site.getManagement().get(0).setManagementId(siteId);
                site.getMacLoopPrevention().get(0).setPreventionId(siteId);
                AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().create(siteUri, site);
                transactionClient.execute();
                description = siteId + " Site Created Successfully";
                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = siteId + " Site Already Exists.";
            }
        } else {
            description = "Received Null Site Id";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "Site", NoaEvents.CREATE_SITE.getEvent(),
                eventStatus, null, resourceMetadata, auth);
        return new ResponseEntity<>(site, reqStatus);
    }

    @PostMapping("/{siteId}")
    public ResponseEntity<Site> modifySite(@PathVariable String siteId, @RequestBody Site site)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Site", siteId, null, null);

        AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId));

        if (siteId != null) {
            if (rClient.exists(siteUri)) {
                AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().create(siteUri, site);
                transactionClient.execute();
                description = siteId + " Site Updated Successfully";
                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = siteId + " Site Doesn't Exists.";
            }
        } else {
            description = "Received Null Site Id";
        }
        Site siteNew = rClient.get(Site.class, siteUri).get();
        auditLogger.addAuditLog(rClient, description, "Service Management", "Site", NoaEvents.MODIFY_SITE.getEvent(),
                eventStatus, null, resourceMetadata, auth);
        return new ResponseEntity<>(siteNew, reqStatus);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteSites(@RequestBody List<String> siteIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String siteId : siteIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Site", siteId, null, null);

            if (siteId != null) {
                AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId));
                if (rClient.exists(siteUri)) {
                    AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().delete(siteUri);
                    transactionClient.execute();
                    description = siteId + " Site Deleted Successfully";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                            NoaEvents.DELETE_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = siteId + " Site Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                            NoaEvents.DELETE_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return new ResponseEntity<>(description, reqStatus);
                }
            } else {
                description = "Received Null Site Id";
                auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                        NoaEvents.DELETE_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return new ResponseEntity<>(description, reqStatus);
            }
        }
        return ResponseEntity.ok("Sites Deleted Successfully");
    }

    @GetMapping("/available-device")
    public ResponseEntity<List<NetworkDevice>> getAvailableDevices()
            throws ParseException, JsonMappingException, JsonProcessingException {

        AAIPluralResourceUri devicesUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevices()).depth(Depth.TWO);

        NetworkDevices networkDevices = rClient.get(NetworkDevices.class, devicesUri).get();
        List<NetworkDevice> allNetworkDevices = networkDevices.getNetworkDevice();

        List<String> deviceIds = new ArrayList<String>();

        DSLStartNode startNode = new DSLStartNode(Types.SITE, __.key("site-id", "", "null").not());
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.NETWORK_DEVICE))
                .output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, NetworkDevice>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, NetworkDevice>>>() {
                });

        for (Map<String, NetworkDevice> m : resultsFromJson.getResult()) {
            deviceIds.add(m.get("network-device").getDeviceId());
        }

        List<NetworkDevice> diffDevices = allNetworkDevices.stream().filter(d -> deviceIds.contains(d.getDeviceId()))
                .collect(Collectors.toList());

        allNetworkDevices.removeAll(diffDevices);

        return ResponseEntity.status(HttpStatus.OK).body(allNetworkDevices);
    }

    @GetMapping("/{siteId}/device")
    public ResponseEntity<List<NetworkDevice>> getDevicesOfSite(@PathVariable("siteId") String siteId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();

        if (siteId != null) {
            DSLStartNode startNode = new DSLStartNode(Types.SITE, __.key("site-id", siteId));
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                    .to(__.node(Types.NETWORK_DEVICE)).output();

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, NetworkDevice>> deviceResults = mapper.readValue(results,
                    new TypeReference<Results<Map<String, NetworkDevice>>>() {
                    });

            for (Map<String, NetworkDevice> m : deviceResults.getResult()) {
                devices.add(m.get("network-device"));
            }

            return ResponseEntity.ok(devices);
        }
        return new ResponseEntity<>(devices, HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/{siteId}/router")
    public ResponseEntity<List<NetworkDevice>> getRoutersOfSite(@PathVariable("siteId") String siteId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();

        if (siteId != null) {
            DSLStartNode startNode = new DSLStartNode(Types.SITE, __.key("site-id", siteId));
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                    .to(__.node(Types.NETWORK_DEVICE, __.key("device-type", "edge-router"))).output();

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, NetworkDevice>> deviceResults = mapper.readValue(results,
                    new TypeReference<Results<Map<String, NetworkDevice>>>() {
                    });

            for (Map<String, NetworkDevice> m : deviceResults.getResult()) {
                devices.add(m.get("network-device"));
            }

            return ResponseEntity.ok(devices);
        }
        return new ResponseEntity<>(devices, HttpStatus.BAD_REQUEST);
    }

    @GetMapping("/{siteId}/location")
    public ResponseEntity<List<Location>> getLocations(@PathVariable("siteId") String siteId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        List<Location> locations = new ArrayList<Location>();
        Site site = new Site();
        if (siteId != null) {
            AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId))
                    .depth(Depth.THREE);
            if (rClient.exists(siteUri)) {
                site = rClient.get(Site.class, siteUri).get();
                if (site.getLocations() != null) {
                    locations = site.getLocations().getLocation();
                }
            }
            return ResponseEntity.ok(locations);
        }
        return ResponseEntity.status(HttpStatus.OK).body(locations);
    }

    @GetMapping("/{siteId}/device/{deviceId}/location")
    public ResponseEntity<Location> getDeviceLocation(@PathVariable("siteId") String siteId,
            @PathVariable("deviceId") String deviceId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        Location location = new Location();
        DSLStartNode startNode = new DSLStartNode(Types.SITE, __.key("site-id", siteId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.NETWORK_DEVICE, __.key("device-id", deviceId))).to(__.node(Types.LOCATION)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Location>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Location>>>() {
                });

        for (Map<String, Location> m : resultsFromJson.getResult()) {
            location = m.get("location");
        }

        return ResponseEntity.status(HttpStatus.OK).body(location);
    }

    @PostMapping("/{siteId}/device/{deviceId}/location")
    public ResponseEntity<String> changeDeviceLocation(@PathVariable("siteId") String siteId,
            @PathVariable("deviceId") String deviceId, @RequestBody List<String> locations) throws BulkProcessFailed {

        String oldLocationId = locations.get(0);
        String newLocationId = locations.get(1);

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Location", newLocationId,
                "Network Device", deviceId);

        AAIResourceUri oldLocationUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().site(siteId).location(oldLocationId));
        AAIResourceUri newLocationUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().site(siteId).location(newLocationId));
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        if (rClient.exists(deviceUri)) {
            if (rClient.exists(oldLocationUri)) {
                if (rClient.exists(newLocationUri)) {
                    AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction()
                            .disconnect(deviceUri, oldLocationUri).connect(deviceUri, newLocationUri);
                    transactionClient.execute();
                    description = "Changed Location from " + oldLocationId + " to " + newLocationId;
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                } else {
                    description = "New Location " + newLocationId + " Doesn't Exists.";
                }
            } else {
                description = "Old Location " + oldLocationId + " Doesn't Exists.";
            }
        } else {
            description = deviceId + "Device Doesn't Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                NoaEvents.CHANGE_DEVICE_LOCATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping("/{siteId}/location/{locationId}")
    public ResponseEntity<String> updateSiteLocation(@PathVariable("siteId") String siteId,
            @PathVariable("locationId") String locationId, @RequestBody Location locationBody)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Location", locationId, "Site", siteId);

        AAIResourceUri locationUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().site(siteId).location(locationId));

        if (rClient.exists(locationUri)) {
            AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().update(locationUri,
                    locationBody);
            transactionClient.execute();
            description = "Updated" + locationId + " Location of " + siteId + " Site";
            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = locationId + " Location Not Found";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                NoaEvents.CHANGE_SITE_LOCATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{siteId}/device/{deviceId}/available-location")
    public ResponseEntity<List<Location>> getAvailableLocationsForDevice(@PathVariable("siteId") String siteId,
            @PathVariable("deviceId") String deviceId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        List<String> locationIds = new ArrayList<String>();
        List<Location> availableLocations = new ArrayList<Location>();

        DSLStartNode startNode = new DSLStartNode(Types.SITE, __.key("site-id", siteId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.NETWORK_DEVICE, __.key("device-id", deviceId))).to(__.node(Types.LOCATION)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Location>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Location>>>() {
                });

        for (Map<String, Location> m : resultsFromJson.getResult()) {
            locationIds.add(m.get("location").getLocationId());
        }

        Site site = new Site();
        if (siteId != null) {
            AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId))
                    .depth(Depth.THREE);
            if (rClient.exists(siteUri)) {
                site = rClient.get(Site.class, siteUri).get();
            }
        }

        if (site.getLocations() != null) {
            availableLocations = site.getLocations().getLocation();
        }

        if (availableLocations.size() > 0) {
            List<Location> diffLocations = availableLocations.stream()
                    .filter(availableLoc -> locationIds.contains(availableLoc.getLocationId()))
                    .collect(Collectors.toList());

            availableLocations.removeAll(diffLocations);
        }

        return ResponseEntity.status(HttpStatus.OK).body(availableLocations);
    }

    @GetMapping("/{siteId}/device-location")
    public ResponseEntity<Map<String, Location>> getDeviceLocationObjectsOfSite(@PathVariable("siteId") String siteId)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException {

        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();
        List<String> deviceIds = new ArrayList<String>();

        Map<String, Location> deviceLocationObject = new HashMap<String, Location>();

        if (siteId != null) {
            DSLStartNode startNode = new DSLStartNode(Types.SITE, __.key("site-id", siteId));
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                    .to(__.node(Types.NETWORK_DEVICE)).output();

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, NetworkDevice>> deviceResults = mapper.readValue(results,
                    new TypeReference<Results<Map<String, NetworkDevice>>>() {
                    });

            for (Map<String, NetworkDevice> m : deviceResults.getResult()) {
                devices.add(m.get("network-device"));
                deviceIds.add(m.get("network-device").getDeviceId());
            }

            for (String deviceId : deviceIds) {
                Location location = new Location();

                DSLStartNode locationStartNode = new DSLStartNode(Types.NETWORK_DEVICE, __.key("device-id", deviceId));
                DSLQueryBuilder<Start, Node> locationBuilder = TraversalBuilder.fragment(locationStartNode)
                        .to(__.node(Types.LOCATION)).output();

                String locationResults = dslClient.query(Format.RESOURCE, new DSLQuery(locationBuilder.build()));

                Results<Map<String, Location>> locationResultsFromJson = mapper.readValue(locationResults,
                        new TypeReference<Results<Map<String, Location>>>() {
                        });

                for (Map<String, Location> m : locationResultsFromJson.getResult()) {
                    location = m.get("location");
                }

                deviceLocationObject.put(deviceId, location);
            }

            return ResponseEntity.ok(deviceLocationObject);
        }
        return new ResponseEntity<>(deviceLocationObject, HttpStatus.BAD_REQUEST);
    }

    @PutMapping("/{siteId}/device")
    public ResponseEntity<String> addDevices(@PathVariable String siteId, @RequestBody JSONObject deviceLocationObject)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", null, "Site", siteId);

        Set<String> locationIdSet = deviceLocationObject.keySet();
        List<String> locationIds = new ArrayList<String>();
        locationIds.addAll(locationIdSet);

        for (String locationId : locationIds) {
            String deviceId = (String) deviceLocationObject.get(locationId);
            resourceMetadata.setResourceId(deviceId);

            AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId));

            AAIResourceUri locationUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().site(siteId).location(locationId));
            AAIResourceUri deviceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

            if (rClient.exists(siteUri)) {
                if (rClient.exists(deviceUri)) {
                    if (rClient.exists(locationUri)) {
                        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction()
                                .connect(siteUri, deviceUri).connect(deviceUri, locationUri);
                        transactionClient.execute();
                        description = deviceId + " Device added to " + siteId + " Site at Location " + locationId;
                        eventStatus = true;
                        reqStatus = HttpStatus.OK;
                        auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                                NoaEvents.ADD_DEVICE_TO_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    } else {
                        description = locationId + " Location Doesn't Exists.";
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                                NoaEvents.ADD_DEVICE_TO_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                        return new ResponseEntity<>(description, reqStatus);
                    }
                } else {
                    description = deviceId + " Device Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                            NoaEvents.ADD_DEVICE_TO_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return new ResponseEntity<>(description, reqStatus);
                }
            } else {
                description = siteId + " Site Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Service Management", "Sites",
                        NoaEvents.ADD_DEVICE_TO_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return new ResponseEntity<>(description, reqStatus);
            }
        }
        return ResponseEntity.ok("Devices Added to Site");
    }

    @DeleteMapping("/{siteId}/device")
    public ResponseEntity<String> removeDevices(@PathVariable String siteId,
            @RequestBody JSONObject deviceLocationObject) throws BulkProcessFailed {

        Set<String> deviceIdsSet = deviceLocationObject.keySet();
        List<String> deviceIds = new ArrayList<String>();
        deviceIds.addAll(deviceIdsSet);

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String deviceId : deviceIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", null, "Site",
                    siteId);
            resourceMetadata.setResourceId(deviceId);

            AAIResourceUri siteUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().site(siteId));
            String locationId = (String) deviceLocationObject.get(deviceId);
            AAIResourceUri locationUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().site(siteId).location(locationId));
            AAIResourceUri deviceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

            if (rClient.exists(siteUri)) {
                if (rClient.exists(deviceUri)) {
                    if (rClient.exists(locationUri)) {
                        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction()
                                .disconnect(siteUri, deviceUri).disconnect(deviceUri, locationUri);
                        transactionClient.execute();

                        description = "Removed " + deviceId + " Device from " + siteId + " Site.";
                        eventStatus = true;
                        reqStatus = HttpStatus.NO_CONTENT;
                        auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                                NoaEvents.REMOVE_DEVICE_FROM_SITE.getEvent(), eventStatus, null, resourceMetadata,
                                auth);
                    } else {
                        description = locationId + " Location Doesn't Exist.";
                        eventStatus = false;
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                                NoaEvents.REMOVE_DEVICE_FROM_SITE.getEvent(), eventStatus, null, resourceMetadata,
                                auth);
                        return new ResponseEntity<>(description, reqStatus);
                    }
                } else {
                    description = deviceId + " Device Doesn't Exist.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                            NoaEvents.REMOVE_DEVICE_FROM_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return new ResponseEntity<>(description, reqStatus);
                }
            } else {
                description = siteId + " Site Doesn't Exist.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Service Management", "Site",
                        NoaEvents.REMOVE_DEVICE_FROM_SITE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return new ResponseEntity<>(description, reqStatus);
            }
        }
        return ResponseEntity.ok("Devices Removed from Site");

    }

}
