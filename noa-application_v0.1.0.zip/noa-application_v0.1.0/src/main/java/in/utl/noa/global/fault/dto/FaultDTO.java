package in.utl.noa.global.fault.dto;

import java.util.Date;

public class FaultDTO {

	private int faultId;

	private String faultCode;

	private String faultContent;

	private Date timeOfDay;

	private String systemId;

	public char status;

	private String clearedBy;

	private String siteId;

	public int getFaultId() {
		return faultId;
	}

	public void setFaultId(int faultId) {
		this.faultId = faultId;
	}

	public String getFaultCode() {
		return faultCode;
	}

	public void setFaultCode(String faultCode) {
		this.faultCode = faultCode;
	}

	public String getFaultContent() {
		return faultContent;
	}

	public void setFaultContent(String faultContent) {
		this.faultContent = faultContent;
	}

	public Date getTimeOfDay() {
		return timeOfDay;
	}

	public void setTimeOfDay(Date timeOfDay) {
		this.timeOfDay = timeOfDay;
	}

	public String getSystemId() {
		return systemId;
	}

	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}

	public char getStatus() {
		return status;
	}

	public void setStatus(char status) {
		this.status = status;
	}

	public String getClearedBy() {
		return clearedBy;
	}

	public void setClearedBy(String clearedBy) {
		this.clearedBy = clearedBy;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	@Override
	public String toString() {
		return "FaultDTO [faultId=" + faultId + ", faultCode=" + faultCode + ", faultContent=" + faultContent
				+ ", timeOfDay=" + timeOfDay + ", systemId=" + systemId + ", status=" + status + ", clearedBy="
				+ clearedBy + ", siteId=" + siteId + "]";
	}

}
