package in.utl.noa.network.l2;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.security.audit.AuditLogger;

import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/network/{networkId}/lsp")
public class LspManagement {
    private static Logger logger = Logger.getLogger(LspManagement.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    @GetMapping()
    public ResponseEntity<List<Lsp>> getLsps(@PathVariable("networkId") String networkId) {

        List<Lsp> lsps = new ArrayList<Lsp>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);
        if (rClient.exists(networkUri)) {
            IetfNetwork network = new IetfNetwork();
            network = rClient.get(IetfNetwork.class, networkUri).get();
            if (network.getLsps() != null) {
                lsps = network.getLsps().getLsp();
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(lsps);
    }

    @GetMapping(value = "/filter")
    public ResponseEntity<ResponseDataDTO> getLspFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "lsp");

        Map<String, Object> columns = new HashMap<>();
        columns.put("lspName", "LSP Name");
        columns.put("sourceElement", "Source Element");
        columns.put("sourceInterface", "Source Endpoint");
        columns.put("destinationElement", "Destination Element");
        columns.put("destinationInterface", "Destination Interface");
        columns.put("lspStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getLspList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject lsps = filterService.queryByFilter(requestBody, "lsp");
        return ResponseEntity.status(HttpStatus.OK).body(lsps);
    }

    @GetMapping(value = "/{lspId}")
    public ResponseEntity<Lsp> getLsp(@PathVariable("networkId") String networkId,
            @PathVariable("lspId") String lspId) {

        Lsp lsp = new Lsp();
        AAIResourceUri lspUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).lsp(lspId));
        if (rClient.exists(lspUri)) {
            lsp = rClient.get(Lsp.class, lspUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(lsp);
    }

    @PostMapping("/exists")
    public ResponseEntity<Boolean> checkLspExistence(@PathVariable("networkId") String networkId,
            @RequestBody JSONObject srcDest) throws ParseException {

        String srcElement = srcDest.get("sourceElement").toString();
        String srcInterface = srcDest.get("sourceInterface").toString();
        String destElement = srcDest.get("destinationElement").toString();
        String destInterface = srcDest.get("destinationInterface").toString();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.LSP, __.key("source-element", srcElement), __.key("source-interface", srcInterface),
                        __.key("destination-element", destElement), __.key("destination-interface", destInterface)))
                .output();

        String results = dslClient.query(Format.COUNT, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        JSONObject countObj = (JSONObject) resultsArray.get(0).get("lsp");

        Boolean exists = false;
        if (countObj != null) {
            exists = true;
        }

        return ResponseEntity.status(HttpStatus.OK).body(exists);
    }

    @PutMapping()
    public ResponseEntity<String> addLspToNetwork(@PathVariable("networkId") String networkId, @RequestBody Lsp lspBody)
            throws BulkProcessFailed, JsonProcessingException {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String lspId = UUID.randomUUID().toString();
        lspBody.setLspId(lspId);
        lspBody.setLspStatus(true);

        logger.info(lspBody.toString());
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));
        if (rClient.exists(networkUri)) {
            AAIResourceUri lspUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).lsp(lspId));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(lspUri, lspBody);

            transactions.execute();
        }
        description = lspBody.getLspName() + " LSP has been Created.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.ADD_LSP_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> removeLspsFromNetwork(@PathVariable("networkId") String networkId,
            @RequestBody List<String> lspIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        for (String lspId : lspIds) {
            resourceMetadata.setResourceId(lspId);
            if (networkId != null && lspId != null) {
                AAIResourceUri lspUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).lsp(lspId));
                if (rClient.exists(lspUri)) {
                    AAITransactionalClient transactions = rClient.beginTransaction().delete(lspUri);
                    transactions.execute();
                    description = lspId + " LSP has been Removed from " + networkId + " Network";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_LSP_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = lspId + "Link Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_LSP_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null LSP Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.REMOVE_LSP_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Links have been Removed.");
    }
}
