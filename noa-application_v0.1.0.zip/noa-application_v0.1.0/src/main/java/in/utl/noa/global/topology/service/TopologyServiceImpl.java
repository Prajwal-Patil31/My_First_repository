package in.utl.noa.global.topology.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.Lsp;
import org.onap.aai.domain.yang.NNode;
import org.onap.aai.domain.yang.Route;
import org.onap.aai.domain.yang.SupportingNetwork;
import org.onap.aai.domain.yang.IetfNetwork;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.platform.config.service.RollbackHandler;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;

@Service
public class TopologyServiceImpl implements TopologyService {

    private static Logger logger = Logger.getLogger(TopologyServiceImpl.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    private ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public TopologyServiceImpl() {
        super();
    }

    @Override
    public Map<String, List<JSONObject>> convertResultsToTopologyData(List<Object> topologyResults,
            RequestBodyDTO requestBody, String vertexName) {
        JSONObject networkFilters = (JSONObject) requestBody.getFilters().get(vertexName);
        Map<String, List<JSONObject>> topologyObject = new HashMap<String, List<JSONObject>>();

        List<IetfNetwork> filteredNetworksList = new ArrayList<IetfNetwork>();
        List<NNode> filteredNodesList = new ArrayList<NNode>();
        List<Link> filteredLinksList = new ArrayList<Link>();
        List<Lsp> filteredLspsList = new ArrayList<Lsp>();
        List<Route> filteredRoutesList = new ArrayList<Route>();

        List<IetfNetwork> servicesList = new ArrayList<IetfNetwork>();

        List<String> nodeIds = new ArrayList<String>();
        List<String> linkIds = new ArrayList<String>();
        ;
        List<String> lspIds = new ArrayList<String>();
        ;
        List<String> routeIds = new ArrayList<String>();
        ;

        for (Object topologyResult : topologyResults) {
            if (topologyResult instanceof IetfNetwork) {
                filteredNetworksList.add((IetfNetwork) topologyResult);
            } else if (topologyResult instanceof NNode) {
                NNode node = (NNode) topologyResult;
                if (!nodeIds.contains(node.getNodeName())) {
                    filteredNodesList.add(node);
                    nodeIds.add(node.getNodeName());
                }
            } else if (topologyResult instanceof Link) {
                Link link = (Link) topologyResult;
                if (!linkIds.contains(link.getLinkName())) {
                    filteredLinksList.add(link);
                    linkIds.add(link.getLinkName());
                }
            } else if (topologyResult instanceof Lsp) {
                Lsp lsp = (Lsp) topologyResult;
                if (!linkIds.contains(lsp.getLspName())) {
                    filteredLspsList.add(lsp);
                    lspIds.add(lsp.getLspName());
                }
            } else if (topologyResult instanceof Route) {
                Route route = (Route) topologyResult;
                if (!linkIds.contains(route.getRouteName())) {
                    filteredRoutesList.add(route);
                    routeIds.add(route.getRouteName());
                }
            }
        }

        List<NNode> networkNodes = new ArrayList<NNode>();

        List<JSONObject> nodes = new ArrayList<JSONObject>();
        List<JSONObject> links = new ArrayList<JSONObject>();
        List<JSONObject> nodeSets = new ArrayList<JSONObject>();

        for (IetfNetwork network : filteredNetworksList) {
            JSONObject networkObj = new JSONObject();

            networkObj.put("id", network.getNetworkId());
            networkObj.put("type", "nodeSet");
            networkObj.put("name", network.getNetworkName());
            if (network.isNetworkStatus() == null || network.isNetworkStatus() == true) {
                networkObj.put("color", "#0how00");
            } else {
                networkObj.put("color", "#FF0000");
            }

            if (network.getNNodes() != null) {
                networkNodes.addAll(network.getNNodes().getNNode());
            }

            List<String> nodesList = new ArrayList<String>();
            for (NNode node : networkNodes) {
                String nodeId = node.getNodeName();
                if (networkFilters != null) {
                    if (networkFilters.containsKey("topology:n-node")) {
                        if (nodeIds.contains(nodeId)) {
                            nodesList.add(nodeId);
                        }
                    } else {
                        nodesList.add(nodeId);
                    }
                } else {
                    nodesList.add(nodeId);
                }
            }
            networkObj.put("nodes", nodesList);
            nodeSets.add(networkObj);

            for (NNode node : filteredNodesList) {
                JSONObject nodeObject = new JSONObject();
                nodeObject.put("id", node.getNodeId());
                nodeObject.put("name", node.getNodeName());
                nodeObject.put("role", "node");
                nodeObject.put("iconType", "router");
                nodeObject.put("color", "#0how00");
                if (node.isNodeStatus() == null || node.isNodeStatus() == true) {
                    nodeObject.put("color", "#0how00");
                } else {
                    nodeObject.put("color", "#FF0000");
                }
                nodes.add(nodeObject);
            }

            for (Link networkLink : filteredLinksList) {
                JSONObject link = new JSONObject();
                link.put("id", networkLink.getLinkId());
                link.put("label", networkLink.getLinkName());
                link.put("source", networkLink.getSourceNode());
                link.put("type", "link");
                link.put("sourceInt", networkLink.getSourceEndpoint());
                link.put("destinationInt", networkLink.getDestinationEndpoint());
                link.put("target", networkLink.getDestinationNode());
                links.add(link);
            }

            for (Lsp networkLsp : filteredLspsList) {
                JSONObject lsp = new JSONObject();
                lsp.put("id", networkLsp.getLspId());
                lsp.put("label", networkLsp.getLspName());
                lsp.put("source", networkLsp.getSourceElement());
                lsp.put("type", "route");
                lsp.put("sourceIp", networkLsp.getSourceInterface());
                lsp.put("destinationIp", networkLsp.getDestinationInterface());
                lsp.put("target", networkLsp.getDestinationElement());
                links.add(lsp);
            }

            for (Route networkRoute : filteredRoutesList) {
                JSONObject route = new JSONObject();
                route.put("id", networkRoute.getRouteId());
                route.put("label", networkRoute.getRouteName());
                route.put("source", networkRoute.getSourceElement());
                route.put("type", "route");
                route.put("sourceIp", networkRoute.getLocalAddress());
                route.put("destinationIp", networkRoute.getNexthopAddress());
                route.put("target", networkRoute.getDestinationElement());
                links.add(route);
            }

            topologyObject.put("nodes", nodes);
            topologyObject.put("links", links);
            topologyObject.put("nodeSets", nodeSets);
        }
        return topologyObject;
    }

    public Map<String, JSONObject> convertToTopologyObjects(List<IetfNetwork> networksList, RequestBodyDTO requestBody,
            String vertexName, List<String> nodeIds) {
        JSONObject networkFilters = (JSONObject) requestBody.getFilters().get(vertexName);
        Map<String, JSONObject> networkTypeObjects = new HashMap<>();

        if (networkFilters.get("network-type") != null) {
            List<String> networkTypes = (List<String>) networkFilters.get("network-type");
            for (String networkType : networkTypes) {
                Map<String, List<Object>> networkTypeObject = new HashMap<>();
                networkTypeObject.put("nodes", new ArrayList<>());
                networkTypeObject.put("links", new ArrayList<>());
                networkTypeObject.put("networks", new ArrayList<>());
                networkTypeObjects.put(networkType, new JSONObject(networkTypeObject));
            }
        }

        Map<String, List<String>> networkTypeNodes = new HashMap<>();
        Map<String, String> networkTypesMap = new HashMap<>();
        Map<String, List<String>> baseNetworksMap = new HashMap<>();
        List<String> parentBaseNetworkIds = new ArrayList<>();

        for (IetfNetwork network : networksList) {
            String networkId = network.getNetworkId();
            String networkType = network.getNetworkType();

            if (networkTypeNodes.get(networkType) == null) {
                networkTypeNodes.put(networkType, new ArrayList<>());
            }

            JSONObject networkObj = new JSONObject();
            networkObj.put("id", network.getNetworkId());
            networkObj.put("type", "nodeSet");
            networkObj.put("name", network.getNetworkName());
            if (network.isNetworkStatus() == null || network.isNetworkStatus() == true) {
                networkObj.put("color", "#0how00");
            } else {
                networkObj.put("color", "#FF0000");
            }

            List<String> nNodeIds = new ArrayList<String>();
            List<JSONObject> nodeObjects = new ArrayList<>();
            List<NNode> filteredNodes = new ArrayList<>();

            if (network.getNNodes() != null) {
                List<NNode> nNodes = network.getNNodes().getNNode();

                if (nNodes != null) {
                    for (NNode node : nNodes) {
                        String nodeId = node.getNodeName();
                        if (networkFilters != null) {
                            if (networkFilters.containsKey("topology:n-node")) {
                                if (nodeIds.contains(nodeId)) {
                                    nNodeIds.add(nodeId);
                                    filteredNodes.add(node);
                                }
                            } else {
                                nNodeIds.add(nodeId);
                                if (!networkTypeNodes.get(networkType).contains(nodeId)) {
                                    networkTypeNodes.get(networkType).add(nodeId);
                                    filteredNodes.add(node);
                                }
                            }
                        } else {
                            nNodeIds.add(nodeId);
                            if (!networkTypeNodes.get(networkType).contains(nodeId)) {
                                networkTypeNodes.get(networkType).add(nodeId);
                                filteredNodes.add(node);
                            }
                        }
                    }
                }
            }

            convertToTopologyNodes(filteredNodes, nodeObjects);
            networkObj.put("nodes", nNodeIds);

            networkTypesMap.put(networkId, networkType);

            if (networkTypeObjects.get(networkType) != null) {
                ((List<JSONObject>) networkTypeObjects.get(networkType).get("nodes")).addAll(nodeObjects);
                ((List<JSONObject>) networkTypeObjects.get(networkType).get("networks")).add(networkObj);
            }
        }

        RequestBodyDTO baseNetworksRequestBody = new RequestBodyDTO();
        Map<String, JSONObject> filters = new HashMap<>();
        JSONObject filterObject = new JSONObject();
        filterObject.put("network-id", parentBaseNetworkIds);
        filters.put("ietf-network", filterObject);

        baseNetworksRequestBody.setFilters(filters);

        List<Object> baseNetworksResults = new ArrayList<>();

        if (parentBaseNetworkIds.size() > 0) {
            baseNetworksResults = filterService.performQueryClientFilter(baseNetworksRequestBody);
        }

        for (Object baseNetworkObject : baseNetworksResults) {
            if (baseNetworkObject instanceof IetfNetwork) {
                IetfNetwork baseNetwork = (IetfNetwork) baseNetworkObject;
                String baseNetworkId = baseNetwork.getNetworkId();
                String baseNetworkType = baseNetwork.getNetworkType();

                networkTypesMap.put(baseNetworkId, baseNetworkType);

                if (!baseNetworksMap.keySet().contains(baseNetworkId)) {
                    baseNetworksMap.put(baseNetworkId, new ArrayList<>());
                }
                if (baseNetwork.getSupportingNetworks() != null) {
                    List<SupportingNetwork> childBaseNetworks = baseNetwork.getSupportingNetworks()
                            .getSupportingNetwork();

                    for (SupportingNetwork childBaseNetwork : childBaseNetworks) {
                        String childBaseNetworkId = childBaseNetwork.getNetworkId();
                        String childBaseNetworkType = "L1 Network";
                        if (!networkTypesMap.keySet().contains(childBaseNetworkId)) {
                            networkTypesMap.put(childBaseNetworkId, childBaseNetworkType);
                        }
                        baseNetworksMap.get(baseNetworkId).add(childBaseNetworkId);
                    }
                }
            }
        }

        Set<String> allNetworkIds = networkTypesMap.keySet();
        List<JSONObject> hierarchicalNodes = new ArrayList<>();

        for (var networkId : allNetworkIds) {
            JSONObject nodeObject = new JSONObject();
            nodeObject.put("id", networkId);
            nodeObject.put("name", networkId);
            nodeObject.put("role", networkTypesMap.get(networkId));
            nodeObject.put("iconType", "router");
            nodeObject.put("color", "#0how00");
            hierarchicalNodes.add(nodeObject);
        }

        Set<String> baseNetworkIds = baseNetworksMap.keySet();
        List<JSONObject> hierarchicalLinks = new ArrayList<>();

        for (var baseNetworkId : baseNetworkIds) {
            JSONObject sourceDest = new JSONObject();
            String source = baseNetworkId;
            for (String destination : baseNetworksMap.get(baseNetworkId)) {
                sourceDest.put("id", source + ":" + destination);
                sourceDest.put("name", source + ":" + destination);
                sourceDest.put("source", source);
                sourceDest.put("target", destination);
                hierarchicalLinks.add(sourceDest);
            }
        }

        JSONObject hierarchicalObject = new JSONObject();
        hierarchicalObject.put("nodes", hierarchicalNodes);
        hierarchicalObject.put("links", hierarchicalLinks);

        networkTypeObjects.put("hierarchy", hierarchicalObject);

        return networkTypeObjects;
    }

    public void convertToTopologyNodes(List<NNode> nodesList, List<JSONObject> nodeObjects) {
        for (NNode node : nodesList) {
            JSONObject nodeObject = new JSONObject();
            nodeObject.put("id", node.getNodeId());
            nodeObject.put("name", node.getNodeName());
            nodeObject.put("role", "node");
            nodeObject.put("iconType", "router");
            nodeObject.put("color", "#0how00");
            if (node.isNodeStatus() == null || node.isNodeStatus() == true) {
                nodeObject.put("color", "#0how00");
            } else {
                nodeObject.put("color", "#FF0000");
            }
            nodeObjects.add(nodeObject);
        }
    }
}
