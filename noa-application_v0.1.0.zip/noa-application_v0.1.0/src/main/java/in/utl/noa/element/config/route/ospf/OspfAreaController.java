package in.utl.noa.element.config.route.ospf;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;
import org.onap.aai.domain.yang.EdgeRouter;
import org.onap.aai.domain.yang.EdgeRouters;
import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.Lsa;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.OspfArea;
import org.onap.aai.domain.yang.OspfAreaStats;
import org.onap.aai.domain.yang.OspfAreas;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/ospf-area")
public class OspfAreaController {
    private static Logger logger = Logger.getLogger(OspfAreaController.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<OspfArea>> getAreas() throws JsonMappingException, JsonProcessingException {
        List<OspfArea> areas = new ArrayList<OspfArea>();

        AAISimplePluralUri areaUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().ospfAreas());

        if (rClient.exists(areaUri)) {

            OspfAreas devicesList = rClient.get(OspfAreas.class, areaUri).get();

            areas = devicesList.getOspfArea();

            return ResponseEntity.status(HttpStatus.OK).body(areas);
        }
        return ResponseEntity.status(HttpStatus.OK).body(areas);
    }

    @GetMapping(value = "/{routerId}/available")
    public ResponseEntity<List<OspfArea>> getAvailableAreas(@PathVariable("routerId") String routerId)
            throws JsonMappingException, JsonProcessingException {
        List<OspfArea> allAreas = new ArrayList<OspfArea>();

        AAISimplePluralUri areaUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().ospfAreas());

        if (rClient.exists(areaUri)) {
            OspfAreas devicesList = rClient.get(OspfAreas.class, areaUri).get();
            allAreas = devicesList.getOspfArea();

            List<String> areaIds = new ArrayList<String>();

            DSLStartNode startNode = new DSLStartNode(Types.EDGE_ROUTER, __.key("router-id", routerId));
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.OSPF_AREA))
                    .output();

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, OspfArea>> resultsFromJson = mapper.readValue(results,
                    new TypeReference<Results<Map<String, OspfArea>>>() {
                    });

            for (Map<String, OspfArea> m : resultsFromJson.getResult()) {
                areaIds.add(m.get("ospf-area").getAreaId());
            }

            if (areaIds.size() > 0) {
                List<OspfArea> diffAreas = allAreas.stream().filter(area -> areaIds.contains(area.getAreaId()))
                        .collect(Collectors.toList());

                allAreas.removeAll(diffAreas);
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(allAreas);
    }

    @GetMapping(value = "/{areaId}", produces = "application/json")
    public ResponseEntity<OspfArea> getArea(@PathVariable("areaId") String areaId)
            throws JsonMappingException, JsonProcessingException {

        OspfArea area = new OspfArea();

        AAIResourceUri areaUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().ospfArea(areaId))
                .depth(Depth.TWO);

        if (rClient.exists(areaUri)) {
            area = rClient.get(OspfArea.class, areaUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(area);
        }
        return ResponseEntity.status(HttpStatus.OK).body(area);
    }

    @PutMapping()
    public ResponseEntity<String> addArea(@RequestBody OspfArea newArea) throws BulkProcessFailed {

        String areaId = newArea.getAreaName();
        if (newArea.getAreaId() == null) {
            newArea.setAreaId(areaId);
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("OSPF Area", newArea.getAreaId(), null,
                null);

        if (newArea.getDfInfOriginate().equals("false") || newArea.getDfInfOriginate() == null) {
            newArea.setDfInfOriginate("disabled");
        } else {
            newArea.setDfInfOriginate("enabled");
        }

        AAIResourceUri areaUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().ospfArea(newArea.getAreaId()));

        if (!rClient.exists(areaUri)) {
            OspfAreaStats areaStats = new OspfAreaStats();
            areaStats.setStatsId(newArea.getAreaId());
            areaStats.setIfCount(12);
            areaStats.setNetCount(20);
            areaStats.setNssaTranslatorEvents(56);
            areaStats.setNssaTranslatorState("enabled");
            areaStats.setRtrCount(20);

            AAITransactionalClient transactions;

            AAIResourceUri areaStatsUri = AAIUriFactory.createResourceUri(
                    AAIFluentTypeBuilder.device().ospfArea(newArea.getAreaId()).ospfAreaStats(newArea.getAreaId()));

            transactions = rClient.beginTransaction().create(areaUri, newArea).create(areaStatsUri, areaStats);
            transactions.execute();
            description = newArea.getAreaId() + " Area Created Successfully.";
            eventStatus = true;
            reqStatus = HttpStatus.CREATED;
        } else {
            description = newArea.getAreaId() + " Already Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                NoaEvents.CREATE_OSPF_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PatchMapping(value = "/{areaId}")
    public ResponseEntity<String> updateArea(@PathVariable("areaId") String areaId, @RequestBody OspfArea newArea)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("OSPF Area", areaId, null, null);

        AAIResourceUri areaUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().ospfArea(areaId));

        if (areaId != null) {
            if (rClient.exists(areaUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().create(areaUri, newArea);

                transactions.execute();
                description = areaId + " Area Updated Successfully.";
                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = areaId + " Area Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Area Id";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                NoaEvents.MODIFY_OSPF_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteAreas(@RequestBody List<String> areaIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String areaId : areaIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("OSPF Area", areaId, null, null);
            if (areaId != null) {
                AAIResourceUri areaUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.device().ospfArea(areaId));
                if (rClient.exists(areaUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(areaUri);
                    transactions.execute();
                    description = areaId + " Area Deleted Successfully.";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                            NoaEvents.DELETE_OSPF_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = areaId + " Area Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                            NoaEvents.DELETE_OSPF_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Area Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                        NoaEvents.DELETE_OSPF_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Areas have been Deleted.");
    }

    @PostMapping(value = "/{areaId}/router")
    public ResponseEntity<String> addRoutersToArea(@PathVariable("areaId") String areaId,
            @RequestBody List<String> routerIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        AAIResourceUri areaUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().ospfArea(areaId));

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", null, "OSPF Area",
                areaId);
        if (areaId != null) {
            if (rClient.exists(areaUri)) {
                for (String routerId : routerIds) {
                    resourceMetadata.setResourceId(routerId);
                    AAIResourceUri edgeRouterUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.device().edgeRouter(routerId));
                    AAITransactionalClient transactions;
                    AAITransactionalClient lsaTransactions;

                    transactions = rClient.beginTransaction().connect(areaUri, edgeRouterUri);
                    transactions.execute();
                    description = routerId + " Edge Router Added to " + areaId + " Area";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                            NoaEvents.ADD_ROUTER_TO_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);

                    NetworkDevice device = new NetworkDevice();
                    AAIResourceUri deviceUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(routerId)).depth(Depth.TWO);
                    device = rClient.get(NetworkDevice.class, deviceUri).get();

                    List<IetfInterface> ietfInterfaces = new ArrayList<IetfInterface>();
                    if (device.getIetfInterfaces() != null) {
                        ietfInterfaces = device.getIetfInterfaces().getIetfInterface();
                    }

                    for (int i = 0; i < ietfInterfaces.size(); i++) {
                        IetfInterface ietfInterface = ietfInterfaces.get(i);
                        String ipAddress = ietfInterface.getIpAddress();
                        Lsa lsa = new Lsa();
                        lsa.setLsaType("router-lsa");
                        lsa.setIpAddress(ipAddress);
                        lsa.setLsaName(ietfInterface.getInterfaceName());
                        lsa.setLsaId(ietfInterface.getInterfaceId());
                        lsa.setRouterId(routerId);
                        lsa.setOpaqueType(10);
                        lsa.setContextId(11);

                        AAIResourceUri lsaUri = AAIUriFactory.createResourceUri(
                                AAIFluentTypeBuilder.device().edgeRouter(routerId).lsa(lsa.getLsaId()));

                        if (!rClient.exists(lsaUri)) {
                            lsaTransactions = rClient.beginTransaction().create(lsaUri, lsa).connect(lsaUri, areaUri);
                            lsaTransactions.execute();
                        }
                    }
                }

                return ResponseEntity.status(HttpStatus.OK).body("Area has been Updated.");
            } else {
                description = areaId + " Area Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                        NoaEvents.ADD_ROUTER_TO_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        } else {
            description = "Received Null Area Id";
            auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                    NoaEvents.ADD_ROUTER_TO_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body(description);
        }
    }

    @DeleteMapping(value = "/{areaId}/router", produces = "application/json")
    public ResponseEntity<String> removeAttachedRouters(@PathVariable("areaId") String areaId,
            @RequestBody List<String> routerIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Device", null, "OSPF Area",
                areaId);

        if (areaId != null) {
            AAIResourceUri areaUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().ospfArea(areaId));
            if (rClient.exists(areaUri)) {
                for (String routerId : routerIds) {
                    resourceMetadata.setResourceId(routerId);
                    AAIResourceUri edgeRouterUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.device().edgeRouter(routerId));
                    AAITransactionalClient transactions;

                    transactions = rClient.beginTransaction().disconnect(areaUri, edgeRouterUri);
                    transactions.execute();
                    description = "Received Null Area Id";
                    reqStatus = HttpStatus.OK;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                            NoaEvents.REMOVE_ROUTER_FROM_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
                }
                return ResponseEntity.status(HttpStatus.OK).body("Selected Routers have been Removed from Area.");
            } else {
                description = "Received Null Area Id";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Area Id";
        }
        auditLogger.addAuditLog(rClient, description, "Service Management", "OSPF Area",
                NoaEvents.REMOVE_ROUTER_FROM_AREA.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Received Null Area Id.");
    }

    @GetMapping(value = "/{areaId}/attached-router", produces = "application/json")
    public ResponseEntity<List<EdgeRouter>> getAttachedRouters(@PathVariable("areaId") String areaId)
            throws JsonMappingException, JsonProcessingException {

        List<EdgeRouter> attachedRouters = new ArrayList<EdgeRouter>();

        DSLStartNode startNode = new DSLStartNode(Types.OSPF_AREA, __.key("area-id", areaId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.EDGE_ROUTER))
                .output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, EdgeRouter>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, EdgeRouter>>>() {
                });

        for (Map<String, EdgeRouter> m : resultsFromJson.getResult()) {
            attachedRouters.add(m.get("edge-router"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(attachedRouters);
    }

    @GetMapping(value = "/{areaId}/available-router", produces = "application/json")
    public ResponseEntity<List<EdgeRouter>> getAvailableRouters(@PathVariable("areaId") String areaId)
            throws JsonMappingException, JsonProcessingException {

        List<EdgeRouter> availableRouters = new ArrayList<EdgeRouter>();
        List<String> routerIds = new ArrayList<String>();

        AAIPluralResourceUri routersUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().edgeRouters())
                .depth(Depth.TWO);

        EdgeRouters edgeRouters = rClient.get(EdgeRouters.class, routersUri).get();
        availableRouters = edgeRouters.getEdgeRouter();

        DSLStartNode startNode = new DSLStartNode(Types.OSPF_AREA, __.key("area-id", areaId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.EDGE_ROUTER))
                .output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, EdgeRouter>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, EdgeRouter>>>() {
                });

        for (Map<String, EdgeRouter> m : resultsFromJson.getResult()) {
            routerIds.add(m.get("edge-router").getRouterId());
        }

        if (routerIds.size() > 0) {
            List<EdgeRouter> diffRouters = availableRouters.stream().filter(d -> routerIds.contains(d.getRouterId()))
                    .collect(Collectors.toList());

            availableRouters.removeAll(diffRouters);
        }

        return ResponseEntity.status(HttpStatus.OK).body(availableRouters);
    }

    @GetMapping(value = "/{areaId}/lsa-db", produces = "application/json")
    public ResponseEntity<List<Lsa>> getLsaDb(@PathVariable("areaId") String areaId)
            throws JsonMappingException, JsonProcessingException {

        List<Lsa> lsas = new ArrayList<Lsa>();

        DSLStartNode startNode = new DSLStartNode(Types.OSPF_AREA, __.key("area-id", areaId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.LSA)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Lsa>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Lsa>>>() {
                });

        for (Map<String, Lsa> m : resultsFromJson.getResult()) {
            lsas.add(m.get("lsa"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(lsas);
    }
}
