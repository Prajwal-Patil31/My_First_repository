package in.utl.noa.account.user;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aai.domain.yang.PasswordPolicy;
import org.onap.aai.domain.yang.AccessRole;
import org.onap.aai.domain.yang.Action;
import org.onap.aai.domain.yang.PasswordHistory;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.UserAccount;
import org.onap.aai.domain.yang.UserAccounts;
import org.onap.aai.domain.yang.UserPrivilege;
/* import org.onap.aai.domain.yang.UserPrivilege;
import org.onap.aai.domain.yang.UserPrivileges; */

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.AAIResultWrapper;
import org.onap.aaiclient.client.aai.entities.Relationships;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;

import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/platform/security/rbac/user")
public class UserController {
    private static Logger logger = Logger.getLogger(UserController.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    AuditLogger auditLogger = new AuditLogger();

    public static final PasswordEncoder PASSWORD_ENCODER = new BCryptPasswordEncoder();
    private static final String UPPERCASE_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE_LETTERS = UPPERCASE_LETTERS.toLowerCase();
    private static final String NUMBERS = "0123456789";
    private static final String SYMBOLS = "@.%$#*";

    private static final String ALL_DIGITS = UPPERCASE_LETTERS + LOWERCASE_LETTERS + NUMBERS + SYMBOLS;
    private static final int MAX_LENGTH = 7;

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public UserController() {
        super();
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getUserFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "user-account");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("userName", "User Name");
        columns.put("firstName", "First Name");
        columns.put("lastName", "Last Name");
        columns.put("accountType", "Account Type");
        columns.put("roleName", "Role");
        columns.put("policyName", "Password Policy");
        columns.put("status", "Account Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getUserList(@RequestBody RequestBodyDTO requestBody)
            throws JsonProcessingException, ParseException {
        JSONObject userAccounts = filterService.queryByFilter(requestBody, "user-account");
        return ResponseEntity.status(HttpStatus.OK).body(userAccounts);
    }

    @GetMapping()
    public ResponseEntity<List<UserAccount>> getUsers() {
        List<UserAccount> userAccountsList = new ArrayList<UserAccount>();
        AAIPluralResourceUri usersUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().userAccounts());
        if (rClient.exists(usersUri)) {
            Optional<UserAccounts> userAccounts = rClient.get(UserAccounts.class, usersUri);
            userAccountsList = userAccounts.get().getUserAccount();
        }
        return ResponseEntity.ok(userAccountsList);
    }

    @PostMapping("/mockdata")
    public ResponseEntity<String> addingMockData() throws BulkProcessFailed {
        List<UserAccount> userAccountsList = new ArrayList<UserAccount>();
        AAIPluralResourceUri usersUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().userAccounts());
        if (rClient.exists(usersUri)) {
            Optional<UserAccounts> userAccounts = rClient.get(UserAccounts.class, usersUri);
            userAccountsList = userAccounts.get().getUserAccount();
        }
        for (UserAccount account : userAccountsList) {
            account.setRoleName("NetworksAdmin");
            account.setPolicyName("DefaultPolicy");
            account.setUserType("Administrator");
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(account.getAccountId()));
            AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().update(userUri, account);

            transactionClient.execute();

        }
        return ResponseEntity.ok("userAccountsList");
    }

    @GetMapping("/{accountId}")
    public ResponseEntity<Optional<UserAccount>> getUser(@PathVariable("accountId") String accountId) {
        Optional<UserAccount> userAccount = null;
        if (accountId != null) {
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId)).depth(Depth.TWO);
            if (rClient.exists(userUri)) {
                userAccount = rClient.get(UserAccount.class, userUri);
            }
            return ResponseEntity.ok(userAccount);
        }
        return new ResponseEntity<>(userAccount, HttpStatus.BAD_REQUEST);
    }

    @PutMapping()
    public ResponseEntity<UserAccount> addUser(@RequestBody UserAccount userAccount)
            throws JsonMappingException, JsonProcessingException {
        String accountId = UUID.randomUUID().toString();
        userAccount.setAccountId(accountId);
        userAccount.setAccountStatus(true);
        userAccount.setUserType("Account");

        String encodedPassword = PASSWORD_ENCODER.encode(userAccount.getPassword());
        Date date = Calendar.getInstance().getTime();
        String timeStamp = DATE_FORMAT.format(date);

        userAccount.setPassword(encodedPassword);
        userAccount.setLatestPasswordTimeStamp(timeStamp);

        PasswordHistory passwordHistory = new PasswordHistory();
        passwordHistory.setOldPassword(encodedPassword);
        passwordHistory.setPosition(0);

        userAccount.getPasswordHistory().add(passwordHistory);

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null, null);

        if (accountId != null) {
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));

            if (!rClient.exists(userUri)) {
                AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().create(userUri,
                        userAccount);
                try {
                    transactionClient.execute();
                    description = "User with Username " + userAccount.getUserName() + " has been Created";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                } catch (Exception e) {
                    logger.info(e);
                }
            } else {
                description = "User with Username " + userAccount.getUserName() + " Already Exists.";
            }
        } else {
            description = "Received Null Account Id";
        }

        auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                NoaEvents.CREATE_USER_ACCOUNT.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(userAccount);
    }

    @GetMapping("/{accountId}/policy")
    public ResponseEntity<PasswordPolicy> getUserPasswordPolicy(@PathVariable("accountId") String accountId)
            throws ParseException, JsonMappingException, JsonProcessingException {
        PasswordPolicy userPolicy = new PasswordPolicy();

        DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT, __.key("account-id", accountId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.PASSWORD_POLICY))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject policyObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            userPolicy = mapper.readValue(policyObj.toString(), PasswordPolicy.class);
        }
        return ResponseEntity.status(HttpStatus.OK).body(userPolicy);
    }

    @PostMapping("/{accountId}/policy/{policyId}")
    public ResponseEntity<String> assignPasswordPolicy(@PathVariable("accountId") String accountId,
            @PathVariable("policyId") String policyId) throws BulkProcessFailed {

        AAIResourceUri policyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));

        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));

        AAITransactionalClient transactions;
        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();
        if (rClient.exists(userUri) && rClient.exists(policyUri)) {

            AAIResultWrapper resultWrapper = rClient.get(userUri);
            if (resultWrapper.hasRelationshipsTo(Types.PASSWORD_POLICY)) {
                Relationships relationships = resultWrapper.getRelationships().get();
                List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.PASSWORD_POLICY);
                for (int i = 0; i < allRelatedNodes.size(); i++) {
                    AAIResourceUri roleUriOld = allRelatedNodes.get(i);
                    transactionClient.disconnect(userUri, roleUriOld);
                    transactionClient.execute();
                }
            }

            transactions = rClient.beginTransaction().connect(userUri, policyUri);
            transactions.execute();
        }
        return ResponseEntity.status(HttpStatus.OK).body("Password Policy Assigned to User");
    }

    @PostMapping("/{accountId}")
    public ResponseEntity<UserAccount> modifyUser(@PathVariable("accountId") String accountId,
            @RequestBody UserAccount userAccount) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null, null);

        if (accountId != null) {
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
            if (rClient.exists(userUri)) {
                AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().create(userUri,
                        userAccount);
                try {
                    transactionClient.execute();
                    description = "User with Username " + userAccount.getUserName() + " has been Updated";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                } catch (Exception e) {
                    logger.info(e);
                }
            } else {
                description = "User with Username " + userAccount.getUserName() + " Doesn't Exists.";
            }
        } else {
            description = "Received Null Account Id";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                NoaEvents.MODIFY_USER_ACCOUNT.getEvent(), eventStatus, null, resourceMetadata, auth);

        return ResponseEntity.status(reqStatus).body(userAccount);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteUsers(@RequestBody List<String> accountIds) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String accountId : accountIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null,
                    null);
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
            if (rClient.exists(userUri)) {
                AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().delete(userUri);
                try {
                    transactionClient.execute();
                    description = "User with Username" + accountId + " has been Deleted";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                            NoaEvents.DELETE_USER_ACCOUNT.getEvent(), eventStatus, null, resourceMetadata, auth);
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            } else {
                description = "User with Username " + accountId + " Doesn't Exists";
                reqStatus = HttpStatus.BAD_REQUEST;
                eventStatus = false;
                auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                        NoaEvents.DELETE_USER_ACCOUNT.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body("User(" + accountId + ") Doesn't Exists.");
            }
        }
        return ResponseEntity.status(reqStatus).body("Users Deleted Successfully");
    }

    @DeleteMapping("/{accountId}")
    public ResponseEntity<String> deleteUser(@PathVariable("accountId") String accountId) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null, null);
        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
        if (rClient.exists(userUri)) {
            AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().delete(userUri);
            try {
                transactionClient.execute();
                description = "User with Username" + accountId + " has been Deleted";
                eventStatus = true;
                reqStatus = HttpStatus.NO_CONTENT;
                auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                        NoaEvents.DELETE_USER_ACCOUNT.getEvent(), eventStatus, null, resourceMetadata, auth);
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        } else {
            description = "User with Username " + accountId + " Doesn't Exists";
            reqStatus = HttpStatus.BAD_REQUEST;
            eventStatus = false;
            auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                    NoaEvents.DELETE_USER_ACCOUNT.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body("User(" + accountId + ") Doesn't Exists.");
        }

        return ResponseEntity.status(reqStatus).body("User Deleted Successfully");
    }

    @PostMapping("/{accountId}/change-password")
    public ResponseEntity<String> changePassword(@PathVariable("accountId") String accountId,
            @RequestBody String password) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null, null);
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        if (accountId != null) {
            return setPassordHistory(accountId, password, "Changed", resourceMetadata);
        } else {
            description = "Account Id is null";
            auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                    NoaEvents.CHANGE_PASSWORD.getEvent(), eventStatus, null, resourceMetadata, auth);

            return new ResponseEntity<>(description, reqStatus);
        }
    }

    @PostMapping("/{accountId}/default")
    public ResponseEntity<String> resetPassword(@PathVariable("accountId") String accountId) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("User Account", accountId, null, null);

        if (accountId != null) {
            Random rnd = new Random();

            StringBuilder randomPassword = new StringBuilder(MAX_LENGTH);
            for (int i = 0; i < MAX_LENGTH; i++) {
                randomPassword.append(ALL_DIGITS.charAt(rnd.nextInt(ALL_DIGITS.length())));
            }
            return setPassordHistory(accountId, randomPassword.toString(), "Reset", resourceMetadata);
        } else {
            description = "Account Id is null";
            auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                    NoaEvents.PASSWORD_RESET.getEvent(), eventStatus, null, resourceMetadata, auth);
            return new ResponseEntity<>(description, reqStatus);
        }
    }

    public ResponseEntity<String> setPassordHistory(String accountId, String password, String processType,
            ResourceMetadata resourceMetadata) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        AAIResourceUri userUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId))
                .depth(Depth.TWO);

        String encodedPassword = PASSWORD_ENCODER.encode(password);
        Date date = Calendar.getInstance().getTime();
        String timeStamp = DATE_FORMAT.format(date);

        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

        if (rClient.exists(userUri)) {
            UserAccount userAccount = rClient.get(UserAccount.class, userUri).get();
            UserAccount userAccountCopy = rClient.get(UserAccount.class, userUri).get();

            final List<PasswordHistory> passwordHistoryList = userAccountCopy.getPasswordHistory();

            for (PasswordHistory oldPassword : passwordHistoryList) {
                if (PASSWORD_ENCODER.matches(password, oldPassword.getOldPassword())) {
                    return new ResponseEntity<>("Can't use Old Password", HttpStatus.BAD_REQUEST);
                }
            }

            int limit = 4;
            PasswordPolicy securityPolicy = new PasswordPolicy();

            AAIResultWrapper resultWrapper = rClient.get(userUri);
            if (resultWrapper.hasRelationshipsTo(Types.PASSWORD_POLICY)) {
                Relationships relationships = resultWrapper.getRelationships().get();
                List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.PASSWORD_POLICY);
                AAIResourceUri policyUri = allRelatedNodes.get(0);
                securityPolicy = rClient.get(PasswordPolicy.class, policyUri).get();
                limit = securityPolicy.getNumOldPassword();
            }

            Collections.sort(passwordHistoryList, new Comparator<PasswordHistory>() {
                @Override
                public int compare(PasswordHistory a, PasswordHistory b) {
                    Integer position1 = a.getPosition();
                    Integer position2 = b.getPosition();
                    return position1.compareTo(position2);
                }
            });

            userAccount.getPasswordHistory().clear();
            userAccount.getPasswordHistory().addAll(passwordHistoryList);

            if (passwordHistoryList.size() == limit) {
                String oldPassword = passwordHistoryList.get(0).getOldPassword();
                AAIResourceUri oldPasswordUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.business().userAccount(accountId).passwordHistory(oldPassword));

                transactionClient.delete(oldPasswordUri);
                passwordHistoryList.remove(0);
                userAccount.getPasswordHistory().remove(0);
            }

            for (int i = 0; i < passwordHistoryList.size(); i++) {
                PasswordHistory passwordHistory = passwordHistoryList.get(i);
                passwordHistory.setPosition(i);
            }

            PasswordHistory passwordHistory = new PasswordHistory();
            passwordHistory.setOldPassword(encodedPassword);
            passwordHistory.setPosition(passwordHistoryList.size());

            userAccount.setPassword(encodedPassword);
            userAccount.setLatestPasswordTimeStamp(timeStamp);
            userAccount.getPasswordHistory().add(passwordHistoryList.size(), passwordHistory);

            transactionClient.create(userUri, userAccount);

            try {
                transactionClient.execute();
                description = "Password " + processType + " Successfully.";
                eventStatus = true;
                reqStatus = HttpStatus.OK;
                auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                        NoaEvents.CHANGE_PASSWORD.getEvent(), eventStatus, null, resourceMetadata, auth);
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        } else {
            description = "User Not Found";
            auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                    NoaEvents.CHANGE_PASSWORD.getEvent(), eventStatus, null, resourceMetadata, auth);
            return new ResponseEntity<>(description, reqStatus);
        }
        return new ResponseEntity<>(description, reqStatus);
    }

    @GetMapping("/{accountId}/role")
    public ResponseEntity<Optional<AccessRole>> getRole(@PathVariable("accountId") String accountId) {
        Optional<AccessRole> accessRole = null;
        if (accountId != null) {
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
            if (rClient.exists(userUri)) {
                AAIResultWrapper resultWrapper = rClient.get(userUri);
                if (resultWrapper.hasRelationshipsTo(Types.ACCESS_ROLE)) {
                    Relationships relationships = resultWrapper.getRelationships().get();
                    List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.ACCESS_ROLE);
                    AAIResourceUri roleUri = allRelatedNodes.get(0);
                    accessRole = rClient.get(AccessRole.class, roleUri);
                }
                return ResponseEntity.ok(accessRole);
            }
            return new ResponseEntity<>(accessRole, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(accessRole, HttpStatus.BAD_REQUEST);
    }

    @PostMapping("/{accountId}/role/{roleId}")
    public ResponseEntity<String> assignRoleToUser(@PathVariable("accountId") String accountId,
            @PathVariable("roleId") String roleId, @RequestBody Map<String, List<String>> resourcesObj)
            throws BulkProcessFailed, JsonMappingException, JsonProcessingException, ParseException {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata(null, null, "User Group", accountId);

        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        AAITransactionalClient transactions;
        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

        if (rClient.exists(roleUri)) {
            AAIResultWrapper resultWrapper = rClient.get(userUri);
            if (resultWrapper.hasRelationshipsTo(Types.ACCESS_ROLE)) {
                Relationships relationships = resultWrapper.getRelationships().get();
                List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.ACCESS_ROLE);
                for (int i = 0; i < allRelatedNodes.size(); i++) {
                    AAIResourceUri roleUriOld = allRelatedNodes.get(i);
                    transactionClient.disconnect(userUri, roleUriOld);
                    transactionClient.execute();
                }
            }
            if (rClient.exists(userUri)) {
                resourceMetadata.setResourceType("Access Role");
                resourceMetadata.setResourceId(roleId);

                List<Action> actions = new ArrayList<Action>();

                DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
                DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                        .to(__.node(Types.ACTION, __.key("per-instance", true))).output();

                String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

                JSONParser parser = new JSONParser();
                JSONObject resultsJson = (JSONObject) parser.parse(results);
                List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

                for (int i = 0; i < resultsArray.size(); i++) {
                    JSONObject actionObj = (JSONObject) resultsArray.get(i).get("properties");
                    mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
                    Action actionBody = mapper.readValue(actionObj.toString(), Action.class);
                    actions.add(actionBody);
                }
                List<UserPrivilege> userPrivileges = new ArrayList<UserPrivilege>();

                if (resourcesObj != null) {
                    List<String> elementIds = resourcesObj.get("element");
                    List<String> serviceIds = resourcesObj.get("service");
                    List<String> networkIds = resourcesObj.get("network");

                    if (elementIds != null && elementIds.size() > 0) {
                        List<Action> elementActions = actions.stream()
                                .filter(action -> action.getRelatedFeature().equals("ElementManagement"))
                                .collect(Collectors.toList());

                        for (String elementId : elementIds) {
                            for (Action elementAction : elementActions) {
                                UserPrivilege userPrivilege = new UserPrivilege();
                                String grpPrivilegeId = UUID.randomUUID().toString();
                                userPrivilege.setPrivilegeId(grpPrivilegeId);
                                userPrivilege.setActionName(elementAction.getActionName());
                                userPrivilege.setActionCode(elementAction.getActionReference());
                                userPrivilege.setPrivilegeType("ElementManagement");
                                userPrivilege.setResource(elementAction.getResourceName());
                                userPrivilege.setResourceId(elementId);
                                userPrivileges.add(userPrivilege);
                            }
                        }
                    }

                    if (serviceIds != null && serviceIds.size() > 0) {
                        List<Action> serviceActions = actions.stream()
                                .filter(action -> action.getRelatedFeature().equals("ServiceManagement"))
                                .collect(Collectors.toList());

                        for (String serviceId : serviceIds) {
                            for (Action serviceAction : serviceActions) {
                                UserPrivilege userPrivilege = new UserPrivilege();
                                String grpPrivilegeId = UUID.randomUUID().toString();
                                userPrivilege.setPrivilegeId(grpPrivilegeId);
                                userPrivilege.setActionName(serviceAction.getActionName());
                                userPrivilege.setActionCode(serviceAction.getActionReference());
                                userPrivilege.setPrivilegeType("ServiceManagement");
                                userPrivilege.setResource(serviceAction.getResourceName());
                                userPrivilege.setResourceId(serviceId);
                                userPrivileges.add(userPrivilege);
                            }
                        }
                    }

                    if (networkIds != null && networkIds.size() > 0) {
                        List<Action> networkActions = actions.stream()
                                .filter(action -> action.getRelatedFeature().equals("NetworkManagement"))
                                .collect(Collectors.toList());

                        for (String networkId : networkIds) {
                            for (Action networkAction : networkActions) {
                                UserPrivilege userPrivilege = new UserPrivilege();
                                String grpPrivilegeId = UUID.randomUUID().toString();
                                userPrivilege.setPrivilegeId(grpPrivilegeId);
                                userPrivilege.setActionName(networkAction.getActionName());
                                userPrivilege.setActionCode(networkAction.getActionReference());
                                userPrivilege.setPrivilegeType("NetworkManagement");
                                userPrivilege.setResource(networkAction.getResourceName());
                                userPrivilege.setResourceId(networkId);
                                userPrivileges.add(userPrivilege);
                            }
                        }
                    }
                }

                transactions = rClient.beginTransaction().connect(userUri, roleUri);
                for (UserPrivilege privilege : userPrivileges) {
                    AAIResourceUri UserPrivilegeUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business()
                            .userAccount(accountId).userPrivilege(privilege.getPrivilegeId()));

                    transactions.create(UserPrivilegeUri, privilege);
                }

                transactions.execute();
                description = roleId + " Role Assigned to " + accountId + " User";
                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = accountId + " User Doesn't Exists";
            }
        } else {
            description = roleId + " Role Doesn't Exists";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                NoaEvents.ASSIGN_ROLE_TO_USER.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{accountId}/group")
    public ResponseEntity<List<String>> getGroups(@PathVariable("accountId") String accountId) throws ParseException {
        List<String> userGroups = new ArrayList<String>();

        DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT, __.key("account-id", accountId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.USER_GROUP))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject userGroupObj = (JSONObject) resultsArray.get(i).get("properties");
            String userGroupName = (String) userGroupObj.get("user-group-name");
            userGroups.add(userGroupName);
        }

        return ResponseEntity.status(HttpStatus.OK).body(userGroups);
    }

    @PostMapping("/{accountId}/group")
    public ResponseEntity<String> addToGroups(@PathVariable("accountId") String accountId,
            @RequestBody List<String> userGroupIds) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata(null, null, "User Account", accountId);
        if (rClient.exists(userUri)) {
            for (String userGroupId : userGroupIds) {

                resourceMetadata.setResourceType("User Group");
                resourceMetadata.setResourceId(userGroupId);
                AAIResourceUri groupUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));
                if (rClient.exists(groupUri)) {
                    transactionClient.connect(userUri, groupUri);
                    description = "User(" + accountId + ") Assigned to User Group(" + userGroupId + ").";
                    eventStatus = true;
                    reqStatus = HttpStatus.OK;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                            NoaEvents.ADD_USER_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = "User Group(" + userGroupId + ") Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                            NoaEvents.ADD_USER_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return new ResponseEntity<>("Group doesn't exist",reqStatus);
                }
            }
            try {
                transactionClient.execute();
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        } else {
            description = "User(" + accountId + ") Doesn't Exists.";
            auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                    NoaEvents.ADD_USER_TO_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
            return new ResponseEntity<>("User doesn't exist",reqStatus);
        }

        return new ResponseEntity<>("User Added to Groups",reqStatus);
    }

    @DeleteMapping("/{accountId}/group")
    public ResponseEntity<String> removeFromGroups(@PathVariable("accountId") String accountId,
            @RequestBody List<String> userGroupIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata(null, null, "User Account", accountId);

        if (accountId != null) {
            AAIResourceUri userUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));
            AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();
            Relationships userRelationships = rClient.get(userUri).getRelationships().get();

            if (rClient.exists(userUri)) {
                for (String userGroupId : userGroupIds) {
                    resourceMetadata.setResourceType("User Group");
                    resourceMetadata.setResourceId(userGroupId);

                    AAIResourceUri groupUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.business().userGroup(userGroupId));

                    if (userRelationships.getRelatedUris().contains(groupUri)) {
                        transactionClient.disconnect(userUri, groupUri);
                        description = "User(" + accountId + ") removed from User Group(" + userGroupId + ").";
                        reqStatus = HttpStatus.NO_CONTENT;
                        auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                                NoaEvents.REMOVE_USER_FROM_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata,
                                auth);
                    } else {
                        description = "Group(" + userGroupId + ") not related to User(" + accountId + ").";
                        reqStatus = HttpStatus.NOT_FOUND;
                        auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                                NoaEvents.REMOVE_USER_FROM_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata,
                                auth);
                        return new ResponseEntity<>(description, HttpStatus.NOT_FOUND);
                    }
                }
                transactionClient.execute();
            } else {
                description = "User doesn't exist";
                eventStatus = false;
                auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                        NoaEvents.REMOVE_USER_FROM_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
                return new ResponseEntity<>(description, HttpStatus.NOT_FOUND);
            }
        } else {
            description = "Account Id is Null";
            auditLogger.addAuditLog(rClient, description, "Security", "User Management",
                    NoaEvents.REMOVE_USER_FROM_USER_GROUP.getEvent(), eventStatus, null, resourceMetadata, auth);
            return new ResponseEntity<>(description, HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<>("User Removed from Groups", reqStatus);
    }
}
