package in.utl.noa.element.config.system;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.onap.aai.domain.yang.LoggingConfig;
import org.onap.aai.domain.yang.NetworkDevice;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/config/log")
public class LogConfig {
    private static Logger logger = Logger.getLogger(LogConfig.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<LoggingConfig> getDeviceLoggingConfig(@PathVariable("deviceId") String deviceId) {
        NetworkDevice device = new NetworkDevice();
        LoggingConfig loggingConfig = new LoggingConfig();

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);
        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            if (device.getLoggingConfig().size() > 0) {
                loggingConfig = device.getLoggingConfig().get(0);
            }
            return ResponseEntity.status(HttpStatus.OK).body(loggingConfig);
        }

        return ResponseEntity.status(HttpStatus.OK).body(loggingConfig);
    }

    @PostMapping()
    public ResponseEntity<String> updateDeviceLoggingConfig(@PathVariable("deviceId") String deviceId,
            @RequestBody LoggingConfig loggingConfig) throws BulkProcessFailed {

        AAIResourceUri logConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).loggingConfig(deviceId));

        if (loggingConfig.getConfigId() == null) {
            loggingConfig.setConfigId(deviceId);
        }

        AAITransactionalClient transactions = null;
        if (rClient.exists(logConfigUri)) {
            transactions = rClient.beginTransaction().update(logConfigUri, loggingConfig);
        } else {
            transactions = rClient.beginTransaction().create(logConfigUri, loggingConfig);
        }
        transactions.execute();

        return ResponseEntity.status(HttpStatus.OK).body("Logging Configuration has been Updated");
    }
}
