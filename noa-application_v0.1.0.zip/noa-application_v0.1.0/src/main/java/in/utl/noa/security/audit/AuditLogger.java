package in.utl.noa.security.audit;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.onap.aai.domain.yang.AccessMetadata;
import org.onap.aai.domain.yang.AuditLog;
import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.security.core.Authentication;

import in.utl.noa.account.user.model.User;

public class AuditLogger {
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    private static Logger logger = Logger.getLogger(AuditLogger.class);

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    public void addAuditLog(AAIResourcesClient rClient, String description, String category, String subCategory,
            String event, Boolean eventStatus, AccessMetadata accessMetadata, ResourceMetadata resourceMetadata,
            Authentication auth) {

        User user = null;
        String accountId = null;
        if (auth.getPrincipal() instanceof User) {
            user = (User) auth.getPrincipal();
            accountId = user.getUserName();
        } else {
            accountId = auth.getName();
        }

        AuditLog auditLog = new AuditLog();
        UUID uuid = UUID.randomUUID();

        Date date = Calendar.getInstance().getTime();
        String timeStamp = DATE_FORMAT.format(date);

        auditLog.setAuditId(uuid.toString());
        auditLog.setDescription(description);
        auditLog.setCategory(category);
        auditLog.setSubCategory(subCategory);
        auditLog.setAccountId(accountId);
        auditLog.setEventStatus(eventStatus);
        auditLog.setTimeStamp(timeStamp);
        auditLog.setEvent(event);

        AAITransactionalClient transactions;
        AAIResourceUri auditLogUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.platform().auditLog(auditLog.getAuditId()));

        transactions = rClient.beginTransaction().create(auditLogUri, auditLog);

        if (accessMetadata != null) {
            accessMetadata.setAuditId(auditLog.getAuditId());
            AAIResourceUri accessMetadataUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform()
                    .auditLog(auditLog.getAuditId()).accessMetadata(accessMetadata.getAuditId()));

            transactions.create(accessMetadataUri, accessMetadata);
        }

        if (resourceMetadata != null) {
            resourceMetadata.setAuditId(auditLog.getAuditId());

            AAIResourceUri resourceMetadataUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform()
                    .auditLog(auditLog.getAuditId()).resourceMetadata(resourceMetadata.getAuditId()));

            transactions.create(resourceMetadataUri, resourceMetadata);
        }

        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }

    public ResourceMetadata createResourceMetadata(String resourceType, String resourceId, String moduleType,
            String moduleId) {
        ResourceMetadata resourceMetadata = new ResourceMetadata();

        resourceMetadata.setResourceType(resourceType);
        resourceMetadata.setResourceId(resourceId);
        resourceMetadata.setModuleType(moduleType);
        resourceMetadata.setModuleId(moduleId);

        return resourceMetadata;
    }

    public AccessMetadata createAccessMetadata(String ipAddress) {

        AccessMetadata accessMetadata = new AccessMetadata();
        accessMetadata.setIpAddress(ipAddress);

        return accessMetadata;
    }
}
