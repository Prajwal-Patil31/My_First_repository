package in.utl.noa.security.session;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import org.apache.log4j.Logger;

import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.session.SessionInformation;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;

@RestController
@RequestMapping(value = "/api/platform/security/session")
public class UserSessionsController {
    private static Logger logger = Logger.getLogger(UserSessionsController.class);

    @Autowired
    SessionRegistry sessionRegistry;

    AuditLogger auditLogger = new AuditLogger();

    @Autowired
    SessionRegistryImpl sessionRegistryImpl;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    public UserSessionsController() {

    }

    @GetMapping()
    public ResponseEntity<List<SessionInformation>> getUsersFromSessionRegistry() {

        List<Object> users = sessionRegistryImpl.getAllPrincipals();
        List<SessionInformation> sessionIds = new ArrayList<>(users.size());

        if (users.size() > 0) {
            for (Object user : users) {
                List<SessionInformation> userSessions = sessionRegistryImpl.getAllSessions(user, false);
                if (userSessions.size() > 0) {
                    sessionIds.add(userSessions.get(0));
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body(sessionIds);
        } else {
            return ResponseEntity.status(HttpStatus.OK).body(sessionIds);
        }
    }

    @DeleteMapping()
    public ResponseEntity<String> removeSessionUsingSessionRegistry(@RequestBody List<String> sessionIds) {
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Session", null, null, null);
        for (String sessionId : sessionIds) {
            resourceMetadata.setResourceId(sessionId);
            if (sessionId != null) {
                sessionRegistryImpl.getSessionInformation(sessionId).expireNow();
                description = sessionId + " Session has been Terminated";
                eventStatus = true;
                reqStatus = HttpStatus.NO_CONTENT;
                auditLogger.addAuditLog(rClient, description, "Security", "Session Management",
                        NoaEvents.TERMINATE_SESSION.getEvent(), eventStatus, null, resourceMetadata, auth);
            } else {
                description = "Received Null Session Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Security", "Session Management",
                        NoaEvents.TERMINATE_SESSION.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Sessions Removed");
    }
}
