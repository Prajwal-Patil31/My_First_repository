package in.utl.noa.mdsal.toaster;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import in.utl.noa.util.SpringContext;
import org.json.JSONObject;
import org.opendaylight.yang.gen.v1.yang.noa.toaster.notifications.rev210817.DeviceNotification;
import org.opendaylight.yang.gen.v1.yang.noa.toaster.notifications.rev210817.NoaToasterNotificationsListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.integration.channel.PriorityChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ToasterDeviceNotificationsListener implements NoaToasterNotificationsListener {
    private static final Logger LOG = LoggerFactory.getLogger(ToasterDeviceNotificationsListener.class);

    @Autowired
    @Qualifier("elementMessageQueueChannel")
    PriorityChannel elementMessageQueueChannel = SpringContext.getBean(PriorityChannel.class);

    @Override
    public void onDeviceNotification(DeviceNotification notification) {
        LOG.info("Notification {} received {}", DeviceNotification.QNAME, notification);

        //TODO: Sanitize Input JSON
        JSONObject body = new JSONObject();
        body.put("faultCode", notification.getFaultCode().toString());
        body.put("faultContent", notification.getFaultContent());

        String date = notification.getFaultDate().toString();
        String faultDate = date.replace("DateAndTime{_value=", "").replace("}","");
        body.put("faultDate", faultDate);

        // TODO: Solution for Attributes with Integer Values
        /* ObjectMapper objectMapper = new ObjectMapper();
        JsonNode jsonNode;
        try {
            jsonNode = objectMapper.readTree(body.toString());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        } */

        Message<String> message = MessageBuilder.withPayload(body.toString())
                .setHeader("messageRouter", "elementFAULT")
                .setPriority(5)
                .build();

        elementMessageQueueChannel.send(message);
    }
}
