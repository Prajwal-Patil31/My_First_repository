package in.utl.noa.network;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.Endpoint;
import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.IetfNetworks;
import org.onap.aai.domain.yang.Link;
import org.onap.aai.domain.yang.Location;
import org.onap.aai.domain.yang.NNode;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.NetworkSlice;
import org.onap.aai.domain.yang.NsConnection;
import org.onap.aai.domain.yang.NsEndpoint;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.RollbackUnit;
import org.onap.aai.domain.yang.SupportingNetwork;
import org.onap.aai.domain.yang.VpnService;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

import in.utl.noa.security.audit.AuditLogger;

import in.utl.noa.global.event.NoaEvents;

import in.utl.noa.platform.config.service.RollbackHandler;

@RestController
@RequestMapping(value = "/api/network")
public class NetworksController {
    private static Logger logger = Logger.getLogger(NetworksController.class);

    @Autowired
    RestClientManager restClientManager;

    AuditLogger auditLogger = new AuditLogger();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    GDBFilterService filterService;

    JSONParser parser = new JSONParser();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    private ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    @GetMapping(value = "/overview")
    public ResponseEntity<JSONObject> getNetworkOverview() throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject activeNetworksObj = (JSONObject) obj.get("active-networks");

        return ResponseEntity.ok(activeNetworksObj);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getIetfNetworkFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "ietf-network");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("networkName", "Network Name");
        columns.put("networkType", "Network Type");
        columns.put("supportNetwork", "Support Networks");
        columns.put("linkType", "Link Type");
        columns.put("linkRate", "Link Rate");
        columns.put("external", "External");
        columns.put("shared", "Shared");
        columns.put("adminStatus", "Admin Status");
        columns.put("networkStatus", "Networks Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getNetworks(@RequestBody RequestBodyDTO requestBody)
            throws JsonProcessingException, ParseException {
        JSONObject networks = filterService.queryByFilter(requestBody, "ietf-network");
        return ResponseEntity.status(HttpStatus.OK).body(networks);
    }

    @GetMapping()
    public ResponseEntity<List<IetfNetwork>> getIetfNetworks() throws JsonProcessingException, ParseException {
        // List<Object> networks = filterService.queryByFilter(requestBody);
        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();
        AAISimplePluralUri networkUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.network().ietfNetworks());

        if (rClient.exists(networkUri)) {
            IetfNetworks networksList = rClient.get(IetfNetworks.class, networkUri).get();
            networks = networksList.getIetfNetwork();
            return ResponseEntity.status(HttpStatus.OK).body(networks);
        }
        return ResponseEntity.status(HttpStatus.OK).body(networks);
    }

    @GetMapping(value = "/{networkId}")
    public ResponseEntity<Optional<IetfNetwork>> getNetworkById(@PathVariable("networkId") String networkId) {

        Optional<IetfNetwork> network = null;
        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

        if (rClient.exists(networkUri)) {
            network = rClient.get(IetfNetwork.class, networkUri);
            return ResponseEntity.status(HttpStatus.OK).body(network);
        }
        return ResponseEntity.status(HttpStatus.OK).body(network);
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> clearAllNetworks() {
        AAIPluralResourceUri networksUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetworks()).depth(Depth.TWO);

        if (rClient.exists(networksUri)) {

            IetfNetworks networksList = rClient.get(IetfNetworks.class, networksUri).get();

            List<IetfNetwork> networks = networksList.getIetfNetwork();

            for (IetfNetwork network : networks) {
                AAIResourceUri networkUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(network.getNetworkId()));

                AAITransactionalClient transactions = rClient.beginTransaction().delete(networkUri);

                try {
                    transactions.execute();
                } catch (BulkProcessFailed e) {
                    e.printStackTrace();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Networks have been Deleted.");
    }

    @PutMapping()
    public ResponseEntity<IetfNetwork> addNetwork(@RequestBody IetfNetwork newNetwork)
            throws BulkProcessFailed, JsonProcessingException, ParseException {
        String networkId = UUID.randomUUID().toString();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network", networkId, null, null);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

        newNetwork = addNetworkParameters(newNetwork);
        newNetwork.setNetworkId(networkId);
        JSONObject newNetworkObj = rollbackHandler.getJsonObject(newNetwork);

        List<Attributes> attributes = rollbackHandler.createAttributes(newNetworkObj, null, null);

        AAITransactionalClient transactions = rClient.beginTransaction();

        transactions.create(networkUri, newNetwork);

        transactions.execute();
        description = "Network " + networkId + " has been Created.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;

        String resourceUri = networkUri.getObjectType().toString();
        rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.IetfNetwork", networkId, resourceUri, null,
                attributes, null, 0, description, true);

        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.CREATE_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(newNetwork);
    }

    public IetfNetwork addNetworkParameters(IetfNetwork network) {
        String networkType = network.getNetworkType();
        switch (networkType) {
            case "L1 Network":
                network.setLinkType("Link");
                break;
            case "L2 Network":
                network.setLinkType("Link");
                break;
            case "L2.5 Network":
                network.setLinkType("LSP");
                break;
            case "L3 Network":
                network.setLinkType("Route");
                break;
            default:
                break;
        }
        network.setShared(0);
        network.setExternal(0);
        network.setNetworkStatus(true);
        network.setAdminStatus(true);
        return network;
    }

    @PostMapping(value = "/{networkId}")
    public ResponseEntity<String> updateNetwork(@PathVariable("networkId") String networkId,
            @RequestBody IetfNetwork newNetwork) throws BulkProcessFailed, JsonProcessingException {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network", networkId, null, null);

        if (networkId != null) {
            AAIResourceUri networkUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

            if (rClient.exists(networkUri)) {
                IetfNetwork network = rClient.get(IetfNetwork.class, networkUri).get();
                AAITransactionalClient transactions = rClient.beginTransaction();
                transactions.update(networkUri, newNetwork);
                transactions.execute();
                description = networkId + " Network has been Updated.";
                reqStatus = HttpStatus.OK;

                JSONObject actNetworkObj = rollbackHandler.getJsonObject(network);
                List<Attributes> attributes = rollbackHandler.createAttributes(actNetworkObj, null, null);

                String resourceUri = networkUri.getObjectType().toString();
                rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.IetfNetwork", networkId,
                        resourceUri, null, attributes, null, 0, description, true);

            } else {
                description = networkId + " Network Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Network Id";
        }
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.MODIFY_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteNetworks(@RequestBody List<String> networkIds)
            throws BulkProcessFailed, JsonProcessingException {
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String networkId : networkIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network", networkId, null, null);
            if (networkId != null) {
                AAIResourceUri networkUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));

                if (rClient.exists(networkUri)) {
                    AAITransactionalClient transactions = rClient.beginTransaction();
                    transactions.delete(networkUri);
                    transactions.execute();
                    description = networkId + " Network has been Deleted.";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.DELETE_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = networkId + " Network Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.DELETE_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Network Id";
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.DELETE_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Networks have been Deleted.");
    }

    @GetMapping(value = "/{networkId}/overview")
    public ResponseEntity<JSONObject> getNetworkOverview(@PathVariable("networkId") String networkId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject elementDetailsObj = (JSONObject) obj.get("network-details");

        return ResponseEntity.ok(elementDetailsObj);
    }

    @GetMapping(value = "/{networkId}/state")
    public ResponseEntity<List<JSONArray>> getNetworkState(@PathVariable("networkId") String networkId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("network-inventory");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{networkId}/node/availability")
    public ResponseEntity<List<JSONArray>> getNetworkNodeAvailability(@PathVariable("networkId") String networkId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("network-device-availability");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{networkId}/node")
    public ResponseEntity<List<NNode>> getNodes(@PathVariable("networkId") String networkId) {

        List<NNode> nodes = new ArrayList<NNode>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);
        if (rClient.exists(networkUri)) {
            IetfNetwork network = new IetfNetwork();
            network = rClient.get(IetfNetwork.class, networkUri).get();
            if (network.getNNodes() != null) {
                nodes = network.getNNodes().getNNode();
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(nodes);
    }

    @GetMapping(value = "/{networkId}/node{nodeId}")
    public ResponseEntity<NNode> getNode(@PathVariable("networkId") String networkId,
            @PathVariable("nodeId") String nodeId)
            throws JsonMappingException, JsonProcessingException, ParseException {

        NNode node = new NNode();
        /*
         * AAIResourceUri linkUri = AAIUriFactory
         * .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).
         * nNode(nodeId,null)); if (rClient.exists(linkUri)) { link =
         * rClient.get(NNode.class,linkUri).get(); }
         */
        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.N_NODE, __.key("node-id", nodeId))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            node = mapper.readValue(interfaceObj.toString(), NNode.class);
        }
        return ResponseEntity.status(HttpStatus.OK).body(node);
    }

    @PutMapping(value = "/{networkId}/node")
    public ResponseEntity<String> addNodesToNetwork(@PathVariable("networkId") String networkId,
            @RequestBody List<String> elementIds) throws BulkProcessFailed, JsonProcessingException {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);
        if (networkId != null) {
            AAIResourceUri networkUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));
            if (rClient.exists(networkUri)) {
                for (String elementId : elementIds) {
                    resourceMetadata.setResourceId(elementId);
                    if (elementId != null) {
                        AAIResourceUri deviceUri = AAIUriFactory
                                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(elementId));
                        NetworkDevice device = rClient.get(NetworkDevice.class, deviceUri).get();
                        NNode node = new NNode();
                        node.setNodeId(elementId);
                        node.setNodeName(device.getDeviceName());
                        node.setNodeType(device.getDeviceType());
                        node.setNodeStatus(device.isElementStatus());
                        node.setIpAddress(device.getHost());

                        AAIResourceUri nodeUri = AAIUriFactory.createResourceUri(
                                AAIFluentTypeBuilder.network().ietfNetwork(networkId).nNode(node.getNodeId()));

                        AAITransactionalClient transactions = rClient.beginTransaction();
                        transactions.create(nodeUri, node).connect(nodeUri, deviceUri);
                        transactions.execute();
                        description = elementId + " Node Added to " + networkId + " Network.";

                        String resourceUri = nodeUri.getObjectType().toString();
                        String attributeUri = deviceUri.getObjectType().toString();

                        JSONObject nodeObject = rollbackHandler.getJsonObject(node);

                        List<Attributes> attributes = rollbackHandler.createAttributes(nodeObject, null, null);
                        RollbackUnit rollbackUnit = rollbackHandler.addRollbackUnit("Create",
                                "org.onap.aai.domain.yang.NNode", elementId, resourceUri, networkId, attributes, null,
                                0, description, true);

                        AAIResourceUri rollbackUri = AAIUriFactory.createResourceUri(
                                AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackUnit.getRollbackId()));

                        JSONObject deviceObj = new JSONObject();
                        deviceObj.put("network-device", elementId);

                        List<Attributes> deviceAttributes = rollbackHandler.createAttributes(deviceObj, attributeUri,
                                null);
                        description = elementId + " Element Connected with Node";
                        rollbackHandler.addRollbackUnit("Connect", "org.onap.aai.domain.yang.NNode", elementId,
                                resourceUri, networkId, deviceAttributes, rollbackUri, 1, description, false);

                        reqStatus = HttpStatus.OK;
                        eventStatus = true;
                        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                                NoaEvents.ADD_NODE_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                    } else {
                        description = elementId + " Device Doesn't Exists.";
                        reqStatus = HttpStatus.NOT_FOUND;
                        eventStatus = false;
                        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                                NoaEvents.ADD_NODE_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                        return ResponseEntity.status(reqStatus).body(description);
                    }
                }
            } else {
                description = "Network Doesn't Exists";
                reqStatus = HttpStatus.BAD_REQUEST;
                eventStatus = false;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.ADD_NODE_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }

            return ResponseEntity.status(HttpStatus.OK).body("Nodes have been Added.");
        } else {
            description = "Received Null Network Id.";
        }
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.ADD_NODE_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("NetworkId is Null.");
    }

    @DeleteMapping(value = "/{networkId}/node")
    public ResponseEntity<String> removeNodesFromNetwork(@PathVariable("networkId") String networkId,
            @RequestBody List<String> nodeIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        for (String nodeId : nodeIds) {
            resourceMetadata.setResourceId(nodeId);
            if (networkId != null && nodeId != null) {
                AAIResourceUri nodeUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).nNode(nodeId));
                if (rClient.exists(nodeUri)) {
                    AAITransactionalClient transactions = rClient.beginTransaction().delete(nodeUri);
                    transactions.execute();
                    description = nodeId + " Node has been Removed from " + networkId + " Network";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_NODE_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = nodeId + "Node Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_NODE_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Node Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.REMOVE_NODE_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Nodes have been Deleted.");
    }

    @GetMapping(value = "/{networkId}/link/availability")
    public ResponseEntity<List<JSONArray>> getNetworkLinkAvailability(@PathVariable("networkId") String networkId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONArray> elementStateObj = (List<JSONArray>) obj.get("network-link-availability");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{networkId}/link/utilization")
    public ResponseEntity<List<JSONObject>> getNetworkLinkUtilization(@PathVariable("networkId") String networkId)
            throws FileNotFoundException, IOException, ParseException {

        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> elementStateObj = (List<JSONObject>) obj.get("network-link-utilization");

        return ResponseEntity.ok(elementStateObj);
    }

    @GetMapping(value = "/{networkId}/l-network")
    public ResponseEntity<List<IetfNetwork>> getSupportingNetworks(@PathVariable("networkId") String networkId) {

        IetfNetwork network = null;
        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();
        if (rClient.exists(networkUri)) {
            network = rClient.get(IetfNetwork.class, networkUri).get();
            if (network.getSupportingNetworks() != null) {
                List<SupportingNetwork> supportingNetworks = network.getSupportingNetworks().getSupportingNetwork();

                for (SupportingNetwork supNetwork : supportingNetworks) {
                    String supNetworkId = supNetwork.getNetworkId();
                    AAIResourceUri supNetworkUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(supNetworkId))
                            .depth(Depth.TWO);
                    IetfNetwork newNetwork = rClient.get(IetfNetwork.class, supNetworkUri).get();
                    networks.add(newNetwork);
                }
            }
            return ResponseEntity.status(HttpStatus.OK).body(networks);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(networks);
    }

    @PutMapping(value = "/{networkId}/l-network")
    public ResponseEntity<String> addSupportingNetworks(@PathVariable("networkId") String networkId,
            @RequestBody List<String> supNetworkIds) throws BulkProcessFailed, JsonProcessingException {
        if (networkId != null) {
            for (String supNetworkId : supNetworkIds) {
                SupportingNetwork network = new SupportingNetwork();
                network.setNetworkId(supNetworkId);
                if (supNetworkId != null) {
                    AAIResourceUri supNetworkUri = AAIUriFactory.createResourceUri(
                            AAIFluentTypeBuilder.network().ietfNetwork(networkId).supportingNetwork(supNetworkId));
                    AAIResourceUri networkUri = AAIUriFactory
                            .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));
                    if (rClient.exists(networkUri) && !rClient.exists(supNetworkUri)) {
                        AAITransactionalClient transactions = rClient.beginTransaction();
                        transactions.create(supNetworkUri, network).connect(supNetworkUri, networkUri);
                        transactions.execute();
                    } else {
                        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Supporting N/W Already Exists.");
                    }
                } else {
                    return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Network Id is Null.");
                }
            }
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Supporting Networks have been Added.");
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Network Id is Null.");
    }

    @DeleteMapping(value = "/{networkId}/l-network")
    public ResponseEntity<String> deleteSupportingNetworks(@PathVariable("networkId") String networkId,
            @RequestBody List<String> supNetworkIds) throws BulkProcessFailed {
        for (String supNetworkId : supNetworkIds) {
            if (networkId != null && supNetworkId != null) {
                AAIResourceUri supNetworkUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.network().ietfNetwork(networkId).supportingNetwork(supNetworkId));
                if (rClient.exists(supNetworkUri)) {
                    AAITransactionalClient transactions = rClient.beginTransaction().delete(supNetworkUri);
                    transactions.execute();
                }
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Networks have been Deleted.");
    }

    @GetMapping(value = "/{networkId}/fault/overview")
    public ResponseEntity<JSONObject> getElementFaultOverview(@PathVariable("networkId") String networkId)
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject networkFaultsObj = (JSONObject) obj.get("network-fault-overview");

        return ResponseEntity.ok(networkFaultsObj);
    }

    @GetMapping(value = "/{networkId}/available-supporting-network")
    public ResponseEntity<List<IetfNetwork>> getAvailableSupportingNetworks(@PathVariable("networkId") String networkId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        IetfNetwork network = new IetfNetwork();
        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

        if (rClient.exists(networkUri)) {
            network = rClient.get(IetfNetwork.class, networkUri).get();
            String networkType = network.getNetworkType();
            String supNetworkType = "";

            switch (networkType) {
                case "L2 Network":
                    supNetworkType = "L1 Network";
                    break;
                case "L3 Network":
                    supNetworkType = "L2 Network";
                    break;

                default:
                    break;
            }

            DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-type", supNetworkType));
            DSLQueryBuilder<Start, Node> allNetworkBuilder = TraversalBuilder.fragment(startNode).output();

            String allNetworkResults = dslClient.query(Format.RESOURCE, new DSLQuery(allNetworkBuilder.build()));

            Results<Map<String, IetfNetwork>> resultsFromJson = mapper.readValue(allNetworkResults,
                    new TypeReference<Results<Map<String, IetfNetwork>>>() {
                    });

            for (Map<String, IetfNetwork> m : resultsFromJson.getResult()) {
                networks.add(m.get("ietf-network"));
            }

            DSLStartNode startNodeNetwork = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));

            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNodeNetwork)
                    .to(__.node(Types.SUPPORTING_NETWORK))
                    .to(__.node(Types.IETF_NETWORK, __.key("network-type", supNetworkType)).output());

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, IetfNetwork>> supResultsFromJson = mapper.readValue(results,
                    new TypeReference<Results<Map<String, IetfNetwork>>>() {
                    });

            List<String> networkIds = new ArrayList<>();
            for (Map<String, IetfNetwork> m : supResultsFromJson.getResult()) {
                networkIds.add((m.get("ietf-network")).getNetworkId());
            }

            List<IetfNetwork> diffNetworks = networks.stream().filter(n -> networkIds.contains(n.getNetworkId()))
                    .collect(Collectors.toList());

            networks.removeAll(diffNetworks);

            return ResponseEntity.status(HttpStatus.OK).body(networks);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(networks);
    }

    @GetMapping(value = "/{networkId}/supported-network")
    public ResponseEntity<List<IetfNetwork>> getSupportedNetworks(@PathVariable("networkId") String networkId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        IetfNetwork network = new IetfNetwork();
        List<IetfNetwork> networks = new ArrayList<IetfNetwork>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);

        if (rClient.exists(networkUri)) {
            network = rClient.get(IetfNetwork.class, networkUri).get();
            String networkType = network.getNetworkType();
            String supNetworkType = "";

            switch (networkType) {
                case "L1 Network":
                    supNetworkType = "L2 Network";
                    break;
                case "L2 Network":
                    supNetworkType = "L3 Network";
                    break;

                default:
                    break;
            }

            DSLStartNode startNode = new DSLStartNode(Types.SUPPORTING_NETWORK, __.key("network-id", networkId));

            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                    .to(__.node(Types.IETF_NETWORK, __.key("network-type", supNetworkType)).output());

            String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

            Results<Map<String, IetfNetwork>> resultsFromJson = mapper.readValue(results,
                    new TypeReference<Results<Map<String, IetfNetwork>>>() {
                    });

            for (Map<String, IetfNetwork> m : resultsFromJson.getResult()) {
                networks.add(m.get("ietf-network"));
            }

            return ResponseEntity.status(HttpStatus.OK).body(networks);
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(networks);
    }

    @GetMapping(value = "/{networkId}/service")
    public ResponseEntity<List<VpnService>> getDeployedServices(@PathVariable("networkId") String networkId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<VpnService> services = new ArrayList<VpnService>();
        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.VPN_SERVICE))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject serviceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            services.add(mapper.readValue(serviceObj.toString(), VpnService.class));
        }
        return ResponseEntity.status(HttpStatus.OK).body(services);
    }

    @PostMapping(value = "/{networkId}/service/")
    public ResponseEntity<Map<String, List<String>>> getDeployedService(@PathVariable("networkId") String networkId,
            @RequestBody List<String> serviceIds) throws ParseException, JsonMappingException, JsonProcessingException {

        Map<String, List<String>> serviceObj = new HashMap<String, List<String>>();
        for (String serviceId : serviceIds) {
            VpnService service = new VpnService();
            AAIResourceUri serviceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.service().vpnService(serviceId)).depth(Depth.TWO);

            service = rClient.get(VpnService.class, serviceUri).get();

            List<Endpoint> endpoints = new ArrayList<Endpoint>();
            if (service.getEndpoints() != null) {
                endpoints = service.getEndpoints().getEndpoint();
            }

            List<String> endpointNames = new ArrayList<String>();
            for (Endpoint endpoint : endpoints) {
                endpointNames.add(endpoint.getEndpointName());
            }
            serviceObj.put(service.getServiceName(), endpointNames);
        }
        return ResponseEntity.status(HttpStatus.OK).body(serviceObj);
    }

    @GetMapping(value = "/{networkId}/network-slice")
    public ResponseEntity<List<NetworkSlice>> getNetworkSlices(@PathVariable("networkId") String networkId)
            throws JsonMappingException, JsonProcessingException {

        List<NetworkSlice> networkSlices = new ArrayList<NetworkSlice>();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.NETWORK_SLICE))
                .output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, NetworkSlice>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, NetworkSlice>>>() {
                });

        for (Map<String, NetworkSlice> m : resultsFromJson.getResult()) {
            networkSlices.add(m.get("network-slice"));
        }

        return ResponseEntity.status(HttpStatus.OK).body(networkSlices);
    }

    @GetMapping(value = "/{networkId}/network-slice/{sliceId}")
    public ResponseEntity<NetworkSlice> getNetworkSlice(@PathVariable("networkId") String networkId,
            @PathVariable("sliceId") String sliceId)
            throws JsonMappingException, JsonProcessingException, ParseException {
        NetworkSlice networkSlice = null;

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.NETWORK_SLICE, __.key("slice-id", sliceId))).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        if (resultsArray.size() > 0) {
            AAIResourceUri networkSliceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId)).depth(Depth.TWO);
            if (rClient.exists(networkSliceUri)) {
                networkSlice = rClient.get(NetworkSlice.class, networkSliceUri).get();
                return ResponseEntity.status(HttpStatus.OK).body(networkSlice);
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(networkSlice);
    }

    @PutMapping(value = "/{networkId}/network-slice")
    public ResponseEntity<String> createNetworkSlices(@PathVariable("networkId") String networkId,
            @RequestBody NetworkSlice newNetworkSlice) throws BulkProcessFailed {

        String sliceId = newNetworkSlice.getSliceId();
        newNetworkSlice.setSliceId(sliceId);

        if (sliceId == null) {
            newNetworkSlice.setSliceId(newNetworkSlice.getSliceName());
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Slice", sliceId, "Network",
                networkId);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));
        AAIResourceUri networkSliceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId));

        if (!rClient.exists(networkSliceUri)) {
            AAITransactionalClient transactions;

            transactions = rClient.beginTransaction().create(networkSliceUri, newNetworkSlice).connect(networkUri,
                    networkSliceUri);
            transactions.execute();
            description = sliceId + " Network Slice has been Created";

            String resourceUri = networkSliceUri.getObjectType().toString();
            String attributeUri = networkUri.getObjectType().toString();

            JSONObject nodeObject = rollbackHandler.getJsonObject(newNetworkSlice);

            List<Attributes> attributes = rollbackHandler.createAttributes(nodeObject, null, null);
            RollbackUnit rollbackUnit = rollbackHandler.addRollbackUnit("Create",
                    "org.onap.aai.domain.yang.NetworkSlice", sliceId, resourceUri, null, attributes, null, 0,
                    description, true);

            AAIResourceUri rollbackUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackUnit.getRollbackId()));

            JSONObject sliceNetworkObj = new JSONObject();
            sliceNetworkObj.put("ietf-network", networkId);

            List<Attributes> nodeAttributes = rollbackHandler.createAttributes(sliceNetworkObj, attributeUri, null);
            rollbackHandler.addRollbackUnit("Connect", "org.onap.aai.domain.yang.NetworkSlice", sliceId, resourceUri,
                    null, nodeAttributes, rollbackUri, 1, description, false);
            eventStatus = true;
            reqStatus = HttpStatus.CREATED;
        } else {
            description = sliceId + " Network Slice Already Exists";
        }
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.CREATE_NETWORK_SLICE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{networkId}/network-slice/{sliceId}/endpoint")
    public ResponseEntity<String> removeEndpoints(@PathVariable("sliceId") String sliceId,
            @RequestBody List<String> nsEndpointIds) throws BulkProcessFailed {

        for (String nsEndpointId : nsEndpointIds) {

            AAIResourceUri nsEndpointUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId).nsEndpoint(nsEndpointId));

            if (rClient.exists(nsEndpointUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().delete(nsEndpointUri);

                transactions.execute();

            } else
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("End Point Doesn't Exists.");
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("End Point Removed from Network Slice.");
    }

    @PatchMapping(value = "/{networkId}/network-slice/{sliceId}")
    public ResponseEntity<String> updateNetworkSlice(@PathVariable("networkId") String networkId,
            @PathVariable("sliceId") String sliceId, @RequestBody NetworkSlice modifiedSlice) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Slice", sliceId, "Network",
                networkId);

        AAIResourceUri networkSliceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId));

        if (sliceId != null) {
            if (rClient.exists(networkSliceUri)) {
                NetworkSlice actSlice = rClient.get(NetworkSlice.class, networkSliceUri).get();
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(networkSliceUri, modifiedSlice);

                transactions.execute();
                description = sliceId + " Network Slice has been Updated.";

                String resourceUri = networkSliceUri.getObjectType().toString();
                JSONObject actSliceObj = rollbackHandler.getJsonObject(actSlice);

                List<Attributes> attributes = rollbackHandler.createAttributes(actSliceObj, null, null);
                rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.NetworkSlice", sliceId, resourceUri,
                        null, attributes, null, 0, description, true);

                reqStatus = HttpStatus.OK;
                eventStatus = true;
            } else {
                description = sliceId + " Network Slice Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Slice Id";
        }
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.MODIFY_NETWORK_SLICE.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{networkId}/network-slice")
    public ResponseEntity<String> removeNetworkSlices(@PathVariable("networkId") String networkId,
            @RequestBody List<String> sliceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Network Slice", null, "Network",
                networkId);
        for (String sliceId : sliceIds) {
            resourceMetadata.setResourceId(sliceId);
            if (sliceId != null) {
                AAIResourceUri networkSliceUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId));
                if (rClient.exists(networkSliceUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(networkSliceUri);
                    transactions.execute();
                    description = sliceId + " Network Slice has been Deleted";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.DELETE_NETWORK_SLICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = sliceId + " Network Slice Doesn't Exists";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.DELETE_NETWORK_SLICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Slice Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.DELETE_NETWORK_SLICE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Network Slices have been Deleted.");
    }

    @PutMapping(value = "/{networkId}/network-slice/{sliceId}/connection")
    public ResponseEntity<String> addSliceConnections(@PathVariable("networkId") String networkId,
            @PathVariable("sliceId") String sliceId, @RequestBody List<String> linkIds) throws BulkProcessFailed {

        return ResponseEntity.status(HttpStatus.CREATED).body("Connections have been Deleted.");
    }

    @DeleteMapping(value = "/{networkId}/network-slice/{sliceId}/connection")
    public ResponseEntity<String> removeConnections(@PathVariable("sliceId") String sliceId,
            @RequestBody List<String> connectionIds) throws BulkProcessFailed {

        for (String connectionId : connectionIds) {

            AAIResourceUri nsConnectionUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId).nsConnection(connectionId));

            if (rClient.exists(nsConnectionUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().delete(nsConnectionUri);

                transactions.execute();

            } else
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Connection Doesn't Exists.");
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Connection Removed from Network Slice.");
    }

    @GetMapping(value = "/{networkId}/network-slice/{sliceId}/node")
    public ResponseEntity<List<NNode>> getNodesOfSlice(@PathVariable("networkId") String networkId,
            @PathVariable("sliceId") String sliceId) throws JsonMappingException, JsonProcessingException {

        List<String> nodeIds = new ArrayList<String>();
        List<NNode> nodesList = new ArrayList<NNode>();

        return ResponseEntity.status(HttpStatus.OK).body(nodesList);
    }

    @GetMapping(value = "/{networkId}/network-slice/{sliceId}/connection")
    public ResponseEntity<List<String>> getLinksOfSlice(@PathVariable("networkId") String networkId,
            @PathVariable("sliceId") String sliceId) throws JsonMappingException, JsonProcessingException {

        List<String> linkIds = new ArrayList<String>();
        List<Link> links = new ArrayList<Link>();

        return ResponseEntity.status(HttpStatus.OK).body(linkIds);
    }

    @GetMapping(value = "/{networkId}/node/{nodeId}/location")
    public ResponseEntity<Location> getNodeLocation(@PathVariable("networkId") String networkId,
            @PathVariable("nodeId") String nodeId) throws JsonMappingException, JsonProcessingException {

        Location location = new Location();
        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.N_NODE, __.key("node-id", nodeId))).to(__.node(Types.NETWORK_DEVICE))
                .to(__.node(Types.LOCATION)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, Location>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, Location>>>() {
                });

        for (Map<String, Location> m : resultsFromJson.getResult()) {
            location = m.get("location");
        }

        return ResponseEntity.status(HttpStatus.OK).body(location);
    }

    @GetMapping("/network-slice/{sliceId}/topology")
    public ResponseEntity<JSONObject> getSliceTopology(@PathVariable("sliceId") String sliceId)
            throws JsonMappingException, JsonProcessingException, ParseException {

        JSONObject sliceResources = new JSONObject();
        String networkId = "Utl L2 Network";
        List<NetworkDevice> devices = new ArrayList<NetworkDevice>();

        NetworkSlice networkSlice = new NetworkSlice();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.NETWORK_SLICE, __.key("slice-id", sliceId))).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        if (resultsArray.size() > 0) {
            AAIResourceUri networkSliceUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().networkSlice(sliceId)).depth(Depth.TWO);
            if (rClient.exists(networkSliceUri)) {
                networkSlice = rClient.get(NetworkSlice.class, networkSliceUri).get();

                List<NsEndpoint> sliceEndpoints = new ArrayList<NsEndpoint>();
                if (networkSlice.getNsEndpoints() != null) {
                    sliceEndpoints = networkSlice.getNsEndpoints().getNsEndpoint();
                }

                List<NsConnection> sliceConnections = new ArrayList<NsConnection>();
                if (networkSlice.getNsConnections() != null) {
                    sliceConnections = networkSlice.getNsConnections().getNsConnection();
                }

                List<JSONObject> nodeObjects = new ArrayList<JSONObject>();

                for (NsEndpoint endPoint : sliceEndpoints) {
                    JSONObject endPointObj = new JSONObject();
                    endPointObj.put("id", endPoint.getNodeId());
                    endPointObj.put("name", endPoint.getNodeId());
                    endPointObj.put("color", "#0how00");
                    endPointObj.put("iconType", "router");

                    nodeObjects.add(endPointObj);
                }

                sliceResources.put("nodes", nodeObjects);

                List<JSONObject> linkObjects = new ArrayList<JSONObject>();
                for (NsConnection sliceConnection : sliceConnections) {
                    JSONObject linkObj = new JSONObject();
                    linkObj.put("id", sliceConnection.getConnectionName());
                    linkObj.put("label", sliceConnection.getConnectionName());
                    if (sliceConnection.getSource() != null) {
                        String srcDevice = getDevicefromSlice(sliceConnection.getSource());
                        linkObj.put("source", srcDevice);
                    }
                    if (sliceConnection.getDestination() != null) {
                        String destDevice = getDevicefromSlice(sliceConnection.getDestination());
                        linkObj.put("target", destDevice);
                    }
                    if (linkObj.keySet().size() == 4) {
                        linkObjects.add(linkObj);
                    }
                }
                sliceResources.put("links", linkObjects);
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body(sliceResources);
    }

    public String getDevicefromSlice(String interfaceId) throws JsonMappingException, JsonProcessingException {
        String deviceId = "";
        DSLStartNode queryNode = new DSLStartNode(Types.IETF_INTERFACE, __.key("interface-id", interfaceId));
        DSLQueryBuilder<Start, Node> querybuilder = TraversalBuilder.fragment(queryNode)
                .to(__.node(Types.NETWORK_DEVICE)).output();

        String queryResults = dslClient.query(Format.RESOURCE, new DSLQuery(querybuilder.build()));

        Results<Map<String, NetworkDevice>> resultsFromJson = mapper.readValue(queryResults,
                new TypeReference<Results<Map<String, NetworkDevice>>>() {
                });

        for (Map<String, NetworkDevice> m : resultsFromJson.getResult()) {
            deviceId = m.get("network-device").getDeviceId();
        }
        return deviceId;
    }
}
