package in.utl.noa.global.fault.repository;

import static in.utl.noa.global.fault.util.FaultConstants.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.global.fault.model.Fault;
import in.utl.noa.platform.security.web.service.WebSocketService;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class FaultRepositoryCustomImpl implements FaultRepositoryCustom<Fault> {

    private static Logger logger = Logger.getLogger(FaultRepositoryCustomImpl.class);

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private WebSocketService webSocketService;

    @Transactional
    public boolean clearFaults(int faultCode) {
        List<Fault> faults = null;
        Query q = em.createQuery("SELECT a FROM Fault a WHERE a.faultCode = :faultCode ");
        q.setParameter("faultCode", faultCode);

        try {
            faults = (List<Fault>) q.getResultList();
        } catch (NoResultException e) {
        }

        if (faults.isEmpty()) {
            return false;
        }

        Calendar cal = Calendar.getInstance();
        java.util.Date today = cal.getTime();
        for (Fault fault : faults) {
            fault.setStatusCode(FAULT_CLEAR_STATUS);
            fault.setClearUsername(FAULT_CLEAR_USERNAME);
            fault.setClearDate(today);
            em.persist(fault);
            webSocketService.pushGlobalNotification(null, null, null, null, null, null, null, null, null, fault, null);
        }
        return true;
    }

    @Transactional
    public boolean isDuplicateFault(int faultCode) {
        List<Fault> faults = null;
        boolean status = false;

        Query q = em.createQuery("SELECT a FROM Fault a WHERE a.faultCode = :faultCode ");
        q.setParameter("faultCode", faultCode);

        try {
            faults = (List<Fault>) q.getResultList();
        } catch (NoResultException e) {
        }

        if (!faults.isEmpty()) {
            status = true;
        }
        return status;
    }

    @Transactional
    public Fault updateFaultCountAndDate(int faultCode, Date genDate) {
        List<Fault> faults = null;
        Query q = em.createQuery("SELECT a FROM Fault a WHERE a.faultCode = :faultCode");
        q.setParameter("faultCode", faultCode);

        try {
            faults = (List<Fault>) q.getResultList();
        } catch (NoResultException e) {
        }

        if (faults.isEmpty()) {
            logger.info("updateFaultCountAndDate:: No Duplicate Faults Found for Updating Count");
            return null;
        }

        Fault fault = faults.get(0);
        int count = fault.getCount();
        fault.setCount(count + 1);
        fault.setFaultDate(genDate);
        em.persist(fault);
        webSocketService.pushGlobalNotification(fault.getFaultId(), "Fault", "Element", "AltranIss",
                fault.getFaultContent(), fault.getFaultDate().toString(), fault.getStatusCode(), fault.getSeverity(),
                fault.getCount(), fault, null);

        logger.info("updateFaultCountAndDate:: Updated Duplicate Fault Count");
        return fault;
    }

    @Transactional
    public Fault updateAcknowledgementDate(int faultCode) {
        List<Fault> faults = null;
        Query q = em.createQuery("SELECT a FROM Fault a WHERE a.faultCode = :faultCode");
        q.setParameter("faultCode", faultCode);

        try {
            faults = (List<Fault>) q.getResultList();
        } catch (NoResultException e) {
        }

        if (faults.isEmpty()) {
            logger.info("updateAcknowledgementDate:: No Duplicate Faults Found for Updating Ack Date");
            return null;
        }

        Fault fault = faults.get(0);
        fault.setAckUsername("AUTO");
        fault.setAckDate(new Date());

        em.persist(fault);
        webSocketService.pushGlobalNotification(null, null, null, null, null, null, null, null, null, fault, null);

        logger.info("updateAcknowledgementDate:: Updated Duplicate Fault Ack Count");
        return fault;
    }

    @Transactional
    public <S extends Fault> S saveAndPush(S entity) {
        logger.info("Handle Before Save");
        em.persist(entity);
        webSocketService.pushGlobalNotification(entity.getFaultId(), "Fault", "Element", "AltranIss",
                entity.getFaultContent(), entity.getFaultDate().toString(), entity.getStatusCode(),
                entity.getSeverity(), entity.getCount(), entity, null);

        return entity;
    }

    @Override
    public JSONObject filterByField(RequestBodyDTO requestBody) {
        JSONObject paginationObj = requestBody.getPagination();
        Map<String, JSONObject> filterObj = requestBody.getFilters();

        JSONObject filters = filterObj.get("fault");

        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Fault> criteriaQuery = cb.createQuery(Fault.class);
        Root<Fault> root = criteriaQuery.from(Fault.class);

        Set<String> keys = filters.keySet();
        if (keys.size() > 0) {
            List<String> filterCategories = new ArrayList<String>();
            filterCategories.addAll(keys);
            String filterCategory = filterCategories.get(0);
            List<?> filterValues = (List<?>) filters.get(filterCategory);
            criteriaQuery.select(root).where(root.get(filterCategory).in(filterValues));
        } else {
            criteriaQuery.select(root);
        }

        Integer pageSize = 4;
        Integer pageIndex = 1;

        if (paginationObj != null) {
            pageSize = paginationObj.get("size") != null ? Integer.parseInt(paginationObj.get("size").toString()) : 4;
            pageIndex = paginationObj.get("number") != null ? Integer.parseInt(paginationObj.get("number").toString())
                    : 1;
        }

        TypedQuery<Fault> query = em.createQuery(criteriaQuery);
        query.setFirstResult(pageIndex);
        query.setMaxResults(pageSize);

        TypedQuery<Fault> queryTotal = em.createQuery(criteriaQuery);

        Integer totalEntries = queryTotal.getResultList().size();

        Integer maxPages = 0;
        if (totalEntries % pageSize != 0) {
            maxPages = totalEntries / pageSize + 1;
        } else {
            maxPages = totalEntries / pageSize;
        }

        JSONObject jsonObject = new JSONObject();
        jsonObject.put("data", query.getResultList());

        JSONObject pageObj = new JSONObject();
        pageObj.put("maxPages", maxPages);
        pageObj.put("totalEntries", totalEntries);
        jsonObject.put("page", pageObj);
        return jsonObject;
    }
}