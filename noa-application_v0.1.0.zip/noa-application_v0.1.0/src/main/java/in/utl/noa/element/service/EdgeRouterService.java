package in.utl.noa.element.service;

import org.onap.aai.domain.yang.AttachmentCircuit;
import org.onap.aai.domain.yang.CrossConnect;
import org.onap.aai.domain.yang.EdgeRouter;
import org.onap.aai.domain.yang.InSegment;
import org.onap.aai.domain.yang.InSegmentStatEntry;
import org.onap.aai.domain.yang.LdpEntity;
import org.onap.aai.domain.yang.MplsL2VpnStats;
import org.onap.aai.domain.yang.MplsTunnel;
import org.onap.aai.domain.yang.MplsTunnelStats;
import org.onap.aai.domain.yang.NetworkDevice;

import in.utl.noa.element.dto.RouterConfigDTO;
import org.onap.aai.domain.yang.OutSegment;
import org.onap.aai.domain.yang.OutSegmentStatEntry;
import org.onap.aai.domain.yang.TunnelStatEntry;

import java.util.List;
import org.json.simple.JSONObject;

public interface EdgeRouterService {
    public EdgeRouter addRouter(NetworkDevice device);

    public RouterConfigDTO getLsrConfig(String routerId);

    public RouterConfigDTO getMplsConfig(String routerId);

    public RouterConfigDTO getMplsTunnelConfig(String routerId);

    public RouterConfigDTO getL2VpnConfig(String routerId);

    public MplsL2VpnStats getL2VpnStats(String routerId);

    public void configureLsr(String routerId, RouterConfigDTO routerConfigDTO);

    public void configureLdp(String routerId, RouterConfigDTO routerConfigDTO);

    public void configureMpls(String routerId, RouterConfigDTO routerConfigDTO);

    public void configureMplsTunnel(String routerId, RouterConfigDTO routerConfigDTO);

    public void configureL2Vpn(String routerId, RouterConfigDTO routerConfigDTO);

    public MplsTunnelStats getMplsTunnelsStatistics(String routerId);

    public List<AttachmentCircuit> getAttachmentCircuit(String routerId);

    public void createAttachmentCircuit(String routerId, AttachmentCircuit attachmentCircuit);

    public void deleteAttachmentCircuit(String routerId, Integer acIndex);

    public List<MplsTunnel> getListOfTunnels(String routerId);

    public void createMplsTunnel(String routerId, MplsTunnel mplsTunnel);

    public void deleteMplsTunnel(String routerId, MplsTunnel mplsTunnel);

    public List<TunnelStatEntry> getTunnelStatistics(String routerId);

    public List<JSONObject> getLdpInSegments(String routerId);

    public void createInSegment(String routerId, InSegment inSegment);

    public void deleteInSegments(String routerId, String inSegmentIndex);

    public List<JSONObject> getLdpOutSegments(String routerId);

    public void createOutSegment(String routerId, OutSegment outSegment);

    public void deleteOutSegments(String routerId, String outSegmentIndex);

    public List<JSONObject> getCrossConnects(String routerId);

    public void createCrossConnect(String routerId, CrossConnect crossConnect);

    public void deleteCrossConnect(String routerId, String crossConnectIndex);

    public List<JSONObject> getLdpEntities(String routerId);

    public void createLdpEntity(String routerId, LdpEntity entity);

    public void deleteLdpEntity(String routerId, String entityId);

    public List<InSegmentStatEntry> getInSegmentStats(String routerId, String inSegmentId);

    public List<OutSegmentStatEntry> getOutSegmentStats(String routerId, String inSegmentId);

}
