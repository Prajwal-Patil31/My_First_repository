package in.utl.noa.element.config.mpls.ldp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.onap.aai.domain.yang.LdpConfig;
import org.onap.aai.domain.yang.LdpEntity;
import org.onap.aai.domain.yang.LdpPeer;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.ResourceMetadata;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.element.service.DeviceOperationService;
import in.utl.noa.element.service.EdgeRouterService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;

import org.onap.aai.domain.yang.Attributes;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/mpls/ldp")
public class LdpConfiguration {
    private static Logger logger = Logger.getLogger(LdpConfiguration.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    /*
     * @Autowired DeviceRepository deviceRepo;
     */

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<LdpConfig> getLdpConfiguration(@PathVariable("deviceId") String deviceId) {

        LdpConfig ldpConfig = new LdpConfig();
        AAIResourceUri ldpConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpConfig(deviceId));

        if (rClient.exists(ldpConfigUri)) {
            ldpConfig = rClient.get(LdpConfig.class, ldpConfigUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(ldpConfig);
    }

    @PostMapping()
    public ResponseEntity<String> updateLdpConfiguration(@PathVariable("deviceId") String deviceId,
            @RequestBody LdpConfig ldpConfig) throws BulkProcessFailed {

        AAITransactionalClient transactions;
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("LDP Config", deviceId, "Network Device",
                deviceId);

        if (deviceId != null) {
            AAIResourceUri ldpConfigUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpConfig(deviceId));

            LdpConfig actldpConfig = new LdpConfig();

            if (ldpConfig.getLdpLsrId() == null) {
                ldpConfig.setLdpLsrId(deviceId);
            }
            if (rClient.exists(ldpConfigUri)) {
                actldpConfig = rClient.get(LdpConfig.class, ldpConfigUri).get();
                transactions = rClient.beginTransaction().update(ldpConfigUri, ldpConfig);
                transactions.execute();
            } else {
                transactions = rClient.beginTransaction().create(ldpConfigUri, ldpConfig);
                transactions.execute();
                actldpConfig = rClient.get(LdpConfig.class, ldpConfigUri).get();
            }

            description = "LDP Configuration has been Updated in " + deviceId + " Device";

            JSONObject ldpConfigObj = rollbackHandler.getJsonObject(actldpConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(ldpConfigObj, null, null);
            String resourceUri = ldpConfigUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.LdpConfig", deviceId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = "Received Null Device Id";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "LDP",
                NoaEvents.MODIFY_LDP_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/peer/filter")
    public ResponseEntity<ResponseDataDTO> getLdpPeerFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "ldp-peer");

        Map<String, Object> columns = new HashMap<>();
        columns.put("peerName", "Peer Name");
        columns.put("peerLabelDistMethod", "Label Distribution Method");
        columns.put("peerPathVectorLimit", "Path Vector Limit");
        columns.put("peerTransportAddrType", "Address Type");
        columns.put("peerTransportAddr", "Transport Address");
        columns.put("peerStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping(value = "/peer")
    public ResponseEntity<JSONObject> getLdpPeerList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject ldpPeers = filterService.queryByFilter(requestBody, "ldp-peer");
        return ResponseEntity.status(HttpStatus.OK).body(ldpPeers);
    }

    @GetMapping(value = "/peer")
    public ResponseEntity<List<LdpPeer>> getLdpPeers(@PathVariable("deviceId") String deviceId) {

        List<LdpPeer> ldpPeers = new ArrayList<LdpPeer>();
        NetworkDevice device = new NetworkDevice();

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {

            device = rClient.get(NetworkDevice.class, deviceUri).get();

            if (device.getLdpPeers() != null) {
                ldpPeers = device.getLdpPeers().getLdpPeer();
            }
            return ResponseEntity.status(HttpStatus.OK).body(ldpPeers);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ldpPeers);
    }

    @GetMapping(value = "/peer/{peerId}")
    public ResponseEntity<LdpPeer> getLdpPeer(@PathVariable("deviceId") String deviceId,
            @PathVariable("peerId") String peerId) {

        LdpPeer ldpPeer = new LdpPeer();

        AAIResourceUri peerUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpPeer(peerId));

        if (rClient.exists(peerUri)) {

            ldpPeer = rClient.get(LdpPeer.class, peerUri).get();

            return ResponseEntity.status(HttpStatus.OK).body(ldpPeer);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ldpPeer);
    }

    @PostMapping(value = "/peer/{peerId}")
    public ResponseEntity<String> updateLdpPeer(@PathVariable("deviceId") String deviceId,
            @PathVariable("peerId") String peerId, @RequestBody LdpPeer ldpPeerBody) throws BulkProcessFailed {

        AAITransactionalClient transactions;
        AAIResourceUri ldpPeerUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpPeer(peerId));

        transactions = rClient.beginTransaction().update(ldpPeerUri, ldpPeerBody);

        transactions.execute();

        return ResponseEntity.status(HttpStatus.OK).body("Peer has been Updated");
    }

    @GetMapping(value = "/entity/filter")
    public ResponseEntity<ResponseDataDTO> getLdpEntityFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "ldp-entity");

        Map<String, Object> columns = new HashMap<>();
        columns.put("entityIndex", "Entity Name");
        columns.put("labelDistMethod", "Label Distribution Method");
        columns.put("labelRetentionMode", "Label Retention Mode");
        columns.put("tcpPort", "TCP Port");
        columns.put("udpDescPort", "UDP Desc Port");
        columns.put("maxPduLength", "Max PDU Length");
        columns.put("operStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping(value = "/entity")
    public ResponseEntity<JSONObject> getLdpEntityList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject ldpEntities = filterService.queryByFilter(requestBody, "ldp-entity");
        return ResponseEntity.status(HttpStatus.OK).body(ldpEntities);
    }

    @GetMapping(value = "/entity")
    public ResponseEntity<List<LdpEntity>> getLdpEntities(@PathVariable("deviceId") String deviceId)
            throws JsonMappingException, JsonProcessingException {

        List<LdpEntity> ldpEntities = new ArrayList<LdpEntity>();

        NetworkDevice device = new NetworkDevice();

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {

            device = rClient.get(NetworkDevice.class, deviceUri).get();

            if (device.getLdpEntities() != null) {
                ldpEntities = device.getLdpEntities().getLdpEntity();
            }

            return ResponseEntity.status(HttpStatus.OK).body(ldpEntities);
        }
        return ResponseEntity.status(HttpStatus.OK).body(ldpEntities);
    }

    @GetMapping(value = "/entity/{entityId}")
    public ResponseEntity<LdpEntity> getLdpEntity(@PathVariable("deviceId") String deviceId,
            @PathVariable("entityId") String entityId) {

        LdpEntity ldpEntity = new LdpEntity();
        AAIResourceUri ldpEntityUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpEntity(entityId));

        if (rClient.exists(ldpEntityUri)) {
            ldpEntity = rClient.get(LdpEntity.class, ldpEntityUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(ldpEntity);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ldpEntity);
    }

    @PutMapping(value = "/entity")
    public ResponseEntity<LdpEntity> createLdpEntity(@PathVariable("deviceId") String deviceId,
            @RequestBody LdpEntity ldpEntityBody) throws BulkProcessFailed {

        AAITransactionalClient transactions;

        String entityId = UUID.randomUUID().toString();
        ldpEntityBody.setEntityId(entityId);

        if (ldpEntityBody.getProtocolVersion() == null) {
            ldpEntityBody.setProtocolVersion(1);
        }

        if (ldpEntityBody.getTcpPort() == null) {
            ldpEntityBody.setTcpPort(646);
        }

        if (ldpEntityBody.getInitSessionThreshold() == null) {
            ldpEntityBody.setInitSessionThreshold(8);
        }

        if (ldpEntityBody.getMaxPduLength() == null) {
            ldpEntityBody.setMaxPduLength(4096);
        }

        if (ldpEntityBody.getKeepAliveHoldTimer() == null) {
            ldpEntityBody.setKeepAliveHoldTimer(40);
        }

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("LDP Entity",
                ldpEntityBody.getEntityId(), "Network Device", deviceId);

        AAIResourceUri entityUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpEntity(ldpEntityBody.getEntityId()));

        transactions = rClient.beginTransaction().create(entityUri, ldpEntityBody);

        transactions.execute();

        LdpPeer peer1 = constructLdpPeer("DEL-PE-154", entityId, "192.168.1.110", "downstreamOnDemand");
        LdpPeer peer2 = constructLdpPeer("HYD-P-475", entityId, "10.1.5.2", "downstreamUnsolicited");
        LdpPeer peer3 = constructLdpPeer("MH-CE-850", entityId, "10.1.5.4", "downstreamOnDemand");

        List<LdpPeer> peers = new ArrayList<LdpPeer>();
        peers.add(peer1);
        peers.add(peer2);
        peers.add(peer3);

        AAITransactionalClient peerTransactions = null;
        for (LdpPeer peer : peers) {
            AAIResourceUri ldpPeerUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpPeer(peer.getPeerId()));

            peerTransactions = rClient.beginTransaction().create(ldpPeerUri, peer);
            peerTransactions.execute();
        }

        description = ldpEntityBody.getEntityId() + " Entity has been Created.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "LDP",
                NoaEvents.CREATE_LDP_ENTITY.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(ldpEntityBody);
    }

    public LdpPeer constructLdpPeer(String peerName, String peerLdpId, String ipAddress, String labelDistMethod) {
        LdpPeer peer = new LdpPeer();
        String peerId = UUID.randomUUID().toString();

        peer.setPeerId(peerId);
        peer.setPeerName(peerName);
        peer.setPeerLdpId(peerLdpId);
        peer.setPeerLabelDistMethod(labelDistMethod);
        peer.setPeerPathVectorLimit(50);
        peer.setPeerTransportAddrType("IPv4");
        peer.setPeerTransportAddr(ipAddress);

        return peer;
    }

    @PostMapping(value = "/entity/{entityId}")
    public ResponseEntity<String> updateLdpEntity(@PathVariable("deviceId") String deviceId,
            @PathVariable("entityId") String entityId, @RequestBody LdpEntity ldpEntityBody) throws BulkProcessFailed {

        AAITransactionalClient transactions;
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("LDP Entity",
                ldpEntityBody.getEntityId(), "Network Device", deviceId);

        AAIResourceUri ldpEntityUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpEntity(ldpEntityBody.getEntityId()));

        if (rClient.exists(ldpEntityUri)) {
            transactions = rClient.beginTransaction().update(ldpEntityUri, ldpEntityBody);

            transactions.execute();
            description = ldpEntityBody.getEntityId() + " Entity has been Updated.";
            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = ldpEntityBody.getEntityId() + " Entity Doesn't Exists.";
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "LDP",
                NoaEvents.MODIFY_LDP_ENTITY.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/entity")
    public ResponseEntity<String> deleteLdpEntities(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> entityIds) throws BulkProcessFailed {

        AAITransactionalClient transactions;
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("LDP Entity", null, "Network Device",
                deviceId);

        for (String entityId : entityIds) {
            resourceMetadata.setResourceId(entityId);
            AAIResourceUri ldpEntityUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ldpEntity(entityId));

            if (rClient.exists(ldpEntityUri)) {
                transactions = rClient.beginTransaction().delete(ldpEntityUri);
                transactions.execute();
                description = entityId + " Entity has been Deleted.";
                eventStatus = true;
                reqStatus = HttpStatus.NO_CONTENT;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "LDP",
                        NoaEvents.DELETE_LDP_ENTITY.getEvent(), eventStatus, null, resourceMetadata, auth);
            } else {
                description = entityId + " Entity Doesn't Exists.";
                eventStatus = false;
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "LDP",
                        NoaEvents.DELETE_LDP_ENTITY.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("LDP Entity have been Deleted.");
    }
}
