package in.utl.noa.security.rbac.authentication.service;

import org.springframework.scheduling.annotation.Async;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.List;
import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.parser.ParseException;
import org.modelmapper.ModelMapper;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import org.onap.aai.domain.yang.UserAccount;
import org.onap.aai.domain.yang.AccessMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.springframework.beans.factory.annotation.Autowired;

import in.utl.noa.account.user.model.User;
import in.utl.noa.util.RestClientManager;

import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.security.rbac.authentication.GDBUserDetails;
import in.utl.noa.global.event.NoaEvents;

@Service
public class AuthenticationService {
    private static Logger logger = Logger.getLogger(AuthenticationService.class);

    AuditLogger auditLogger = new AuditLogger();
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @Autowired
    private GDBUserDetails userDetails;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @Async
    public void authSuccess(Authentication authentication) {
        UserAccount user = null;

        AccessMetadata accessMetadata = auditLogger.createAccessMetadata("10.0.0.115");

        String event = NoaEvents.LOGIN.getEvent();

        User account = (User) authentication.getPrincipal();
        user = modelMapper.map(account, UserAccount.class);
        logger.info("Event Handler");
        if (user != null) {
            user.setFailedAttempts(0);
            updateUser(user);
            String description = user.getUserName() + "Logged-in Successfully.";
            Boolean eventStatus = true;
            auditLogger.addAuditLog(rClient, description, "Security", "Authentication", NoaEvents.LOGIN.getEvent(),
                    eventStatus, accessMetadata, null, authentication);
        }
    }

    @Async
    public void authFailure(Authentication authentication) {
        User user = null;
        String description = null;
        Boolean eventStatus = false;
        AccessMetadata accessMetadata = auditLogger.createAccessMetadata("10.0.0.115");

        try {
            user = userDetails.findByUserName(authentication.getName());
            // TODO:change to getPrincipal when auth completely happens through GDB instead
            // of DSL Query.
        } catch (JsonProcessingException | ParseException e) {
            e.printStackTrace();
        }

        if (user != null) {
            int failedAttempts = user.getFailedAttempts();

            DSLStartNode startNode = new DSLStartNode(Types.USER_ACCOUNT,
                    __.key("user-name", authentication.getName()));
            DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                    .to(__.node(Types.PASSWORD_POLICY).output());

            String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

            JSONParser parser = new JSONParser();
            JSONObject resultsJson = null;
            try {
                resultsJson = (JSONObject) parser.parse(results);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

            int maxFailAttempts = 2;

            if (resultsArray.size() > 0) {
                JSONObject securityPolicyObject = (JSONObject) resultsArray.get(0).get("properties");
                Object newobj = securityPolicyObject.get("max-fail-attempt");
                maxFailAttempts = Integer.parseInt(newobj.toString());
            }

            if (failedAttempts >= maxFailAttempts) {
                user.setAccountStatus(false);
                updateUser(user);
                description = authentication.getName() + " User Account has been Locked";
                auditLogger.addAuditLog(rClient, description, "Security", "Authentication",
                        NoaEvents.LOCK_ACCOUNT.getEvent(), eventStatus, accessMetadata, null, authentication);
            } else {
                user.setFailedAttempts(failedAttempts + 1);
                updateUser(user);
            }
            description = authentication.getName() + " Log-in Failed.";
            auditLogger.addAuditLog(rClient, description, "Security", "Authentication", NoaEvents.LOGIN.getEvent(),
                    eventStatus, accessMetadata, null, authentication);
        } else {
            description = authentication.getName() + " Not Found in DB.";
            auditLogger.addAuditLog(rClient, description, "Security", "Authentication", NoaEvents.LOGIN.getEvent(),
                    eventStatus, accessMetadata, null, authentication);
        }
    }

    public void updateUser(UserAccount user) {
        String accountId = user.getAccountId();
        AAIResourceUri userUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().userAccount(accountId));

        rClient.update(userUri, user);
    }
}
