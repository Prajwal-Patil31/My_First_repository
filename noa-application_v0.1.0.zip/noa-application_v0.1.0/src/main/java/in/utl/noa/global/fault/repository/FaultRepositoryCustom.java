package in.utl.noa.global.fault.repository;

import java.util.Date;

import org.json.simple.JSONObject;

import in.utl.noa.dto.RequestBodyDTO;

public interface FaultRepositoryCustom<Fault> {
    public boolean clearFaults(int faultCode);

    public boolean isDuplicateFault(int faultCode);

    public Fault updateFaultCountAndDate(int faultCode, Date genDate);

    public Fault updateAcknowledgementDate(int faultCode);

    <S extends Fault> S saveAndPush(S entity);

    JSONObject filterByField(RequestBodyDTO requestBody);
}