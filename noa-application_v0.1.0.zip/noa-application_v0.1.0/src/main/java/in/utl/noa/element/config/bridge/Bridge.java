package in.utl.noa.element.config.bridge;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.onap.aai.domain.yang.BridgeInstance;
import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.StpConfig;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.element.service.DeviceOperationService;
import in.utl.noa.element.service.EdgeRouterService;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.platform.config.service.RollbackHandler;

import org.onap.aai.domain.yang.Attributes;

@RestController
@RequestMapping(value = "/api/element/{deviceId}/bridge")
public class Bridge {

    private static Logger logger = Logger.getLogger(Bridge.class);

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    @Autowired
    RollbackHandler rollbackHandler;

    @Autowired
    DeviceOperationService deviceService;

    /*
     * @Autowired DeviceRepository deviceRepo;
     */

    @Autowired
    EdgeRouterService edgeRouterService;

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<BridgeInstance>> getBridgeInstances(@PathVariable("deviceId") String deviceId) {

        List<BridgeInstance> bridgeInstances = new ArrayList<BridgeInstance>();

        NetworkDevice device = new NetworkDevice();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);

        if (rClient.exists(deviceUri)) {

            device = rClient.get(NetworkDevice.class, deviceUri).get();

            if (device.getBridgeInstances() != null) {
                bridgeInstances = device.getBridgeInstances().getBridgeInstance();
            }
            return ResponseEntity.status(HttpStatus.OK).body(bridgeInstances);
        }
        return ResponseEntity.status(HttpStatus.OK).body(bridgeInstances);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getBridgeFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "bridge-instance");

        Map<String, Object> columns = new HashMap<>();
        columns.put("bridgeName", "Interface Name");
        columns.put("gvrpStatus", "GVRP Status");
        columns.put("gmrpStatus", "GMRP Status");
        columns.put("trafficClass", "Traffic Class");
        columns.put("maxVlanId", "Max VLAN Id");
        columns.put("maxSupportedVlans", "Max VLANs");
        columns.put("numOfVlans", "Num of VLANs");
        columns.put("activeVlans", "Active VLANs");
        columns.put("bridgeState", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getBridgeInstanceList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject bridgeInstances = filterService.queryByFilter(requestBody, "bridge-instance");
        return ResponseEntity.status(HttpStatus.OK).body(bridgeInstances);
    }

    @GetMapping(value = "/{bridgeId}")
    public ResponseEntity<BridgeInstance> getBridgeInstances(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId) {

        BridgeInstance bridgeInstance = new BridgeInstance();

        AAIResourceUri bridgeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

        if (rClient.exists(bridgeUri)) {

            bridgeInstance = rClient.get(BridgeInstance.class, bridgeUri).get();

            return ResponseEntity.status(HttpStatus.OK).body(bridgeInstance);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(bridgeInstance);
    }

    @PutMapping()
    public ResponseEntity<BridgeInstance> createBridgeInstance(@PathVariable("deviceId") String deviceId,
            @RequestBody BridgeInstance bridgeConfig) throws BulkProcessFailed {

        String bridgeId = UUID.randomUUID().toString();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Bridge Config", bridgeId,
                "Network Device", deviceId);

        AAIResourceUri bridgeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

        bridgeConfig.setActiveVlans(0);
        bridgeConfig.setNumOfVlans(0);
        bridgeConfig.setBridgeId(bridgeId);

        AAITransactionalClient transactions;
        transactions = rClient.beginTransaction().create(bridgeUri, bridgeConfig);
        transactions.execute();
        description = "Bridge Instance has been Created in " + deviceId;

        JSONObject bridgeConfigObj = rollbackHandler.getJsonObject(bridgeConfig);

        List<Attributes> attributes = rollbackHandler.createAttributes(bridgeConfigObj, null, null);
        String resourceUri = bridgeUri.getObjectType().toString();
        rollbackHandler.addRollbackUnit("Create", "org.onap.aai.domain.yang.BridgeInstance", bridgeId, resourceUri,
                deviceId, attributes, null, 0, description, true);

        eventStatus = true;
        reqStatus = HttpStatus.OK;

        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Bridge",
                NoaEvents.CREATE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(bridgeConfig);
    }

    @PostMapping(value = "/{bridgeId}")
    public ResponseEntity<String> updateBridgeConfiguration(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @RequestBody BridgeInstance updatedBridgeConfig)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Bridge Config", bridgeId,
                "Network Device", deviceId);

        AAIResourceUri bridgeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

        if (rClient.exists(bridgeUri)) {
            AAITransactionalClient transactions;
            BridgeInstance updBridgeConfig = rClient.get(BridgeInstance.class, bridgeUri).get();
            transactions = rClient.beginTransaction().update(bridgeUri, updatedBridgeConfig);
            transactions.execute();
            description = "Bridge Configuration has been Updated in " + deviceId + " Device";

            JSONObject bridgeConfigObj = rollbackHandler.getJsonObject(updBridgeConfig);

            List<Attributes> attributes = rollbackHandler.createAttributes(bridgeConfigObj, null, null);
            String resourceUri = bridgeUri.getObjectType().toString();
            rollbackHandler.addRollbackUnit("Update", "org.onap.aai.domain.yang.Bridge", bridgeId, resourceUri,
                    deviceId, attributes, null, 0, description, true);

            eventStatus = true;
            reqStatus = HttpStatus.OK;
        } else {
            description = bridgeId + " Bridge Doesn't Exists";
            reqStatus = HttpStatus.NOT_FOUND;
        }
        auditLogger.addAuditLog(rClient, description, "Device Configuration", "Bridge",
                NoaEvents.UPDATE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteBridgeInstances(@PathVariable("deviceId") String deviceId,
            @RequestBody List<String> bridgeInstanceIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Bridge Config", null, "Network Device",
                deviceId);

        for (String bridgeInstanceId : bridgeInstanceIds) {
            resourceMetadata.setResourceId(bridgeInstanceId);
            if (bridgeInstanceId != null) {
                AAIResourceUri bridgeUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeInstanceId));
                if (rClient.exists(bridgeUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(bridgeUri);
                    transactions.execute();
                    description = bridgeInstanceId + " Bridge Instance has been Deleted";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "BridgeInstance",
                            NoaEvents.DELETE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                } else {
                    description = bridgeInstanceId + " Bridge Instance Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Device Configuration", "BridgeInstance",
                            NoaEvents.DELETE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Bridge Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Device Configuration", "BridgeInstance",
                        NoaEvents.DELETE_BRIDGE_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/{bridgeId}/port")
    public ResponseEntity<List<IetfInterface>> getBridgePorts(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<IetfInterface> interfaces = new ArrayList<IetfInterface>();

        DSLStartNode startNode = new DSLStartNode(Types.BRIDGE_INSTANCE, __.key("bridge-id", bridgeId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.IETF_INTERFACE))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject interfaceObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            IetfInterface interfaceBody = mapper.readValue(interfaceObj.toString(), IetfInterface.class);
            interfaces.add(interfaceBody);
        }
        return ResponseEntity.status(HttpStatus.OK).body(interfaces);
    }

    @PostMapping(value = "/{bridgeId}/port")
    public ResponseEntity<String> addBridgePorts(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @RequestBody List<String> interfaceIds)
            throws ParseException, BulkProcessFailed {

        if (bridgeId != null) {
            for (String interfaceId : interfaceIds) {
                AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

                AAIResourceUri bridgeUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().connect(bridgeUri, interfaceUri);
                transactions.execute();
            }
            return ResponseEntity.status(HttpStatus.OK).body("Ports Added to Bridge Instance");
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No Bridge Instance Found");
        }
    }

    @DeleteMapping(value = "/{bridgeId}/port")
    public ResponseEntity<String> removeBridgePorts(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @RequestBody List<String> interfaceIds)
            throws ParseException, BulkProcessFailed {

        if (bridgeId != null) {
            for (String interfaceId : interfaceIds) {
                AAIResourceUri interfaceUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));

                AAIResourceUri bridgeUri = AAIUriFactory.createResourceUri(
                        AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId));

                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().disconnect(bridgeUri, interfaceUri);
                transactions.execute();
            }
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Ports Removed from Bridge Instance");
        } else {
            return ResponseEntity.status(HttpStatus.OK).body("No Bridge Instance Found");
        }
    }

    @GetMapping(value = "/{bridgeId}/stp")
    public ResponseEntity<StpConfig> getStpConfigInBridge(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId) {

        BridgeInstance bridge = new BridgeInstance();
        StpConfig stpConfig = new StpConfig();

        AAIResourceUri bridgeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId))
                .depth(Depth.TWO);
        if (rClient.exists(bridgeUri)) {
            bridge = rClient.get(BridgeInstance.class, bridgeUri).get();
            if (bridge.getStpConfig().size() > 0) {
                stpConfig = bridge.getStpConfig().get(0);
                return ResponseEntity.status(HttpStatus.OK).body(stpConfig);
            }
        }

        return ResponseEntity.status(HttpStatus.OK).body(stpConfig);
    }

    @PostMapping(value = "/{bridgeId}/stp")
    public ResponseEntity<String> updateStpConfigInBridge(@PathVariable("deviceId") String deviceId,
            @PathVariable("bridgeId") String bridgeId, @RequestBody StpConfig stpConfig) throws BulkProcessFailed {

        AAIResourceUri stpConfigUri = AAIUriFactory.createResourceUri(
                AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance(bridgeId).stpConfig(bridgeId));

        if (stpConfig.getConfigId() == null) {
            stpConfig.setConfigId(bridgeId);
        }

        AAITransactionalClient transactions = null;
        if (rClient.exists(stpConfigUri)) {
            transactions = rClient.beginTransaction().update(stpConfigUri, stpConfig);
            transactions.execute();
        } else {
            transactions = rClient.beginTransaction().create(stpConfigUri, stpConfig);
            transactions.execute();
        }
        return ResponseEntity.status(HttpStatus.OK).body("STP Configuration has been Updated");
    }
}
