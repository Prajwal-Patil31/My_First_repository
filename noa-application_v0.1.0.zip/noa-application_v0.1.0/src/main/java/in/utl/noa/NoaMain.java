package in.utl.noa;

import java.util.concurrent.Executor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.rest.core.config.RepositoryRestConfiguration;
import org.springframework.data.rest.webmvc.config.RepositoryRestConfigurer;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import in.utl.noa.account.user.model.UserAccount;
import in.utl.noa.global.fault.model.Fault;

import in.utl.noa.global.fault.model.FaultEscalatePolicy;
import in.utl.noa.security.rbac.role.model.Role;
import in.utl.noa.security.rbac.role.model.Feature;
import in.utl.noa.global.fault.model.FaultConfig;
import org.modelmapper.ModelMapper;

@EnableZuulProxy
@SpringBootApplication
@EnableAsync
/*
 * @EnableHypermediaSupport(type = EnableHypermediaSupport.HypermediaType.HAL)
 */
public class NoaMain {

	public static void main(String[] args) {
		SpringApplication.run(NoaMain.class, args);
	}

	@Bean
	public Executor taskExecutor() {
	  ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	  executor.setCorePoolSize(2);
	  executor.setMaxPoolSize(2);
	  executor.setQueueCapacity(500);
	  executor.setThreadNamePrefix("NOA-");
	  executor.initialize();
	  return executor;
	}

	@Bean
	public WebServerFactoryCustomizer<ConfigurableWebServerFactory> webServerFactoryCustomizer() {
		return factory -> {
			ErrorPage error404Page = new ErrorPage(HttpStatus.NOT_FOUND, "/resources/templates/index.html");
			ErrorPage error401Page = new ErrorPage(HttpStatus.UNAUTHORIZED, "/resources/templates/index.html");
			factory.addErrorPages(error404Page);
			//factory.addErrorPages(error401Page);
		};
	}
	
	@Configuration
	public class RepositoryConfig implements RepositoryRestConfigurer {

		@Override
		public void configureRepositoryRestConfiguration(RepositoryRestConfiguration config, CorsRegistry registry) {
			config.exposeIdsFor(UserAccount.class, Role.class, Feature.class, Fault.class, FaultEscalatePolicy.class,
					FaultConfig.class);
		}

		@Configuration
		public class NoaAppConfig {
			@Bean
			public ModelMapper modelMapper() {
				return new ModelMapper();
			}
		}
	}

}
