package in.utl.noa.mdsal.toaster;

import org.eclipse.jdt.annotation.NonNull;
import org.opendaylight.mdsal.dom.api.DOMNotification;
import org.opendaylight.yangtools.yang.binding.NotificationListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericLoggingNotificationListener implements NotificationListener {
    private static final Logger LOG = LoggerFactory.getLogger(GenericLoggingNotificationListener.class);

    public void onNotification(@NonNull DOMNotification notification) {
        LOG.info("Notification {} received", notification);
    }
}
