package in.utl.noa.platform.config.service;

import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.Attributes;
import org.onap.aai.domain.yang.RollbackUnit;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIObjectType;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.AAIResultWrapper;
import org.onap.aaiclient.client.aai.entities.CustomQuery;
import org.onap.aaiclient.client.aai.entities.Relationships;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Output;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import in.utl.noa.util.RestClientManager;

@Service
public class RollbackHandler {

    private static Logger logger = Logger.getLogger(RollbackHandler.class);

    private static final String PATTERN = "dd/MM/yyyy HH:mm:ss";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat(PATTERN);

    private ObjectMapper objectMapper = new AAICommonObjectMapperProvider().getMapper();
    private JSONParser parser = new JSONParser();

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIQueryClient qClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        qClient = restClientManager.getQClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public RollbackUnit addRollbackUnit(String operation, String resource, String resourceId, String resourceUri,
            String moduleId, List<Attributes> attributes, AAIResourceUri sequencedUri, Integer sequenceNumber,
            String description, Boolean visibility) {

        Integer rollbackUnitsCount = getRollbackUnitsCount();
        AAITransactionalClient transactions = rClient.beginTransaction();

        if (rollbackUnitsCount > 1000) {
            String query = "g.V().hasLabel('rollback-unit').order().by('time-stamp', asc).limit(1)";
            String results = null;
            try {
                results = qClient.query(Format.RESOURCE, new CustomQuery(query));
            } catch (UnsupportedEncodingException e1) {
                e1.printStackTrace();
            }

            String oldRecordId = null;
            Results<Map<String, RollbackUnit>> resultsFromJson;
            try {
                resultsFromJson = objectMapper.readValue(results,
                        new TypeReference<Results<Map<String, RollbackUnit>>>() {
                        });
                for (Map<String, RollbackUnit> m : resultsFromJson.getResult()) {
                    oldRecordId = m.get("rollback-unit").getRollbackId();
                }
            } catch (JsonProcessingException e1) {
                e1.printStackTrace();
            }

            AAIResourceUri oldestRecordUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(oldRecordId));
            transactions.delete(oldestRecordUri);
            try {
                transactions.execute();
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        }

        RollbackUnit rollbackUnit = new RollbackUnit();
        UUID uuid = UUID.randomUUID();

        Date date = Calendar.getInstance().getTime();
        String timeStamp = DATE_FORMAT.format(date);

        rollbackUnit.setRollbackId(uuid.toString());
        rollbackUnit.setOperation(operation);
        rollbackUnit.setResource(resource);
        rollbackUnit.setResourceId(resourceId);
        rollbackUnit.setTimeStamp(timeStamp);
        rollbackUnit.setVisibility(visibility);
        rollbackUnit.setValid(true);
        rollbackUnit.setResourceUri(resourceUri);
        rollbackUnit.setDescription(description);
        rollbackUnit.setOrder(sequenceNumber);
        if (moduleId != null) {
            rollbackUnit.setModuleId(moduleId);
        }

        AAIResourceUri rollbackUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackUnit(rollbackUnit.getRollbackId()));

        if (attributes != null && attributes.size() > 0) {
            rollbackUnit.getAttributes().addAll(attributes);
        }
        transactions = rClient.beginTransaction();

        transactions.create(rollbackUri, rollbackUnit);
        if (sequencedUri != null) {
            transactions.connect(rollbackUri, sequencedUri);
        }
        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
        return rollbackUnit;
    }

    public List<Attributes> createAttributes(JSONObject json, String attributeUri, String moduleId) {

        List<Attributes> attributes = new ArrayList<Attributes>();

        if (json != null) {
            Set<String> keys = json.keySet();
            List<String> modifiedKeys = new ArrayList<String>();
            modifiedKeys.addAll(keys);

            for (int i = 0; i < modifiedKeys.size(); i++) {
                Attributes attribute = new Attributes();
                String attributeKey = modifiedKeys.get(i);
                UUID uuid = UUID.randomUUID();
                attribute.setAttributeId(uuid.toString());
                attribute.setAttributeKey(attributeKey);
                if (attributeUri != null) {
                    attribute.setAttributeUri(attributeUri);
                }
                attribute.setModuleId(moduleId);
                attribute.setAttributeValue(json.get(attributeKey).toString());
                if (!attributeKey.equals("relationship-list")) {
                    attributes.add(attribute);
                }
            }
        }
        return attributes;
    }

    public Integer getRollbackUnitsCount() {

        AAIPluralResourceUri rollbackRecordsUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.rollback().rollbackRecords()).format(Format.COUNT);

        Integer count = 0;
        if (rClient.exists(rollbackRecordsUri)) {
            String results = rClient.get(rollbackRecordsUri).getJson();
            Results<Map<String, Integer>> resultsFromJson;
            try {
                resultsFromJson = objectMapper.readValue(results, new TypeReference<Results<Map<String, Integer>>>() {
                });
                for (Map<String, Integer> m : resultsFromJson.getResult()) {
                    count = m.get("rollback-unit");
                }
            } catch (JsonProcessingException e1) {
                e1.printStackTrace();
            }
        }

        return count;
    }

    public List<RollbackUnit> getRollbackUnits() {
        List<RollbackUnit> rollbackUnits = new ArrayList<RollbackUnit>();

        DSLStartNode startNode = new DSLStartNode(Types.ROLLBACK_UNIT, __.key("visibility", true));

        DSLQueryBuilder<Output, Output> builder = TraversalBuilder.traversal(startNode.output());

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, RollbackUnit>> resultsFromJson;
        try {
            resultsFromJson = objectMapper.readValue(results, new TypeReference<Results<Map<String, RollbackUnit>>>() {
            });
            for (Map<String, RollbackUnit> m : resultsFromJson.getResult()) {
                rollbackUnits.add(m.get("rollback-unit"));
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        return rollbackUnits;
    }

    public Date getDateFromTimestamp(String timeStamp) {
        Date date = new Date();
        try {
            date = DATE_FORMAT.parse(timeStamp);
        } catch (java.text.ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public void revertConfiguration(AAIResourceUri rollbackUri)
            throws IllegalArgumentException, ClassNotFoundException, BulkProcessFailed {

        AAIResultWrapper resultWrapper = rClient.get(rollbackUri);

        List<AAIResourceUri> connectedUris = new ArrayList<AAIResourceUri>();
        if (resultWrapper.hasRelationshipsTo(Types.ROLLBACK_UNIT)) {
            Relationships relationships = resultWrapper.getRelationships().get();
            List<AAIResourceUri> allRelatedNodes = relationships.getRelatedUris(Types.ROLLBACK_UNIT);
            connectedUris.addAll(allRelatedNodes);
        }

        List<RollbackUnit> rollbackUnits = new ArrayList<RollbackUnit>();
        rollbackUnits.add(rClient.get(RollbackUnit.class, rollbackUri).get());

        for (AAIResourceUri connectedUri : connectedUris) {
            RollbackUnit rollbackUnit = rClient.get(RollbackUnit.class, connectedUri.depth(Depth.TWO)).get();
            rollbackUnits.add(rollbackUnit);
        }

        Collections.sort(rollbackUnits, new Comparator<RollbackUnit>() {
            @Override
            public int compare(RollbackUnit a, RollbackUnit b) {
                Integer position1 = a.getOrder();
                Integer position2 = b.getOrder();
                return position1.compareTo(position2);
            }
        });

        AAITransactionalClient transactions = rClient.beginTransaction();

        for (RollbackUnit rollbackUnit : rollbackUnits) {

            String operation = rollbackUnit.getOperation();
            String resource = rollbackUnit.getResource();
            String resourceId = rollbackUnit.getResourceId();
            String resourceUri = rollbackUnit.getResourceUri();
            String objType = getObjectType(resource);

            List<String> ids = new ArrayList<String>();
            if (rollbackUnit.getModuleId() != null) {
                ids.add(rollbackUnit.getModuleId());
            }
            ids.add(resourceId);
            String[] valuesArray = ids.toArray(new String[0]);

            AAIResourceUri uri = AAIUriFactory.createResourceUri(AAIObjectType.fromTypeName(objType, resourceUri),
                    valuesArray);

            switch (operation) {
                case "Create":
                    rollbackCreate(transactions, uri, rollbackUnit);
                    break;
                case "Update":
                    rollbackUpdate(transactions, uri, rollbackUnit);
                    break;
                case "Connect":
                    rollbackConnect(transactions, uri, rollbackUnit);
                    break;
                default:
                    break;
            }
        }
        transactions.execute();
    }

    public void rollbackCreate(AAITransactionalClient transactions, AAIResourceUri uri, RollbackUnit rollbackUnit)
            throws BulkProcessFailed, IllegalArgumentException, ClassNotFoundException {

        List<Attributes> attributes = rollbackUnit.getAttributes();

        JSONObject jsonObject = new JSONObject();
        for (Attributes attribute : attributes) {
            jsonObject.put(attribute.getAttributeKey(), attribute.getAttributeValue());
        }

        if (rClient.exists(uri)) {
            String resourceVersion = (String) rClient.get(uri).asMap().get("resource-version");
            jsonObject.put("resource-version", resourceVersion);
            transactions.create(uri, objectMapper.convertValue(jsonObject, Class.forName(rollbackUnit.getResource())));
        } else {
            jsonObject.remove("resource-version");
            transactions.create(uri, objectMapper.convertValue(jsonObject, Class.forName(rollbackUnit.getResource())));
        }
    }

    public void rollbackUpdate(AAITransactionalClient transactions, AAIResourceUri uri, RollbackUnit rollbackUnit)
            throws BulkProcessFailed, IllegalArgumentException, ClassNotFoundException {

        List<Attributes> attributes = rollbackUnit.getAttributes();

        JSONObject jsonObject = new JSONObject();
        for (Attributes attribute : attributes) {
            jsonObject.put(attribute.getAttributeKey(), attribute.getAttributeValue());
        }

        if (rClient.exists(uri)) {
            transactions.update(uri, objectMapper.convertValue(jsonObject, Class.forName(rollbackUnit.getResource())));
        } else {
            jsonObject.remove("resource-version");
            transactions.create(uri, objectMapper.convertValue(jsonObject, Class.forName(rollbackUnit.getResource())));
        }
    }

    public void rollbackConnect(AAITransactionalClient transactions, AAIResourceUri uri, RollbackUnit rollbackUnit)
            throws BulkProcessFailed {
        List<Attributes> attributes = rollbackUnit.getAttributes();

        for (Attributes attribute : attributes) {
            String resourceUri = attribute.getAttributeUri();
            String objType = getObjectType(attribute.getAttributeKey());

            List<String> ids = new ArrayList<String>();

            if (attribute.getModuleId() != null) {
                ids.add(attribute.getModuleId());
            }

            ids.add(attribute.getAttributeValue());

            String[] valuesArray = ids.toArray(new String[0]);
            AAIResourceUri attributeUri = AAIUriFactory
                    .createResourceUri(AAIObjectType.fromTypeName(objType, resourceUri), valuesArray);

            transactions.connect(uri, attributeUri);
        }
    }

    public String getObjectType(String attributeKey) {

        String objType = attributeKey.substring(attributeKey.lastIndexOf(".") + 1);

        String regex = "(?!^)(?=[A-Z][a-z0-9])";

        objType = objType.replaceAll(regex, "-").toLowerCase();
        return objType;
    }

    public JSONObject getJsonObject(Object value) {
        JSONObject json = new JSONObject();

        String nodeAsString = "";
        objectMapper.setSerializationInclusion(Include.NON_NULL);
        try {
            nodeAsString = objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException e1) {
            e1.printStackTrace();
        }

        try {
            json = (JSONObject) parser.parse(nodeAsString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return json;
    }
}
