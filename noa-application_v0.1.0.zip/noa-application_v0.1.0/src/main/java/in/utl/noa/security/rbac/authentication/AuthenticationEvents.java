package in.utl.noa.security.rbac.authentication;

import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import in.utl.noa.security.rbac.authentication.service.AuthenticationService;

@Service
public class AuthenticationEvents {
	private static Logger logger = Logger.getLogger(AuthenticationEvents.class);

	@Autowired
	private AuthenticationService authService;

	@EventListener
	public void onSuccess(AuthenticationSuccessEvent success) {
		Authentication auth = success.getAuthentication();
		authService.authSuccess(auth);
	}

	@EventListener
	public void onFailure(AbstractAuthenticationFailureEvent failures) {
		Authentication auth = failures.getAuthentication();
		authService.authFailure(auth);
	}
}
