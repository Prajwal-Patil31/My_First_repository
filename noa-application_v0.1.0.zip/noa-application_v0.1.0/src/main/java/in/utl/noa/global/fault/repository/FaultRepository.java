package in.utl.noa.global.fault.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import in.utl.noa.global.fault.model.Fault;

import java.util.Optional;

@RepositoryRestResource(collectionResourceRel = "fault", path = "fault")
public interface FaultRepository extends JpaRepository<Fault, Integer>, FaultRepositoryCustom<Fault> {

    public Optional<Fault> findByFaultId(int faultId);

    public Page<Fault> findAll(Pageable pageable);

    public Page<Fault> findBySeverity(Integer severity, Pageable pageable);

    public Page<Fault> findByResource(String resource, Pageable pageable);

}