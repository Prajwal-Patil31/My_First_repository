package in.utl.noa.network.l3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.log4j.Logger;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.onap.aai.domain.yang.IetfNetwork;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.Route;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.security.audit.AuditLogger;

import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/network/{networkId}/route")
public class RouteManagement {
    private static Logger logger = Logger.getLogger(RouteManagement.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();
    AuditLogger auditLogger = new AuditLogger();

    JSONParser parser = new JSONParser();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;
    private AAIQueryClient qClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
        qClient = restClientManager.getQClient();
    }

    @GetMapping()
    public ResponseEntity<List<Route>> getRoutes(@PathVariable("networkId") String networkId) {

        List<Route> routes = new ArrayList<Route>();

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId)).depth(Depth.TWO);
        if (rClient.exists(networkUri)) {
            IetfNetwork network = new IetfNetwork();
            network = rClient.get(IetfNetwork.class, networkUri).get();
            if (network.getRoutes() != null) {
                routes = network.getRoutes().getRoute();
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(routes);
    }

    @GetMapping(value = "/filter")
    public ResponseEntity<ResponseDataDTO> getNetworkLinkFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "route");

        Map<String, Object> columns = new HashMap<>();
        columns.put("routeName", "Route Name");
        columns.put("sourceElement", "Source Element");
        columns.put("localAddress", "Local Address");
        columns.put("destinationElement", "Destination Element");
        columns.put("nexthopAddress", "Next Hop Address");
        columns.put("routeStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getLinkList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject lsps = filterService.queryByFilter(requestBody, "route");
        return ResponseEntity.status(HttpStatus.OK).body(lsps);
    }

    @GetMapping(value = "/{routeId}")
    public ResponseEntity<Route> getRoute(@PathVariable("networkId") String networkId,
            @PathVariable("routeId") String routeId) {

        Route route = new Route();
        AAIResourceUri routeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).route(routeId));
        if (rClient.exists(routeUri)) {
            route = rClient.get(Route.class, routeUri).get();
        }
        return ResponseEntity.status(HttpStatus.OK).body(route);
    }

    @PostMapping("/exists")
    public ResponseEntity<Boolean> checkRouteExistence(@PathVariable("networkId") String networkId,
            @RequestBody JSONObject srcDest) throws ParseException {

        String srcElement = srcDest.get("sourceElement").toString();
        String localAddress = srcDest.get("localAddress").toString();
        String destElement = srcDest.get("destinationElement").toString();
        String nexthopAddress = srcDest.get("nexthopAddress").toString();

        DSLStartNode startNode = new DSLStartNode(Types.IETF_NETWORK, __.key("network-id", networkId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.ROUTE, __.key("source-element", srcElement), __.key("local-address", localAddress),
                        __.key("destination-element", destElement), __.key("nexthop-address", nexthopAddress)))
                .output();

        String results = dslClient.query(Format.COUNT, new DSLQuery(builder.build()));

        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        JSONObject countObj = (JSONObject) resultsArray.get(0).get("route");

        Boolean exists = false;
        if (countObj != null) {
            exists = true;
        }

        return ResponseEntity.status(HttpStatus.OK).body(exists);
    }

    @PutMapping()
    public ResponseEntity<String> addRoutesToNetwork(@PathVariable("networkId") String networkId,
            @RequestBody Route routeBody) throws BulkProcessFailed, JsonProcessingException {

        String description = null;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Boolean eventStatus = false;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String routeId = UUID.randomUUID().toString();
        routeBody.setRouteId(routeId);
        routeBody.setRouteStatus(true);

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        AAIResourceUri networkUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId));
        if (rClient.exists(networkUri)) {
            AAIResourceUri routeUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).route(routeId));

            AAITransactionalClient transactions;
            transactions = rClient.beginTransaction().create(routeUri, routeBody);

            transactions.execute();
        }
        description = routeBody.getRouteName() + " Route has been Created.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;
        auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                NoaEvents.ADD_ROUTE_TO_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> removeRoutesFromNetwork(@PathVariable("networkId") String networkId,
            @RequestBody List<String> routeIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Node", null, "Network", networkId);

        for (String routeId : routeIds) {
            resourceMetadata.setResourceId(routeId);
            if (networkId != null && routeId != null) {
                AAIResourceUri routeUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().ietfNetwork(networkId).route(routeId));
                if (rClient.exists(routeUri)) {
                    AAITransactionalClient transactions = rClient.beginTransaction().delete(routeUri);
                    transactions.execute();
                    description = routeId + " Route has been Removed from " + networkId + " Network";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_ROUTE_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = routeId + "Route Doesn't Exists.";
                    eventStatus = false;
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                            NoaEvents.REMOVE_ROUTE_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Route Id";
                eventStatus = false;
                reqStatus = HttpStatus.BAD_REQUEST;
                auditLogger.addAuditLog(rClient, description, "Network Management", "Network",
                        NoaEvents.REMOVE_ROUTE_FROM_NETWORK.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Routes have been Removed.");
    }
}
