package in.utl.noa.dto;

import org.onap.aai.domain.yang.Event;

import in.utl.noa.global.fault.model.Fault;

public class NotificationDTO {
    private Event notification;
    private Fault fault;
    private Object eventObject;

    public NotificationDTO() {
    }

    public Event getNotification() {
        return this.notification;
    }

    public void setNotification(Event notification) {
        this.notification = notification;
    }

    public Fault getFault() {
        return this.fault;
    }

    public void setFault(Fault fault) {
        this.fault = fault;
    }

    public Object getEventObject() {
        return this.eventObject;
    }

    public void setEventObject(Object eventObject) {
        this.eventObject = eventObject;
    }

}
