package in.utl.noa.mdsal;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.util.concurrent.ListenableFuture;
import in.utl.noa.mdsal.toaster.GenericLoggingNotificationListener;
import in.utl.noa.mdsal.toaster.LoggingNotificationListener;
import in.utl.noa.mdsal.toaster.ToasterDeviceNotificationsListener;
import in.utl.noa.element.service.DeviceOperationService;
import in.utl.noa.element.service.DeviceOperationServiceImpl;
import io.lighty.core.controller.api.LightyServices;
import org.eclipse.jdt.annotation.NonNull;
import org.opendaylight.mdsal.binding.api.*;
import org.opendaylight.netconf.sal.connect.netconf.sal.NetconfDeviceNotificationService;
import org.opendaylight.netconf.sal.connect.netconf.schema.mapping.NetconfMessageTransformer;
import org.opendaylight.yang.gen.v1.http.netconfcentral.org.ns.toaster.rev091120.Toaster;
import org.opendaylight.yang.gen.v1.http.netconfcentral.org.ns.toaster.rev091120.ToasterRestocked;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.netconf.notification._1._0.rev080714.CreateSubscriptionInputBuilder;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.netconf.notification._1._0.rev080714.NotificationsService;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.netconf.notification._1._0.rev080714.StreamNameType;
import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.NetconfNode;
import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.NetconfNodeConnectionStatus;
import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.network.topology.topology.topology.types.TopologyNetconf;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NetworkTopology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NodeId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TopologyId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.TopologyKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Node;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.NodeKey;
import org.opendaylight.yang.gen.v1.yang.noa.toaster.notifications.rev210817.DeviceNotification;
import org.opendaylight.yangtools.concepts.ListenerRegistration;
import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.binding.KeyedInstanceIdentifier;
import org.opendaylight.yangtools.yang.binding.NotificationListener;
import org.opendaylight.yangtools.yang.common.QName;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public class DeviceDataTreeChangeListener implements DataTreeChangeListener<Node> {

    private static final Logger LOG = LoggerFactory.getLogger(DeviceDataTreeChangeListener.class);
    private LightyServices lightyServices = null;
    
    private DeviceOperationServiceImpl deviceOperationsImpl = new DeviceOperationServiceImpl();
    
    public static final InstanceIdentifier<Topology> NETCONF_TOPO_IID =
            InstanceIdentifier
                    .create(NetworkTopology.class)
                    .child(Topology.class,
                            new TopologyKey(new TopologyId(TopologyNetconf.QNAME.getLocalName())));

    LoadingCache<String, KeyedInstanceIdentifier<Node, NodeKey>> mountIds = CacheBuilder.newBuilder()
            .maximumSize(20)
            .build(
                    new CacheLoader<String, KeyedInstanceIdentifier<Node, NodeKey>>() {
                        @Override
                        public KeyedInstanceIdentifier<Node, NodeKey> load(final String key) {
                            return NETCONF_TOPO_IID.child(Node.class, new NodeKey(new NodeId(key)));
                        }
                    });

    public DeviceDataTreeChangeListener (LightyServices lightyServices) {
        this.lightyServices = lightyServices;
    }

    @Override
    public void onDataTreeChanged(@NonNull Collection<DataTreeModification<Node>> changes) {
        changes.forEach(this::onDataChanged);
    }

    private void onDataChanged(DataTreeModification<Node> change) {
        /* LOG.info("OnDataChange, change: {}", change); */

        final DataObjectModification<Node> node = change.getRootNode();
        switch (node.getModificationType()) {
            case DELETE:
                LOG.info("NETCONF Node: {} was removed", node.getIdentifier());
                String nodeId = node.getDataBefore().getNodeId().getValue();
                //deviceOperationsImpl.updateDeviceState(nodeId,false);
                break;
            case SUBTREE_MODIFIED:
                LOG.info("NETCONF Node: {} was updated", node.getIdentifier());
                onNodeUpdated(node.getDataAfter());
                break;
            case WRITE:
                LOG.info("NETCONF Node: {} was created", node.getIdentifier());
                onNodeUpdated(node.getDataAfter());
                break;
            default:
                throw new IllegalStateException("Unhandled node change" + change);
        }
    }

    private void onNodeUpdated(final Node node) {
        // Do we have a Netconf device?
        final NetconfNode nnode = node.augmentation(NetconfNode.class);
        if (nnode == null) {
            LOG.info("NETCONF Node: {} is not managed", node.getNodeId());
            return;
        }

        final NetconfNodeConnectionStatus.ConnectionStatus csts = nnode.getConnectionStatus();
        switch (csts) {
            case Connected: {
                LOG.info("NETCONF Node: {} is fully connected", node.getNodeId());
                List<String> capabilities =
                        nnode.getAvailableCapabilities().getAvailableCapability().stream().map(cp ->
                                cp.getCapability()).collect(Collectors.toList());

                String nodeId = node.getNodeId().getValue();
                //deviceOperationsImpl.updateDeviceState(nodeId,true);
                LOG.info("Capabilities: {}", capabilities);

                String capRestocked = QName.create(ToasterRestocked.QNAME, "toaster").toString();
                if (capabilities.contains(QName.create(ToasterRestocked.QNAME, "toaster").toString())) {
                    registerNotificationListener(node.getNodeId());
                }

                break;
            }
            case Connecting:
                LOG.info("NETCONF Node: {} was disconnected", node.getNodeId());
                break;
            case UnableToConnect:
                LOG.info("NETCONF Node: {} connection failed", node.getNodeId());
                break;
            default:
                LOG.warn("NETCONF Node: {} unhandled status {}", node.getNodeId(), csts);
        }
    }

    private void registerNotificationListener(final NodeId nodeId) {
        final Optional<MountPoint> mountPoint;
        try {
            // Get mount point for specified device
            mountPoint = lightyServices.getBindingMountPointService().getMountPoint(mountIds.get(nodeId.getValue()));
        } catch (ExecutionException e) {
            throw new IllegalArgumentException(e);
        }

        // Instantiate notification listener
        final LoggingNotificationListener listener;
        final ToasterDeviceNotificationsListener devListener;

        // Regular simple notification listener with a simple log message
        listener = new LoggingNotificationListener();
        devListener = new ToasterDeviceNotificationsListener();

        // Register notification listener
        final Optional<NotificationService> service = mountPoint.get().getService(NotificationService.class);

        LOG.info("Registering notification listener on {} for node: {}", ToasterRestocked.QNAME, nodeId);
        final ListenerRegistration<LoggingNotificationListener> accessTopologyListenerRestock =
                service.get().registerNotificationListener(listener);
        LOG.info("Registering notification listener on {} for node: {}", DeviceNotification.QNAME, nodeId);
        final ListenerRegistration<ToasterDeviceNotificationsListener> accessTopologyListenerDev =
                service.get().registerNotificationListener(devListener);

        /*final ListenerRegistration<GenericLoggingNotificationListener> topoListenerRegistration =
                service.get().registerNotificationListener(new GenericLoggingNotificationListener());*/

        final Optional<RpcConsumerRegistry> rpcConsumerRegistry = mountPoint.get().getService(RpcConsumerRegistry.class);
        final NotificationsService rpcService = rpcConsumerRegistry.get().getRpcService(NotificationsService.class);
        final CreateSubscriptionInputBuilder createSubscriptionInputBuilder = new CreateSubscriptionInputBuilder();

        final String RestockStreamName = "toaster:toasterRestocked";
        createSubscriptionInputBuilder.setStream(new StreamNameType(RestockStreamName));
        LOG.info("Triggering notification stream {} for node {}", RestockStreamName, nodeId);
        // FIXME: do something with this
        final ListenableFuture<?> RestockSubscription = rpcService.createSubscription(createSubscriptionInputBuilder.build());

        final String devStreamName = "noa-toaster-notifications:deviceNotification";
        createSubscriptionInputBuilder.setStream(new StreamNameType(devStreamName));
        LOG.info("Triggering notification stream {} for node {}", devStreamName, nodeId);
        final ListenableFuture<?> devSubscription = rpcService.createSubscription(createSubscriptionInputBuilder.build());
    }
}
