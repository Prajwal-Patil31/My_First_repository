package in.utl.noa.security.rbac.role;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;

import org.onap.aai.domain.yang.Privilege;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.UserAccount;
import org.onap.aai.domain.yang.UserGroup;
import org.onap.aai.domain.yang.AccessRole;
import org.onap.aai.domain.yang.AccessRoles;
import org.onap.aai.domain.yang.Action;
import org.onap.aai.domain.yang.Actions;
import org.onap.aai.domain.yang.Feature;
import org.onap.aai.domain.yang.Features;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import org.onap.aaiclient.client.graphinventory.Format;

import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

@RestController
@RequestMapping(value = "/api/platform/security/rbac/role")
public class RoleController {
    private static Logger logger = Logger.getLogger(RoleController.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    private JSONParser parser = new JSONParser();
    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    AuditLogger auditLogger = new AuditLogger();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    public RoleController() {
        super();
    }

    @GetMapping()
    public ResponseEntity<List<AccessRole>> getRoles() {
        List<AccessRole> rolesList = new ArrayList<AccessRole>();
        AAIPluralResourceUri rolesUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRoles());

        if (rClient.exists(rolesUri)) {
            AccessRoles roles = rClient.get(AccessRoles.class, rolesUri).get();
            rolesList = roles.getAccessRole();
        }
        return ResponseEntity.ok(rolesList);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getRoleFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "access-role");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("roleName", "Role Name");
        columns.put("roleCode", "Role Code");
        columns.put("assignedUsers", "Assigned Users");
        columns.put("assignedGroups", "Assigned Groups");
        columns.put("adminStatus", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getRoleList(@RequestBody RequestBodyDTO requestBody)
            throws JsonProcessingException, ParseException {
        JSONObject roles = filterService.queryByFilter(requestBody, "access-role");
        return ResponseEntity.status(HttpStatus.OK).body(roles);
    }

    @GetMapping("/{roleId}")
    public ResponseEntity<AccessRole> getRole(@PathVariable("roleId") String roleId) {
        AccessRole role = new AccessRole();
        if (roleId != null) {
            AAIResourceUri roleUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));
            if (rClient.exists(roleUri)) {
                role = rClient.get(AccessRole.class, roleUri).get();
            }
            return ResponseEntity.ok(role);
        }
        return new ResponseEntity<>(role, HttpStatus.BAD_REQUEST);
    }

    @PutMapping()
    public ResponseEntity<AccessRole> addRole(@RequestBody AccessRole role) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String roleId = UUID.randomUUID().toString();
        role.setRoleId(roleId);

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Access Role", roleId, null, null);

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().create(roleUri, role);
        transactionClient.execute();
        description = roleId + " Role Created Successfully.";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;

        auditLogger.addAuditLog(rClient, description, "Security", "Role Management", NoaEvents.CREATE_ROLE.getEvent(),
                eventStatus, null, resourceMetadata, auth);
        return new ResponseEntity<>(role, reqStatus);
    }

    @PostMapping("/{roleId}")
    public ResponseEntity<AccessRole> modifyRole(@PathVariable String roleId, @RequestBody AccessRole role)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Access Role", roleId, null, null);

        if (roleId != null) {

            AAIResourceUri roleUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));
            if (rClient.exists(roleUri)) {
                AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().update(roleUri, role);
                transactionClient.execute();
                description = roleId + " Role Updated Successfully.";
                eventStatus = true;
                reqStatus = HttpStatus.OK;
            } else {
                description = roleId + " Role Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Role Id";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "Role Management", NoaEvents.MODIFY_ROLE.getEvent(),
                eventStatus, null, resourceMetadata, auth);
        return new ResponseEntity<>(role, reqStatus);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteRoles(@RequestBody List<String> roleIds) {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String roleId : roleIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Access Role", roleId, null, null);
            if (roleId != null) {
                AAIResourceUri roleUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

                if (rClient.exists(roleUri)) {
                    AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction().delete(roleUri);
                    try {
                        transactionClient.execute();
                        description = roleId + " Role has been Deleted";
                        eventStatus = true;
                        reqStatus = HttpStatus.NO_CONTENT;
                        auditLogger.addAuditLog(rClient, description, "Security", "Role Management",
                                NoaEvents.DELETE_ROLE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    } catch (BulkProcessFailed e) {
                        e.printStackTrace();
                    }
                } else {
                    description = roleId + " Role doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    eventStatus = false;
                    auditLogger.addAuditLog(rClient, description, "Security", "Role Management",
                            NoaEvents.DELETE_ROLE.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return new ResponseEntity<>("Role doesn't Exists", HttpStatus.NOT_FOUND);
                }
            } else {
                description = "Received Null Role Id.";
                auditLogger.addAuditLog(rClient, description, "Security", "Role Management",
                        NoaEvents.DELETE_ROLE.getEvent(), eventStatus, null, resourceMetadata, auth);
                return new ResponseEntity<>("Role doesn't Exists", HttpStatus.BAD_REQUEST);
            }
        }
        return new ResponseEntity<>("Roles Deleted Successfully", reqStatus);
    }

    @GetMapping("/{roleId}/privilege")
    public ResponseEntity<List<Privilege>> getPrivileges(@PathVariable("roleId") String roleId)
            throws BulkProcessFailed {

        List<Privilege> privileges = new ArrayList<Privilege>();

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId))
                .depth(Depth.TWO);

        if (rClient.exists(roleUri)) {
            AccessRole role = rClient.get(AccessRole.class, roleUri).get();
            if (role.getPrivileges() != null) {
                privileges.addAll(role.getPrivileges().getPrivilege());
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(privileges);
    }

    @PutMapping("/{roleId}/privilege")
    public ResponseEntity<String> addPrivileges(@PathVariable("roleId") String roleId,
            @RequestBody Map<String, List<String>> assignmentsObj) throws BulkProcessFailed {

        Set<String> keys = assignmentsObj.keySet();
        List<String> keysAsList = new ArrayList<String>();
        keysAsList.addAll(keys);

        List<String> actionIds = assignmentsObj.get("actionIds");
        List<String> featureIds = assignmentsObj.get("featureIds");

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String actionId : actionIds) {
                AAIResourceUri actionUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().action(actionId));
                transactions.connect(actionUri, roleUri);
            }

            for (String featureId : featureIds) {
                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));
                transactions.connect(featureUri, roleUri);
            }
            transactions.execute();
            description = "Privileges Added to Role " + roleId;
            reqStatus = HttpStatus.OK;
        } else {
            description = roleId + " Role Doesn't Exists.";
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping("/{roleId}/privilege")
    public ResponseEntity<String> removePrivileges(@PathVariable("roleId") String roleId,
            @RequestBody Map<String, List<String>> assignmentsObj) throws BulkProcessFailed {

        Set<String> keys = assignmentsObj.keySet();
        List<String> keysAsList = new ArrayList<String>();
        keysAsList.addAll(keys);

        List<String> actionIds = assignmentsObj.get(keysAsList.get(0));
        List<String> featureIds = assignmentsObj.get(keysAsList.get(1));

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String actionId : actionIds) {
                AAIResourceUri actionUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().action(actionId));
                transactions.connect(actionUri, roleUri);
            }

            for (String featureId : featureIds) {
                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));
                transactions.connect(featureUri, roleUri);
            }
            transactions.execute();
            description = "Privileges Added to Role " + roleId;
            reqStatus = HttpStatus.OK;
        } else {
            description = roleId + " Role Doesn't Exists.";
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{roleId}/resourceAction")
    public ResponseEntity<List<String>> getResourceRequiredActions(@PathVariable("roleId") String roleId)
            throws ParseException, JsonMappingException, JsonProcessingException {
        List<Action> actions = new ArrayList<Action>();

        List<String> featureNames = new ArrayList<String>();
        DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.ACTION, __.key("per-instance", true))).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject actionObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            Action actionBody = mapper.readValue(actionObj.toString(), Action.class);
            actions.add(actionBody);
        }

        for (Action action : actions) {
            String featureName = action.getRelatedFeature();
            if (!featureNames.contains(featureName)) {
                featureNames.add(featureName);
            }
        }
        return ResponseEntity.status(HttpStatus.OK).body(featureNames);
    }

    @GetMapping("/{roleId}/action")
    public ResponseEntity<List<String>> getRoleActions(@PathVariable("roleId") String roleId) throws ParseException {
        List<String> actionNames = new ArrayList<String>();

        DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.ACTION)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject actionObj = (JSONObject) resultsArray.get(i).get("properties");
            String actionName = (String) actionObj.get("action-name");
            actionNames.add(actionName);
        }
        return ResponseEntity.status(HttpStatus.OK).body(actionNames);
    }

    public List<Action> getAllActions() {
        List<Action> actions = new ArrayList<Action>();
        AAIPluralResourceUri actionsUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().actions());

        if (rClient.exists(actionsUri)) {
            Actions actionsList = rClient.get(Actions.class, actionsUri).get();
            actions = actionsList.getAction();
        }
        return actions;
    }

    @PostMapping("/{roleId}/action")
    public ResponseEntity<String> addActionsToRole(@PathVariable("roleId") String roleId,
            @RequestBody List<String> actionNames) throws BulkProcessFailed {
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            List<Action> actions = getAllActions();

            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String actionName : actionNames) {
                Action actionObj = actions.stream().filter(action -> action.getActionName().equals(actionName))
                        .findAny().orElse(null);
                String actionId = actionObj.getActionId();
                AAIResourceUri actionUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().action(actionId));
                transactions.connect(actionUri, roleUri);
            }

            transactions.execute();
            return ResponseEntity.status(HttpStatus.OK).body("Actions Assigned to Role");
        } else {
            return ResponseEntity.status(HttpStatus.OK).body("Role Doesn't Exists");
        }
    }

    @DeleteMapping("/{roleId}/action")
    public ResponseEntity<String> removeActionsFromRole(@PathVariable("roleId") String roleId,
            @RequestBody List<String> actionNames) throws BulkProcessFailed {
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            List<Action> actions = getAllActions();

            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String actionName : actionNames) {
                Action actionObj = actions.stream().filter(action -> action.getActionName().equals(actionName))
                        .findAny().orElse(null);
                String actionId = actionObj.getActionId();
                AAIResourceUri actionUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().action(actionId));
                transactions.disconnect(actionUri, roleUri);
            }

            transactions.execute();
            return ResponseEntity.status(HttpStatus.OK).body("Actions Removed from Role");
        } else {
            return ResponseEntity.status(HttpStatus.OK).body("Role Doesn't Exists");
        }
    }

    @GetMapping("/{roleId}/feature")
    public ResponseEntity<List<String>> getRoleFeatures(@PathVariable("roleId") String roleId) throws ParseException {
        List<String> featureNames = new ArrayList<String>();

        DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.FEATURE)).output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject featureObj = (JSONObject) resultsArray.get(i).get("properties");
            String featureName = (String) featureObj.get("feature-name");
            featureNames.add(featureName);
        }
        return ResponseEntity.status(HttpStatus.OK).body(featureNames);
    }

    public List<Feature> getAllFeatures() {
        List<Feature> features = new ArrayList<Feature>();
        AAIPluralResourceUri featuresUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().features());

        if (rClient.exists(featuresUri)) {
            Features featuresList = rClient.get(Features.class, featuresUri).get();
            features = featuresList.getFeature();
        }
        return features;
    }

    @PostMapping("/{roleId}/feature")
    public ResponseEntity<String> addFeaturesToRole(@PathVariable("roleId") String roleId,
            @RequestBody List<String> featureNames) throws BulkProcessFailed {
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            List<Feature> features = getAllFeatures();
            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String featureName : featureNames) {
                Feature featureObj = features.stream().filter(feature -> feature.getFeatureName().equals(featureName))
                        .findAny().orElse(null);
                String featureId = featureObj.getFeatureId();
                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));
                transactions.connect(featureUri, roleUri);
            }

            transactions.execute();
            return ResponseEntity.status(HttpStatus.OK).body("Features added to Role");
        } else {
            return ResponseEntity.status(HttpStatus.OK).body("Role Doesn't Exists");
        }
    }

    @DeleteMapping("/{roleId}/feature")
    public ResponseEntity<String> removeFeaturesFromRole(@PathVariable("roleId") String roleId,
            @RequestBody List<String> featureNames) throws BulkProcessFailed {
        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            List<Feature> features = getAllFeatures();
            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String featureName : featureNames) {
                Feature featureObj = features.stream().filter(feature -> feature.getFeatureName().equals(featureName))
                        .findAny().orElse(null);
                String featureId = featureObj.getFeatureId();
                AAIResourceUri featureUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.platform().feature(featureId));
                transactions.disconnect(featureUri, roleUri);
            }

            transactions.execute();
            return ResponseEntity.status(HttpStatus.OK).body("Features Removed from Role");
        } else {
            return ResponseEntity.status(HttpStatus.OK).body("Role Doesn't Exists");
        }
    }

    @GetMapping("/{roleId}/user")
    public ResponseEntity<List<UserAccount>> getUsers(@PathVariable("roleId") String roleId)
            throws ParseException, JsonMappingException, JsonProcessingException {
        List<UserAccount> users = new ArrayList<UserAccount>();

        DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.USER_ACCOUNT))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject userObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            UserAccount accountBody = mapper.readValue(userObj.toString(), UserAccount.class);
            users.add(accountBody);
        }
        return ResponseEntity.status(HttpStatus.OK).body(users);
    }

    @PostMapping("/{roleId}/user")
    public ResponseEntity<String> assignToUsers(@PathVariable("roleId") String roleId,
            @RequestBody List<String> userIds) throws BulkProcessFailed {
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            AAITransactionalClient transactions = rClient.beginTransaction();
            for (String userId : userIds) {
                AAIResourceUri userUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().userAccount(userId));
                transactions.connect(userUri, roleUri);
            }
            transactions.execute();
            description = roleId + " Role has been Assigned Successfully";
            reqStatus = HttpStatus.OK;
        } else {
            description = roleId + " Role Doesn't Exists.";
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping("/{roleId}/group")
    public ResponseEntity<String> assignRoleToGroups(@PathVariable("roleId") String roleId,
            @RequestBody List<String> groupIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;

        AAIResourceUri roleUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.business().accessRole(roleId));

        if (rClient.exists(roleUri)) {
            AAITransactionalClient transactions = rClient.beginTransaction();

            for (String groupId : groupIds) {
                AAIResourceUri groupUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().userGroup(groupId));
                transactions.connect(groupUri, roleUri);
            }
            transactions.execute();
            description = roleId + " Role has been Assigned Successfully";
            reqStatus = HttpStatus.OK;
        } else {
            description = roleId + " Role Doesn't Exists.";
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping("/{roleId}/group")
    public ResponseEntity<List<UserGroup>> getGroupsWithRole(@PathVariable("roleId") String roleId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        List<UserGroup> groups = new ArrayList<UserGroup>();

        DSLStartNode startNode = new DSLStartNode(Types.ACCESS_ROLE, __.key("role-id", roleId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode).to(__.node(Types.USER_GROUP))
                .output();

        String results = dslClient.query(Format.SIMPLE, new DSLQuery(builder.build()));

        JSONParser parser = new JSONParser();
        JSONObject resultsJson = (JSONObject) parser.parse(results);
        List<JSONObject> resultsArray = (List<JSONObject>) resultsJson.get("results");

        for (int i = 0; i < resultsArray.size(); i++) {
            JSONObject userGroupObj = (JSONObject) resultsArray.get(i).get("properties");
            mapper.setPropertyNamingStrategy(PropertyNamingStrategy.KEBAB_CASE);
            UserGroup group = mapper.readValue(userGroupObj.toString(), UserGroup.class);
            groups.add(group);
        }

        return ResponseEntity.status(HttpStatus.OK).body(groups);
    }
}