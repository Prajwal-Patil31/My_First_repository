package in.utl.noa.account.user.password.service;

import org.onap.aai.domain.yang.PasswordPolicy;

import org.passay.CharacterRule;
import org.passay.EnglishCharacterData;
import org.passay.LengthRule;
import org.passay.PasswordData;
import org.passay.PasswordValidator;
import org.passay.RuleResult;

public class CustomPasswordValidator {

    public Boolean checkPassword(PasswordPolicy policy, String password) {

        PasswordValidator passwordValidator = new PasswordValidator(new LengthRule(policy.getMinLength(), 16),
                new CharacterRule(EnglishCharacterData.Digit, policy.getMinDigits()),
                new CharacterRule(EnglishCharacterData.LowerCase, policy.getMinLowChar()),
                new CharacterRule(EnglishCharacterData.UpperCase, policy.getMinUpperChar()),
                new CharacterRule(EnglishCharacterData.Special, policy.getMinSplChar()));

        RuleResult validate = passwordValidator.validate(new PasswordData(password));
        return validate.isValid();
    }

}