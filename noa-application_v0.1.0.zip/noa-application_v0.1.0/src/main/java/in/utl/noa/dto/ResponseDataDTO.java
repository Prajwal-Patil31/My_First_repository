package in.utl.noa.dto;

import java.util.Map;

import org.json.simple.JSONObject;

public class ResponseDataDTO {
    private Map<String, Object> columns;
    private Map<String, JSONObject> filters;

    public ResponseDataDTO() {
    }

    public Map<String, Object> getColumns() {
        return this.columns;
    }

    public void setColumns(Map<String, Object> columns) {
        this.columns = columns;
    }

    public Map<String, JSONObject> getFilters() {
        return this.filters;
    }

    public void setFilters(Map<String, JSONObject> filters) {
        this.filters = filters;
    }
}
