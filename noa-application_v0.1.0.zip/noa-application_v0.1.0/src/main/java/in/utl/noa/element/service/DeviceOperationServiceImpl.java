package in.utl.noa.element.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import java.util.concurrent.ExecutionException;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.MoreExecutors;

import org.json.simple.JSONObject;
import org.onap.aai.domain.yang.BridgeInstance;
import org.onap.aai.domain.yang.IetfInterface;
import org.onap.aai.domain.yang.NetworkDevice;

import org.opendaylight.mdsal.binding.api.DataBroker;
import org.opendaylight.mdsal.binding.api.WriteTransaction;
import org.opendaylight.mdsal.common.api.LogicalDatastoreType;
import org.opendaylight.mdsal.dom.api.DOMDataBroker;
import org.opendaylight.mdsal.dom.api.DOMDataTreeReadTransaction;
import org.opendaylight.mdsal.dom.api.DOMDataTreeReadWriteTransaction;
import org.opendaylight.mdsal.dom.api.DOMDataTreeWriteTransaction;
import org.opendaylight.mdsal.dom.api.DOMMountPoint;
import org.opendaylight.mdsal.dom.api.DOMMountPointService;

import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NetworkTopology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.NodeId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.TopologyId;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.Topology;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.TopologyKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.Node;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.NodeKey;
import org.opendaylight.yang.gen.v1.urn.tbd.params.xml.ns.yang.network.topology.rev131021.network.topology.topology.NodeBuilder;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev130715.PortNumber;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2._if.mib.rev000614.IFMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2._if.mib.rev000614._if.mib.Interfaces;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2._if.mib.rev000614._if.mib.interfaces.IfTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2._if.mib.rev000614._if.mib.interfaces.iftable.IfEntry;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.ARICENTCFAMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib.If;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib._if.IfIpTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib._if.IfMainTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib._if.ifiptable.IfIpEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib._if.ifmaintable.IfMainEntry;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.ARICENTQBRIDGEMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.VlanIndex;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.FsQBridgeMIBObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.FsDot1qBase;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.FsDot1qTp;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.FsDot1qVlan;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qbase.FsDot1qBaseTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qbase.fsdot1qbasetable.FsDot1qBaseEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qtp.FsDot1qTpGroupTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qtp.fsdot1qtpgrouptable.FsDot1qTpGroupEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qvlan.FsDot1qPortVlanStatisticsTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qvlan.FsDot1qVlanStaticPortConfigTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qvlan.FsDot1qVlanStaticTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qvlan.fsdot1qportvlanstatisticstable.FsDot1qPortVlanStatisticsEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qvlan.fsdot1qvlanstaticportconfigtable.FsDot1qVlanStaticPortConfigEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricentq.bridge.mib.rev120905.aricentq.bridge.mib.fsqbridgemibobjects.fsdot1qvlan.fsdot1qvlanstatictable.FsDot1qVlanStaticEntry;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.snmpv2.tc.rev990401.RowStatus;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev130715.Host;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev130715.IpAddress;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.ietf.inet.types.rev130715.Ipv4Address;

import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.NetconfNodeBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.netconf.node.credentials.credentials.LoginPasswordBuilder;
import org.opendaylight.yang.gen.v1.urn.opendaylight.netconf.node.topology.rev150114.network.topology.topology.topology.types.TopologyNetconf;

import org.opendaylight.yangtools.yang.binding.InstanceIdentifier;
import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.common.Uint16;
import org.opendaylight.yangtools.yang.common.Uint32;

import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier.NodeIdentifier;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier.NodeIdentifierWithPredicates;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier.PathArgument;
import org.opendaylight.yangtools.yang.data.api.schema.AugmentationNode;
import org.opendaylight.yangtools.yang.data.api.schema.DataContainerChild;
import org.opendaylight.yangtools.yang.data.api.schema.LeafNode;
import org.opendaylight.yangtools.yang.data.api.schema.MapEntryNode;
import org.opendaylight.yangtools.yang.data.api.schema.NormalizedNode;
import org.opendaylight.yangtools.yang.data.impl.schema.Builders;
import org.opendaylight.yangtools.yang.data.impl.schema.ImmutableNodes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.utl.noa.element.config.vlan.dto.VlanInterfaceDTO;
import in.utl.noa.mdsal.service.MDSALService;
import in.utl.noa.util.RestClientManager;
import io.lighty.core.controller.api.LightyServices;

import javax.annotation.PostConstruct;

import org.opendaylight.mdsal.common.api.CommitInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.entities.uri.Depth;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;

@Service
public class DeviceOperationServiceImpl implements DeviceOperationService {

    private static final Logger LOG = LoggerFactory.getLogger(DeviceOperationServiceImpl.class);

    LightyServices lightyServices;

    @Autowired
    MDSALService mdsalService;

    @Autowired
    DeviceOperationServiceImpl deviceServiceImpl;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    public DeviceOperationServiceImpl() {}

    @Override
    public void attachDevice(NetworkDevice device) {

        String deviceId = device.getDeviceId();
        this.lightyServices = mdsalService.getLightyServices();
        DataBroker dataBroker = lightyServices.getBindingDataBroker();

        final InstanceIdentifier<Node> NETCONF_TOPO_IID = InstanceIdentifier.create(NetworkTopology.class)
                .child(Topology.class, new TopologyKey(new TopologyId(TopologyNetconf.QNAME.getLocalName())))
                .child(Node.class, new NodeKey(new NodeId(deviceId)));

        Host host = new Host(new IpAddress(new Ipv4Address(device.getHost())));

        NodeBuilder nodeBuilder = new NodeBuilder().setNodeId(new NodeId(deviceId))
                .addAugmentation(new NetconfNodeBuilder().setPort(new PortNumber(Uint16.valueOf(device.getPort())))
                        .setReconnectOnChangedSchema(false).setConnectionTimeoutMillis(Uint32.valueOf(20000))
                        .setTcpOnly(false).setMaxConnectionAttempts(Uint32.valueOf(0))
                        .setSleepFactor(new BigDecimal(1.5)).setHost(host)
                        .setCredentials(new LoginPasswordBuilder().setUsername(device.getUserName())
                                .setPassword(device.getPassword()).build())
                        .setKeepaliveDelay(Uint32.valueOf(120)).setBetweenAttemptsTimeoutMillis(Uint16.valueOf(2000))
                        .build());

        Node node = nodeBuilder.build();

        WriteTransaction tx = dataBroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, NETCONF_TOPO_IID, node);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.debug("Successfully Attached Device");
                //addBridgeInGdb(deviceId);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Attach Device", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    public void addBridgeInGdb(String deviceId)  {
        /* List<JSONObject> bridges = getBridgeDetails(deviceId);
        JSONObject deviceBridge = bridges.get(1);
        Integer vlanContextId = (Integer)deviceBridge.get("fsDot1qVlanContextId"); */
        BridgeInstance bridge = new BridgeInstance();
        bridge.setBridgeId("1");
        bridge.setBridgeName("DefaultBridge");
        bridge.setGvrpStatus(false);
        bridge.setGmrpStatus(true);
        bridge.setTrafficClass("ForwardAll");
        bridge.setMaxVlanId(400);
        bridge.setMaxSupportedVlans(500);
        bridge.setNumOfVlans(0);
        bridge.setActiveVlans(0);
        
        

        NetworkDevice device = new NetworkDevice();
        List<IetfInterface> ietfInterfaces = new ArrayList<IetfInterface>();
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId)).depth(Depth.TWO);
        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            if(device.getIetfInterfaces() != null) {
                ietfInterfaces.addAll(device.getIetfInterfaces().getIetfInterface());
            }
        }

        AAIResourceUri bridgeUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).bridgeInstance("1"));
        
        AAITransactionalClient transaction = rClient.beginTransaction().create(bridgeUri, bridge);
        try {
            transaction.execute();
        } catch (Exception e) {
            e.printStackTrace();
        };

/*         for(IetfInterface ietfInterface : ietfInterfaces) {
            Integer interfaceId = ietfInterface.getInterfaceId();
            AAIResourceUri interfaceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId).ietfInterface(interfaceId));
            AAITransactionalClient connectionTransaction = rClient.beginTransaction().connect(bridgeUri, interfaceUri);
            try {
                connectionTransaction.execute();
            } catch (Exception e) {
                e.printStackTrace();
            };
        } */
    }

    @Override
    public void detachDevice(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();
        DataBroker dataBroker = lightyServices.getBindingDataBroker();

        final InstanceIdentifier<Node> NETCONF_TOPO_IID = InstanceIdentifier.create(NetworkTopology.class)
                .child(Topology.class, new TopologyKey(new TopologyId(TopologyNetconf.QNAME.getLocalName())))
                .child(Node.class, new NodeKey(new NodeId(deviceId)));

        WriteTransaction tx = dataBroker.newWriteOnlyTransaction();
        tx.delete(LogicalDatastoreType.CONFIGURATION, NETCONF_TOPO_IID);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.debug("Successfully deleted the operational Toaster");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Delete of the operational Toaster failed", failure);
            }
        }, MoreExecutors.directExecutor());

    }

    @Override
    public void updateDeviceState(String deviceId, Boolean status) {
        NetworkDevice device = null;
        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));
        if (rClient.exists(deviceUri)) {
            device = rClient.get(NetworkDevice.class, deviceUri).get();
            device.setElementStatus(status);
            AAITransactionalClient transactions;

            transactions = rClient.beginTransaction().update(deviceUri, device);

            try {
                transactions.execute();
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void getInterfaces(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();
        DataBroker dataBroker = lightyServices.getBindingDataBroker();
        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();
        
        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier IFMIB_IID = YangInstanceIdentifier.builder().node(IFMIB.QNAME).node(Interfaces.QNAME)
                .node(IfTable.QNAME).node(IfEntry.QNAME).build();
        
        DOMDataTreeReadWriteTransaction tx = mountPointDatabroker.newReadWriteTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> interfacesList = new ArrayList<JSONObject>();
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, IFMIB_IID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> ifEntries = (Collection<MapEntryNode>) readFuture.get().getValue();
                for(MapEntryNode ifEntry : ifEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = ifEntry.getValue();
                    JSONObject interfaceObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            interfaceObj.putAll(keyValuePair);
                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                interfaceObj.putAll(keyValuePair);
                            });
                        }
                    });
                    interfacesList.add(interfaceObj);
                }
            } else {
                LOG.info("No Interfaces Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    public Map<String,String> getKeyValuePairs(DataContainerChild<? extends PathArgument, ?> node) {
        Map<String,String> keyValuePair = new HashMap<String,String>();
        
        String identifier = node.getIdentifier().toString();
        String key = identifier.substring(identifier.lastIndexOf(")")+1);
        
        String value = node.getValue().toString();

        keyValuePair.put(key,value);
        return keyValuePair;
    }

    @Override
    public void deleteInterfaces(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_YIID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_YIID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        Map<QName, Object> uriMap = new HashMap<QName, Object>();

        uriMap.put(QName.create(IfEntry.QNAME, "ifIndex").intern(), 1);

        YangInstanceIdentifier IFMIB_IID = YangInstanceIdentifier.builder().node(IFMIB.QNAME).node(Interfaces.QNAME)
                .node(IfTable.QNAME).node(IfEntry.QNAME).nodeWithKey(IfEntry.QNAME, uriMap).build();

        tx.delete(LogicalDatastoreType.CONFIGURATION, IFMIB_IID);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Removed Interface");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.info("Failed to Remove Interface", failure);
            }
        }, MoreExecutors.directExecutor());

    }

    @Override
    public void createIfEntry(String deviceId, VlanInterfaceDTO vlanInterfaces) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
     
        Integer ifIndex = vlanInterfaces.getIfIndex();
        String ifAlias = vlanInterfaces.getIfAlias();

        YangInstanceIdentifier IF_ENTRY_YII = YangInstanceIdentifier.builder().node(IFMIB.QNAME).node(Interfaces.QNAME)
                .node(IfTable.QNAME)
                .nodeWithKey(IfEntry.QNAME, QName.create(IfEntry.QNAME, "ifIndex").intern(), ifIndex).build();
            
        NormalizedNode ifEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(IfEntry.QNAME))
                        .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                            NodeIdentifierWithPredicates.of(IfEntry.QNAME, QName.create(IfEntry.QNAME, "ifIndex"), ifIndex))
                            .withChild(ImmutableNodes.leafNode(QName.create(IfEntry.QNAME, "ifIndex"), ifIndex))
                            .withChild(ImmutableNodes.leafNode(QName.create(IfEntry.QNAME, "ifAlias"), ifAlias))
                            .build()).build();

        /* NormalizedNode ifEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(IfEntry.QNAME))
                        .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                            NodeIdentifierWithPredicates.of(IfEntry.QNAME, QName.create(IfEntry.QNAME, "ifIndex"), ifIndex))
                            .withChild(ImmutableNodes.leafNode(QName.create(IfEntry.QNAME, "ifIndex"), ifIndex))
                            .withChild(Builders.augmentationBuilder().withNodeIdentifier(
                                AugmentationIdentifier.create(ImmutableSet.of(QName.create(IFMIB.QNAME, "ifAlias"))))
                                .withChild(ImmutableNodes.leafNode(QName.create(IFMIB.QNAME, "ifAlias"), ifAlias))
                                .build()
                            ).build()
                        ).build(); */

        tx.put(LogicalDatastoreType.CONFIGURATION, IF_ENTRY_YII, ifEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created IfEntry");
                createIfMainEntry(deviceId, vlanInterfaces);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create IfEntry", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void createIfMainEntry(String deviceId, VlanInterfaceDTO vlanInterfaces) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        int ifMainIndex = vlanInterfaces.getIfIndex();
        String ifMainType = vlanInterfaces.getIfMainType();

        YangInstanceIdentifier IF_MAIN_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTCFAMIB.QNAME).node(If.QNAME)
                .node(IfMainTable.QNAME)
                .nodeWithKey(IfMainEntry.QNAME, QName.create(IfMainEntry.QNAME, "ifMainIndex").intern(), ifMainIndex)
                .build();

        NormalizedNode mainEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(IfMainEntry.QNAME))
                .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                    NodeIdentifierWithPredicates.of(IfMainEntry.QNAME, QName.create(IfMainEntry.QNAME, "ifMainIndex"), ifMainIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfMainEntry.QNAME, "ifMainIndex"), ifMainIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfMainEntry.QNAME, "ifMainType"), ifMainType))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfMainEntry.QNAME, "ifMainAdminStatus"), "up"))
                    .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, IF_MAIN_ENTRY_YII, mainEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created If Main Entry");
                createIpEntry(deviceId, vlanInterfaces);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create If Main Entry", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void createIpEntry(String deviceId, VlanInterfaceDTO vlanInterfaces) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        int ifMainIndex = vlanInterfaces.getIfIndex();
        String ifIpAddr = vlanInterfaces.getIfIpAddr();
        String ifIpSubnetMask = vlanInterfaces.getIfIpSubnetMask();
        String ifIpBroadcastAddr = vlanInterfaces.getIfIpBroadcastAddr();

        YangInstanceIdentifier IF_IP_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTCFAMIB.QNAME).node(If.QNAME)
                .node(IfIpTable.QNAME)
                .nodeWithKey(IfIpEntry.QNAME, QName.create(IfIpEntry.QNAME, "ifMainIndex").intern(), ifMainIndex)
                .build();

        NormalizedNode ipEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(IfIpEntry.QNAME))
                .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                    NodeIdentifierWithPredicates.of(IfIpEntry.QNAME, QName.create(IfIpEntry.QNAME, "ifMainIndex"), ifMainIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfIpEntry.QNAME, "ifMainIndex"), ifMainIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfIpEntry.QNAME, "ifIpAddr"), ifIpAddr))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfIpEntry.QNAME, "ifIpSubnetMask"), ifIpSubnetMask))
                    .withChild(ImmutableNodes.leafNode(QName.create(IfIpEntry.QNAME, "ifIpBroadcastAddr"), ifIpBroadcastAddr))
                    .build()).build();
        
        tx.put(LogicalDatastoreType.CONFIGURATION, IF_IP_ENTRY_YII, ipEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created IpEntry");
                addTpGroupEntry(deviceId, vlanInterfaces);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create IpEntry", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    public List<JSONObject> getBridgeDetails (String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();
        DataBroker dataBroker = lightyServices.getBindingDataBroker();
        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();
        
        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeReadWriteTransaction tx = mountPointDatabroker.newReadWriteTransaction();

        YangInstanceIdentifier BRIDGE_BASE_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qBase.QNAME).node(FsDot1qBaseTable.QNAME).build();
        
        
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> bridgeList = new ArrayList<JSONObject>();
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, BRIDGE_BASE_ENTRY_YII).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> baseEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode baseEntry : baseEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = baseEntry.getValue();
                    JSONObject baseEntryObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            baseEntryObj.putAll(keyValuePair);
                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                baseEntryObj.putAll(keyValuePair);
                            });
                        }
                    });
                    bridgeList.add(baseEntryObj);
                }
            } else {
                LOG.info("No Bridge Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return bridgeList;
    }

    @Override
    public void createVlanBaseEntry(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(FsDot1qBaseEntry.QNAME, "fsDot1qVlanContextId").intern(), 0);

        YangInstanceIdentifier VLAN_STATIC_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qBase.QNAME).node(FsDot1qBaseTable.QNAME).build();

        /* FsDot1qBaseEntry baseEntry = new FsDot1qBaseEntryBuilder().setFsDot1qVlanContextId(0)
                .setFsDot1qGvrpStatus(EnabledStatus.Enabled).setFsDot1qNumVlans(new Unsigned32(Uint32.valueOf(12)))
                .setFsDot1qMaxSupportedVlans(new Unsigned32(Uint32.valueOf(12))).setFsDot1qMaxVlanId(new VlanId(12))
                .setFsDot1qVlanVersionNumber(FsDot1qBaseEntry.FsDot1qVlanVersionNumber.Version1).build(); */

        NormalizedNode leafNode1 = Builders.containerBuilder()
                                    .withNodeIdentifier(NodeIdentifier.create(FsDot1qBaseTable.QNAME))
                                    .addChild(Builders.mapBuilder()
                                            .withNodeIdentifier(NodeIdentifier.create(FsDot1qBaseEntry.QNAME))
                                            .addChild(Builders.mapEntryBuilder()
                                                    .withNodeIdentifier(NodeIdentifierWithPredicates.of(FsDot1qBaseEntry.QNAME, 
                                                                Map.of(QName.create(FsDot1qBaseEntry.QNAME, "fsDot1qVlanContextId"),0)))
                                                    .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qBaseEntry.QNAME, "fsDot1qVlanContextId"),0))
                                                    .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qBaseEntry.QNAME, "fsDot1qGvrpStatus"),"disabled"))
                                                    .build())
                                            .build())
                                    .build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, VLAN_STATIC_ENTRY_YII, leafNode1);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Vlan Base Entry");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Vlan Base Entry", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public Boolean addTpGroupEntry(String deviceId, VlanInterfaceDTO vlanInterfaces) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();
        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        List<String> ifIndexes = vlanInterfaces.getInterfaceIds();

        Integer vlanId = vlanInterfaces.getIfIndex();
        String tqGroupAddress = vlanInterfaces.getTqGroupAddress();
        if(tqGroupAddress == null) {
            tqGroupAddress = vlanInterfaces.getIfAlias();
        }

        for(String ifIndex : ifIndexes) {
            Map<QName, Object> uriMap = new HashMap<QName, Object>();
            uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanContextId").intern(), 0);
            uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanIndex").intern(), vlanId);
            uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpGroupAddress").intern(), tqGroupAddress);
            uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpPortfsDot1qTpPort").intern(), ifIndex);

            YangInstanceIdentifier TP_GROUP_TABLE_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qTp.QNAME).node(FsDot1qTpGroupTable.QNAME)
                .nodeWithKey(FsDot1qTpGroupEntry.QNAME, uriMap).build();

            NormalizedNode tpGroupNode = Builders.mapBuilder()
                                    .withNodeIdentifier(NodeIdentifier.create(FsDot1qTpGroupEntry.QNAME))
                                    .addChild(Builders.mapEntryBuilder()
                                            .withNodeIdentifier(NodeIdentifierWithPredicates.of(FsDot1qTpGroupEntry.QNAME, 
                                                        Map.of(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanContextId"),0,
                                                        QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanIndex"),vlanId,
                                                        QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpGroupAddress"),tqGroupAddress,
                                                        QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpPort"),ifIndex)))
                                            .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanContextId"),0))
                                            .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanIndex"),vlanId))
                                            .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpGroupAddress"),tqGroupAddress))
                                            .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpPort"),ifIndex))
                                            .build())
                                    .build();
                                    
            tx.put(LogicalDatastoreType.CONFIGURATION, TP_GROUP_TABLE_YII, tpGroupNode);
        }

        List<Boolean> results = new ArrayList<Boolean>();
        results.add(0, false);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Tp Group Entry");
                results.add(0, true);
                //createStaticVlan(deviceId, vlanInterfaces);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.info("Failed to Create Tp Group Entry");
                results.add(0, false);
            }
        }, MoreExecutors.directExecutor());

        return results.get(0);
    }

    @Override
    public void createStaticVlan(String deviceId, VlanInterfaceDTO vlanInterfaces) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        Integer vlanIndex = vlanInterfaces.getIfIndex();
        String vlanStaticName = vlanInterfaces.getIfAlias();
        RowStatus staticRowStatus;

        /* Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanContextId").intern(), 0);
        uriMap.put(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanIndex").intern(),
                new VlanIndex(Uint32.valueOf(12))); */

        YangInstanceIdentifier VLAN_STATIC_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qVlan.QNAME).node(FsDot1qVlanStaticTable.QNAME)
                .build();
        
        /* FsDot1qVlanStaticEntryBuilder staticEntryBuilder = new FsDot1qVlanStaticEntryBuilder()
                .setFsDot1qVlanStaticName(new DisplayString("vlanStaticName")).setFsDot1qVlanContextId(0)
                .setFsDot1qVlanIndex(new VlanIndex(Uint32.valueOf(12))).setFsDot1qVlanStaticRowStatus(RowStatus.Active);

        FsDot1qVlanStaticEntry vlanStaticEntry = staticEntryBuilder.build(); */

        NormalizedNode leafNode1 = Builders.containerBuilder()
                                    .withNodeIdentifier(NodeIdentifier.create(FsDot1qVlanStaticTable.QNAME))
                                    .addChild(Builders.mapBuilder()
                                            .withNodeIdentifier(NodeIdentifier.create(FsDot1qVlanStaticEntry.QNAME))
                                            .addChild(Builders.mapEntryBuilder()
                                                    .withNodeIdentifier(NodeIdentifierWithPredicates.of(FsDot1qVlanStaticEntry.QNAME, 
                                                                Map.of(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanContextId"),0,
                                                                QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanIndex"),vlanIndex)))
                                                    .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanContextId"),0))
                                                    .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanIndex"),vlanIndex))
                                                    .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanStaticName"),vlanStaticName))
                                                    .build())
                                            .build())
                                    .build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        
        tx.put(LogicalDatastoreType.CONFIGURATION, VLAN_STATIC_ENTRY_YII, leafNode1);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Vlan");
                //addInterfacesToVlan(deviceId, vlanInterfaces);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Vlan", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteTpGroupEntry(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_YIID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_YIID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanContextId").intern(), 0);
        uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qVlanIndex").intern(), 12);
        uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpGroupAddress").intern(), 12);
        uriMap.put(QName.create(FsDot1qTpGroupEntry.QNAME, "fsDot1qTpPort ").intern(), 12);

        YangInstanceIdentifier VLAN_STATIC_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qTp.QNAME).node(FsDot1qTpGroupTable.QNAME)
                .node(FsDot1qTpGroupEntry.QNAME).nodeWithKey(FsDot1qTpGroupEntry.QNAME, uriMap).build();

        tx.delete(LogicalDatastoreType.CONFIGURATION, VLAN_STATIC_ENTRY_YII);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Removed Vlan Tp Group Entry");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Remove Vlan Tp Group Entry", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteStaticVlan(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_YIID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_YIID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        
        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanContextId").intern(), 0);
        uriMap.put(QName.create(FsDot1qVlanStaticEntry.QNAME, "fsDot1qVlanIndex").intern(),
                new VlanIndex(Uint32.valueOf(12)));

        YangInstanceIdentifier VLAN_STATIC_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qVlan.QNAME).node(FsDot1qVlanStaticTable.QNAME)
                .node(FsDot1qVlanStaticEntry.QNAME).nodeWithKey(FsDot1qVlanStaticEntry.QNAME, uriMap).build();

        tx.delete(LogicalDatastoreType.CONFIGURATION, VLAN_STATIC_ENTRY_YII);
        
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.debug("Successfully Removed Vlan");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Remove Vlan", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void addInterfacesToVlan(String deviceId, VlanInterfaceDTO vlanInterfaces) {
        this.lightyServices = mdsalService.getLightyServices();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();
        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        Integer vlanIndex = vlanInterfaces.getIfIndex();
        String tagType = vlanInterfaces.getTagType();
        List<String> vlanStaticPortType = new ArrayList<String>();

        switch (tagType) {
            case "untagged":
                vlanStaticPortType.add(0,"addUntagged");
                break;
            case "tagged":
                vlanStaticPortType.add(0,"addTagged");
                break;
            case "hybrid-port":
                vlanStaticPortType.add(0,"addTagged");
                vlanStaticPortType.add(1,"addUntagged");
                break;
            case "forbidden-port":
                vlanStaticPortType.add(0,"addForbidden");
                break;
            default:
                vlanStaticPortType.add(0,"addUntagged");
                break;
        }     
        List<String> ifIndexes = vlanInterfaces.getInterfaceIds();

        for(String ifIndex : ifIndexes) {
            Map<QName, Object> uriMap = new HashMap<QName, Object>();
            uriMap.put(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanContextId").intern(), 0);
            uriMap.put(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanIndex").intern(), vlanIndex);
            uriMap.put(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qTpPort").intern(), ifIndex);

            YangInstanceIdentifier VLAN_PORT_CONFIG_ENTRY_YII = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
            .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qVlan.QNAME).node(FsDot1qVlanStaticPortConfigTable.QNAME)
            .nodeWithKey(FsDot1qVlanStaticPortConfigEntry.QNAME, uriMap).build();


            NormalizedNode vlanPortConfigNode = Builders.mapBuilder()
                                .withNodeIdentifier(NodeIdentifier.create(FsDot1qVlanStaticEntry.QNAME))
                                .addChild(Builders.mapEntryBuilder()
                                        .withNodeIdentifier(NodeIdentifierWithPredicates.of(FsDot1qVlanStaticPortConfigEntry.QNAME, 
                                                    Map.of(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanContextId"),0,
                                                    QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanIndex"),vlanIndex,
                                                    QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qTpPort"),ifIndex)))
                                        .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanContextId"),0))
                                        .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanIndex"),vlanIndex))
                                        .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qTpPort"),ifIndex))
                                        .addChild(ImmutableNodes.leafNode(QName.create(FsDot1qVlanStaticPortConfigEntry.QNAME, "fsDot1qVlanStaticPort"),vlanStaticPortType.get(0)))
                                        .build())
                                .build();
                                
            tx.put(LogicalDatastoreType.CONFIGURATION, VLAN_PORT_CONFIG_ENTRY_YII, vlanPortConfigNode);
        }
        
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Added Interfaces to Vlan");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Add Interfaces to Vlan", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void getBridgeStatistics(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();
        DataBroker dataBroker = lightyServices.getBindingDataBroker();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();

        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier VLAN_PORT_STATS_IID = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qBase.QNAME).node(FsDot1qBaseTable.QNAME).node(FsDot1qBaseEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> bridgeStats = new ArrayList<JSONObject>();
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, VLAN_PORT_STATS_IID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> baseEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode baseEntry : baseEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = baseEntry.getValue();
                    JSONObject bridgeStatsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            bridgeStatsObj.putAll(keyValuePair);
                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                bridgeStatsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    bridgeStats.add(bridgeStatsObj);
                }
            } else {
                LOG.info("No Statistics Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }


    @Override
    public void getVlanPortStatistics(String deviceId) {
        this.lightyServices = mdsalService.getLightyServices();
        DataBroker dataBroker = lightyServices.getBindingDataBroker();

        YangInstanceIdentifier NETCONF_TOPO_IID = YangInstanceIdentifier.builder().node(NetworkTopology.QNAME)
                .node(Topology.QNAME)
                .nodeWithKey(Topology.QNAME, QName.create(Topology.QNAME, "topology-id").intern(),
                        TopologyNetconf.QNAME.getLocalName())
                .node(Node.QNAME).nodeWithKey(Node.QNAME, QName.create(Node.QNAME, "node-id").intern(), deviceId)
                .build();

        DOMMountPointService mountPointService = mdsalService.getLightyServices().getDOMMountPointService();

        Optional<DOMMountPoint> xrNodeOptional = mountPointService.getMountPoint(NETCONF_TOPO_IID);
        final DOMMountPoint mount = xrNodeOptional.get();
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier VLAN_PORT_STATS_IID = YangInstanceIdentifier.builder().node(ARICENTQBRIDGEMIB.QNAME)
                .node(FsQBridgeMIBObjects.QNAME).node(FsDot1qVlan.QNAME).node(FsDot1qPortVlanStatisticsTable.QNAME)
                .node(FsDot1qPortVlanStatisticsEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> vlanStats = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, VLAN_PORT_STATS_IID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> vlanStatEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode vlanStatEntry : vlanStatEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = vlanStatEntry.getValue();
                    JSONObject vlanStatsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            vlanStatsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                vlanStatsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    vlanStats.add(vlanStatsObj);
                }
            } else {
                LOG.info("No Vlan Statistics Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }
}
