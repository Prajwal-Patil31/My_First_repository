package in.utl.noa.element.service;

import org.onap.aai.domain.yang.NetworkDevice;

import in.utl.noa.element.config.vlan.dto.VlanInterfaceDTO;

public interface DeviceOperationService {
    public void attachDevice(NetworkDevice device);
    public void detachDevice(String nodeId);
    public void updateDeviceState(String deviceId, Boolean status);
    
    public void getInterfaces(String deviceId);
    public void deleteInterfaces(String deviceId);
    public void createIfEntry(String deviceId, VlanInterfaceDTO vlanInterfaces);
    public void createIfMainEntry(String deviceId, VlanInterfaceDTO vlanInterfaces);
    public void createIpEntry(String deviceId, VlanInterfaceDTO vlanInterfaces);
    
    public void createVlanBaseEntry(String deviceId);
    public Boolean addTpGroupEntry(String deviceId, VlanInterfaceDTO vlanInterfaces);
    public void createStaticVlan(String deviceId, VlanInterfaceDTO vlanInterfaces);
    public void deleteTpGroupEntry(String deviceId);
    public void deleteStaticVlan(String deviceId);
    
    public void addInterfacesToVlan(String deviceId, VlanInterfaceDTO vlanInterfaces);

    public void getBridgeStatistics(String deviceId);
    public void getVlanPortStatistics(String deviceId);
}
