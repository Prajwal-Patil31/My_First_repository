package in.utl.noa.global.fault.controller;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.onap.aai.domain.yang.FaultProcessingPolicies;
import org.onap.aai.domain.yang.FaultProcessingPolicy;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/platform/fault/policy")
public class FaultProcessingPoliciesController {
    private static Logger logger = Logger.getLogger(FaultProcessingPoliciesController.class);

    AuditLogger auditLogger = new AuditLogger();

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @Autowired
    GDBFilterService filterService;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<List<FaultProcessingPolicy>> getFaultProcessingPolicies() {
        List<FaultProcessingPolicy> policiesList = new ArrayList<FaultProcessingPolicy>();
        AAISimplePluralUri uri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicies());
        if (rClient.exists(uri)) {
            FaultProcessingPolicies polcies = rClient.get(FaultProcessingPolicies.class, uri).get();
            policiesList = polcies.getFaultProcessingPolicy();
        }
        return ResponseEntity.ok(policiesList);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getFaultConfigurationFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "fault-processing-policy");

        Map<String, Object> columns = new HashMap<>();
        columns.put("policyName", "Policy Name");
        columns.put("policyType", "Policy Type");
        columns.put("toSeverity", "To Severity");
        columns.put("severity", "Severity");
        columns.put("numOfHoursOlder", "Num of Hours Older");
        columns.put("numOfDaysOlder", "Num of Days Older");
        columns.put("retainMinFaults", "Retain Min Faults");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getFaultConfigurationList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject policies = filterService.queryByFilter(requestBody, "fault-processing-policy");
        return ResponseEntity.status(HttpStatus.OK).body(policies);
    }

    @GetMapping(value = "/{policyId}", produces = "application/json")
    public ResponseEntity<Optional<FaultProcessingPolicy>> getFaultProcessingPolicyById(
            @PathVariable("policyId") String policyId) {

        Optional<FaultProcessingPolicy> faultPolicy = null;
        AAIResourceUri faultPolicyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));
        if (rClient.exists(faultPolicyUri)) {
            faultPolicy = rClient.get(FaultProcessingPolicy.class, faultPolicyUri);
            return ResponseEntity.status(HttpStatus.OK).body(faultPolicy);
        }
        return ResponseEntity.status(HttpStatus.OK).body(faultPolicy);
    }

    @PutMapping()
    public ResponseEntity<String> addPolicy(@RequestBody FaultProcessingPolicy newPolicy) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String policyId = UUID.randomUUID().toString();
        newPolicy.setPolicyId(policyId);

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Processing Policy",
                newPolicy.getPolicyId(), null, null);

        AAIResourceUri policyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));

        AAITransactionalClient transactions;

        transactions = rClient.beginTransaction().create(policyUri, newPolicy);

        transactions.execute();
        description = policyId + " Fault Processing Policy has been Created Successfully";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;
        auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Processing Policy",
                NoaEvents.CREATE_FAULT_PROCESSING_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping(value = "/{policyId}", consumes = "application/json")
    public ResponseEntity<String> updatePolicy(@PathVariable("policyId") String policyId,
            @RequestBody FaultProcessingPolicy policyBody) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Processing Policy",
                policyBody.getPolicyId(), null, null);

        if (policyId != null) {
            AAIResourceUri policyUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));

            if (rClient.exists(policyUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().update(policyUri, policyBody);

                transactions.execute();
                description = policyId + " Fault Processing Policy has been Updated.";
                reqStatus = HttpStatus.OK;
                eventStatus = true;
            } else {
                description = policyId + " Fault Processing Policy Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Policy Id";
        }
        auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Processing Policy",
                NoaEvents.MODIFY_FAULT_PROCESSING_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deletePolicy(@RequestBody List<String> policyIds) throws BulkProcessFailed {
        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Processing Policy", null, null,
                null);

        for (String policyId : policyIds) {
            resourceMetadata.setResourceId(policyId);
            if (policyId != null) {
                AAIResourceUri policyUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));

                if (rClient.exists(policyUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(policyUri);
                    transactions.execute();
                    description = policyId + " Fault Processing Policy Doesn't Exists.";
                    reqStatus = HttpStatus.NO_CONTENT;
                    eventStatus = true;
                    auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Processing Policy",
                            NoaEvents.DELETE_FAULT_PROCESSING_POLICY.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                } else {
                    description = policyId + " Fault Processing Policy Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Processing Policy",
                            NoaEvents.DELETE_FAULT_PROCESSING_POLICY.getEvent(), eventStatus, null, resourceMetadata,
                            auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Policy Id";
                auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Processing Policy",
                        NoaEvents.DELETE_FAULT_PROCESSING_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(reqStatus).body("Policy Deleted Successfully");
    }

}
