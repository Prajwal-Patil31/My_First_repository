package in.utl.noa.platform.security.web.service;

import org.apache.log4j.Logger;

import javax.annotation.PostConstruct;

import org.onap.aai.domain.yang.Event;

import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.messaging.simp.SimpMessagingTemplate;

import org.springframework.stereotype.Service;

import in.utl.noa.dto.NotificationDTO;

import in.utl.noa.global.fault.model.Fault;

import in.utl.noa.util.RestClientManager;

import static in.utl.noa.platform.security.web.WebSocketConfig.NOTIFICATION_PREFIX;
import static in.utl.noa.platform.security.web.WebSocketConfig.MESSAGE_PREFIX;

@Service
public class WebSocketService {
    private static Logger logger = Logger.getLogger(WebSocketService.class);

    @Autowired
    private SimpMessagingTemplate ws;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    public void pushGlobalNotification(Integer eventId, String eventType, String resource, String resourceId,
            String description, String timeStamp, Integer statusCode, Integer severity, Integer count, Fault fault,
            Object eventObject) {
        NotificationDTO notificationDto = new NotificationDTO();

        if (eventId != null) {
            Event notification = new Event();
            notification.setEventId(eventId.toString());
            notification.setEventType(eventType);
            notification.setResource(resource);
            notification.setResourceId(resourceId);
            notification.setDescription(description);
            notification.setTimeStamp(timeStamp);
            notification.setSeverity(severity.toString());
            notification.setCount(count);
            notification.setEventStatus(false);

            addNotification(notification);
            notificationDto.setNotification(notification);
        }
        notificationDto.setFault(fault);
        notificationDto.setEventObject(eventObject);

        ws.convertAndSend(MESSAGE_PREFIX + NOTIFICATION_PREFIX, notificationDto);
    }

    public void addNotification(Event event) {
        AAITransactionalClient transactions = rClient.beginTransaction();

        String eventId = event.getEventId();
        AAIResourceUri eventUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.platform().event(eventId));

        if (!rClient.exists(eventUri)) {
            transactions.create(eventUri, event);
        } else {
            transactions.update(eventUri, event);
        }

        try {
            transactions.execute();
        } catch (BulkProcessFailed e) {
            e.printStackTrace();
        }
    }
}
