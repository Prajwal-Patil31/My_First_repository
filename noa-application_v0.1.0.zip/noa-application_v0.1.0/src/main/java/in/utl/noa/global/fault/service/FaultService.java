package in.utl.noa.global.fault.service;

import static in.utl.noa.global.fault.util.FaultConstants.CLEARING_FAULT;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.json.JSONException;
import org.json.JSONObject;
import org.onap.aai.domain.yang.FaultProcessingPolicy;
import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.integration.annotation.Transformer;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import in.utl.noa.global.fault.dto.FaultDTO;
import in.utl.noa.global.fault.model.Fault;
import in.utl.noa.global.fault.model.FaultConfigRepository;
import in.utl.noa.global.fault.model.FaultConfig;
import in.utl.noa.global.fault.repository.FaultRepository;

import in.utl.noa.util.RestClientManager;

@Service("faultService")
@Transactional
public class FaultService {
    private static Logger logger = Logger.getLogger(FaultService.class);
    
    @Autowired
    Environment env;
    
    @Autowired
    JavaMailSenderImpl mailSender;

    @Autowired
    FaultConfigRepository faultConfigRepo;

    @Autowired
    FaultRepository faultRepo;

    @Autowired
	RestClientManager restClientManager;

    private AAIDSLQueryClient dslClient;

    ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @PostConstruct
	public void initialize() {
        dslClient = restClientManager.getDSLQueryClient();
    }
    
    public Message<?> processSeverity(Message<?> msg) throws JsonMappingException, JsonProcessingException  {
        Message<?> message;

        Fault payload = ((Fault) msg.getPayload());
        FaultConfig faultConfig = this.faultConfigRepo.isFaultConfigured(payload.getFaultCode());

        if (faultConfig == null) {
            logger.info("Processing Fault Severity:: Fault is Not Configured...Discarding");
            return null;
        }

        List<FaultProcessingPolicy> resultsArray = new ArrayList<FaultProcessingPolicy>();

        DSLStartNode startNode = new DSLStartNode(Types.FAULT_CONFIG, __.key("error-code", payload.getFaultCode()));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                        .to(__.node(Types.FAULT_PROCESSING_POLICY, __.key("policy-type", "ESCALATION")).output());

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, FaultProcessingPolicy>> resultsFromJson = mapper.readValue(results,
                    new TypeReference<Results<Map<String, FaultProcessingPolicy>>>() {
                    });

        for (Map<String, FaultProcessingPolicy> m : resultsFromJson.getResult()) {
            resultsArray.add(m.get("fault-processing-policy"));
        }

        if(resultsArray.size() == 1) {
            FaultProcessingPolicy policy = resultsArray.get(0);
            int severity = policy.getToSeverity();
            payload.setSeverity(severity);
            logger.info(payload.getFaultCode() + " Severity Escalated to " + severity);
        } else {
            payload.setSeverity(faultConfig.getSeverity());
        }
        
        message = MessageBuilder.createMessage(payload, msg.getHeaders());

        logger.info("Processing Fault Severity:: Updated Fault Severity " + ((Fault)message.getPayload()).getSeverity());
        return message;
    }
    
    public Message<?> processClearance(Message<?> msg) {

        Fault payload = ((Fault) msg.getPayload());
        int faultCode = payload.getFaultCode();
        Date genDate = payload.getFaultDate();

        FaultConfig faultConfig = this.faultConfigRepo.isFaultConfigured(faultCode);

        if (faultConfig == null) {
            logger.info("Processing Fault Clearance:: Fault is Not Configured...Discarding");
            return null;
        }

        if (faultConfig.getSeverity() == CLEARING_FAULT) {
            boolean clr = this.faultRepo.clearFaults(faultConfig.getFaultCode());
            logger.info("Processing Fault Clearance:: Faults Cleared: " + clr);
        }

        //TODO:: To Process in a Dedicated Fault Correlation Handler
        boolean dup = this.faultRepo.isDuplicateFault(faultCode);

        //TODO:: To Mark Messages for Handling by JPA Outbound Adapter later in the Processing Chain
        if (!dup) {
            logger.info("Processing Fault Clearance:: No Duplicate Faults Found, Storing Received Fault");
            this.faultRepo.saveAndPush(payload);
        } else {
            logger.info("Processing Fault Clearance:: Updating Count for Duplicate Fault");
            this.faultRepo.updateFaultCountAndDate(faultCode, genDate);
        }

        return msg;
    }

    public Message<?> processAcknowledgement(Message<?> msg) throws JsonMappingException, JsonProcessingException {

        Fault payload = ((Fault) msg.getPayload());
        int faultCode = payload.getFaultCode();

        FaultConfig faultConfig = this.faultConfigRepo.isFaultConfigured(faultCode);

        if (faultConfig == null) {
            logger.info("Processing Fault Clearance:: Fault is Not Configured...Discarding");
            return null;
        }

        List<FaultProcessingPolicy> resultsArray = new ArrayList<FaultProcessingPolicy>();

        DSLStartNode startNode = new DSLStartNode(Types.FAULT_CONFIG, __.key("error-code", faultCode));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                        .to(__.node(Types.FAULT_PROCESSING_POLICY, __.key("policy-type", "AUTO ACK")).output());

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, FaultProcessingPolicy>> resultsFromJson = mapper.readValue(results,
                    new TypeReference<Results<Map<String, FaultProcessingPolicy>>>() {
                    });

        for (Map<String, FaultProcessingPolicy> m : resultsFromJson.getResult()) {
            resultsArray.add(m.get("fault-processing-policy"));
        }

        if(resultsArray.size() == 1) {
            boolean dup = this.faultRepo.isDuplicateFault(faultCode);
            if (!dup) {
                logger.info("Processing Fault Acknowledgement:: Adding Acknowledgement UserName & Date to Fault");
                payload.setAckUsername("AUTO");
                payload.setAckDate(new Date());
            } else {
                logger.info("Processing Fault Auto Acknowledge:: Updating Acknowledgement UserName & Date");
                this.faultRepo.updateAcknowledgementDate(faultCode);
            }
        }

        return msg;
    }

    public Message<?> processReporting(Message<?> msg) {
        //TODO:: Add Business Logic for Sending Mail/Trap Based on Configuration
        Message<?> message = MessageBuilder.fromMessage(msg)
            .setHeader("report-mail", true)
            .setHeader("report-trap", true)
            .build();

        logger.info("Processing Fault Reporting:: " + message);
        return message;
    }

    @Transformer
    public FaultDTO faultDto(Message<String> msg) {
        String payload = msg.getPayload();
        FaultDTO dto = new FaultDTO();
        JSONObject jsonObject = null;

        try {
            jsonObject = new JSONObject(payload);
        }catch (JSONException err){
            logger.error("Error in Converting Fault DTO", err);
        }

        dto.setFaultId(Integer.parseInt(jsonObject.getString("faultCode")));
        dto.setFaultCode(jsonObject.getString("faultCode"));
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
        try {
            dto.setTimeOfDay(formatter.parse(jsonObject.getString("faultDate")));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        dto.setFaultContent(jsonObject.getString("faultContent"));

        return dto;
    }

    @Transformer
    public Fault faultDao(FaultDTO dto) {
        Fault fault = new Fault();
        String faultCode = dto.getFaultCode();
        fault.setFaultCode(Integer.parseInt(dto.getFaultCode()));
        fault.setFaultDate(dto.getTimeOfDay());
        fault.setFaultContent(dto.getFaultContent());
        fault.setSeverity(0);

        return fault;
    }

    @Transformer
    public MimeMessage faultMail(Fault fault) {        
        MimeMessage mimeMessage = null;
        String mailBody = null;
    
        mailBody = fault.getHost() + fault.getFaultId() + fault.getFaultContent();

        try {
            mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper message = new MimeMessageHelper(mimeMessage);
            message.setTo(env.getProperty("mail.message.to"));
            message.setFrom(env.getProperty("mail.message.from"));
            message.setSubject("NOA Fault : " + fault.getFaultId() + "On Host " + fault.getHost());
            message.setText(mailBody);
            message.setSentDate(new Date(System.currentTimeMillis()));
        }
        catch (MessagingException | MailException e) {
            logger.error("faultMail:: Error Creating Mail Message: ", e);
        }
        
        logger.info("faultMail:: Mail Message: " + mimeMessage);
        return mimeMessage;
    }

    @Transformer
    public Fault faultTrap(Fault fault) {
        logger.info("faultTrap:: " + fault);
        return fault;
    }
}