package in.utl.noa.service.dto;

import org.onap.aai.domain.yang.VpnService;

public class ServiceDTO extends VpnService {
    public String discoveryType;
    public String signalingType;
    public String mtu;
    public String macAgingTimer;
    public String instanceType;

    public String addressType;
    public String applyLabelMode;
    public Integer prexifLimitNumber;
    public Integer routingTableLimitNumber;

    public String getDiscoveryType() {
        return discoveryType;
    }

    public void setDiscoveryType(String discoveryType) {
        this.discoveryType = discoveryType;
    }

    public String getInstanceType() {
        return instanceType;
    }

    public void setInstanceType(String instanceType) {
        this.instanceType = instanceType;
    }

    public String getSignalingType() {
        return signalingType;
    }

    public void setSignalingType(String signalingType) {
        this.signalingType = signalingType;
    }

    public String getMtu() {
        return mtu;
    }

    public void setMtu(String mtu) {
        this.mtu = mtu;
    }

    public String getMacAgingTimer() {
        return macAgingTimer;
    }

    public void setMacAgingTimer(String macAgingTimer) {
        this.macAgingTimer = macAgingTimer;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public String getApplyLabelMode() {
        return applyLabelMode;
    }

    public void setApplyLabelMode(String applyLabelMode) {
        this.applyLabelMode = applyLabelMode;
    }

    public Integer getPrefixLimitNumber() {
        return prexifLimitNumber;
    }

    public void setPrefixLimitNumber(Integer prexifLimitNumber) {
        this.prexifLimitNumber = prexifLimitNumber;
    }

    public Integer getRoutingTableLimitNumber() {
        return routingTableLimitNumber;
    }

    public void setRoutingTableLimitNumber(Integer routingTableLimitNumber) {
        this.routingTableLimitNumber = routingTableLimitNumber;
    }
}
