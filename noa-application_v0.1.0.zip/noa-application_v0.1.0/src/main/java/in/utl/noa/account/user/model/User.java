package in.utl.noa.account.user.model;

import java.util.List;

import org.onap.aai.domain.yang.UserAccount;

import org.springframework.security.core.GrantedAuthority;

public class User extends UserAccount {

    List<GrantedAuthority> authorities;

    public User() {

    }

    public List<GrantedAuthority> getAuthorities() {
        return authorities;
    }

    public void setAuthorities(List<GrantedAuthority> authorities) {
        this.authorities = authorities;
    }
}