package in.utl.noa.account.user.password;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.UUID;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aai.domain.yang.PasswordPolicies;
import org.onap.aai.domain.yang.PasswordPolicy;
import org.onap.aai.domain.yang.UserAccount;

import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;

import org.onap.aaiclient.client.aai.entities.AAIResultWrapper;
import org.onap.aaiclient.client.aai.entities.Relationships;
import org.onap.aaiclient.client.aai.entities.uri.AAIPluralResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;

import in.utl.noa.util.RestClientManager;
import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.global.event.NoaEvents;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

@RestController
@RequestMapping(value = "/api/platform/security/policy/password")
public class PasswordPolicyController {
    private static Logger logger = Logger.getLogger(PasswordPolicyController.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    AuditLogger auditLogger = new AuditLogger();

    private AAIResourcesClient rClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
    }

    @GetMapping()
    public ResponseEntity<List<PasswordPolicy>> getSecurityPolicies() {
        List<PasswordPolicy> policiesList = null;
        AAIPluralResourceUri policiesUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicies());
        if (rClient.exists(policiesUri)) {
            Optional<PasswordPolicies> passwordPolicies = rClient.get(PasswordPolicies.class, policiesUri);
            policiesList = passwordPolicies.get().getPasswordPolicy();
            return ResponseEntity.status(HttpStatus.OK).body(policiesList);
        } else
            return ResponseEntity.status(HttpStatus.OK).body(policiesList);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "password-policy");

        Map<String, Object> columns = new HashMap<String, Object>();
        columns.put("policyName", "Policy Name");
        columns.put("maxFailAttempt", "Max Fail Attempts");
        columns.put("passExpDays", "Password Expiry Date");
        columns.put("minLength", "Min Length");
        columns.put("numMultipleLogin", "Num Multiple Logins");
        columns.put("numOldPassword", "Num Old Passoword");
        columns.put("minReuseDays", "Min Reuse Days");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getPolicyList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject passwordPolicies = filterService.queryByFilter(requestBody, "password-policy");
        return ResponseEntity.status(HttpStatus.OK).body(passwordPolicies);
    }

    @GetMapping(value = "/{policyId}")
    public ResponseEntity<Optional<PasswordPolicy>> getPolicyById(@PathVariable("policyId") String policyId) {

        Optional<PasswordPolicy> policy = null;
        AAIResourceUri policyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));
        if (rClient.exists(policyUri)) {
            policy = rClient.get(PasswordPolicy.class, policyUri);
            return ResponseEntity.status(HttpStatus.OK).body(policy);
        } else
            return ResponseEntity.status(HttpStatus.OK).body(policy);
    }

    @PutMapping()
    public ResponseEntity<String> addPolicy(@RequestBody PasswordPolicy newPolicy) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String policyId = UUID.randomUUID().toString();
        newPolicy.setPolicyId(policyId);

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Password Policy", policyId, null, null);

        if (policyId != null) {
            AAIResourceUri policyUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));
            if (!rClient.exists(policyUri)) {
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().create(policyUri, newPolicy);
                transactions.execute();

                description = policyId + " Password Policy Created Successfully.";
                eventStatus = true;
                reqStatus = HttpStatus.CREATED;
            } else {
                description = policyId + " Policy Already Exists.";
            }
        } else {
            description = "Received Null Policy Id.";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "Password Policy Management",
                NoaEvents.CREATE_PASSWORD_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @PostMapping(value = "/{policyId}", consumes = "application/json")
    public ResponseEntity<String> updatePolicy(@PathVariable("policyId") String policyId,
            @RequestBody PasswordPolicy policyBody) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Password Policy", policyId, null, null);

        if (policyId != null) {
            AAIResourceUri policyUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));

            if (rClient.exists(policyUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().update(policyUri, policyBody);

                transactions.execute();
                description = policyId + " Password Policy Updated Successfully.";
                reqStatus = HttpStatus.OK;
                eventStatus = true;
            } else {
                description = policyId + " Password Policy Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Policy Id";
        }
        auditLogger.addAuditLog(rClient, description, "Security", "Password Policy Management",
                NoaEvents.MODIFY_PASSWORD_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deletePolicies(@RequestBody List<String> passwordPolicyIds) throws BulkProcessFailed {

        List<String> descriptions = new ArrayList<String>();

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        for (String policyId : passwordPolicyIds) {
            ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Security Policy", policyId, null,
                    null);
            if (policyId != null) {
                AAIResourceUri policyUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));

                if (rClient.exists(policyUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(policyUri);
                    transactions.execute();
                    description = policyId + " Password Policy Deleted Successfully.";
                    eventStatus = true;
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Security", "Password Policy Management",
                            NoaEvents.DELETE_PASSWORD_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = policyId + " Password Policy Doesn't Exists.";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Security", "Password Policy Management",
                            NoaEvents.DELETE_PASSWORD_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Id";
                auditLogger.addAuditLog(rClient, description, "Security", "Password Policy Management",
                        NoaEvents.DELETE_PASSWORD_POLICY.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(reqStatus).body("Policies Deleted Successfully");
    }

    @GetMapping("/{policyId}/user")
    public ResponseEntity<List<Optional<UserAccount>>> getUsers(@PathVariable("policyId") String policyId) {
        List<Optional<UserAccount>> userAccounts = new ArrayList<Optional<UserAccount>>();

        AAIResourceUri policyUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.business().passwordPolicy(policyId));
        if (rClient.exists(policyUri)) {
            AAIResultWrapper resultWrapper = rClient.get(policyUri);
            if (resultWrapper.hasRelationshipsTo(Types.USER_ACCOUNT)) {
                Relationships relationships = resultWrapper.getRelationships().get();
                List<AAIResourceUri> userUris = relationships.getRelatedUris(Types.USER_ACCOUNT);
                for (AAIResourceUri userUri : userUris) {
                    userAccounts.add(rClient.get(UserAccount.class, userUri));
                }
                return ResponseEntity.status(HttpStatus.OK).body(userAccounts);
            } else
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(userAccounts);
        } else
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(userAccounts);
    }
}
