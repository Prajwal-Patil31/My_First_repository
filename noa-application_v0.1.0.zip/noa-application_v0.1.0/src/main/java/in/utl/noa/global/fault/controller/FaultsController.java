package in.utl.noa.global.fault.controller;

import org.apache.log4j.Logger;

import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.json.simple.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import in.utl.noa.global.fault.model.Fault;
import in.utl.noa.global.fault.repository.FaultRepository;
import in.utl.noa.account.user.model.User;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;

import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

@RestController
@RequestMapping(value = "/api/global/fault")
public class FaultsController {
    private static Logger logger = Logger.getLogger(FaultsController.class);

    JSONParser parser = new JSONParser();
    ObjectMapper mapper = new ObjectMapper();

    @Autowired
    FaultRepository faultRepo;

    @Autowired
    GDBFilterService filterService;

    @GetMapping()
    public ResponseEntity<List<Fault>> getFaults() throws BulkProcessFailed {
        List<Fault> faults = faultRepo.findAll();
        return ResponseEntity.status(HttpStatus.OK).body(faults);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getFaultConfigurationFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "fault");

        Map<String, Object> columns = new HashMap<>();
        columns.put("faultCode", "Fault Code");
        columns.put("description", "Description");
        columns.put("resource", "Resource");
        columns.put("resourceId", "Resource Id");
        columns.put("severity", "Severity");
        columns.put("occurance", "Occurance");
        columns.put("count", "Count");
        columns.put("status", "Status");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getFaultConfigurationList(@RequestBody RequestBodyDTO requestBody) {

        JSONObject faultList = faultRepo.filterByField(requestBody);
        return ResponseEntity.status(HttpStatus.OK).body(faultList);
    }

    @PostMapping(value = "/acknowledge")
    public ResponseEntity<String> acknowledgeFaults(@RequestBody List<Integer> faultIds, final Authentication auth)
            throws BulkProcessFailed {

        logger.info(faultIds);
        for (int faultId : faultIds) {
            Fault fault = faultRepo.findByFaultId(faultId).get();
            logger.info(fault.toString());

            User user = (User) auth.getPrincipal();
            String username = user.getUserName();
            fault.setAckUsername(username);
            fault.setAckDate(new Date());
            fault.setStatus("Acknowledged");
            logger.info(fault.toString());
            faultRepo.save(fault);
        }
        return ResponseEntity.status(HttpStatus.OK).body("Faults Acknowledged");
    }

    @PostMapping(value = "/clear")
    public ResponseEntity<String> clearFaults(@RequestBody List<Integer> faultIds, final Authentication auth)
            throws BulkProcessFailed {

        for (int faultId : faultIds) {
            Fault fault = faultRepo.findByFaultId(faultId).get();

            logger.info(fault.toString());
            User user = (User) auth.getPrincipal();
            String username = user.getUserName();
            fault.setClearUsername(username);
            fault.setClearDate(new Date());

            fault.setStatus("Cleared");
            logger.info(fault.toString());
            faultRepo.save(fault);

        }
        return ResponseEntity.status(HttpStatus.OK).body("Faults Cleared");
    }

    @GetMapping("/summary")
    public ResponseEntity<JSONObject> getNetworkOverview() throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject alarmSummaryObj = (JSONObject) obj.get("alarm-event-summary");

        return ResponseEntity.ok(alarmSummaryObj);
    }

    @GetMapping("/distribution")
    public ResponseEntity<JSONObject> getAlarmEventsDistribution()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        JSONObject alarmDistributionObj = (JSONObject) obj.get("fault-event-distribution");

        return ResponseEntity.ok(alarmDistributionObj);
    }

    @GetMapping("/recent")
    public ResponseEntity<List<JSONObject>> getRecentFaults()
            throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> recentFaultsObj = (List<JSONObject>) obj.get("recent-faults");

        return ResponseEntity.ok(recentFaultsObj);
    }

    @GetMapping("/top")
    public ResponseEntity<List<JSONObject>> getTopFaults() throws FileNotFoundException, IOException, ParseException {
        JSONParser parser = new JSONParser();
        JSONObject obj = (JSONObject) parser.parse(new FileReader("src/main/java/in/utl/noa/ChartsMockData.json"));
        List<JSONObject> topFaultsObj = (List<JSONObject>) obj.get("top-faults");

        return ResponseEntity.ok(topFaultsObj);
    }

    @PostMapping(value = "/create")
    public ResponseEntity<String> createFaults()
            throws BulkProcessFailed, FileNotFoundException, IOException, ParseException {

        JSONArray obj = (JSONArray) parser.parse(new FileReader("src/main/java/in/utl/noa/DefaultFaults.json"));
        JSONObject faultsObj = (JSONObject) obj.get(0);
        List<JSONObject> faultsList = (List<JSONObject>) faultsObj.get("faults");

        for (JSONObject fault : faultsList) {
            String defaultFault = fault.toString();
            Fault faultObj = mapper.readValue(defaultFault, Fault.class);
            String faultId = UUID.randomUUID().toString();
            faultObj.setFaultIdentifier(faultId);
            faultObj.setFaultDate(new Date());
            faultRepo.save(faultObj);
        }
        return ResponseEntity.status(HttpStatus.OK).body("Faults Added");
    }

}
