package in.utl.noa.element.config.vlan.dto;

import java.util.List;

public class VlanInterfaceDTO {
    private String vlanId;
    private String vlanName;
    private String vlanType;
    private String tqPort;
    private String vlanStaticName;
    private String tqGroupAddress;
    private Boolean vlanStaticRowStatus;
    private String tagType;
    private int ifIndex;
    private String ifAlias;
    private String ifMainType;
    private String ifIpAddr;
    private String ifIpSubnetMask;
    private String ifIpBroadcastAddr;
    private List<String> interfaceIds;

    public VlanInterfaceDTO() {
    }

    public String getTagType() {
        return tagType;
    }

    public void setTagType(String tagType) {
        this.tagType = tagType;
    }

    public String getVlanId() {
        return this.vlanId;
    }

    public void setVlanId(String vlanId) {
        this.vlanId = vlanId;
    }

    public String getVlanName() {
        return this.vlanName;
    }

    public void setVlanName(String vlanName) {
        this.vlanName = vlanName;
    }

    public String getVlanType() {
        return this.vlanType;
    }

    public void setVlanType(String vlanType) {
        this.vlanType = vlanType;
    }

    public String getTqPort() {
        return this.tqPort;
    }

    public void setTqPort(String tqPort) {
        this.tqPort = tqPort;
    }

    public String getVlanStaticName() {
        return this.vlanStaticName;
    }

    public void setVlanStaticName(String vlanStaticName) {
        this.vlanStaticName = vlanStaticName;
    }

    public String getTqGroupAddress() {
        return this.tqGroupAddress;
    }

    public void setTqGroupAddress(String tqGroupAddress) {
        this.tqGroupAddress = tqGroupAddress;
    }

    public Boolean isVlanStaticRowStatus() {
        return this.vlanStaticRowStatus;
    }

    public Boolean getVlanStaticRowStatus() {
        return this.vlanStaticRowStatus;
    }

    public void setVlanStaticRowStatus(Boolean vlanStaticRowStatus) {
        this.vlanStaticRowStatus = vlanStaticRowStatus;
    }

    public int getIfIndex() {
        return this.ifIndex;
    }

    public void setIfIndex(int ifIndex) {
        this.ifIndex = ifIndex;
    }

    public String getIfAlias() {
        return this.ifAlias;
    }

    public void setIfAlias(String ifAlias) {
        this.ifAlias = ifAlias;
    }

    public String getIfMainType() {
        return this.ifMainType;
    }

    public void setIfMainType(String ifMainType) {
        this.ifMainType = ifMainType;
    }

    public String getIfIpAddr() {
        return this.ifIpAddr;
    }

    public void setIfIpAddr(String ifIpAddr) {
        this.ifIpAddr = ifIpAddr;
    }

    public String getIfIpSubnetMask() {
        return this.ifIpSubnetMask;
    }

    public void setIfIpSubnetMask(String ifIpSubnetMask) {
        this.ifIpSubnetMask = ifIpSubnetMask;
    }

    public String getIfIpBroadcastAddr() {
        return this.ifIpBroadcastAddr;
    }

    public void setIfIpBroadcastAddr(String ifIpBroadcastAddr) {
        this.ifIpBroadcastAddr = ifIpBroadcastAddr;
    }

    public List<String> getInterfaceIds() {
        return this.interfaceIds;
    }

    public void setInterfaceIds(List<String> interfaceIds) {
        this.interfaceIds = interfaceIds;
    }

    @Override
    public String toString() {
        return "{" + " vlanId='" + getVlanId() + "'" + ", vlanName='" + getVlanName() + "'" + ", vlanType='"
                + getVlanType() + "'" + ", tqPort='" + getTqPort() + "'" + ", vlanStaticName='" + getVlanStaticName()
                + "'" + ", tqGroupAddress='" + getTqGroupAddress() + "'" + ", vlanStaticRowStatus='"
                + isVlanStaticRowStatus() + "'" + ", tagType='" + getTagType() + "'" + ", ifIndex='" + getIfIndex()
                + "'" + ", ifAlias='" + getIfAlias() + "'" + ", ifMainType='" + getIfMainType() + "'" + ", ifIpAddr='"
                + getIfIpAddr() + "'" + ", ifIpSubnetMask='" + getIfIpSubnetMask() + "'" + ", ifIpBroadcastAddr='"
                + getIfIpBroadcastAddr() + "'" + ", interfaceIds='" + getInterfaceIds() + "'" + "}";
    }

}
