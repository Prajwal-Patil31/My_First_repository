package in.utl.noa.element.dto;

public class RouterConfigDTO {
    private String ldpLsrId;
    private String routerId;
    private String labelDistributionMode;
    private String labelControlMode;
    private String labelAllocationMode;
    private String loopDetectionCapable;
    private Boolean xcNotificationsEnable;
    private Boolean forceOption;
    private Boolean configurationSequenceTlvEnable;
    private String mplsAdminStatus;
    private String qosPolicy;
    private Integer activeLsps;
    private Boolean tunnelNotificationEnable;
    private Integer tunnelNotificationMaxRate;
    private String teDistProto;
    private Integer maxHops;
    private Integer l2VpnTrcFlag;
    private Integer l2VpnCleanupInterval;
    private String l2VpnAdminStatus;
    private String localCcTypesCapabilities;
    private String localCvTypesCapabilities;

    public RouterConfigDTO() {
    }

    public String getLdpLsrId() {
        return ldpLsrId;
    }

    public void setLdpLsrId(String ldpLsrId) {
        this.ldpLsrId = ldpLsrId;
    }

    public String getRouterId() {
        return routerId;
    }

    public void setRouterId(String routerId) {
        this.routerId = routerId;
    }

    public String getLabelDistributionMode() {
        return labelDistributionMode;
    }

    public void setLabelDistributionMode(String labelDistributionMode) {
        this.labelDistributionMode = labelDistributionMode;
    }

    public String getLabelControlMode() {
        return labelControlMode;
    }

    public void setLabelControlMode(String labelControlMode) {
        this.labelControlMode = labelControlMode;
    }

    public String getLabelAllocationMode() {
        return labelAllocationMode;
    }

    public void setLabelAllocationMode(String labelAllocationMode) {
        this.labelAllocationMode = labelAllocationMode;
    }

    public String getLoopDetectionCapable() {
        return loopDetectionCapable;
    }

    public void setLoopDetectionCapable(String loopDetectionCapable) {
        this.loopDetectionCapable = loopDetectionCapable;
    }

    public Boolean getXcNotificationsEnable() {
        return xcNotificationsEnable;
    }

    public void setXcNotificationsEnable(Boolean xcNotificationsEnable) {
        this.xcNotificationsEnable = xcNotificationsEnable;
    }

    public Boolean getForceOption() {
        return forceOption;
    }

    public void setForceOption(Boolean forceOption) {
        this.forceOption = forceOption;
    }

    public Boolean getConfigurationSequenceTlvEnable() {
        return configurationSequenceTlvEnable;
    }

    public void setConfigurationSequenceTlvEnable(Boolean configurationSequenceTlvEnable) {
        this.configurationSequenceTlvEnable = configurationSequenceTlvEnable;
    }

    public String getMplsAdminStatus() {
        return mplsAdminStatus;
    }

    public void setMplsAdminStatus(String mplsAdminStatus) {
        this.mplsAdminStatus = mplsAdminStatus;
    }

    public String getQosPolicy() {
        return qosPolicy;
    }

    public void setQosPolicy(String qosPolicy) {
        this.qosPolicy = qosPolicy;
    }

    public Integer getActiveLsps() {
        return activeLsps;
    }

    public void setActiveLsps(Integer activeLsps) {
        this.activeLsps = activeLsps;
    }

    public Boolean getTunnelNotificationEnable() {
        return tunnelNotificationEnable;
    }

    public void setTunnelNotificationEnable(Boolean tunnelNotificationEnable) {
        this.tunnelNotificationEnable = tunnelNotificationEnable;
    }

    public Integer getTunnelNotificationMaxRate() {
        return tunnelNotificationMaxRate;
    }

    public void setTunnelNotificationMaxRate(Integer tunnelNotificationMaxRate) {
        this.tunnelNotificationMaxRate = tunnelNotificationMaxRate;
    }

    public String getTeDistProto() {
        return teDistProto;
    }

    public void setTeDistProto(String teDistProto) {
        this.teDistProto = teDistProto;
    }

    public Integer getMaxHops() {
        return maxHops;
    }

    public void setMaxHops(Integer maxHops) {
        this.maxHops = maxHops;
    }

    public Integer getL2VpnTrcFlag() {
        return l2VpnTrcFlag;
    }

    public void setL2VpnTrcFlag(Integer l2VpnTrcFlag) {
        this.l2VpnTrcFlag = l2VpnTrcFlag;
    }

    public Integer getL2VpnCleanupInterval() {
        return l2VpnCleanupInterval;
    }

    public void setL2VpnCleanupInterval(Integer l2VpnCleanupInterval) {
        this.l2VpnCleanupInterval = l2VpnCleanupInterval;
    }

    public String getL2VpnAdminStatus() {
        return l2VpnAdminStatus;
    }

    public void setL2VpnAdminStatus(String l2VpnAdminStatus) {
        this.l2VpnAdminStatus = l2VpnAdminStatus;
    }

    public String getLocalCcTypesCapabilities() {
        return localCcTypesCapabilities;
    }

    public void setLocalCcTypesCapabilities(String localCcTypesCapabilities) {
        this.localCcTypesCapabilities = localCcTypesCapabilities;
    }

    public String getLocalCvTypesCapabilities() {
        return localCvTypesCapabilities;
    }

    public void setLocalCvTypesCapabilities(String localCvTypesCapabilities) {
        this.localCvTypesCapabilities = localCvTypesCapabilities;
    }

    @Override
    public String toString() {
        return "RouterConfigDTO [activeLsps=" + activeLsps + ", configurationSequenceTlvEnable="
                + configurationSequenceTlvEnable + ", forceOption=" + forceOption + ", l2VpnAdminStatus="
                + l2VpnAdminStatus + ", l2VpnCleanupInterval=" + l2VpnCleanupInterval + ", l2VpnTrcFlag=" + l2VpnTrcFlag
                + ", labelAllocationMode=" + labelAllocationMode + ", labelControlMode=" + labelControlMode
                + ", labelDistributionMode=" + labelDistributionMode + ", ldpLsrId=" + ldpLsrId
                + ", localCcTypesCapabilities=" + localCcTypesCapabilities + ", localCvTypesCapabilities="
                + localCvTypesCapabilities + ", loopDetectionCapable=" + loopDetectionCapable + ", maxHops=" + maxHops
                + ", mplsAdminStatus=" + mplsAdminStatus + ", tunnelNotificationMaxRate=" + tunnelNotificationMaxRate
                + ", qosPolicy=" + qosPolicy + ", routerId=" + routerId + ", teDistProto=" + teDistProto
                + ", tunnelNotificationEnable=" + tunnelNotificationEnable + ", xcNotificationsEnable="
                + xcNotificationsEnable + "]";
    }

}
