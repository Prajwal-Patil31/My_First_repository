package in.utl.noa.global.fault.model;

public interface FaultConfigRepositoryCustom {
    public FaultConfig isFaultConfigured(int errorCode);
}