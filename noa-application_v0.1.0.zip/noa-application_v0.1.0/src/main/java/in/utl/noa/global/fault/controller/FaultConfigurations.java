package in.utl.noa.global.fault.controller;

import org.apache.log4j.Logger;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.PostConstruct;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.onap.aai.domain.yang.FaultConfig;
import org.onap.aai.domain.yang.FaultConfigs;
import org.onap.aai.domain.yang.FaultProcessingPolicy;
import org.onap.aai.domain.yang.ResourceMetadata;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.entities.AAIResultWrapper;
import org.onap.aaiclient.client.aai.entities.Relationships;
import org.onap.aaiclient.client.aai.entities.Results;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAISimplePluralUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder.Types;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.onap.aaiclient.client.graphinventory.Format;
import org.onap.aaiclient.client.graphinventory.entities.DSLQuery;
import org.onap.aaiclient.client.graphinventory.entities.DSLQueryBuilder;
import org.onap.aaiclient.client.graphinventory.entities.DSLStartNode;
import org.onap.aaiclient.client.graphinventory.entities.Node;
import org.onap.aaiclient.client.graphinventory.entities.Start;
import org.onap.aaiclient.client.graphinventory.entities.TraversalBuilder;
import org.onap.aaiclient.client.graphinventory.entities.__;

import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;

import org.onap.aaiclient.client.aai.AAICommonObjectMapperProvider;
import org.onap.aaiclient.client.aai.AAIDSLQueryClient;

import in.utl.noa.security.audit.AuditLogger;
import in.utl.noa.util.GDBFilterService;
import in.utl.noa.util.RestClientManager;
import in.utl.noa.dto.RequestBodyDTO;
import in.utl.noa.dto.ResponseDataDTO;
import in.utl.noa.global.event.NoaEvents;

@RestController
@RequestMapping(value = "/api/platform/fault/config")
public class FaultConfigurations {
    private static Logger logger = Logger.getLogger(FaultConfigurations.class);

    @Autowired
    RestClientManager restClientManager;

    @Autowired
    GDBFilterService filterService;

    AuditLogger auditLogger = new AuditLogger();

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    static ObjectMapper mapper = new AAICommonObjectMapperProvider().getMapper();

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @GetMapping()
    public ResponseEntity<List<FaultConfig>> getFaultConfigurations()
            throws JsonMappingException, JsonProcessingException {
        List<FaultConfig> configurationList = new ArrayList<FaultConfig>();
        AAISimplePluralUri uri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.network().faultConfigs());

        if (rClient.exists(uri)) {
            FaultConfigs configurations = rClient.get(FaultConfigs.class, uri).get();
            configurationList = configurations.getFaultConfig();
        }

        return ResponseEntity.ok(configurationList);
    }

    @GetMapping("/filter")
    public ResponseEntity<ResponseDataDTO> getFaultConfigurationFilters() {
        ResponseDataDTO responseData = new ResponseDataDTO();

        Map<String, JSONObject> filters = filterService.getFilterCriteria(null, "fault-config");

        Map<String, Object> columns = new HashMap<>();
        columns.put("errorCode", "Error Code");
        columns.put("severity", "Severity");
        columns.put("relatedErrorCode", "Related Error Code");
        columns.put("trapCategory", "Trap Category");
        columns.put("policyType", "Policy Type");
        columns.put("policyName", "Policy Name");

        responseData.setColumns(columns);
        responseData.setFilters(filters);

        return ResponseEntity.status(HttpStatus.OK).body(responseData);
    }

    @PostMapping()
    public ResponseEntity<JSONObject> getFaultConfigurationList(@RequestBody RequestBodyDTO requestBody) {
        JSONObject configurations = filterService.queryByFilter(requestBody, "fault-config");
        return ResponseEntity.status(HttpStatus.OK).body(configurations);
    }

    @GetMapping(value = "/{configId}", produces = "application/json")
    public ResponseEntity<FaultConfig> getFaultConfigurationById(@PathVariable("configId") String configId) {

        FaultConfig faultConfig = new FaultConfig();
        AAIResourceUri faultConfigUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));

        if (rClient.exists(faultConfigUri)) {
            faultConfig = rClient.get(FaultConfig.class, faultConfigUri).get();
            return ResponseEntity.status(HttpStatus.OK).body(faultConfig);
        }
        return ResponseEntity.status(HttpStatus.OK).body(faultConfig);
    }

    @PutMapping()
    public ResponseEntity<FaultConfig> addConfiguration(@RequestBody FaultConfig newConfiguration)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String configId = UUID.randomUUID().toString();
        newConfiguration.setConfigId(configId);
        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Configuration", configId, null,
                null);

        AAIResourceUri configurationUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));

        AAITransactionalClient transactions;

        transactions = rClient.beginTransaction().create(configurationUri, newConfiguration);

        transactions.execute();
        description = configId + " Configuration Created Successfully";
        eventStatus = true;
        reqStatus = HttpStatus.CREATED;

        auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                NoaEvents.CREATE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(newConfiguration);
    }

    @PostMapping(value = "/{configId}", consumes = "application/json")
    public ResponseEntity<String> updateConfiguration(@PathVariable("configId") String configId,
            @RequestBody FaultConfig configurationBody) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Configuration",
                configurationBody.getConfigId(), null, null);

        if (configId != null) {
            AAIResourceUri configurationUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));

            if (rClient.exists(configurationUri)) {
                AAITransactionalClient transactions;

                transactions = rClient.beginTransaction().update(configurationUri, configurationBody);

                transactions.execute();
                description = configId + " Fault Configuration Updated Successfully.";
                reqStatus = HttpStatus.OK;
                eventStatus = true;
            } else {
                description = configId + " Fault Configuration Doesn't Exists.";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Config Id";
        }
        auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                NoaEvents.MODIFY_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping(value = "/{configId}")
    public ResponseEntity<String> deleteConfiguration(@PathVariable("configId") String configId)
            throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Configuration", null, null, null);
        resourceMetadata.setResourceId(configId);
        if (configId != null) {
            AAIResourceUri configurationUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));

            if (rClient.exists(configurationUri)) {
                AAITransactionalClient transactions;
                transactions = rClient.beginTransaction().delete(configurationUri);
                transactions.execute();
                description = configId + " Fault Configuration Deleted Successfully.";
                reqStatus = HttpStatus.NO_CONTENT;
                auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                        NoaEvents.DELETE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
            } else {
                description = configId + " Fault Configuration Doesn't Exists";
                reqStatus = HttpStatus.NOT_FOUND;
                auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                        NoaEvents.DELETE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        } else {
            description = "Received Null Config Id";
            auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                    NoaEvents.DELETE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
            return ResponseEntity.status(reqStatus).body(description);
        }
        return ResponseEntity.status(reqStatus).body(description);
    }

    @DeleteMapping()
    public ResponseEntity<String> deleteConfigurations(@RequestBody List<String> configIds) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.BAD_REQUEST;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Configuration", null, null, null);

        for (String configId : configIds) {
            resourceMetadata.setResourceId(configId);
            if (configId != null) {
                AAIResourceUri configurationUri = AAIUriFactory
                        .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));

                if (rClient.exists(configurationUri)) {
                    AAITransactionalClient transactions;
                    transactions = rClient.beginTransaction().delete(configurationUri);
                    transactions.execute();
                    description = configId + " Fault Configuration Deleted Successfully.";
                    reqStatus = HttpStatus.NO_CONTENT;
                    auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                            NoaEvents.DELETE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                } else {
                    description = configId + " Fault Configuration Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                    auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                            NoaEvents.DELETE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                    return ResponseEntity.status(reqStatus).body(description);
                }
            } else {
                description = "Received Null Config Id";
                auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                        NoaEvents.DELETE_FAULT_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata, auth);
                return ResponseEntity.status(reqStatus).body(description);
            }
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Fault Configurations Deleted Successfully");
    }

    @PostMapping(value = "/{configId}/policy/{policyId}")
    public ResponseEntity<String> addPolicyToConfiguration(@PathVariable("configId") String configId,
            @PathVariable("policyId") String policyId) throws BulkProcessFailed {

        String description = null;
        Boolean eventStatus = false;
        HttpStatus reqStatus = HttpStatus.NOT_FOUND;
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        ResourceMetadata resourceMetadata = auditLogger.createResourceMetadata("Fault Processing Policy", policyId,
                "Fault Configuration", configId);

        if (configId != null && policyId != null) {
            AAIResourceUri configurationUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().faultConfig(configId));
            AAIResourceUri policyUri = AAIUriFactory
                    .createResourceUri(AAIFluentTypeBuilder.network().faultProcessingPolicy(policyId));

            if (rClient.exists(policyUri)) {
                if (rClient.exists(configurationUri)) {
                    AAISingleTransactionClient transactionClient = rClient.beginSingleTransaction();
                    AAIResultWrapper resultWrapper = rClient.get(configurationUri);
                    if (resultWrapper.hasRelationshipsTo(Types.FAULT_PROCESSING_POLICY)) {
                        Relationships relationships = resultWrapper.getRelationships().get();
                        List<AAIResourceUri> allRelatedNodes = relationships
                                .getRelatedUris(Types.FAULT_PROCESSING_POLICY);
                        AAIResourceUri policyUriOld = allRelatedNodes.get(0);
                        transactionClient.disconnect(configurationUri, policyUriOld);
                    }
                    transactionClient.connect(configurationUri, policyUri);

                    transactionClient.execute();
                    description = policyId + " Fault Processing Policy has been Assigned to " + configId
                            + "Fault Configuration.";
                    reqStatus = HttpStatus.OK;
                    eventStatus = true;
                } else {
                    description = configId + " Fault Configuration Doesn't Exists";
                    reqStatus = HttpStatus.NOT_FOUND;
                }
            } else {
                description = policyId + " Fault Processing Policy Doesn't Exists";
                reqStatus = HttpStatus.NOT_FOUND;
            }
        } else {
            description = "Received Null Value; ConfigId : " + configId + ", Policy Id: " + policyId;
        }
        auditLogger.addAuditLog(rClient, description, "Fault Management", "Fault Configuration",
                NoaEvents.ASSIGN_PROCESSING_POLICY_TO_CONFIGURATION.getEvent(), eventStatus, null, resourceMetadata,
                auth);
        return ResponseEntity.status(reqStatus).body(description);
    }

    @GetMapping(value = "/{configId}/policy", produces = "application/json")
    public ResponseEntity<FaultProcessingPolicy> getPolicy(@PathVariable("configId") String configId)
            throws ParseException, JsonMappingException, JsonProcessingException {

        FaultProcessingPolicy faultProcessingPolicy = new FaultProcessingPolicy();

        DSLStartNode startNode = new DSLStartNode(Types.FAULT_CONFIG, __.key("config-id", configId));
        DSLQueryBuilder<Start, Node> builder = TraversalBuilder.fragment(startNode)
                .to(__.node(Types.FAULT_PROCESSING_POLICY)).output();

        String results = dslClient.query(Format.RESOURCE, new DSLQuery(builder.build()));

        Results<Map<String, FaultProcessingPolicy>> resultsFromJson = mapper.readValue(results,
                new TypeReference<Results<Map<String, FaultProcessingPolicy>>>() {
                });

        for (Map<String, FaultProcessingPolicy> m : resultsFromJson.getResult()) {
            faultProcessingPolicy = m.get("fault-processing-policy");
        }

        return ResponseEntity.status(HttpStatus.OK).body(faultProcessingPolicy);
    }
}
