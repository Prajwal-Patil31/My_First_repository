package in.utl.noa.element.config.resource.port.model;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "interface-stats", path = "interface-stats")
public interface InterfaceStatsRepository extends JpaRepository<InterfaceStats, String> {

    public InterfaceStats findByStatsId(String statsId);
    public List<InterfaceStats> findByInterfaceId(String interfaceId);

    @Query(
        value="select * FROM noa.noa.interfacestats i where i.interfaceid = :interfaceId and i.timestamp > clock_timestamp()-make_interval(hours => :hours,days => :days,mins => :minutes)"
        ,nativeQuery = true)
    public List<InterfaceStats> findByDuration(@Param("interfaceId") String interfaceId, @Param("minutes") int minutes, @Param("hours") int hours, @Param("days") int days);
}
