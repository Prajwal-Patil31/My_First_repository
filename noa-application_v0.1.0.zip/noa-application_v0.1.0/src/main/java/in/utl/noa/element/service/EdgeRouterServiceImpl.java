package in.utl.noa.element.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import javax.annotation.PostConstruct;

import com.google.common.util.concurrent.FutureCallback;
import com.google.common.util.concurrent.Futures;
import com.google.common.util.concurrent.MoreExecutors;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;

import org.onap.aai.domain.yang.AttachmentCircuit;
import org.onap.aai.domain.yang.CrossConnect;
import org.onap.aai.domain.yang.EdgeRouter;
import org.onap.aai.domain.yang.InSegment;
import org.onap.aai.domain.yang.InSegmentStatEntry;
import org.onap.aai.domain.yang.LdpEntity;
import org.onap.aai.domain.yang.LsrConfig;
import org.onap.aai.domain.yang.MplsL2VpnStats;
import org.onap.aai.domain.yang.MplsTunnel;
import org.onap.aai.domain.yang.MplsTunnelConfig;
import org.onap.aai.domain.yang.MplsTunnelStats;
import org.onap.aai.domain.yang.NetworkDevice;
import org.onap.aai.domain.yang.OutSegment;
import org.onap.aai.domain.yang.OutSegmentStatEntry;
import org.onap.aai.domain.yang.TunnelStatEntry;

import org.onap.aaiclient.client.aai.AAIDSLQueryClient;
import org.onap.aaiclient.client.aai.AAIResourcesClient;
import org.onap.aaiclient.client.aai.AAISingleTransactionClient;
import org.onap.aaiclient.client.aai.AAITransactionalClient;
import org.onap.aaiclient.client.aai.entities.uri.AAIResourceUri;
import org.onap.aaiclient.client.aai.entities.uri.AAIUriFactory;

import org.onap.aaiclient.client.generated.fluentbuilders.AAIFluentTypeBuilder;
import org.onap.aaiclient.client.graphinventory.exceptions.BulkProcessFailed;

import org.opendaylight.mdsal.common.api.CommitInfo;
import org.opendaylight.mdsal.common.api.LogicalDatastoreType;
import org.opendaylight.mdsal.dom.api.DOMDataBroker;
import org.opendaylight.mdsal.dom.api.DOMDataTreeReadTransaction;
import org.opendaylight.mdsal.dom.api.DOMDataTreeWriteTransaction;
import org.opendaylight.mdsal.dom.api.DOMMountPoint;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.ARICENTCFAMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib.If;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib._if.IfACTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.cfa.mib.rev120905.aricent.cfa.mib._if.ifactable.IfACEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.mpls.mib.rev120905.AricentMPLSMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.mpls.mib.rev120905.aricent.mpls.mib.FsMplsConfigObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.mpls.mib.rev120905.aricent.mpls.mib.FsMplsL2VpnObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.mpls.mib.rev120905.aricent.mpls.mib.FsMplsLdpScalarObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.mpls.mib.rev120905.aricent.mpls.mib.fsmplsl2vpnobjects.FsMplsL2VpnConfigObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.aricent.mpls.mib.rev120905.aricent.mpls.mib.fsmplsl2vpnobjects.FsMplsL2VpnStatsObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.MPLSLSRSTDMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.MplsLsrObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.te.std.mib.rev050307.MPLSTESTDMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.te.std.mib.rev050307.mpls.te.std.mib.MplsTeObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.te.std.mib.rev050307.mpls.te.std.mib.MplsTeScalars;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.te.std.mib.rev050307.mpls.te.std.mib.mplsteobjects.MplsTunnelTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.te.std.mib.rev050307.mpls.te.std.mib.mplsteobjects.mplstunneltable.MplsTunnelEntry;

import org.opendaylight.yangtools.yang.common.QName;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier.NodeIdentifier;
import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier.NodeIdentifierWithPredicates;
import org.opendaylight.yangtools.yang.data.api.schema.NormalizedNode;
import org.opendaylight.yangtools.yang.data.impl.schema.Builders;
import org.opendaylight.yangtools.yang.data.impl.schema.ImmutableNodes;
import org.opendaylight.yangtools.yang.data.impl.schema.builder.api.DataContainerNodeBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.opendaylight.yangtools.yang.data.api.schema.MapEntryNode;

import in.utl.noa.element.dto.RouterConfigDTO;
import io.lighty.core.controller.api.LightyServices;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.MPLSLDPSTDMIB;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.MplsLdpObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.mplsldpobjects.MplsLdpEntityObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.mplsldpobjects.MplsLdpSessionObjects;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.mplsldpobjects.mplsldpentityobjects.MplsLdpEntityTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.mplsldpobjects.mplsldpentityobjects.mplsldpentitytable.MplsLdpEntityEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.mplsldpobjects.mplsldpsessionobjects.MplsLdpPeerTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.ldp.std.mib.rev040603.mpls.ldp.std.mib.mplsldpobjects.mplsldpsessionobjects.mplsldppeertable.MplsLdpPeerEntry;

import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.mplslsrobjects.MplsInSegmentTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.mplslsrobjects.MplsOutSegmentTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.mplslsrobjects.MplsXCTable;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.mplslsrobjects.mplsinsegmenttable.MplsInSegmentEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.mplslsrobjects.mplsoutsegmenttable.MplsOutSegmentEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.mpls.lsr.std.mib.rev050307.mpls.lsr.std.mib.mplslsrobjects.mplsxctable.MplsXCEntry;
import org.opendaylight.yang.gen.v1.urn.ietf.params.xml.ns.yang.smiv2.snmpv2.tc.rev990401.DisplayString;

import org.opendaylight.yangtools.yang.data.api.YangInstanceIdentifier.PathArgument;
import org.opendaylight.yangtools.yang.data.api.schema.AugmentationNode;
import org.opendaylight.yangtools.yang.data.api.schema.DataContainerChild;
import org.opendaylight.yangtools.yang.data.api.schema.LeafNode;

import in.utl.noa.mdsal.service.MDSALService;
import in.utl.noa.util.RestClientManager;

@Service
public class EdgeRouterServiceImpl implements EdgeRouterService {
    private static Logger LOG = Logger.getLogger(EdgeRouterServiceImpl.class);

    private AAISingleTransactionClient transaction;

    LightyServices lightyServices;

    @Autowired
    MDSALService mdsalService;

    @Autowired
    RestClientManager restClientManager;

    private AAIResourcesClient rClient;
    private AAIDSLQueryClient dslClient;

    @PostConstruct
    public void init() {
        rClient = restClientManager.getRClient();
        dslClient = restClientManager.getDSLQueryClient();
    }

    @Override
    public EdgeRouter addRouter(NetworkDevice device) {
        String deviceId = device.getDeviceId();
        EdgeRouter edgeRouter = new EdgeRouter();
        edgeRouter.setRouterId(deviceId);
        edgeRouter.setRouterName(device.getDeviceName());
        edgeRouter.setRouterType("Provider Edge");
        edgeRouter.setIpAddress(device.getHost());
        
        LsrConfig lsrConfig = new LsrConfig();
        lsrConfig.setLdpLsrId(deviceId);
        lsrConfig.setLabelDistributionMode("LDP");
        lsrConfig.setLoopDetectionCapable("hopCountAndPathVector");
        lsrConfig.setLabelAllocationMode("independent");
        edgeRouter.getLsrConfig().add(lsrConfig);

        /* LdpConfig ldpConfig = new LdpConfig();
        ldpConfig.setLdpLsrId(deviceId);
        edgeRouter.getLdpConfig().add(ldpConfig);

        MplsConfig mplsConfig = new MplsConfig();
        mplsConfig.setConfigId(deviceId);
        mplsConfig.setRouterId(deviceId);
        mplsConfig.setLocalCcTypesCapabilities("routerAlertLabel");
        mplsConfig.setLocalCvTypesCapabilities("lspping");
        mplsConfig.setQosPolicy("diffserv");
        edgeRouter.getMplsConfig().add(mplsConfig); */

        MplsTunnelConfig mplsTunnelConfig = new MplsTunnelConfig();
        mplsTunnelConfig.setConfigId(deviceId);
        mplsTunnelConfig.setNotificationEnable(true);
        mplsTunnelConfig.setNotificationMaxRate(10);
        mplsTunnelConfig.setTeDistProto("ospf");
        mplsTunnelConfig.setMaxHops(10);
        edgeRouter.getMplsTunnelConfig().add(mplsTunnelConfig);

        MplsTunnelStats mplsTunnelStats = new MplsTunnelStats();
        mplsTunnelStats.setStatsId(deviceId);
        mplsTunnelStats.setActiveTunnels(0);
        mplsTunnelStats.setConfiguredTunnels(0);
        edgeRouter.getMplsTunnelStats().add(mplsTunnelStats);

        /* MplsL2VpnConfig mplsL2VpnConfig = new MplsL2VpnConfig();
        mplsL2VpnConfig.setConfigId(deviceId);
        mplsL2VpnConfig.setL2VpnTrcFlag(1);
        mplsL2VpnConfig.setL2VpnCleanupInterval(60000);
        mplsL2VpnConfig.setL2VpnAdminStatus("up");
        edgeRouter.getMplsL2VpnConfig().add(mplsL2VpnConfig); */

        MplsL2VpnStats mplsL2VpnStats = new MplsL2VpnStats();
        mplsL2VpnStats.setStatsId(deviceId);
        mplsL2VpnStats.setActivePwVcEntries(0);
        mplsL2VpnStats.setActivePwVcMplsEntries(0);
        mplsL2VpnStats.setNoOfPwVcEntriesCreated(0);
        mplsL2VpnStats.setNoOfPwVcEntriesDeleted(0);
        edgeRouter.getMplsL2VpnStats().add(mplsL2VpnStats);

        AAIResourceUri routerUri = AAIUriFactory.createResourceUri(AAIFluentTypeBuilder.device().edgeRouter(deviceId));

        AAIResourceUri deviceUri = AAIUriFactory
                .createResourceUri(AAIFluentTypeBuilder.device().networkDevice(deviceId));

        if (rClient.exists(deviceUri) && !rClient.exists(routerUri)) {
            AAITransactionalClient transaction = rClient.beginTransaction().create(routerUri, edgeRouter)
                    .connect(deviceUri, routerUri);
            try {
                transaction.execute();
            } catch (BulkProcessFailed e) {
                e.printStackTrace();
            }
        }
        return edgeRouter;
    }

    @Override
    public RouterConfigDTO getLsrConfig(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        RouterConfigDTO routerConfigDTO = new RouterConfigDTO();
        JSONObject configObj = new JSONObject();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, YII).get();
            if (readFuture.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        configObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            configObj.putAll(keyValuePair);
                        });
                    }
                });
                
                Boolean xCNotificationsEnable = Boolean.parseBoolean(configObj.get("mplsXCNotificationsEnable").toString());
                routerConfigDTO.setXcNotificationsEnable(xCNotificationsEnable);
            } else {
                LOG.info("No LSR Config Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return routerConfigDTO;
    }

    @Override
    public RouterConfigDTO getMplsConfig(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(AricentMPLSMIB.QNAME)
                .node(FsMplsConfigObjects.QNAME).build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        RouterConfigDTO routerConfigDTO = new RouterConfigDTO();
        JSONObject configObj = new JSONObject();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, YII).get();
            if (readFuture.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        configObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            configObj.putAll(keyValuePair);
                        });
                    }
                });
                
                String ldpLsrId = (String) configObj.get("fsMplsLdpLsrId");
                String mplsAdminStatus = (String) configObj.get("fsMplsAdminStatus");
                String qosPolicy = (String) configObj.get("fsMplsQosPolicy");
                Boolean forceOption = Boolean.parseBoolean(configObj.get("fsMplsLdpForceOption").toString());
                String labelAllocationMode = (String) configObj.get("fsMplsLsrLabelAllocationMethod");

                routerConfigDTO.setLdpLsrId(ldpLsrId);
                routerConfigDTO.setMplsAdminStatus(mplsAdminStatus);
                routerConfigDTO.setQosPolicy(qosPolicy);
                routerConfigDTO.setForceOption(forceOption);
                routerConfigDTO.setLabelAllocationMode(labelAllocationMode);

            } else {
                LOG.info("No MPLS Config Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return routerConfigDTO;
    }

    @Override
    public RouterConfigDTO getMplsTunnelConfig(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier TE_SCALARS_YII = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                        .node(MplsTeScalars.QNAME).build();

        YangInstanceIdentifier TE_OBJECTS_YII = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                        .node(MplsTeObjects.QNAME).build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture1;
        Optional<NormalizedNode<?,?>> readFuture2;
        
        RouterConfigDTO routerConfigDTO = new RouterConfigDTO();
        JSONObject configObj = new JSONObject();
        
        try {
            readFuture1 = tx.read(LogicalDatastoreType.CONFIGURATION, TE_SCALARS_YII).get();
            readFuture2 = tx.read(LogicalDatastoreType.CONFIGURATION, TE_OBJECTS_YII).get();
            if (readFuture1.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture1.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        configObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            configObj.putAll(keyValuePair);
                        });
                    }
                });
            } else {
                LOG.info("No MPLS Tunnel Config Found");
            }

            if (readFuture2.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture2.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        configObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            configObj.putAll(keyValuePair);
                        });
                    }
                });
            } else {
                LOG.info("No MPLS Tunnel Config Found");
            }

            Integer tunnelNotificationMaxRate = Integer.parseInt(configObj.get("mplsTunnelNotificationMaxRate").toString());
            Boolean tunnelNotificationEnable = Boolean.parseBoolean(configObj.get("mplsTunnelNotificationEnable").toString());
            Integer maxHops = Integer.parseInt(configObj.get("mplsTunnelMaxHops").toString());
            String teDistProto = (String) configObj.get("mplsTunnelTEDistProto");

            routerConfigDTO.setTunnelNotificationMaxRate(tunnelNotificationMaxRate);
            routerConfigDTO.setTunnelNotificationEnable(tunnelNotificationEnable);
            routerConfigDTO.setMaxHops(maxHops);
            routerConfigDTO.setTeDistProto(teDistProto);
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return routerConfigDTO;
    }

    @Override
    public RouterConfigDTO getL2VpnConfig(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(AricentMPLSMIB.QNAME)
                .node(FsMplsL2VpnObjects.QNAME).node(FsMplsL2VpnConfigObjects.QNAME).build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        RouterConfigDTO routerConfigDTO = new RouterConfigDTO();
        JSONObject configObj = new JSONObject();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, YII).get();
            if (readFuture.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        configObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            configObj.putAll(keyValuePair);
                        });
                    }
                });
                
                Integer l2VpnTrcFlag = Integer.parseInt(configObj.get("fsMplsL2VpnTrcFlag").toString());
                Integer l2VpnCleanupInterval = Integer.parseInt(configObj.get("fsMplsL2VpnCleanupInterval").toString());
                String l2VpnAdminStatus = (String) configObj.get("fsMplsL2VpnAdminStatus");
                String localCcTypesCapabilities = (String) configObj.get("fsMplsLocalCCTypesCapabilities");
                String localCvTypesCapabilities = (String) configObj.get("fsMplsLocalCVTypesCapabilities");

                routerConfigDTO.setL2VpnTrcFlag(l2VpnTrcFlag);
                routerConfigDTO.setL2VpnCleanupInterval(l2VpnCleanupInterval);
                routerConfigDTO.setL2VpnAdminStatus(l2VpnAdminStatus);
                routerConfigDTO.setLocalCcTypesCapabilities(localCcTypesCapabilities);
                routerConfigDTO.setLocalCvTypesCapabilities(localCvTypesCapabilities);

            } else {
                LOG.info("No MPLS L2 VPN Config Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return routerConfigDTO;
    }

    @Override
    public MplsL2VpnStats getL2VpnStats(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(AricentMPLSMIB.QNAME)
                .node(FsMplsL2VpnObjects.QNAME).node(FsMplsL2VpnStatsObjects.QNAME).build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        MplsL2VpnStats l2VpnStats = new MplsL2VpnStats();
        JSONObject statsObj = new JSONObject();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, YII).get();
            if (readFuture.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        statsObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            statsObj.putAll(keyValuePair);
                        });
                    }
                });

                l2VpnStats.setActivePwVcEntries(Integer.parseInt(statsObj.get("fsMplsL2VpnActivePwVcEntries").toString()));
                l2VpnStats.setActivePwVcMplsEntries(Integer.parseInt(statsObj.get("fsMplsL2VpnActivePwVcMplsEntries").toString()));
                l2VpnStats.setNoOfPwVcEntriesCreated(Integer.parseInt(statsObj.get("fsMplsL2VpnNoOfPwVcEntriesCreated").toString()));
                l2VpnStats.setNoOfPwVcEntriesDeleted(Integer.parseInt(statsObj.get("fsMplsL2VpnNoOfPwVcEntriesDeleted").toString()));

            } else {
                LOG.info("No L2 VPN Stats Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return l2VpnStats;
    }

    @Override
    public void configureLsr(String routerId, RouterConfigDTO routerConfigDTO) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).build();

        NormalizedNode<?, ?> normalizedNode = Builders.containerBuilder()
                .withNodeIdentifier(NodeIdentifier.create(MplsLsrObjects.QNAME))
                .addChild(ImmutableNodes.leafNode(QName.create(MplsLsrObjects.QNAME, "mplsXCNotificationsEnable"),
                        routerConfigDTO.getXcNotificationsEnable().toString()))
                .build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, YII, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Configured LSR");
                configureMpls(routerId, routerConfigDTO);
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Configure LSR", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void configureLdp(String routerId, RouterConfigDTO routerConfigDTO) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(AricentMPLSMIB.QNAME).build();

        DataContainerNodeBuilder<?, ?> nodeBuilder = Builders.containerBuilder()
                .withNodeIdentifier(NodeIdentifier.create(AricentMPLSMIB.QNAME));

        NormalizedNode<?, ?> normalizedNode = nodeBuilder
                .addChild(Builders.containerBuilder().withNodeIdentifier(NodeIdentifier.create(FsMplsConfigObjects.QNAME))
                .addChild(
                    ImmutableNodes.leafNode(QName.create(FsMplsConfigObjects.QNAME, "fsMplsLdpLsrId"), routerId))
                .addChild(ImmutableNodes.leafNode(
                                QName.create(FsMplsConfigObjects.QNAME, "fsMplsLdpForceOption"),
                                routerConfigDTO.getForceOption().toString()))
                        .build())
                .addChild(Builders.containerBuilder().withNodeIdentifier(NodeIdentifier.create(FsMplsLdpScalarObjects.QNAME))
                        .addChild(ImmutableNodes.leafNode(
                                QName.create(FsMplsLdpScalarObjects.QNAME, "fsMplsLdpConfigurationSequenceTLVEnable"),
                                routerConfigDTO.getConfigurationSequenceTlvEnable().toString()))
                        .build())
                .build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, YII, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Configured LDP");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Configure LDP", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void configureMpls(String routerId, RouterConfigDTO routerConfigDTO) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(AricentMPLSMIB.QNAME)
                .node(FsMplsConfigObjects.QNAME).build();

        DataContainerNodeBuilder<?, ?> nodeBuilder = Builders.containerBuilder()
                .withNodeIdentifier(NodeIdentifier.create(FsMplsConfigObjects.QNAME));

        if (routerConfigDTO.getMplsAdminStatus() != null) {
            nodeBuilder.addChild(ImmutableNodes.leafNode(QName.create(FsMplsConfigObjects.QNAME, "fsMplsAdminStatus"),
                    routerConfigDTO.getMplsAdminStatus()));
        }

        if (routerConfigDTO.getQosPolicy() != null) {
            nodeBuilder.addChild(ImmutableNodes.leafNode(QName.create(FsMplsConfigObjects.QNAME, "fsMplsQosPolicy"),
                    routerConfigDTO.getQosPolicy()));
        }

        if (routerConfigDTO.getLabelAllocationMode() != null) {
            nodeBuilder.addChild(
                    ImmutableNodes.leafNode(QName.create(FsMplsConfigObjects.QNAME, "fsMplsLsrLabelAllocationMethod"),
                            routerConfigDTO.getLabelAllocationMode()));
        }

        NormalizedNode<?, ?> normalizedNode = nodeBuilder.build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, YII, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Configured MPLS");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Configure MPLS", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void configureMplsTunnel(String routerId, RouterConfigDTO routerConfigDTO) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME).build();

        DataContainerNodeBuilder<?, ?> nodeBuilder = Builders.containerBuilder()
                .withNodeIdentifier(NodeIdentifier.create(MPLSTESTDMIB.QNAME));

        NormalizedNode<?, ?> normalizedNode = nodeBuilder
                .addChild(Builders.containerBuilder().withNodeIdentifier(NodeIdentifier.create(MplsTeScalars.QNAME))
                        .addChild(ImmutableNodes.leafNode(
                                QName.create(MplsTeScalars.QNAME, "mplsTunnelNotificationMaxRate"),
                                routerConfigDTO.getTunnelNotificationMaxRate()))
                        .build())
                .addChild(Builders.containerBuilder().withNodeIdentifier(NodeIdentifier.create(MplsTeObjects.QNAME))
                        .addChild(ImmutableNodes.leafNode(
                                QName.create(MplsTeScalars.QNAME, "mplsTunnelNotificationEnable"),
                                routerConfigDTO.getTunnelNotificationEnable().toString()))
                        .build())
                .build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, YII, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Configured MPLS Tunnel");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Configure MPLS Tunnel", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void configureL2Vpn(String routerId, RouterConfigDTO routerConfigDTO) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier YII = YangInstanceIdentifier.builder().node(AricentMPLSMIB.QNAME)
                .node(FsMplsL2VpnObjects.QNAME).node(FsMplsL2VpnConfigObjects.QNAME).build();

        DataContainerNodeBuilder<?, ?> nodeBuilder = Builders.containerBuilder()
                .withNodeIdentifier(NodeIdentifier.create(FsMplsL2VpnConfigObjects.QNAME));

        if (routerConfigDTO.getL2VpnTrcFlag() != null) {
            nodeBuilder.addChild(
                    ImmutableNodes.leafNode(QName.create(FsMplsL2VpnConfigObjects.QNAME, "fsMplsL2VpnTrcFlag"),
                            routerConfigDTO.getL2VpnTrcFlag()));
        }

        if (routerConfigDTO.getL2VpnCleanupInterval() != null) {
            nodeBuilder.addChild(
                    ImmutableNodes.leafNode(QName.create(FsMplsL2VpnConfigObjects.QNAME, "fsMplsL2VpnCleanupInterval"),
                            routerConfigDTO.getL2VpnCleanupInterval()));
        }

        if (routerConfigDTO.getL2VpnAdminStatus() != null) {
            nodeBuilder.addChild(
                    ImmutableNodes.leafNode(QName.create(FsMplsL2VpnConfigObjects.QNAME, "fsMplsL2VpnAdminStatus"),
                            routerConfigDTO.getL2VpnAdminStatus()));
        }

        if (routerConfigDTO.getLocalCcTypesCapabilities() != null) {
            nodeBuilder.addChild(ImmutableNodes.leafNode(
                    QName.create(FsMplsL2VpnConfigObjects.QNAME, "fsMplsLocalCCTypesCapabilities"),
                    routerConfigDTO.getLocalCcTypesCapabilities()));
        }

        if (routerConfigDTO.getLocalCvTypesCapabilities() != null) {
            nodeBuilder.addChild(ImmutableNodes.leafNode(
                    QName.create(FsMplsL2VpnConfigObjects.QNAME, "fsMplsLocalCVTypesCapabilities"),
                    routerConfigDTO.getLocalCvTypesCapabilities()));
        }

        NormalizedNode<?, ?> normalizedNode = nodeBuilder.build();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
        tx.put(LogicalDatastoreType.CONFIGURATION, YII, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Configured LDP");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Configure LDP", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public MplsTunnelStats getMplsTunnelsStatistics(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();
     
        YangInstanceIdentifier TE_SCALARS_YII = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                        .node(MplsTeScalars.QNAME).build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        MplsTunnelStats mplsTunnelStats = new MplsTunnelStats();
        JSONObject statsObj = new JSONObject();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, TE_SCALARS_YII).get();
            if (readFuture.isPresent()) {
                Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = 
                (Collection<DataContainerChild<? extends PathArgument, ?>>) readFuture.get().getValue();
            
                leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                    if(leafNode instanceof LeafNode) {
                        Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                        statsObj.putAll(keyValuePair);

                    } else if (leafNode instanceof AugmentationNode) {
                        Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                        augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                            Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                            statsObj.putAll(keyValuePair);
                        });
                    }
                });
            } else {
                LOG.info("No MPLS Tunnel Stats Found");
            }

            Integer configuredTunnels = Integer.parseInt(statsObj.get("mplsTunnelConfigured").toString());
            Integer activeTunnels = Integer.parseInt(statsObj.get("mplsTunnelActive").toString());

            mplsTunnelStats.setConfiguredTunnels(configuredTunnels);
            mplsTunnelStats.setActiveTunnels(activeTunnels);

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return mplsTunnelStats;
    }

    @Override
    public List<AttachmentCircuit> getAttachmentCircuit(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();
     
        YangInstanceIdentifier AC_YID = YangInstanceIdentifier.builder().node(ARICENTCFAMIB.QNAME)
                .node(If.QNAME).node(IfACTable.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<AttachmentCircuit> attachmentCircuits = new ArrayList<AttachmentCircuit>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, AC_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> acEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode acEntry : acEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = acEntry.getValue();
                    JSONObject acEntryObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            acEntryObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                acEntryObj.putAll(keyValuePair);
                            });
                        }
                    });

                    AttachmentCircuit attachmentCircuit = new AttachmentCircuit();
                    attachmentCircuit.setAcId(acEntryObj.get("ifMainIndex").toString() + "@" + routerId);
                    attachmentCircuit.setAcIndex(Integer.parseInt(acEntryObj.get("ifMainIndex").toString()));
                    attachmentCircuit.setAcName(acEntryObj.get("ifMainIndex").toString());
                    attachmentCircuit.setAcPort(acEntryObj.get("ifACPortIdentifier").toString());
                    
                    attachmentCircuits.add(attachmentCircuit);
                }
            } else {
                LOG.info("No Tunnels Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return attachmentCircuits;
    }

    @Override
    public void createAttachmentCircuit(String routerId, AttachmentCircuit attachmentCircuit) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(IfACEntry.QNAME, "ifMainIndex").intern(), attachmentCircuit.getAcIndex());
     
        YangInstanceIdentifier AC_YID = YangInstanceIdentifier.builder().node(ARICENTCFAMIB.QNAME)
                .node(If.QNAME).node(IfACTable.QNAME)
                .nodeWithKey(IfACEntry.QNAME, uriMap)
                .build();

        NormalizedNode normalizedNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(IfACEntry.QNAME))
                        .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                            NodeIdentifierWithPredicates.of(
                                IfACEntry.QNAME, QName.create(IfACEntry.QNAME, "ifMainIndex"),attachmentCircuit.getAcIndex()
                                ))
                            .withChild(ImmutableNodes.leafNode(QName.create(IfACEntry.QNAME, "ifMainIndex").intern(), attachmentCircuit.getAcIndex()))
                            .withChild(ImmutableNodes.leafNode(QName.create(IfACEntry.QNAME, "ifACPortIdentifier").intern(), Integer.parseInt(attachmentCircuit.getAcPort())))
                            //.withChild(ImmutableNodes.leafNode(QName.create(IfACEntry.QNAME, "ifACCustomerVlan").intern(), Integer.parseInt(attachmentCircuit.getAcCustomerVlan())))
                            .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, AC_YID, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Attachment Circuit");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Attachment Circuit", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteAttachmentCircuit(String routerId, Integer acIndex) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(IfACEntry.QNAME, "ifMainIndex").intern(), acIndex);
     
        YangInstanceIdentifier AC_YID = YangInstanceIdentifier.builder().node(ARICENTCFAMIB.QNAME)
                .node(If.QNAME).node(IfACTable.QNAME)
                .nodeWithKey(IfACEntry.QNAME, uriMap)
                .build();

        tx.delete(LogicalDatastoreType.CONFIGURATION, AC_YID);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Removed Attachment Circuit");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.info("Failed to Remove Attachment Circuit", failure);
            }
        }, MoreExecutors.directExecutor());

    }

    @Override
    public List<MplsTunnel> getListOfTunnels(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();
     
        YangInstanceIdentifier TUNNEL_YID = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                .node(MplsTeObjects.QNAME).node(MplsTunnelTable.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<MplsTunnel> tunnels = new ArrayList<MplsTunnel>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, TUNNEL_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> tunnelEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode tunnelEntry : tunnelEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = tunnelEntry.getValue();
                    JSONObject tunnelEntryObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            tunnelEntryObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                tunnelEntryObj.putAll(keyValuePair);
                            });
                        }
                    });

                    MplsTunnel tunnel = new MplsTunnel();
                    tunnel.setTunnelId(tunnelEntryObj.get("mplsTunnelIndex").toString() + "@" + routerId);
                    tunnel.setTunnelIndex(Integer.parseInt(tunnelEntryObj.get("mplsTunnelIndex").toString()));
                    tunnel.setTunnelName(tunnelEntryObj.get("mplsTunnelName").toString());
                    tunnel.setTunnelInstance(Integer.parseInt(tunnelEntryObj.get("mplsTunnelInstance").toString()));
                    tunnel.setIngressLsrId(tunnelEntryObj.get("mplsTunnelIngressLSRId").toString());
                    tunnel.setEgressLsrId(tunnelEntryObj.get("mplsTunnelEgressLSRId").toString());
                    tunnel.setAdminStatus(Boolean.parseBoolean(tunnelEntryObj.get("mplsTunnelAdminStatus").toString()));
                    tunnel.setTunnelRole(tunnelEntryObj.get("mplsTunnelRole").toString());
                    
                    tunnels.add(tunnel);
                }
            } else {
                LOG.info("No Tunnels Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return tunnels;
    }

    @Override
    public void createMplsTunnel(String routerId, MplsTunnel mplsTunnel) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIndex").intern(), mplsTunnel.getTunnelIndex());
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelInstance").intern(), mplsTunnel.getTunnelInstance());
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIngressLSRId").intern(), mplsTunnel.getIngressLsrId());
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelEgressLSRId").intern(), mplsTunnel.getEgressLsrId());
     
        YangInstanceIdentifier TUNNEL_YID = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                .node(MplsTeObjects.QNAME).node(MplsTunnelTable.QNAME)
                .nodeWithKey(MplsTunnelEntry.QNAME, uriMap)
                .build();

        NormalizedNode normalizedNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(MplsTunnelEntry.QNAME))
                        .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                            NodeIdentifierWithPredicates.of(MplsTunnelEntry.QNAME, 
                                Map.of(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIndex"),mplsTunnel.getTunnelIndex(),
                                QName.create(MplsTunnelEntry.QNAME, "mplsTunnelInstance"),mplsTunnel.getTunnelInstance(),
                                QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIngressLSRId"), mplsTunnel.getIngressLsrId(),
                                QName.create(MplsTunnelEntry.QNAME, "mplsTunnelEgressLSRId"),mplsTunnel.getEgressLsrId())))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIndex").intern(), mplsTunnel.getTunnelIndex()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelInstance").intern(), mplsTunnel.getTunnelInstance()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIngressLSRId").intern(), mplsTunnel.getIngressLsrId()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelEgressLSRId").intern(), mplsTunnel.getEgressLsrId()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIsIf").intern(), mplsTunnel.isIsInterface().toString()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelRole").intern(), mplsTunnel.getTunnelRole()))
                            //.withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelXCPointer").intern(), mplsTunnel.getCrossConnectId()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelSignallingProto").intern(), mplsTunnel.getSignalingProtocol()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelSetupPrio").intern(), mplsTunnel.getSetUpPriority()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelHoldingPrio").intern(), mplsTunnel.getHoldingPriority()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelInstancePriority").intern(), mplsTunnel.getInstancePriority()))
                            .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, TUNNEL_YID, normalizedNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Tunnel");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Tunnel", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteMplsTunnel(String routerId, MplsTunnel mplsTunnel) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIndex").intern(), mplsTunnel.getTunnelIndex());
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelInstance").intern(), mplsTunnel.getTunnelInstance());
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelIngressLSRId").intern(), mplsTunnel.getIngressLsrId());
        uriMap.put(QName.create(MplsTunnelEntry.QNAME, "mplsTunnelEgressLSRId").intern(), mplsTunnel.getEgressLsrId());
     
        YangInstanceIdentifier TUNNEL_YID = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                .node(MplsTeObjects.QNAME).node(MplsTunnelTable.QNAME)
                .nodeWithKey(MplsTunnelEntry.QNAME, uriMap)
                .build();

        tx.delete(LogicalDatastoreType.CONFIGURATION, TUNNEL_YID);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Removed MPLS Tunnel");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.info("Failed to Remove MPLS Tunnel", failure);
            }
        }, MoreExecutors.directExecutor());

    }

    public Map<String,String> getKeyValuePairs(DataContainerChild<? extends PathArgument, ?> node) {
        Map<String,String> keyValuePair = new HashMap<String,String>();
        
        String identifier = node.getIdentifier().toString();
        String key = identifier.substring(identifier.lastIndexOf(")")+1);
        
        String value = node.getValue().toString();

        keyValuePair.put(key,value);
        return keyValuePair;
    }

    @Override
    public List<TunnelStatEntry> getTunnelStatistics(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();
     
        YangInstanceIdentifier TUNNEL_YID = YangInstanceIdentifier.builder().node(MPLSTESTDMIB.QNAME)
                .node(MplsTeObjects.QNAME).node(MplsTunnelTable.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<TunnelStatEntry> tunnelStats = new ArrayList<TunnelStatEntry>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, TUNNEL_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> tunnelStatEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode tunnelStatEntry : tunnelStatEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = tunnelStatEntry.getValue();
                    JSONObject tunnelStatsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            tunnelStatsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                tunnelStatsObj.putAll(keyValuePair);
                            });
                        }
                    });

                    TunnelStatEntry tunnelStat = new TunnelStatEntry();
                    tunnelStat.setTotalUpTime(Integer.parseInt(tunnelStatsObj.get("mplsTunnelTotalUpTime").toString()));
                    tunnelStat.setInstanceUpTime(Integer.parseInt(tunnelStatsObj.get("mplsTunnelInstanceUpTime").toString()));
                    tunnelStat.setPrimaryUpTime(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPrimaryUpTime").toString()));
                    tunnelStat.setPathChanges(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPathChanges").toString()));
                    tunnelStat.setLastPathChange(Integer.parseInt(tunnelStatsObj.get("mplsTunnelLastPathChange").toString()));
                    tunnelStat.setCreationTime(tunnelStatsObj.get("mplsTunnelCreationTime").toString());
                    tunnelStat.setStateTransitions(Integer.parseInt(tunnelStatsObj.get("mplsTunnelStateTransitions").toString()));
                    tunnelStat.setForwardedPackets(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPerfPackets").toString()));
                    tunnelStat.setForwardedHcPackets(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPerfHCPackets").toString()));
                    tunnelStat.setDroppedPackets(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPerfErrors").toString()));
                    tunnelStat.setForwardedBytes(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPerfBytes").toString()));
                    tunnelStat.setForwaredHcBytes(Integer.parseInt(tunnelStatsObj.get("mplsTunnelPerfHCBytes").toString()));
                    
                    tunnelStats.add(tunnelStat);
                }
            } else {
                LOG.info("No Tunnel Statistics Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }

        return tunnelStats;
    }
    
    public void getListOfLdpPeers(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier LDP_PEERS_YID = YangInstanceIdentifier.builder().node(MPLSLDPSTDMIB.QNAME)
                .node(MplsLdpObjects.QNAME).node(MplsLdpSessionObjects.QNAME).node(MplsLdpPeerTable.QNAME)
                .node(MplsLdpPeerEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> ldpPeers = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, LDP_PEERS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> peerEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode peerEntry : peerEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = peerEntry.getValue();
                    JSONObject ldpPeersObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            ldpPeersObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                ldpPeersObj.putAll(keyValuePair);
                            });
                        }
                    });
                    ldpPeers.add(ldpPeersObj);
                }
            } else {
                LOG.info("No LDP Peers Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    public void getListOfLdpSessions(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier LDP_SESSIONS_YID = YangInstanceIdentifier.builder().node(MPLSLDPSTDMIB.QNAME)
                .node(MplsLdpObjects.QNAME).node(MplsLdpSessionObjects.QNAME).node(MplsLdpPeerTable.QNAME)
                .node(MplsLdpPeerEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> ldpSessions = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, LDP_SESSIONS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> sessionEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode sessionEntry : sessionEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = sessionEntry.getValue();
                    JSONObject sessionsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            sessionsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                sessionsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    ldpSessions.add(sessionsObj);
                }
            } else {
                LOG.info("No LDP Sessions Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<JSONObject> getLdpInSegments(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier IN_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsInSegmentTable.QNAME).node(MplsInSegmentEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> inSegments = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, IN_SEGMENTS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> insegmentEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode insegmentEntry : insegmentEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = insegmentEntry.getValue();
                    JSONObject inSegmentsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            inSegmentsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                inSegmentsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    inSegments.add(inSegmentsObj);
                }
            } else {
                LOG.info("No In Segments Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return inSegments;
    }

    @Override
    public void createInSegment(String routerId, InSegment inSegment) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
     
        String inSegmentIndex = inSegment.getInSegmentIndex();

        YangInstanceIdentifier IN_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsInSegmentTable.QNAME)
                .nodeWithKey(MplsInSegmentEntry.QNAME, QName.create(MplsInSegmentEntry.QNAME,"mplsInSegmentIndex").intern(),new DisplayString(inSegmentIndex))
                .build();

        NormalizedNode inSegmentEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(MplsInSegmentEntry.QNAME))
                        .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                            NodeIdentifierWithPredicates.of(MplsInSegmentEntry.QNAME, QName.create(MplsInSegmentEntry.QNAME, "mplsInSegmentIndex"), inSegmentIndex))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsInSegmentEntry.QNAME, "mplsInSegmentInterface"), Integer.parseInt(inSegment.getInSegmentInterface())))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsInSegmentEntry.QNAME, "mplsInSegmentLabel"), Integer.parseInt(inSegment.getInSegmentLabel())))
                            //.withChild(ImmutableNodes.leafNode(QName.create(MplsInSegmentEntry.QNAME, "mplsInSegmentNPop"), inSegment.getInSegmentNPops()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsInSegmentEntry.QNAME, "mplsInSegmentAddrFamily"), inSegment.getInSegmentAddrFamily()))
                            //.withChild(ImmutableNodes.leafNode(QName.create(MplsInSegmentEntry.QNAME, "mplsInSegmentRowStatus"), RowStatus.forName(inSegment.getInSegmentRowStatus()).get()))
                            .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, IN_SEGMENTS_YID, inSegmentEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created In Segment");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create In Segment", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteInSegments(String routerId, String inSegmentIndex) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        YangInstanceIdentifier IN_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsInSegmentTable.QNAME)
                .nodeWithKey(MplsInSegmentEntry.QNAME, QName.create(MplsInSegmentEntry.QNAME,"mplsInSegmentIndex").intern(),new DisplayString(inSegmentIndex))
                .build();

        tx.delete(LogicalDatastoreType.CONFIGURATION, IN_SEGMENTS_YID);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Removed In Segment");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.info("Failed to Remove In Segment", failure);
            }
        }, MoreExecutors.directExecutor());

    }

    @Override
    public List<JSONObject> getLdpOutSegments(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier OUT_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsOutSegmentTable.QNAME).node(MplsOutSegmentEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> outSegments = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, OUT_SEGMENTS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> vlanStatEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode vlanStatEntry : vlanStatEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = vlanStatEntry.getValue();
                    JSONObject outSegmentsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            outSegmentsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                outSegmentsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    outSegments.add(outSegmentsObj);
                }
            } else {
                LOG.info("No Out Segments Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return outSegments;
    }

    @Override
    public void createOutSegment(String routerId, OutSegment outSegment) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
     
        String outSegmentIndex = outSegment.getOutSegmentIndex();

        YangInstanceIdentifier OUT_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsOutSegmentTable.QNAME)
                .nodeWithKey(MplsOutSegmentEntry.QNAME, QName.create(MplsOutSegmentEntry.QNAME,"mplsOutSegmentIndex").intern(),new DisplayString(outSegmentIndex))
                .build();

        NormalizedNode outSegmentEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(MplsOutSegmentEntry.QNAME))
                        .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                            NodeIdentifierWithPredicates.of(MplsOutSegmentEntry.QNAME, QName.create(MplsOutSegmentEntry.QNAME, "mplsOutSegmentIndex"), outSegmentIndex))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsOutSegmentEntry.QNAME, "mplsOutSegmentInterface"), Integer.parseInt(outSegment.getOutSegmentInterface())))
                            //.withChild(ImmutableNodes.leafNode(QName.create(MplsOutSegmentEntry.QNAME, "mplsOutSegmentNextHopAddrType"), InetAddressType.forName(outSegment.getNextHopAddressFamily()).get()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsOutSegmentEntry.QNAME, "mplsOutSegmentNextHopAddr"), outSegment.getNextHopAddress()))
                            .withChild(ImmutableNodes.leafNode(QName.create(MplsOutSegmentEntry.QNAME, "mplsOutSegmentStorageType"), outSegment.getOutSegmentStorageType()))
                            //.withChild(ImmutableNodes.leafNode(QName.create(MplsOutSegmentEntry.QNAME, "mplsOutSegmentRowStatus"), RowStatus.forName(outSegment.getOutSegmentRowStatus()).get()))
                            .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, OUT_SEGMENTS_YID, outSegmentEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Out Segment");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Out Segment", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteOutSegments(String routerId, String outSegmentIndex) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();

        YangInstanceIdentifier OUT_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsOutSegmentTable.QNAME)
                .nodeWithKey(MplsOutSegmentEntry.QNAME, QName.create(MplsOutSegmentEntry.QNAME,"mplsOutSegmentIndex").intern(),new DisplayString(outSegmentIndex))
                .build();
        
        tx.delete(LogicalDatastoreType.CONFIGURATION, OUT_SEGMENTS_YID);
        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Removed Out Segment");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.info("Failed to Remove Out Segment", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public List<JSONObject> getCrossConnects(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier CROSS_CONNECTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsXCTable.QNAME).node(MplsXCEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> crossConnects = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, CROSS_CONNECTS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> crossConnectEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode crossConnectEntry : crossConnectEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = crossConnectEntry.getValue();
                    JSONObject crossConnectObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            crossConnectObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                crossConnectObj.putAll(keyValuePair);
                            });
                        }
                    });
                    crossConnects.add(crossConnectObj);
                }
            } else {
                LOG.info("No Cross Connects Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return crossConnects;
    }

    @Override
    public void createCrossConnect(String routerId, CrossConnect crossConnect) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
     
        String crossConnectIndex = crossConnect.getCrossConnectIndex();
        String inSegmentIndex = crossConnect.getInSegmentIndex();
        String outSegmentIndex = crossConnect.getOutSegmentIndex();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(MplsXCEntry.QNAME, "mplsXCIndex").intern(), crossConnectIndex);
        uriMap.put(QName.create(MplsXCEntry.QNAME, "mplsXCInSegmentIndex").intern(), inSegmentIndex);
        uriMap.put(QName.create(MplsXCEntry.QNAME, "mplsXCOutSegmentIndex").intern(), outSegmentIndex);

        YangInstanceIdentifier CROSS_CONNECT_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsXCTable.QNAME).nodeWithKey(MplsXCEntry.QNAME,uriMap)
                .build();

        NormalizedNode crossConnectEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(MplsInSegmentEntry.QNAME))
                .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                    NodeIdentifierWithPredicates.of(MplsXCEntry.QNAME, QName.create(MplsXCEntry.QNAME, "mplsXCIndex"), crossConnectIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsXCEntry.QNAME, "mplsXCInSegmentIndex"), inSegmentIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsXCEntry.QNAME, "mplsXCOutSegmentIndex"), outSegmentIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsXCEntry.QNAME, "mplsXCLspId"), crossConnect.getLspId()))
                    //.withChild(ImmutableNodes.leafNode(QName.create(MplsXCEntry.QNAME, "mplsXCRowStatus"), RowStatus.forName(crossConnect.getRowStatus()).get()))
                    .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, CROSS_CONNECT_YID, crossConnectEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Cross Connect");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Cross Connect", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteCrossConnect(String routerId, String crossConnectIndex) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<JSONObject> getLdpEntities(String routerId) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier LDP_ENTITIES_YID = YangInstanceIdentifier.builder().node(MPLSLDPSTDMIB.QNAME)
                .node(MplsLdpObjects.QNAME).node(MplsLdpEntityObjects.QNAME).node(MplsLdpEntityTable.QNAME).node(MplsLdpEntityEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> ldpEntities = new ArrayList<JSONObject>();
        
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, LDP_ENTITIES_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> entitiesEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode entitiesEntry : entitiesEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = entitiesEntry.getValue();
                    JSONObject entitiesObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            entitiesObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                entitiesObj.putAll(keyValuePair);
                            });
                        }
                    });
                    ldpEntities.add(entitiesObj);
                }
            } else {
                LOG.info("No Ldp Entities Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return ldpEntities;
    }

    @Override
    public void createLdpEntity(String routerId, LdpEntity entity) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        DOMDataTreeWriteTransaction tx = mountPointDatabroker.newWriteOnlyTransaction();
     
        //should be integer
        String entityIndex = entity.getEntityId();
        String entityLdpId = entity.getEntityLdpId();

        Map<QName, Object> uriMap = new HashMap<QName, Object>();
        uriMap.put(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityIndex").intern(), entityIndex);
        uriMap.put(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityLdpId").intern(), entityLdpId);
        
        YangInstanceIdentifier LDP_ENTITIES_YID = YangInstanceIdentifier.builder().node(MPLSLDPSTDMIB.QNAME)
                .node(MplsLdpObjects.QNAME).node(MplsLdpEntityObjects.QNAME).node(MplsLdpEntityTable.QNAME).nodeWithKey(MplsLdpEntityEntry.QNAME,uriMap)
                .build();

        NormalizedNode entityEntryNode = Builders.mapBuilder().withNodeIdentifier(NodeIdentifier.create(MplsLdpEntityEntry.QNAME))
                .withChild(Builders.mapEntryBuilder().withNodeIdentifier(
                    NodeIdentifierWithPredicates.of(MplsLdpEntityEntry.QNAME, QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityIndex"), entityIndex))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityProtocolVersion"), entity.getProtocolVersion()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityLdpId"), entityLdpId))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityAdminStatus"), entity.isAdminStatus()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityTcpPort"), entity.getTcpPort()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityMaxPduLength"), entity.getMaxPduLength()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityKeepAliveHoldTimer"), entity.getKeepAliveHoldTimer()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityInitSessionThreshold"), entity.getInitSessionThreshold()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityLabelDistMethod"), entity.getLabelDistMethod()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityLabelRetentionMode"), entity.getLabelRetentionMode()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityTargetPeerAddrType"), entity.getTargetPeerAddrType()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityTargetPeerAddr"), entity.getTargetPeerAddr()))
                    .withChild(ImmutableNodes.leafNode(QName.create(MplsLdpEntityEntry.QNAME, "mplsLdpEntityLabelType"), entity.getLabelType()))
                    .build()).build();

        tx.put(LogicalDatastoreType.CONFIGURATION, LDP_ENTITIES_YID, entityEntryNode);

        Futures.addCallback(tx.commit(), new FutureCallback<CommitInfo>() {
            @Override
            public void onSuccess(final CommitInfo result) {
                LOG.info("Successfully Created Ldp Entity");
            }

            @Override
            public void onFailure(final Throwable failure) {
                LOG.error("Failed to Create Ldp Entity", failure);
            }
        }, MoreExecutors.directExecutor());
    }

    @Override
    public void deleteLdpEntity(String routerId, String entityId) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public List<InSegmentStatEntry> getInSegmentStats(String routerId, String inSegmentIndex) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier IN_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsInSegmentTable.QNAME).node(MplsInSegmentEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> inSegments = new ArrayList<JSONObject>();
        List<InSegmentStatEntry> statEntries = new ArrayList<InSegmentStatEntry>();

        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, IN_SEGMENTS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> insegmentEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode insegmentEntry : insegmentEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = insegmentEntry.getValue();
                    JSONObject inSegmentsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            inSegmentsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                inSegmentsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    inSegments.add(inSegmentsObj);
                }

                for(JSONObject inSegment : inSegments) {
                    InSegmentStatEntry statEntry = new InSegmentStatEntry();

                    Integer octetsReceived = (Integer) inSegment.get("mplsInSegmentPerfOctets");
                    Integer packetsReceived = (Integer) inSegment.get("mplsInSegmentPerfPackets");
                    Integer errorPacketsReceived = (Integer) inSegment.get("mplsInSegmentPerfErrors");
                    Integer discardedPackets = (Integer)inSegment.get("mplsInSegmentPerfDiscards");
                    Integer discontinuityTime = (Integer)inSegment.get("mplsInSegmentPerfDiscontinuityTime");

                    statEntry.setStatsId(inSegmentIndex);
                    statEntry.setOctetsReceived(octetsReceived);
                    statEntry.setPacketsReceived(packetsReceived);
                    statEntry.setErrorPacketsReceived(errorPacketsReceived);
                    statEntry.setDiscardedPackets(discardedPackets);
                    statEntry.setDiscontinuityTime(discontinuityTime);

                    statEntries.add(statEntry);
                }
            } else {
                LOG.info("No In Segments Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return statEntries;
    }

    @Override
    public List<OutSegmentStatEntry> getOutSegmentStats(String routerId, String inSegmentIndex) {
        DOMMountPoint mount = mdsalService.getDomMountPoint(routerId);
        DOMDataBroker mountPointDatabroker = mount.getService(DOMDataBroker.class).get();

        YangInstanceIdentifier OUT_SEGMENTS_YID = YangInstanceIdentifier.builder().node(MPLSLSRSTDMIB.QNAME)
                .node(MplsLsrObjects.QNAME).node(MplsOutSegmentTable.QNAME).node(MplsOutSegmentEntry.QNAME)
                .build();
        
        DOMDataTreeReadTransaction tx = mountPointDatabroker.newReadOnlyTransaction();
        Optional<NormalizedNode<?,?>> readFuture;
        
        List<JSONObject> outSegments = new ArrayList<JSONObject>();
        List<OutSegmentStatEntry> statEntries = new ArrayList<OutSegmentStatEntry>();
        try {
            readFuture = tx.read(LogicalDatastoreType.CONFIGURATION, OUT_SEGMENTS_YID).get();
            if (readFuture.isPresent()) {
                Collection<MapEntryNode> vlanStatEntries = (Collection<MapEntryNode>) readFuture.get().getValue();

                for(MapEntryNode vlanStatEntry : vlanStatEntries) {
                    Collection<DataContainerChild<? extends PathArgument, ?>> leafNodes = vlanStatEntry.getValue();
                    JSONObject outSegmentsObj = new JSONObject();
                    
                    leafNodes.forEach((DataContainerChild<? extends PathArgument, ?>leafNode) -> {
                        if(leafNode instanceof LeafNode) {
                            Map<String,String> keyValuePair = getKeyValuePairs(leafNode);
                            outSegmentsObj.putAll(keyValuePair);

                        } else if (leafNode instanceof AugmentationNode) {
                            Collection<DataContainerChild<? extends PathArgument, ?>> augmentedNodes = 
                                    (Collection<DataContainerChild<? extends PathArgument, ?>>) leafNode.getValue();

                            augmentedNodes.forEach((DataContainerChild<? extends PathArgument, ?>augmentedNode) -> {
                                Map<String,String> keyValuePair = getKeyValuePairs(augmentedNode);
                                outSegmentsObj.putAll(keyValuePair);
                            });
                        }
                    });
                    outSegments.add(outSegmentsObj);
                }

                for(JSONObject outSegment : outSegments) {
                    OutSegmentStatEntry statEntry = new OutSegmentStatEntry();

                    Integer octetsSent = (Integer) outSegment.get("mplsOutSegmentPerfOctets");
                    Integer packetsSent = (Integer) outSegment.get("mplsOutSegmentPerfPackets");
                    Integer errorPacketsNotSent = (Integer) outSegment.get("mplsOutSegmentPerfErrors");
                    Integer discardedPacketsNotSent = (Integer)outSegment.get("mplsOutSegmentPerfDiscards");
                    Integer discontinuityTime = (Integer)outSegment.get("mplsOutSegmentPerfDiscontinuityTime");

                    statEntry.setStatsId(inSegmentIndex);
                    statEntry.setOctetsSent(octetsSent);
                    statEntry.setPacketsSent(packetsSent);
                    statEntry.setErrorPacketsNotSent(errorPacketsNotSent);
                    statEntry.setDiscardedPacketsNotSent(discardedPacketsNotSent);
                    statEntry.setDiscontinuityTime(discontinuityTime);

                    statEntries.add(statEntry);
                }
            } else {
                LOG.info("No Out Segments Found");
            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
        return statEntries;
    }
}
