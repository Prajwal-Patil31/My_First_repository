CREATE SCHEMA noadb AUTHORIZATION postgres;

CREATE TYPE noadb."_audit_info" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.audit_info,
	DELIMITER = ',');

-- DROP TYPE noadb."_fault_ack";

CREATE TYPE noadb."_fault_ack" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.fault_ack,
	DELIMITER = ',');

-- DROP TYPE noadb."_fault_config";

CREATE TYPE noadb."_fault_config" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.fault_config,
	DELIMITER = ',');

-- DROP TYPE noadb."_fault_esc";

CREATE TYPE noadb."_fault_esc" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.fault_esc,
	DELIMITER = ',');

-- DROP TYPE noadb."_faults";

CREATE TYPE noadb."_faults" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.faults,
	DELIMITER = ',');

-- DROP TYPE noadb."_feature_info";

CREATE TYPE noadb."_feature_info" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.feature_info,
	DELIMITER = ',');

-- DROP TYPE noadb."_heartbeat";

CREATE TYPE noadb."_heartbeat" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.heartbeat,
	DELIMITER = ',');

-- DROP TYPE noadb."_password_policy";

CREATE TYPE noadb."_password_policy" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.password_policy,
	DELIMITER = ',');

-- DROP TYPE noadb."_privilege";

CREATE TYPE noadb."_privilege" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.privilege,
	DELIMITER = ',');

-- DROP TYPE noadb."_resource";

CREATE TYPE noadb."_resource" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.resource,
	DELIMITER = ',');

-- DROP TYPE noadb."_resource_group";

CREATE TYPE noadb."_resource_group" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.resource_group,
	DELIMITER = ',');

-- DROP TYPE noadb."_resource_privilege";

CREATE TYPE noadb."_resource_privilege" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.resource_privilege,
	DELIMITER = ',');

-- DROP TYPE noadb."_resourcegroup_resource";

CREATE TYPE noadb."_resourcegroup_resource" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.resourcegroup_resource,
	DELIMITER = ',');

-- DROP TYPE noadb."_role";

CREATE TYPE noadb."_role" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb."role",
	DELIMITER = ',');

-- DROP TYPE noadb."_role_feature";

CREATE TYPE noadb."_role_feature" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.role_feature,
	DELIMITER = ',');

-- DROP TYPE noadb."_spring_session";

CREATE TYPE noadb."_spring_session" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.spring_session,
	DELIMITER = ',');

-- DROP TYPE noadb."_spring_session_attributes";

CREATE TYPE noadb."_spring_session_attributes" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.spring_session_attributes,
	DELIMITER = ',');

-- DROP TYPE noadb."_uri_feature";

CREATE TYPE noadb."_uri_feature" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.uri_feature,
	DELIMITER = ',');

-- DROP TYPE noadb."_user_account";

CREATE TYPE noadb."_user_account" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.user_account,
	DELIMITER = ',');

-- DROP TYPE noadb."_user_group";

CREATE TYPE noadb."_user_group" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.user_group,
	DELIMITER = ',');

-- DROP TYPE noadb."_user_role";

CREATE TYPE noadb."_user_role" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.user_role,
	DELIMITER = ',');

-- DROP TYPE noadb."_usergroup_user";

CREATE TYPE noadb."_usergroup_user" (
	INPUT = array_in,
	OUTPUT = array_out,
	RECEIVE = array_recv,
	SEND = array_send,
	ANALYZE = array_typanalyze,
	ALIGNMENT = 8,
	STORAGE = any,
	CATEGORY = A,
	ELEMENT = noadb.usergroup_user,
	DELIMITER = ',');

-- DROP SEQUENCE noadb.audit_info_audit_id_seq;

CREATE SEQUENCE noadb.audit_info_audit_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.audit_info_audit_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.audit_info_audit_id_seq TO noadba;

-- DROP SEQUENCE noadb.fault_ack_policy_id_seq;

CREATE SEQUENCE noadb.fault_ack_policy_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.fault_ack_policy_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.fault_ack_policy_id_seq TO noadba;

-- DROP SEQUENCE noadb.fault_config_fault_id_seq;

CREATE SEQUENCE noadb.fault_config_fault_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.fault_config_fault_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.fault_config_fault_id_seq TO noadba;

-- DROP SEQUENCE noadb.fault_esc_policy_id_seq;

CREATE SEQUENCE noadb.fault_esc_policy_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.fault_esc_policy_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.fault_esc_policy_id_seq TO noadba;

-- DROP SEQUENCE noadb.faults_fault_id_seq;

CREATE SEQUENCE noadb.faults_fault_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.faults_fault_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.faults_fault_id_seq TO noadba;

-- DROP SEQUENCE noadb.feature_info_feature_id_seq;

CREATE SEQUENCE noadb.feature_info_feature_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.feature_info_feature_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.feature_info_feature_id_seq TO noadba;

-- DROP SEQUENCE noadb.heartbeat_hb_id_seq;

CREATE SEQUENCE noadb.heartbeat_hb_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.heartbeat_hb_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.heartbeat_hb_id_seq TO noadba;

-- DROP SEQUENCE noadb.password_policy_policy_id_seq;

CREATE SEQUENCE noadb.password_policy_policy_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.password_policy_policy_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.password_policy_policy_id_seq TO noadba;

-- DROP SEQUENCE noadb.privilege_privilege_id_seq;

CREATE SEQUENCE noadb.privilege_privilege_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.privilege_privilege_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.privilege_privilege_id_seq TO noadba;

-- DROP SEQUENCE noadb.resource_group_resource_group_id_seq;

CREATE SEQUENCE noadb.resource_group_resource_group_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.resource_group_resource_group_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.resource_group_resource_group_id_seq TO noadba;

-- DROP SEQUENCE noadb.resource_resource_id_seq;

CREATE SEQUENCE noadb.resource_resource_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.resource_resource_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.resource_resource_id_seq TO noadba;

-- DROP SEQUENCE noadb.role_role_id_seq;

CREATE SEQUENCE noadb.role_role_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.role_role_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.role_role_id_seq TO noadba;

-- DROP SEQUENCE noadb.uri_feature_uri_id_seq;

CREATE SEQUENCE noadb.uri_feature_uri_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.uri_feature_uri_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.uri_feature_uri_id_seq TO noadba;

-- DROP SEQUENCE noadb.user_account_account_id_seq;

CREATE SEQUENCE noadb.user_account_account_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.user_account_account_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.user_account_account_id_seq TO noadba;

-- DROP SEQUENCE noadb.user_group_group_id_seq;

CREATE SEQUENCE noadb.user_group_group_id_seq
	INCREMENT BY 1
	MINVALUE 1
	MAXVALUE 2147483647
	START 1
	CACHE 1
	NO CYCLE;

-- Permissions

ALTER SEQUENCE noadb.user_group_group_id_seq OWNER TO noadba;
GRANT ALL ON SEQUENCE noadb.user_group_group_id_seq TO noadba;
-- noadb.audit_info definition

-- Drop table

-- DROP TABLE noadb.audit_info;

CREATE TABLE noadb.audit_info (
	audit_id serial NOT NULL,
	user_name varchar(200) NOT NULL,
	"time" timestamp NOT NULL,
	operation varchar(200) NOT NULL,
	status varchar(200) NOT NULL,
	host varchar(45) NOT NULL,
	activity varchar(200) NULL DEFAULT NULL::character varying,
	api_name varchar(45) NULL DEFAULT NULL::character varying,
	change_description varchar(500) NULL DEFAULT NULL::character varying,
	CONSTRAINT audit_info_pkey PRIMARY KEY (audit_id)
);

-- Permissions

ALTER TABLE noadb.audit_info OWNER TO noadba;
GRANT ALL ON TABLE noadb.audit_info TO noadba;


-- noadb.fault_ack definition

-- Drop table

-- DROP TABLE noadb.fault_ack;

CREATE TABLE noadb.fault_ack (
	policy_id serial NOT NULL,
	policy_name varchar(200) NULL DEFAULT NULL::character varying,
	no_of_hrs_older int4 NOT NULL,
	no_of_days_older int4 NOT NULL DEFAULT 0,
	severity varchar(50) NOT NULL,
	retain_min_faults int4 NOT NULL DEFAULT 0,
	CONSTRAINT alarm_ack_pkey PRIMARY KEY (policy_id)
);

-- Permissions

ALTER TABLE noadb.fault_ack OWNER TO noadba;
GRANT ALL ON TABLE noadb.fault_ack TO noadba;


-- noadb.fault_config definition

-- Drop table

-- DROP TABLE noadb.fault_config;

CREATE TABLE noadb.fault_config (
	fault_id serial NOT NULL,
	error_code int4 NOT NULL DEFAULT 0,
	severity int4 NOT NULL DEFAULT 0,
	related_error_code int4 NOT NULL DEFAULT 0,
	trap_category int4 NOT NULL DEFAULT 0,
	CONSTRAINT alarm_config_error_code_key UNIQUE (error_code),
	CONSTRAINT alarm_config_pkey PRIMARY KEY (fault_id)
);

-- Permissions

ALTER TABLE noadb.fault_config OWNER TO noadba;
GRANT ALL ON TABLE noadb.fault_config TO noadba;


-- noadb.fault_esc definition

-- Drop table

-- DROP TABLE noadb.fault_esc;

CREATE TABLE noadb.fault_esc (
	policy_id serial NOT NULL,
	policy_name varchar(200) NULL DEFAULT NULL::character varying,
	no_of_hrs_older int4 NOT NULL,
	no_of_days_older int4 NOT NULL,
	from_severity varchar(50) NOT NULL,
	to_severity varchar(50) NOT NULL,
	CONSTRAINT alarm_esc_pkey PRIMARY KEY (policy_id)
);

-- Permissions

ALTER TABLE noadb.fault_esc OWNER TO noadba;
GRANT ALL ON TABLE noadb.fault_esc TO noadba;


-- noadb.faults definition

-- Drop table

-- DROP TABLE noadb.faults;

CREATE TABLE noadb.faults (
	fault_id serial NOT NULL,
	fault_date timestamp NULL,
	count int4 NULL,
	error_code int4 NOT NULL,
	related_fault_id int4 NULL,
	severity int4 NOT NULL,
	status_code int4 NOT NULL,
	fault_content varchar(500) NOT NULL,
	fault_system_id int4 NOT NULL,
	clr_username varchar(200) NULL DEFAULT NULL::character varying,
	clr_date timestamp NULL,
	ack_username varchar(200) NULL DEFAULT NULL::character varying,
	ack_date timestamp NULL,
	fault_hostname varchar(200) NULL DEFAULT NULL::character varying,
	site_id int4 NULL DEFAULT '-1'::integer,
	CONSTRAINT alarms_pkey PRIMARY KEY (fault_id)
);

-- Permissions

ALTER TABLE noadb.faults OWNER TO noadba;
GRANT ALL ON TABLE noadb.faults TO noadba;


-- noadb.feature_info definition

-- Drop table

-- DROP TABLE noadb.feature_info;

CREATE TABLE noadb.feature_info (
	feature_id serial NOT NULL,
	feature_name varchar(50) NULL DEFAULT NULL::character varying,
	subsystem_id varchar(50) NULL DEFAULT NULL::character varying,
	service_id float8 NOT NULL,
	CONSTRAINT feature_info_pkey PRIMARY KEY (feature_id)
);

-- Permissions

ALTER TABLE noadb.feature_info OWNER TO noadba;
GRANT ALL ON TABLE noadb.feature_info TO noadba;


-- noadb.heartbeat definition

-- Drop table

-- DROP TABLE noadb.heartbeat;

CREATE TABLE noadb.heartbeat (
	hb_id serial NOT NULL,
	comp_id int4 NOT NULL,
	comp_type varchar(10) NOT NULL,
	"timestamp" timestamp NOT NULL,
	status float8 NOT NULL,
	CONSTRAINT heartbeat_pkey PRIMARY KEY (hb_id)
);

-- Permissions

ALTER TABLE noadb.heartbeat OWNER TO noadba;
GRANT ALL ON TABLE noadb.heartbeat TO noadba;


-- noadb.password_policy definition

-- Drop table

-- DROP TABLE noadb.password_policy;

CREATE TABLE noadb.password_policy (
	policy_id serial NOT NULL,
	policy_name varchar(50) NOT NULL,
	max_fail_attempt int4 NOT NULL,
	passwd_exp_days int4 NOT NULL,
	min_len int4 NOT NULL DEFAULT 1,
	min_digits int4 NOT NULL DEFAULT 0,
	min_spl_char int4 NOT NULL DEFAULT 0,
	min_uppr_char int4 NOT NULL DEFAULT 0,
	min_low_char int4 NOT NULL DEFAULT 0,
	num_multiple_login int4 NOT NULL DEFAULT 3,
	num_old_passwd int4 NOT NULL DEFAULT 3,
	min_reuse_days int4 NOT NULL DEFAULT 30,
	CONSTRAINT password_policy_pkey PRIMARY KEY (policy_id)
);

-- Permissions

ALTER TABLE noadb.password_policy OWNER TO noadba;
GRANT ALL ON TABLE noadb.password_policy TO noadba;


-- noadb.privilege definition

-- Drop table

-- DROP TABLE noadb.privilege;

CREATE TABLE noadb.privilege (
	privilege_id serial NOT NULL,
	privilege_code varchar(50) NULL,
	privilege_name varchar(50) NULL
);

-- Permissions

ALTER TABLE noadb.privilege OWNER TO noadba;
GRANT ALL ON TABLE noadb.privilege TO noadba;


-- noadb.resource definition

-- Drop table

-- DROP TABLE noadb.resource;

CREATE TABLE noadb.resource (
	resource_id serial NOT NULL,
	resource_name varchar(50) NULL DEFAULT NULL::character varying,
	resource_type varchar(50) NULL,
	resource_code varchar(50) NULL,
	resource_uri varchar NULL,
	CONSTRAINT resource_pkey PRIMARY KEY (resource_id)
);

-- Permissions

ALTER TABLE noadb.resource OWNER TO noadba;
GRANT ALL ON TABLE noadb.resource TO noadba;


-- noadb.resource_group definition

-- Drop table

-- DROP TABLE noadb.resource_group;

CREATE TABLE noadb.resource_group (
	resource_group_id serial NOT NULL,
	resource_group_name varchar(50) NULL DEFAULT NULL::character varying,
	resource_group_code varchar(50) NULL,
	resource_group_type varchar(50) NULL,
	CONSTRAINT resource_group_pkey PRIMARY KEY (resource_group_id)
);

-- Permissions

ALTER TABLE noadb.resource_group OWNER TO noadba;
GRANT ALL ON TABLE noadb.resource_group TO noadba;


-- noadb.resource_privilege definition

-- Drop table

-- DROP TABLE noadb.resource_privilege;

CREATE TABLE noadb.resource_privilege (
	resource_id int4 NULL,
	privilege_id int4 NULL
);

-- Permissions

ALTER TABLE noadb.resource_privilege OWNER TO noadba;
GRANT ALL ON TABLE noadb.resource_privilege TO noadba;


-- noadb.resourcegroup_resource definition

-- Drop table

-- DROP TABLE noadb.resourcegroup_resource;

CREATE TABLE noadb.resourcegroup_resource (
	resource_id int4 NOT NULL,
	resource_group_id int4 NOT NULL
);

-- Permissions

ALTER TABLE noadb.resourcegroup_resource OWNER TO noadba;
GRANT ALL ON TABLE noadb.resourcegroup_resource TO noadba;


-- noadb."role" definition

-- Drop table

-- DROP TABLE noadb."role";

CREATE TABLE noadb."role" (
	service_id int4 NOT NULL,
	role_name varchar(50) NOT NULL DEFAULT NULL::character varying,
	role_id serial NOT NULL,
	last_update_id varchar(64) NULL DEFAULT NULL::character varying,
	last_update_timestamp timestamp NULL,
	role_code varchar NULL,
	CONSTRAINT role_info_pkey PRIMARY KEY (role_id)
);

-- Permissions

ALTER TABLE noadb."role" OWNER TO noadba;
GRANT ALL ON TABLE noadb."role" TO noadba;


-- noadb.role_feature definition

-- Drop table

-- DROP TABLE noadb.role_feature;

CREATE TABLE noadb.role_feature (
	feature_id int4 NOT NULL,
	role_id int4 NOT NULL
);

-- Permissions

ALTER TABLE noadb.role_feature OWNER TO noadba;
GRANT ALL ON TABLE noadb.role_feature TO noadba;


-- noadb.spring_session definition

-- Drop table

-- DROP TABLE noadb.spring_session;

CREATE TABLE noadb.spring_session (
	primary_id bpchar(36) NOT NULL,
	session_id bpchar(36) NOT NULL,
	creation_time int8 NOT NULL,
	last_access_time int8 NOT NULL,
	max_inactive_interval int4 NOT NULL,
	expiry_time int8 NOT NULL,
	principal_name varchar(100) NULL,
	CONSTRAINT spring_session_pk PRIMARY KEY (primary_id)
);
CREATE UNIQUE INDEX spring_session_ix1 ON noadb.spring_session USING btree (session_id);
CREATE INDEX spring_session_ix2 ON noadb.spring_session USING btree (expiry_time);
CREATE INDEX spring_session_ix3 ON noadb.spring_session USING btree (principal_name);

-- Permissions

ALTER TABLE noadb.spring_session OWNER TO noadba;
GRANT ALL ON TABLE noadb.spring_session TO noadba;


-- noadb.user_account definition

-- Drop table

-- DROP TABLE noadb.user_account;

CREATE TABLE noadb.user_account (
	account_id serial NOT NULL,
	user_name varchar(64) NOT NULL,
	"password" varchar(64) NOT NULL,
	tui_password varchar(32) NULL DEFAULT NULL::character varying,
	first_name varchar(50) NULL DEFAULT NULL::character varying,
	middle_initial varchar(10) NULL DEFAULT NULL::character varying,
	last_name varchar(50) NULL DEFAULT NULL::character varying,
	activation_date timestamp NULL,
	expiration_date timestamp NULL,
	preferred_lang_code varchar(10) NULL DEFAULT NULL::character varying,
	time_zone varchar(50) NULL DEFAULT NULL::character varying,
	status bool NULL DEFAULT true,
	auth_type float8 NULL,
	failed_attempts int4 NULL,
	last_login_timestamp timestamp NULL,
	num_current_sessions int4 NULL,
	policy_id int4 NULL,
	last_update_id varchar(64) NULL DEFAULT NULL::character varying,
	last_update_timestamp timestamp NULL,
	options_flag float8 NULL,
	locked_timestamp float8 NULL,
	mobile_number varchar NULL,
	email varchar NULL,
	"Role" varchar NULL,
	logged_time varchar NULL,
	pwd_question varchar NULL,
	pwd_answer varchar NULL,
	CONSTRAINT user_account_pkey PRIMARY KEY (account_id),
	CONSTRAINT user_account_user_id_key UNIQUE (user_name)
);

-- Permissions

ALTER TABLE noadb.user_account OWNER TO noadba;
GRANT ALL ON TABLE noadb.user_account TO noadba;


-- noadb.user_group definition

-- Drop table

-- DROP TABLE noadb.user_group;

CREATE TABLE noadb.user_group (
	group_id serial NOT NULL,
	group_name varchar(50) NULL DEFAULT NULL::character varying,
	group_code varchar NULL,
	"role" varchar NULL,
	resource varchar NULL,
	CONSTRAINT user_group_pkey PRIMARY KEY (group_id)
);

-- Permissions

ALTER TABLE noadb.user_group OWNER TO noadba;
GRANT ALL ON TABLE noadb.user_group TO noadba;


-- noadb.user_role definition

-- Drop table

-- DROP TABLE noadb.user_role;

CREATE TABLE noadb.user_role (
	account_id int4 NOT NULL,
	role_id int4 NOT NULL,
	subsystem_id varchar(50) NULL DEFAULT NULL::character varying,
	component_id numeric(10) NULL DEFAULT NULL::numeric,
	activation_date timestamp NULL,
	expiration_date timestamp NULL,
	last_update_id varchar(64) NULL DEFAULT NULL::character varying,
	last_update_timestamp timestamp NULL,
	lu_seq numeric(30) NULL DEFAULT NULL::numeric
);

-- Permissions

ALTER TABLE noadb.user_role OWNER TO noadba;
GRANT ALL ON TABLE noadb.user_role TO noadba;


-- noadb.usergroup_user definition

-- Drop table

-- DROP TABLE noadb.usergroup_user;

CREATE TABLE noadb.usergroup_user (
	account_id float8 NOT NULL,
	group_id float8 NOT NULL
);

-- Permissions

ALTER TABLE noadb.usergroup_user OWNER TO noadba;
GRANT ALL ON TABLE noadb.usergroup_user TO noadba;


-- noadb.spring_session_attributes definition

-- Drop table

-- DROP TABLE noadb.spring_session_attributes;

CREATE TABLE noadb.spring_session_attributes (
	session_primary_id bpchar(36) NOT NULL,
	attribute_name varchar(200) NOT NULL,
	attribute_bytes bytea NOT NULL,
	CONSTRAINT spring_session_attributes_pk PRIMARY KEY (session_primary_id, attribute_name),
	CONSTRAINT spring_session_attributes_fk FOREIGN KEY (session_primary_id) REFERENCES noadb.spring_session(primary_id) ON DELETE CASCADE
);

-- Permissions

ALTER TABLE noadb.spring_session_attributes OWNER TO noadba;
GRANT ALL ON TABLE noadb.spring_session_attributes TO noadba;


-- noadb.uri_feature definition

-- Drop table

-- DROP TABLE noadb.uri_feature;

CREATE TABLE noadb.uri_feature (
	uri_id serial NOT NULL,
	uri_path varchar(45) NULL DEFAULT NULL::character varying,
	feature_id int4 NULL,
	CONSTRAINT uri_feature_pkey PRIMARY KEY (uri_id),
	CONSTRAINT feature_id FOREIGN KEY (feature_id) REFERENCES noadb.feature_info(feature_id)
);

-- Permissions

ALTER TABLE noadb.uri_feature OWNER TO noadba;
GRANT ALL ON TABLE noadb.uri_feature TO noadba;




-- Permissions

GRANT ALL ON SCHEMA noa TO postgres;
GRANT ALL ON SCHEMA noa TO noadba;
