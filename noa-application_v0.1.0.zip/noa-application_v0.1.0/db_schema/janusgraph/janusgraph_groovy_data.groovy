:remote connect tinkerpop.server conf/remote.yaml session

:remote console

graph = JanusGraphFactory.open("conf/janusgraph-cql-es.properties")

mgmt=graph.openManagement()

g.V().drop()
g.E().drop()

g.addV('user-account').property('account-id','1').property('user-name','admin').property('password','pass').property('first-name','noa').property('last-name','admin')
g.addV('user-account').property('account-id','2').property('user-name','user').property('password','pass').property('first-name','noa').property('last-name','user')
g.addV('user-account').property('account-id','3').property('user-name','noaadmin').property('password','pass').property('first-name','noa').property('last-name','admin')

g.addV('security-role').property('role-id','1').property('role-name','Administrator').property('service-id','1234').property('role-code','1001')
g.addV('security-role').property('role-id','2').property('role-name', 'Default Role').property('service-id','1111').property('role-code','1002')

g.addV('security-privilege').property('privilege-id',"1").property('privilege-name','AlarmManagement')
g.addV('security-privilege').property('privilege-id',"2").property('privilege-name','ElementManagement')
g.addV('security-privilege').property('privilege-id',"3").property('privilege-name','TopologyManagement')
g.addV('security-privilege').property('privilege-id',"4").property('privilege-name','ConfigManagement')
g.addV('security-privilege').property('privilege-id',"5").property('privilege-name','PerformanceManagement')
g.addV('security-privilege').property('privilege-id',"6").property('privilege-name','SecurityManagement')
g.addV('security-privilege').property('privilege-id',"7").property('privilege-name','LogManagement')
g.addV('security-privilege').property('privilege-id',"8").property('privilege-name','DiagnosticsManagement')
g.addV('security-privilege').property('privilege-id',"9").property('privilege-name','InventoryManagement')
g.addV('security-privilege').property('privilege-id',"10").property('privilege-name','MeasurementCountersAndThresholdManagement')


g.addV('security-privilege').property('privilege-id',"11").property('privilege-name','AlarmManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"12").property('privilege-name','ElementManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"13").property('privilege-name','TopologyManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"14").property('privilege-name','ConfigManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"15").property('privilege-name','PerformanceManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"16").property('privilege-name','SecurityManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"17").property('privilege-name','LogManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"18").property('privilege-name','DiagnosticsManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"19").property('privilege-name','InventoryManagementViewOnly')
g.addV('security-privilege').property('privilege-id',"20").property('privilege-name','MeasurementCountersAndThresholdManagementViewOnly')


g.addV('resource').property('resource-id','1').property('resource-name','switch1').property('resource-type','physical').property('resource-code','1234').property('resource-uri','/switch1')
g.addV('resource').property('resource-id','2').property('resource-name','switch2').property('resource-type','virtual').property('resource-code','1234').property('resource-uri','/switch2')

g.addV('resource-group').property('resource-group-id','1').property('resource-group-name','resourceGroup1').property('resource-group-code','1001').property('resource-group-type', 'physical')
g.addV('resource-group').property('resource-group-id','2').property('resource-group-name','resourceGroup2').property('resource-group-code','1002').property('resource-group-type', 'virtual')

g.addV('user-group').property('user-group-id','1').property('user-group-name','adminGroup').property('user-group-code','1001')
g.addV('user-group').property('user-group-id','2').property('user-group-name','userGroup').property('user-group-code','1002')

g.V().hasLabel('user-account')\
    .has('account-id',within('1','3'))\
    .as('a')\
    .V().hasLabel('user-group')\
    .has('user-group-id','1')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('user-account')\
    .has('account-id','2')\
    .as('a')\
    .V().hasLabel('user-group')\
    .has('user-group-id','2')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('user-account')\
    .has('account-id',within('1','3'))\
    .as('a')\
    .V().hasLabel('security-role')\
    .has('role-id','1')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('user-account')\
    .has('account-id','2')\
    .as('a')\
    .V().hasLabel('security-role')\
    .has('role-id','2')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('security-privilege')\
    .has('privilege-id',within('1','2','3','4','5','6','7','8','9','10'))\
    .as('a')\
    .V().hasLabel('security-role')\
    .has('role-id','1')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('security-privilege')\
    .has('privilege-id',within('11','12','13','14','15','16','17','18','19','20'))\
    .as('a')\
    .V().hasLabel('security-role')\
    .has('role-id','2')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('security-privilege')\
    .has('privilege-id',within('1','2','3','4','5','6','7','8','9','10'))\
    .as('a')\
    .V().hasLabel('resource')\
    .has('resource-id','1')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('security-privilege')\
    .has('privilege-id',within('11','12','13','14','15','16','17','18','19','20'))\
    .as('a')\
    .V().hasLabel('resource')\
    .has('resource-id','2')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('resource')\
    .has('resource-id','1')\
    .as('a')\
    .V().hasLabel('resource-group')\
    .has('resource-group-id','1')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.V().hasLabel('resource')\
    .has('resource-id','2')\
    .as('a')\
    .V().hasLabel('resource-group')\
    .has('resource-group-id','2')\
    .as('b')\
    .addE('BelongsTo')\
    .from('a')\
    .to('b')

g.tx().commit()