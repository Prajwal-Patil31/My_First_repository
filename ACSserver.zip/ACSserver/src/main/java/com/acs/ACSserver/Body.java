package com.acs.ACSserver;

import javax.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Body {
    @XmlElement(name = "Inform", namespace = "urn:dslforum-org:cwmp-1-0")
    private Inform inform;

    public Inform getInform() {
        return inform;
    }

    public void setInform(Inform inform) {
        this.inform = inform;
    }

    // Getters and setters
    
}
