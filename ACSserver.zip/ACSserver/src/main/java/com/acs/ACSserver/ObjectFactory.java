package com.acs.ACSserver;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
   //private static final QName _InformResponse_QNAME = new QName("http://www.example.org/ACS", "InformResponse");
    private static final QName _Empty_QNAME = new QName("http://www.example.org/ACS", "Empty");

    // public JAXBElement<InformResponse> createInformResponse(InformResponse value) {
    //     return new JAXBElement<>(_InformResponse_QNAME, InformResponse.class, null, value);
    // }
    
    // public Empty createEmpty() {
    //     return new Empty();
    // }

    @XmlElementDecl(namespace = "http://www.example.org/ACS", name = "Empty")
    public JAXBElement<Empty> createEmptyResponse(Empty value) {
        return new JAXBElement<>(_Empty_QNAME, Empty.class, null, value);
    }
}