package com.acs.ACSserver;
import javax.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Inform {
    @XmlElement(name = "DeviceId")
    private DeviceId deviceId;

    @XmlElement(name = "Event")
    private Event event;

    @XmlElement(name = "MaxEnvelopes")
    private int maxEnvelopes;

    @XmlElement(name = "CurrentTime")
    private String currentTime;

    @XmlElement(name = "RetryCount")
    private int retryCount;

    @XmlElement(name = "ParameterList")
    private ParameterList parameterList;

    public DeviceId getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(DeviceId deviceId) {
        this.deviceId = deviceId;
    }

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public int getMaxEnvelopes() {
        return maxEnvelopes;
    }

    public void setMaxEnvelopes(int maxEnvelopes) {
        this.maxEnvelopes = maxEnvelopes;
    }

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(int retryCount) {
        this.retryCount = retryCount;
    }

    public ParameterList getParameterList() {
        return parameterList;
    }

    public void setParameterList(ParameterList parameterList) {
        this.parameterList = parameterList;
    }

    // Getters and setters
    
}
