package com.acs.ACSserver;

import javax.xml.bind.*;
import java.io.StringReader;

public class JAXBParser {
    public static Inform parseInformResponse(String xmlString) throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(Envelope.class);
        Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
        Envelope envelope = (Envelope) unmarshaller.unmarshal(new StringReader(xmlString));
        return envelope.getBody().getInform();
    }
}
