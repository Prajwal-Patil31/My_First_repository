package com.acs.ACSserver;
import javax.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class EventStruct {
    @XmlElement(name = "EventCode")
    private String eventCode;

    @XmlElement(name = "CommandKey")
    private String commandKey;

    public String getEventCode() {
        return eventCode;
    }

    public void setEventCode(String eventCode) {
        this.eventCode = eventCode;
    }

    public String getCommandKey() {
        return commandKey;
    }

    public void setCommandKey(String commandKey) {
        this.commandKey = commandKey;
    }
    // Getters and setters
    
}
