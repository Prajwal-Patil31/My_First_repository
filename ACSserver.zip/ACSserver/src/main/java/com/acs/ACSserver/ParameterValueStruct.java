package com.acs.ACSserver;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class ParameterValueStruct {
    @XmlElement(name = "Name")
    private String name;

    @XmlElement(name = "Value")
    private Value value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Value getValue() {
        return value;
    }

    public void setValue(Value value) {
        this.value = value;
    }

    // Getters and setters
    
    @Override
    public String toString() {
        return "ParameterValueStruct [Name=" + name + ", Value=" + value + "]";
    }
}
