package com.acs.ACSserver;
import javax.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class DeviceId {
    private String Manufacturer;
    private String OUI;
    private String ProductClass;
    private String SerialNumber;
    public String getManufacturer() {
        return Manufacturer;
    }
    public void setManufacturer(String manufacturer) {
        Manufacturer = manufacturer;
    }
    public String getOUI() {
        return OUI;
    }
    public void setOUI(String oUI) {
        OUI = oUI;
    }
    public String getProductClass() {
        return ProductClass;
    }
    public void setProductClass(String productClass) {
        ProductClass = productClass;
    }
    public String getSerialNumber() {
        return SerialNumber;
    }
    public void setSerialNumber(String serialNumber) {
        SerialNumber = serialNumber;
    }
    public DeviceId(String manufacturer, String oUI, String productClass, String serialNumber) {
        Manufacturer = manufacturer;
        OUI = oUI;
        ProductClass = productClass;
        SerialNumber = serialNumber;
    }
    @Override
    public String toString() {
        return "DeviceId [Manufacturer=" + Manufacturer + ", OUI=" + OUI + ", ProductClass=" + ProductClass
                + ", SerialNumber=" + SerialNumber + "]";
    }

    
}
