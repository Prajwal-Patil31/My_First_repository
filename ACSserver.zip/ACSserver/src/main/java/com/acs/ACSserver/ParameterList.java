package com.acs.ACSserver;
import java.util.List;


import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class ParameterList {
    @XmlElement(name = "ParameterValueStruct")
    private List<ParameterValueStruct> parameterValueStructs;

    public List<ParameterValueStruct> getParameterValueStructs() {
        return parameterValueStructs;
    }

    public void setParameterValueStructs(List<ParameterValueStruct> parameterValueStructs) {
        this.parameterValueStructs = parameterValueStructs;
    }

    // Getters and setters
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (ParameterValueStruct parameterValueStruct : parameterValueStructs) {
            sb.append(parameterValueStruct.toString()).append("\n");
        }
        return sb.toString();
    }
}