package com.acs.ACSserver;

//import org.springframework.beans.factory.annotation.Autowired;

// import org.springframework.boot.SpringApplication;
// import org.springframework.boot.autoconfigure.SpringBootApplication;
// import org.springframework.boot.context.properties.ConfigurationProperties;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestMapping;
// import org.springframework.web.bind.annotation.RestController;

// @SpringBootApplication
// public class ACSserverApplication {

//     public static void main(String[] args) {
//         SpringApplication.run(ACSserverApplication.class, args);
//     }
// }

// @RestController
// @RequestMapping("/acs")
// @ConfigurationProperties(prefix = "acs.server")
// class AcsController {

//     private String ipAddress;
//     private int port;
//     private String url;
// 	private String username;
// 	private String password;

//     // getters and setters for ipAddress, port, and url
// 	public String getIpAddress() {
// 		return ipAddress;
// 	}

// 	public void setIpAddress(String ipAddress) {
// 		this.ipAddress = ipAddress;
// 	}

// 	public int getPort() {
// 		return port;
// 	}

// 	public void setPort(int port) {
// 		this.port = port;
// 	}

// 	public String getUrl() {
// 		return url;
// 	}

// 	public void setUrl(String url) {
// 		this.url = url;
// 	}
	

//     public String getUsername() {
// 		return username;
// 	}

// 	public void setUsername(String username) {
// 		this.username = username;
// 	}

// 	public String getPassword() {
// 		return password;
// 	}

// 	public void setPassword(String password) {
// 		this.password = password;
// 	}

// 	@PostMapping
//     public String handleInform(@RequestBody String informRequest) {
//         // Handle Inform request
//         System.out.println("Received Inform Request:\n" + informRequest);

//         // TODO: Implement logic to process the Inform request

//         // Respond with an empty InformResponse for simplicity
//         return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
//                "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
//                "SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
//                "  <SOAP-ENV:Body>" +
//                "    <cwmp:InformResponse xmlns:cwmp=\"urn:dslforum-org:cwmp-1-0\">" +
//                "      <MaxEnvelopes>1</MaxEnvelopes>" +
//                "    </cwmp:InformResponse>" +
//                "  </SOAP-ENV:Body>" +
//                "</SOAP-ENV:Envelope>";
//     }

	
// }


// import org.springframework.beans.factory.annotation.Value;
//  import org.springframework.boot.SpringApplication;
// import org.springframework.boot.autoconfigure.SpringBootApplication;
// import org.springframework.context.annotation.Bean;
// import org.springframework.http.HttpMethod;
// import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
// import org.springframework.security.config.annotation.web.builders.HttpSecurity;
// import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
// import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.web.bind.annotation.PostMapping;
// import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RestController;
// import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;
// import org.springframework.http.HttpMethod;
// import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
// import org.springframework.security.config.annotation.web.builders.HttpSecurity;
// import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
// import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
// import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
// import org.springframework.security.crypto.password.PasswordEncoder;
// import org.springframework.web.bind.annotation.RestController;

// import javax.xml.ws.http.HTTPException;

// @SpringBootApplication
// public class ACSserverApplication {

//     public static void main(String[] args) {
//         SpringApplication.run(ACSserverApplication.class, args);
//     }

//     @Bean
//     public PasswordEncoder passwordEncoder() {
//         return new BCryptPasswordEncoder();
//     }
// }

// @EnableWebSecurity
// class SecurityConfig extends WebSecurityConfiguration {

//     @Value("${acs.username}")
//     private String username;

//     @Value("${acs.password}")
//     private String password;

// 	@Override
//     protected void configure(HttpSecurity http) throws Exception {
//         http
//             .authorizeRequests()
//                 .antMatchers(HttpMethod.POST, "/acs").authenticated()
//                 .and()
//             .httpBasic()
//                 .and()
//             .csrf().disable(); // Disable CSRF for simplicity, you may want to enable it in a production environment
//     }

//     @Autowired
//     public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//         auth.inMemoryAuthentication()
//             .withUser(username)
//             .password(passwordEncoder().encode(password))
//             .roles("USER");
//     }
// }

// @RestController
// class AcsController {

//     @Value("${acs.ip}")
//     private String acsIp;

//     @Value("${acs.port}")
//     private int acsPort;

//     @Value("${acs.inform.interval}")
//     private int informInterval;

//     @Value("${acs.provisioning.session}")
//     private String provisioningSession;

//     @PostMapping("/acs")
//     public String inform(@RequestBody String informRequest) {
//         try {
//             // Process the INFORM message
//             String response = processInformMessage(informRequest);

//             // Return the response to the CPE device
//             return response;
//         } catch (Exception e) {
//             throw new HTTPException(500);
//         }
//     }

//     private String processInformMessage(String informRequest) throws Exception {
//         // Process the INFORM message (parse, validate, and perform necessary actions)
//         // For simplicity, let's assume you just want to echo back the received message
//         String response = informRequest;

//         // Schedule periodic INFORM messages
//         schedulePeriodicInform();

//         return response;
//     }

//     private void schedulePeriodicInform() {
//         // Implement logic to schedule periodic INFORM messages
//         // You can use a scheduler or a separate thread for this
//         // For simplicity, we'll just print a message here
//         System.out.println("Scheduling periodic INFORM at interval: " + informInterval + " seconds");
//     }
// }


// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.boot.SpringApplication;
// import org.springframework.boot.autoconfigure.SpringBootApplication;
// import org.springframework.context.annotation.Bean;
// import org.springframework.oxm.jaxb.Jaxb2Marshaller;
// import org.springframework.ws.server.endpoint.annotation.Endpoint;
// import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
// import org.springframework.ws.server.endpoint.annotation.RequestPayload;
// import org.springframework.ws.server.endpoint.annotation.ResponsePayload;
// import javax.xml.namespace.QName;
// import javax.xml.bind.JAXBElement;
// import javax.xml.bind.annotation.XmlElement;
// import javax.xml.bind.annotation.XmlRootElement;
// import javax.xml.bind.annotation.XmlType;

// @SpringBootApplication
// public class ACSserverApplication {

//     public static void main(String[] args) {
//         SpringApplication.run(ACSserverApplication.class, args);
//     }

//     @Bean
//     public Jaxb2Marshaller marshaller() {
//     Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
//     marshaller.setContextPath("com.acs.ACSserver");
//     return marshaller;
//     }
// }

// @Endpoint
// class ACSController {

//     @Value("${acs.username}")
//     private String acsUsername;

//     @Value("${acs.password}")
//     private String acsPassword;

//     @PayloadRoot(namespace = "http://www.example.org/ACS", localPart = "InformRequest")
//     @ResponsePayload
//     public JAXBElement<InformResponse> handleInformRequest(@RequestPayload JAXBElement<InformRequest> request) {
//         // Log the content of the INFORM message
//        System.out.println("Received INFORM message: " + request.toString());
//         // Process the INFORM message
//         InformRequest informRequest = request.getValue();
//         // Perform necessary actions based on informRequest

//         // Construct the response (for simplicity, echo back the received message)
//         InformResponse informResponse = new InformResponse();
//         informResponse.setResult("Inform Acknowledged");

//         return new ObjectFactory().createInformResponse(informResponse);
//     }
// }

// // Define the XML request and response objects using JAXB
// @XmlRootElement(name = "InformRequest", namespace = "http://www.example.org/ACS")
// @XmlType(name = "InformRequest", propOrder = {"deviceId", "softwareVersion"})
// class InformRequest {
//     private String deviceId;
//     private String softwareVersion;

//     @XmlElement(name = "DeviceId")
//     public String getDeviceId() {
//         return deviceId;
//     }

//     public void setDeviceId(String deviceId) {
//         this.deviceId = deviceId;
//     }

//     @XmlElement(name = "SoftwareVersion")
//     public String getSoftwareVersion() {
//         return softwareVersion;
//     }

//     public void setSoftwareVersion(String softwareVersion) {
//         this.softwareVersion = softwareVersion;
//     }
// }

// @XmlRootElement(name = "InformResponse", namespace = "http://www.example.org/ACS")
// @XmlType(name = "InformResponse", propOrder = {"result"})
// class InformResponse {
//     private String result;

//     @XmlElement(name = "Result")
//     public String getResult() {
//         return result;
//     }

//     public void setResult(String result) {
//         this.result = result;
//     }
// }

// // ObjectFactory to create JAXBElement instances
// class ObjectFactory {
//     public JAXBElement<InformResponse> createInformResponse(InformResponse value) {
//         QName name = new QName("http://www.example.org/ACS", "InformResponse");
//         JAXBElement<InformResponse> jaxbElement = new JAXBElement<>(name, InformResponse.class, value);
//         return jaxbElement;
//     }
// }


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

@SpringBootApplication
public class ACSserverApplication {

    public static void main(String[] args) {
        SpringApplication.run(ACSserverApplication.class, args);
    }

    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        marshaller.setContextPath("com.acs.ACSserver");
        return marshaller;
    }
}