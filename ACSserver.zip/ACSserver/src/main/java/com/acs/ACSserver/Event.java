package com.acs.ACSserver;
import java.util.List;

import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Event {
    @XmlElement(name = "EventStruct")
    private List<EventStruct> eventStructs;

    public List<EventStruct> getEventStructs() {
        return eventStructs;
    }

    public void setEventStructs(List<EventStruct> eventStructs) {
        this.eventStructs = eventStructs;
    }
    
    // Getters and setters
    
}
