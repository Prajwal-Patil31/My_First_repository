package com.acs.ACSserver;




/*import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.beans.factory.BeanFactory;
import jakarta.annotation.Resource;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class ACSController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
     @Resource
    private BeanFactory beanFactory;
    private String informRequestXml; // Variable to store the XML response

    @PostMapping(value = "/inform", consumes = "text/xml; charset=UTF-8", produces = MediaType.TEXT_XML_VALUE)
public String handleInformRequest(@RequestBody String informRequestXml) {
    // Log that the ACS server has started
    logger.info("ACS server started: ");
    
    // Print the incoming XML request
    System.out.println("Inform message: " + informRequestXml);
    
    // Store the entire XML response in the variable
   // this.informRequestXml = informRequestXml;

    // Parse the incoming XML to extract the Inform message
    String deviceId = extractDeviceId(informRequestXml);
    System.out.println("device id"+ deviceId);
    String softwareVersion = extractSoftwareVersion(informRequestXml);
    String capabilities = extractCapabilities(informRequestXml);

    // Construct the response with device ID, software version, and other capabilities
    return buildInformResponse(deviceId, softwareVersion, capabilities);
}
    @ResponseBody
    private String extractDeviceId(String informRequestXml) {
        // Find the <DeviceId> tag and extract the content between the tags
        int startIdx = informRequestXml.indexOf("<DeviceId>");
        int endIdx = informRequestXml.indexOf("</DeviceId>");
        if (startIdx != -1 && endIdx != -1) {
            return informRequestXml.substring(startIdx + "<DeviceId>".length(), endIdx);
        }
        return null;
    }

    private String extractSoftwareVersion(String informRequestXml) {
        // Find the <SoftwareVersion> tag and extract the content between the tags
        int startIdx = informRequestXml.indexOf("<SoftwareVersion>");
        int endIdx = informRequestXml.indexOf("</SoftwareVersion>");
        if (startIdx != -1 && endIdx != -1) {
            return informRequestXml.substring(startIdx + "<SoftwareVersion>".length(), endIdx);
        }
        return null;
    }

    private String extractCapabilities(String informRequestXml) {
        // Extract other capabilities from the Inform message based on your XML structure
        // Implement the logic to extract capabilities from the XML
        return "Sample capabilities"; // Placeholder for demonstration
    }

    private String buildInformResponse(String deviceId, String softwareVersion, String capabilities) {
        // Construct the Inform response XML with device ID, software version, and other capabilities
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" " +
                "SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                "  <SOAP-ENV:Body>" +
                "    <cwmp:InformResponse xmlns:cwmp=\"urn:dslforum-org:cwmp-1-0\">" +
                "      <DeviceId>" + deviceId + "</DeviceId>" +
                "      <SoftwareVersion>" + softwareVersion + "</SoftwareVersion>" +
                "      <Capabilities>" + capabilities + "</Capabilities>" +
                "      <MaxEnvelopes>1</MaxEnvelopes>" +
                "    </cwmp:InformResponse>" +
                "  </SOAP-ENV:Body>" +
                "</SOAP-ENV:Envelope>";
    }
    /*@GetMapping("/showResponse")
    public String showResponse(Model model) {
        //System.out.println("response"+ informRequestXml);
        model.addAttribute("response", informRequestXml); 
        return "response-template"; 
    }*/
    /*@GetMapping("/showResponse")
    public String showResponse(Model model) {
        try {
            Inform inform = JAXBParser.parseInformResponse(informRequestXml);
            model.addAttribute("response", inform);
            System.out.println("response"+inform);

        } catch (JAXBException e) {
            // Handle exception
        }
        return "response-template";
    }
}*/

import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.beans.factory.BeanFactory;
import jakarta.annotation.Resource;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.InputSource; // Import for InputSource
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
public class ACSController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Resource
    private BeanFactory beanFactory;
    private String informRequestXml; // Variable to store the XML response

    @PostMapping(value = "/inform", consumes = "text/xml; charset=UTF-8", produces = "text/xml; charset=UTF-8")
    public String handleInformRequest(@RequestBody String informRequestXml, Model model) {
        // Log that the ACS server has started
        logger.info("ACS server started: ");

        // Print the incoming XML request
        System.out.println("Inform message: " + informRequestXml);

        // Parse the incoming XML to extract the Inform message
        DeviceId deviceId = extractDeviceId(informRequestXml);
        System.out.println("Device ID: " + deviceId);
  
        List<String> event = extractEvent(informRequestXml);
        System.out.println("Events: " + event);

        // Extract MaxEnvelopes, CurrentTime, and RetryCount
        int maxEnvelopes = extractMaxEnvelopes(informRequestXml);
        String currentTime = extractCurrentTime(informRequestXml);
        int retryCount = extractRetryCount(informRequestXml);
        System.out.println("MaxEnvelopes: " + maxEnvelopes);
        System.out.println("CurrentTime: " + currentTime);
        System.out.println("RetryCount: " + retryCount);
        // Extract ParameterList
        ParameterList parameterList = extractParameterList(informRequestXml);
        System.out.println("ParameterList: " + parameterList);
        
        return "inform";
    }

    private DeviceId extractDeviceId(String informRequestXml) {
        DeviceId deviceId = null;
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(informRequestXml)));

            NodeList deviceIdList = document.getElementsByTagName("DeviceId");
            Element deviceIdElement = (Element) deviceIdList.item(0);
            
            // Extract values from XML and initialize DeviceId object
            String manufacturer = getTagValue(deviceIdElement, "Manufacturer");
            String oui = getTagValue(deviceIdElement, "OUI");
            String productClass = getTagValue(deviceIdElement, "ProductClass");
            String serialNumber = getTagValue(deviceIdElement, "SerialNumber");

            ParameterList parameterList = extractParameterList(informRequestXml);
            System.out.println("ParameterList: " + parameterList);
            
            deviceId = new DeviceId(manufacturer, oui, productClass, serialNumber);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return deviceId;
    }

    private List<String> extractEvent(String informRequestXml) {
        List<String> eventCodes = new ArrayList<>();
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(informRequestXml)));
    
            NodeList eventList = document.getElementsByTagName("EventStruct");
            for (int i = 0; i < eventList.getLength(); i++) {
                Element eventElement = (Element) eventList.item(i);
                
                // Extract the EventCode value from each EventStruct element
                String eventCode = getTagValue(eventElement, "EventCode");
                eventCodes.add(eventCode);
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return eventCodes;
    }

    private int extractMaxEnvelopes(String informRequestXml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(informRequestXml)));

            NodeList maxEnvelopesList = document.getElementsByTagName("MaxEnvelopes");
            if (maxEnvelopesList.getLength() > 0) {
                return Integer.parseInt(maxEnvelopesList.item(0).getTextContent());
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private String extractCurrentTime(String informRequestXml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(informRequestXml)));

            NodeList currentTimeList = document.getElementsByTagName("CurrentTime");
            if (currentTimeList.getLength() > 0) {
                return currentTimeList.item(0).getTextContent();
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    private int extractRetryCount(String informRequestXml) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(informRequestXml)));

            NodeList retryCountList = document.getElementsByTagName("RetryCount");
            if (retryCountList.getLength() > 0) {
                return Integer.parseInt(retryCountList.item(0).getTextContent());
            }
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return 0;
    }
    
    private ParameterList extractParameterList(String informRequestXml) {
        ParameterList parameterList = new ParameterList();
        List<ParameterValueStruct> parameterValueStructs = new ArrayList<>();
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(new InputSource(new StringReader(informRequestXml)));
    
            NodeList parameterListElements = document.getElementsByTagName("ParameterList");
            if (parameterListElements.getLength() > 0) {
                Element parameterListElement = (Element) parameterListElements.item(0);
                NodeList parameterValueStructElements = parameterListElement.getElementsByTagName("ParameterValueStruct");
                for (int i = 0; i < parameterValueStructElements.getLength(); i++) {
                    Element parameterValueStructElement = (Element) parameterValueStructElements.item(i);
                    String name = getTagValue(parameterValueStructElement, "Name");
    
                    // Get the Value element
                    Element valueElement = (Element) parameterValueStructElement.getElementsByTagName("Value").item(0);
                    
                    // Get the type attribute of the Value element
                    String type = valueElement.getAttribute("xsi:type");
                    
                    // Get the text content of the Value element
                    String value = valueElement.getTextContent();
    
                    Value valueObj = new Value();
                    valueObj.setType(type);
                    valueObj.setValue(value);
    
                    ParameterValueStruct parameterValueStruct = new ParameterValueStruct();
                    parameterValueStruct.setName(name);
                    parameterValueStruct.setValue(valueObj);
                    parameterValueStructs.add(parameterValueStruct);
                }
            }
            parameterList.setParameterValueStructs(parameterValueStructs);
        } catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        }
        return parameterList;
    }

    private String getTagValue(Element element, String tagName) {
        NodeList nodeList = element.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent();
        }
        return null;
    }

  

    // Mapping to display the ACS server page
@GetMapping("/acs-server")
public String acsServer(Model model) throws Exception {
  
    // Populate model attributes with data retrieved from the XML parsing
    model.addAttribute("deviceId", "DeviceId [Manufacturer=MikroTik, OUI=E48D8C, ProductClass=RB450, SerialNumber=723F06336490]");
    model.addAttribute("events", "[0 BOOTSTRAP, 1 BOOT, 4 VALUE CHANGE]");
    model.addAttribute("maxEnvelopes", 1);
    model.addAttribute("currentTime", "2024-02-15T11:56:22+05:30");
    model.addAttribute("retryCount", 1);
    // Example parameter list
    List<String> parameterList = List.of(
            "ParameterValueStruct [Name=Device.RootDataModelVersion, Value=Value [type=xsd:string, value=2.11]]",
            "ParameterValueStruct [Name=Device.DeviceInfo.SoftwareVersion, Value=Value [type=xsd:string, value=6.49.12]]",
            "ParameterValueStruct [Name=Device.DeviceInfo.ProvisioningCode, Value=Value [type=xsd:string, value=]]",
            "ParameterValueStruct [Name=Device.DeviceInfo.HardwareVersion, Value=Value [type=xsd:string, value=v1.0]]",
            "ParameterValueStruct [Name=Device.ManagementServer.ParameterKey, Value=Value [type=xsd:string, value=]]",
            "ParameterValueStruct [Name=Device.ManagementServer.ConnectionRequestURL, Value=Value [type=xsd:string, value=http://192.168.21.129:7547/63a9ee4a2b874191e05b67975f6928eb135e]]",
            "ParameterValueStruct [Name=Device.ManagementServer.AliasBasedAddressing, Value=Value [type=xsd:boolean, value=0]]"
    );
    model.addAttribute("parameterList", parameterList);

    // Return the HTML template name
        return "acs-server-view"; 
   
    
}

}