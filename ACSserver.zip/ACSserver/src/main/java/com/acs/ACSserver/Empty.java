package com.acs.ACSserver;



import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Empty")
public class Empty {
    // You can leave this class empty since it represents an empty element
}
