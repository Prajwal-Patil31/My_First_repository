package com.acs.ACSserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcSserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
